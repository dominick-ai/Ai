TABO AI RENDER FIX

Upload BOTH files in this folder to the ROOT of the existing GitHub repository,
replacing the existing package.json when prompted:
- package.json
- prepare-public.js

Then commit the changes. Render should automatically redeploy from the connected
main branch. The startup helper detects the common GitHub mobile upload mistake
(where public/ contents were uploaded into the repository root) and moves only
frontend files into public/ before starting the server. It leaves backend files
and tests in place.

If the repo already has public/index.html, the helper does nothing.
