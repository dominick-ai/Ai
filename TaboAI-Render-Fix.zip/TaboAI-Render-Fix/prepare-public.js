import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(root, 'public');
const indexInPublic = path.join(publicDir, 'index.html');
const indexAtRoot = path.join(root, 'index.html');

// Normal deployments already have public/index.html; leave them untouched.
try {
  await fs.access(indexInPublic);
  console.log('Frontend structure OK: public/index.html exists.');
} catch {
  // GitHub mobile uploads can accidentally place the contents of public/ at
  // the repository root. Repair that layout at container startup, without
  // exposing backend source files through Express static hosting.
  try {
    await fs.access(indexAtRoot);
  } catch {
    console.error('Frontend missing: neither public/index.html nor root index.html exists.');
    process.exit(1);
  }

  await fs.mkdir(publicDir, { recursive: true });
  const backendFiles = new Set([
    'Dockerfile', 'docker-compose.yml', 'package.json', 'package-lock.json',
    'server.js', 'prepare-public.js', '_worker.js', 'railway.json',
    'render.yaml', '.dockerignore', '.gitignore', '.env', '.env.example',
    'README-KEYLESS-RAILWAY.md', 'README-RENDER-MIGRATION.md',
    'THIRD_PARTY_NOTICES.txt', 'tests', 'test', 'node_modules',
    'tabo-local.db'
  ]);
  const entries = await fs.readdir(root, { withFileTypes: true });
  let moved = 0;
  for (const entry of entries) {
    if (backendFiles.has(entry.name) || entry.name === 'public' || entry.name.startsWith('.')) continue;
    const from = path.join(root, entry.name);
    const to = path.join(publicDir, entry.name);
    try {
      await fs.access(to);
      // Preserve an existing destination rather than overwriting it.
      continue;
    } catch {}
    await fs.rename(from, to);
    moved++;
  }
  console.log(`Repaired flattened frontend layout: moved ${moved} items into public/.`);
}
