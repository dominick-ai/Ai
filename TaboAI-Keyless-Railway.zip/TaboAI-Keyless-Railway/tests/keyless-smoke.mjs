import assert from 'node:assert/strict';
const calls = []; let activeMock = null;
globalThis.fetch = (...args) => activeMock(...args);
const { default: worker } = await import('../_worker.js');
const mock = mode => async (url, init = {}) => {
  const target = String(url), body = init.body ? JSON.parse(init.body) : {};
  const first = body.messages?.[0]?.content || '';
  calls.push({ target, auth: init.headers?.authorization || '', model: body.model });
  if (mode !== 'primary' && target.includes('ai-gateway.kilo.ai')) return new Response('{"error":"busy"}', { status: 429 });
  if (target.endsWith('/models') && target.includes('oai.aihorde.net')) return new Response(JSON.stringify({ data: [{ id: 'mock/text-model', architecture: { input_modalities: ['text'], output_modalities: ['text'] }, x_horde: { workers: 4, queued: 0 } }] }), { status: 200, headers: { 'content-type': 'application/json' } });
  if (target.includes('api.llmfaucet.dev') && mode === 'horde') return new Response('{"error":"unavailable"}', { status: 503 });
  if (String(first).startsWith('Safety check')) return new Response(JSON.stringify({ choices: [{ message: { content: '{"violation":0,"category":"none"}' } }] }), { status: 200, headers: { 'content-type': 'application/json' } });
  const answer = mode === 'primary' ? 'Kilo primary passed.' : mode === 'faucet' ? 'LLMFaucet fallback passed.' : 'AI Horde fallback passed.';
  return new Response(JSON.stringify({ choices: [{ message: { content: answer } }] }), { status: 200, headers: { 'content-type': 'application/json' } });
};
async function chat(text, ip) {
  const req = new Request('https://tabo.test/api/chat', { method: 'POST', headers: { 'content-type': 'application/json', 'cf-connecting-ip': ip }, body: JSON.stringify({ messages: [{ role: 'user', content: text }] }) });
  return worker.fetch(req, { ASSETS: { fetch: async () => new Response('Not found', { status: 404 }) } }, { waitUntil() {} });
}
activeMock = mock('primary');
let res = await chat('Primary provider smoke test.', '192.0.2.21'); let data = await res.json();
assert.equal(res.status, 200); assert.equal(data.reply, 'Kilo primary passed.'); assert.equal(data.ai, 'sigma');
assert.ok(calls.some(x => x.target.includes('ai-gateway.kilo.ai') && !x.auth && x.model === 'z-ai/glm-5:free'));

calls.length = 0; activeMock = mock('faucet');
res = await chat('LLMFaucet fallback smoke test.', '192.0.2.22'); data = await res.json();
assert.equal(res.status, 200); assert.equal(data.reply, 'LLMFaucet fallback passed.'); assert.equal(data.ai, 'faucet');
assert.ok(calls.some(x => x.target.includes('api.llmfaucet.dev/v1/chat/completions') && x.auth === 'Bearer free'));

calls.length = 0; activeMock = mock('horde');
res = await chat('AI Horde fallback smoke test.', '192.0.2.23'); data = await res.json();
assert.equal(res.status, 200); assert.equal(data.reply, 'AI Horde fallback passed.'); assert.equal(data.ai, 'qwen');
assert.ok(calls.some(x => x.target.includes('oai.aihorde.net/v1/chat/completions') && x.auth === 'Bearer 0000000000'));
console.log('Keyless smoke tests passed: Kilo primary, LLMFaucet backup, AI Horde fallback.');
