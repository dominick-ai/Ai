/* hcf.js (v2.1: markdown-lite, type-out replies, quick replies, tap a reply for Copy/Read/Retry, growing box + counter, napping messages; v1.9.3: fires 'hc:reply' for voice.js, hcApp.send; v1.2: + Code mode hooks (hccode.js); v1.1.1: memory has no visible limits, long entries, pin, budgeted send): Tabo AI, "the AI with choices". Same server AI as the Domotime site (44 models, kid-safe rules,
   Safety Shield on every ask + reply, next-smartest fallback with a "who answered" tag). The model picker is aipick.js.
   v1.1 (the user, Oct 29): saved chats (drawer), personality (text + presets), memory (add/edit/delete/clear, learns from
   "remember ..."). Everything lives ONLY in this browser's localStorage; the server stores nothing. Personality text and each
   memory fact pass the Safety Shield (/api/hc/check) before they are saved; the server checks them again on every chat and
   always puts its fixed kid-safe prompt first. ES5 only. */
(function(){
  'use strict';
  var W=window,D=document;
  if(!W.domoHaptic)W.domoHaptic=function(){};
  function $(id){return D.getElementById(id);}
  var log=$('log'),form=$('composer'),input=$('msg'),chips=$('chips'),sendBtn=form.querySelector('.send');
  var CK='hc_chats_v1',PK='hc_persona_v1',MK='hc_mem_v1',OLD='hcf_chat_v1';
  var MAXCHATS=50,MAXMSG=40,PMAX=300,FMAX=30000,MSEND=32000,MBUD=30000,MBUD_TINY=2500; /* v1.1.1: no memory limits you can see; long entries OK */
  var TINY={'cf-llama32-1b':1,'cf-llama32-3b':1,'tiny-aya':1,'tiny-aya-earth':1,'tiny-aya-fire':1,'tiny-aya-water':1,'cf-granite':1};
  function now(){return new Date().getTime();}
  function trim(s){return String(s==null?'':s).replace(/^\s+|\s+$/g,'');}
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  /* v1.0.1: no socials (the user, Oct 29): social links are dropped and handles shown as plain names */
  function fmtLine(s){s=esc(String(s==null?'':s).replace(/\*+\s*BLEEP\s*\*+/gi,function(m){return m.replace(/\*/g,'\u2217');}).replace(/(^|[^A-Za-z*])([A-Za-z]{1,3}\*+[A-Za-z]*)(?![A-Za-z*])/g,function(m,a,b){return a+b.replace(/\*/g,'\u2217');})) /* v2.0.1: bleeped words (f***, *BLEEP*) show their stars instead of turning into bold/italic */.replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>').replace(/(^|[^\w*])\*([^*\n]+)\*(?![\w*])/g,'$1<i>$2</i>');
    s=s.replace(/(https?:\/\/)?(www\.)?(tiktok|youtube|instagram)\.com\/[^\s<]*/gi,'').replace(/@[A-Za-z0-9._]{2,30}\b/g,'Domotime');
    return s.replace(/`([^`\n]+)`/g,'<code class="hc-ic">$1</code>');}
  /* v2.1 markdown-lite: **bold**, *italic*, `code`, # headings, - / 1. lists and ```code blocks``` with a 📋 Copy button */
  function fmtText(s){var lines=String(s).split('\n'),out='',list='',i;
    function close(){if(list){out+='</'+list+'>';list='';}}
    for(i=0;i<lines.length;i++){var L=lines[i],m;
      if((m=L.match(/^\s*[-*\u2022]\s+(.*)$/))){if(list!=='ul'){close();out+='<ul class="hc-ul">';list='ul';}out+='<li>'+fmtLine(m[1])+'</li>';continue;}
      if((m=L.match(/^\s*(\d{1,3})[.)]\s+(.*)$/))){if(list!=='ol'){close();out+='<ol class="hc-ol" start="'+(+m[1]||1)+'">';list='ol';}out+='<li>'+fmtLine(m[2])+'</li>';continue;}
      close();
      if((m=L.match(/^\s{0,3}#{1,6}\s+(.*)$/))){out+='<b class="hc-hd">'+fmtLine(m[1].replace(/\*\*/g,''))+'</b><br>';continue;}
      out+=fmtLine(L)+(i<lines.length-1?'<br>':'');}
    close();return out.replace(/(<br>)+(<(ul|ol))/g,'$2').replace(/(<\/(ul|ol)>)<br>/g,'$1');}
  function fmt(s){s=String(s==null?'':s);var parts=s.split(/```/),h='';
    for(var i=0;i<parts.length;i++){if(i%2===0){var tx=parts[i];if(i>0)tx=tx.replace(/^\n+/,'');if(i<parts.length-1)tx=tx.replace(/\n+$/,'');h+=fmtText(tx);continue;}
      var p=parts[i],nl=p.indexOf('\n'),lang=nl>=0?trim(p.slice(0,nl)):'',code=nl>=0?p.slice(nl+1):p;if(lang&&!/^[\w+#.-]{1,15}$/.test(lang)){code=p;lang='';}
      h+='<div class="hc-code"><div class="hc-code-b"><span>'+esc(lang||'code')+'</span><button type="button" class="hc-cp">\uD83D\uDCCB Copy</button></div><pre><code>'+esc(code.replace(/\n+$/,''))+'</code></pre></div>';}
    return h;}
  function load(k,d){try{var r=localStorage.getItem(k);if(r){var v=JSON.parse(r);if(v&&typeof v==='object')return v;}}catch(e){}return d;}
  function store(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(e){return false;}}
  function uid(){return now().toString(36)+Math.floor(Math.random()*1e6).toString(36);}

  /* ---------- toast (with optional Undo) ---------- */
  var toastEl=$('hc-toast'),toastT=$('hc-toast-t'),toastU=$('hc-toast-u'),toastTimer=null,toastUndo=null;
  function toast(msg,undo){toastT.textContent=msg;toastUndo=undo||null;toastU.hidden=!undo;toastEl.hidden=false;
    toastEl.className='hc-toast on';clearTimeout(toastTimer);toastTimer=setTimeout(hideToast,undo?5000:3200);}
  function hideToast(){toastEl.className='hc-toast';toastEl.hidden=true;toastUndo=null;}
  toastU.addEventListener('click',function(){var u=toastUndo;hideToast();if(u)u();});

  /* ---------- saved chats ---------- */
  var db=load(CK,null);
  if(!db||!db.list||!(db.list instanceof Array))db={cur:null,list:[]};
  if(!db.list.length){ /* bring over the v1.0 single saved chat */
    var old=null;try{old=JSON.parse(localStorage.getItem(OLD)||'null');}catch(e){}
    if(old&&old.length){var c0={id:uid(),t:'',u:now(),m:old.slice(-MAXMSG)};c0.t=autoTitle(c0);db.list.push(c0);db.cur=c0.id;}
  }
  function autoTitle(c){for(var i=0;i<c.m.length;i++)if(c.m[i].r==='user'){var t=trim(c.m[i].c);return t.length>42?t.slice(0,40)+'\u2026':t;}return 'New chat';}
  function find(id){for(var i=0;i<db.list.length;i++)if(db.list[i].id===id)return db.list[i];return null;}
  var cur=db.cur?find(db.cur):null;
  if(!cur)cur={id:uid(),t:'',u:now(),m:[]}; /* a fresh chat joins the list with its first message */
  function sortList(){db.list.sort(function(a,b){return b.u-a.u;});}
  function saveDb(){
    db.cur=cur.id;
    if(cur.m.length&&!find(cur.id))db.list.push(cur);
    sortList();
    var dropped=0;while(db.list.length>MAXCHATS){var last=db.list[db.list.length-1];if(last.id===cur.id)break;db.list.pop();dropped++;}
    var guard=0;while(!store(CK,db)&&db.list.length>1&&guard<60){ /* storage full: drop the oldest chat and try again */
      var l=db.list[db.list.length-1];if(l.id===cur.id)break;db.list.pop();dropped++;guard++;}
    try{localStorage.removeItem(OLD);}catch(e){}
    if(dropped)toast('\uD83D\uDDC2\uFE0F Oldest chat removed (50 chats max)');
    renderList();
  }
  var GREET="Hey! I'm <b>Tabo AI</b> \uD83D\uDC9C the AI with choices. Pick a model up top, tap \u2699\uFE0F to give me a personality or things to remember, or just ask me something!";
  function nearBottom(){return log.scrollHeight-log.scrollTop-log.clientHeight<90;}
  function toBottom(force){if(force||nearBottom())log.scrollTop=log.scrollHeight;}
  function add(who,html){var stick=nearBottom()||who==='me';var d=D.createElement('div');d.className='msg '+who;d.innerHTML=html;log.appendChild(d);if(stick)log.scrollTop=log.scrollHeight;return d;}
  function paint(){log.innerHTML='';add('bot',GREET);for(var i=0;i<cur.m.length;i++){var m=cur.m[i];if(m.r==='user')add('me',esc(m.c));else add('bot',fmt(m.c)+(m.g||''));}
    chips.style.display=cur.m.length?'none':'';log.scrollTop=log.scrollHeight;}
  function openChat(id){if(busy)return;var c=find(id);if(!c)return;cur=c;db.cur=c.id;store(CK,db);paint();renderList();closeAll();}
  function newChat(){if(busy)return;cur={id:uid(),t:'',u:now(),m:[]};db.cur=cur.id;store(CK,db);paint();renderList();closeAll();try{input.focus();}catch(e){}}
  function when(t){var d=new Date(t),n=new Date();if(d.toDateString()===n.toDateString()){var h=d.getHours(),m=d.getMinutes();return (h%12||12)+':'+(m<10?'0':'')+m+(h<12?' AM':' PM');}
    return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()]+' '+d.getDate();}
  var listEl=$('hc-list'),editing=null;
  function renderList(){
    var h='';
    if(!db.list.length)h='<p class="hd-empty">No saved chats yet. Start chatting and it saves by itself!</p>';
    for(var i=0;i<db.list.length;i++){var c=db.list[i],on=c.id===cur.id?' on':'';
      if(editing===c.id){h+='<div class="ci ed'+on+'"><input class="ci-in" type="text" maxlength="60" value="'+esc(c.t||autoTitle(c))+'" aria-label="Chat name" data-id="'+c.id+'"><button type="button" class="ci-b" data-act="ok" data-id="'+c.id+'" aria-label="Save name">\u2714\uFE0F</button></div>';continue;}
      h+='<div class="ci'+on+'"><button type="button" class="ci-o" data-act="open" data-id="'+c.id+'"><span class="ci-t">'+esc(c.t||autoTitle(c))+'</span><span class="ci-w">'+esc(when(c.u))+' \u00B7 '+c.m.length+' msgs</span></button>'+
        '<button type="button" class="ci-b" data-act="ren" data-id="'+c.id+'" aria-label="Rename chat">\u270F\uFE0F</button><button type="button" class="ci-b" data-act="del" data-id="'+c.id+'" aria-label="Delete chat">\uD83D\uDDD1\uFE0F</button></div>';}
    listEl.innerHTML=h;
    if(editing){var inp=listEl.querySelector('.ci-in');if(inp){try{inp.focus();inp.select();}catch(e){}}}
  }
  function finishRename(id){var inp=listEl.querySelector('.ci-in'),c=find(id);if(c&&inp){var v=trim(inp.value).slice(0,60);c.t=v||autoTitle(c);store(CK,db);}editing=null;renderList();
    var b=listEl.querySelector('[data-act="ren"][data-id="'+id+'"]');if(b)try{b.focus();}catch(e){}}
  function delChat(id){var idx=-1;for(var i=0;i<db.list.length;i++)if(db.list[i].id===id)idx=i;if(idx<0)return;
    var gone=db.list.splice(idx,1)[0],wasCur=gone.id===cur.id;
    if(wasCur){cur=db.list.length?db.list[0]:{id:uid(),t:'',u:now(),m:[]};paint();}
    db.cur=cur.id;store(CK,db);renderList();
    toast('\uD83D\uDDD1\uFE0F Chat deleted',function(){db.list.push(gone);sortList();if(wasCur){cur=gone;paint();}db.cur=cur.id;store(CK,db);renderList();});
  }
  listEl.addEventListener('click',function(e){var b=e.target;while(b&&b!==listEl&&!b.getAttribute('data-act'))b=b.parentNode;if(!b||b===listEl)return;
    var a=b.getAttribute('data-act'),id=b.getAttribute('data-id');
    if(a==='open')openChat(id);else if(a==='ren'){editing=id;renderList();}else if(a==='ok')finishRename(id);else if(a==='del'){if(!busy||id!==cur.id)delChat(id);}});
  listEl.addEventListener('keydown',function(e){var t=e.target;if(t&&t.className==='ci-in'){var k=e.keyCode;if(k===13){e.preventDefault();finishRename(t.getAttribute('data-id'));}else if(k===27){e.preventDefault();if(e.stopPropagation)e.stopPropagation();editing=null;renderList();}}});

  /* ---------- personality ---------- */
  var PRESETS=[['normal','\uD83D\uDE42 Normal',''],['hype','\uD83D\uDD25 Hype','Be super hype and energetic! Lots of excitement and fun emojis.'],
    ['pirate','\uD83C\uDFF4\u200D\u2620\uFE0F Pirate','Talk like a friendly pirate. Arr, matey!'],['chill','\uD83D\uDE0E Chill','Be calm, relaxed and chill. Short, laid-back replies.'],
    ['teacher','\uD83C\uDF93 Teacher','Explain things step by step like a friendly teacher, simple enough for a 10 year old.'],
    ['funny','\uD83D\uDE02 Funny','Be funny! Add a kid-friendly joke or pun when you can.'],['robot','\uD83E\uDD16 Robot','Talk like a friendly robot. BEEP BOOP. Use robot words but stay helpful.']];
  var pers=load(PK,{t:'',p:'normal'});if(typeof pers.t!=='string')pers={t:'',p:'normal'};
  var pBox=$('hc-pers'),pN=$('hc-pers-n'),pMsg=$('hc-pers-msg'),pPre=$('hc-presets');
  function presetOf(t){for(var i=0;i<PRESETS.length;i++)if(PRESETS[i][2]===t)return PRESETS[i];return null;}
  function persLabel(){if(!pers.t)return '';var p=presetOf(pers.t);return p?p[1]:'\uD83C\uDFAD Custom';}
  function renderPresets(){var h='',sel=presetOf(pers.t),sid=sel?sel[0]:(pers.t?'':'normal');
    for(var i=0;i<PRESETS.length;i++)h+='<button type="button" class="pc'+(PRESETS[i][0]===sid?' on':'')+'" data-p="'+i+'" aria-pressed="'+(PRESETS[i][0]===sid)+'">'+PRESETS[i][1]+'</button>';
    pPre.innerHTML=h;}
  function pCount(){pN.textContent=pBox.value.length+'/'+PMAX;}
  function pSay(t,bad){pMsg.textContent=t;pMsg.className='hd-msg'+(bad?' bad':(t?' ok':''));}
  function savePers(t,p){pers={t:t,p:p||''};store(PK,pers);renderPresets();ctxBar();}
  function check(kind,text,cb){ /* Safety Shield check on the server before saving */
    fetch('/api/hc/check',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({kind:kind,text:text})})
      .then(function(r){return r.json()['catch'](function(){return {};});})
      .then(function(j){cb(j&&j.ok?'ok':(j&&j.error)||'busy',j||{});})['catch'](function(){cb('net',{});});}
  function whyNot(r,what){if(r==='blocked')return what==='p'?'\uD83D\uDEE1\uFE0F That personality isn\u2019t allowed, try another!':'\uD83D\uDEE1\uFE0F That memory isn\u2019t allowed (no personal info or not-nice stuff), try another!';
    if(r==='too_long')return 'That\u2019s too long, make it shorter.';if(r==='rate_limited')return 'Whoa, slow down a little and try again in a few minutes!';
    if(r==='net')return 'Couldn\u2019t reach the server. Check your wifi and try again.';return '\uD83D\uDEE1\uFE0F The Safety Shield is busy right now. Try again in a minute!';}
  pPre.addEventListener('click',function(e){var b=e.target;while(b&&b!==pPre&&!b.getAttribute('data-p'))b=b.parentNode;if(!b||b===pPre)return;
    var p=PRESETS[+b.getAttribute('data-p')];pBox.value=p[2];pCount();savePers(p[2],p[0]);pSay(p[2]?'\u2705 Personality set: '+p[1]:'\u2705 Back to normal Tabo',false);
    var nb=pPre.querySelector('[data-p="'+b.getAttribute('data-p')+'"]');if(nb)try{nb.focus();}catch(e2){}});
  pBox.addEventListener('input',function(){if(pBox.value.length>PMAX)pBox.value=pBox.value.slice(0,PMAX);pCount();pSay('');});
  var pBusy=false;
  $('hc-pers-save').addEventListener('click',function(){if(pBusy)return;var t=trim(pBox.value).replace(/\s+/g,' ').slice(0,PMAX);
    if(!t){savePers('','normal');pSay('\u2705 Back to normal Tabo');return;}
    var pr=presetOf(t);if(pr){savePers(t,pr[0]);pSay('\u2705 Personality set: '+pr[1]);return;}
    if(t===pers.t){pSay('\u2705 Already saved');return;}
    pBusy=true;pSay('\uD83D\uDEE1\uFE0F Checking with the Safety Shield\u2026');
    check('persona',t,function(r){pBusy=false;if(r==='ok'){savePers(t,'');pSay('\u2705 Personality saved! Tabo will act like that now.');toast('\uD83C\uDFAD Personality saved');}else pSay(whyNot(r,'p'),true);});});
  $('hc-pers-clear').addEventListener('click',function(){pBox.value='';pCount();savePers('','normal');pSay('\u2705 Back to normal Tabo');});

  /* ---------- memory (v1.1.1: no visible limits; long entries; 📌 pin; only what fits is sent, pinned + newest first) ---------- */
  var mem=load(MK,{on:true,f:[]});if(!(mem.f instanceof Array))mem={on:true,f:[]};if(mem.on!==false)mem.on=true;
  var mOn=$('hc-mem-on'),mForm=$('hc-mem-form'),mIn=$('hc-mem-in'),mMsg=$('hc-mem-msg'),mList=$('hc-mem-list'),mN=$('hc-mem-n'),mClear=$('hc-mem-clear'),mEdit=null,clearArm=0,mOpen={};
  var FULL='\uD83E\uDDE0 Memory is full on this device. Delete or shorten a memory to add more.';
  function saveMem(){var ok=store(MK,mem);renderMem();ctxBar();return ok;}
  function commit(undo){if(saveMem())return true;undo();saveMem();return false;} /* storage full -> put it back, say so, never break */
  function mSay(t,bad){mMsg.textContent=t;mMsg.className='hd-msg'+(bad?' bad':(t?' ok':''));}
  function hasFact(t){t=t.toLowerCase();for(var i=0;i<mem.f.length;i++)if(mem.f[i].t.toLowerCase()===t)return true;return false;}
  function clean(t){return trim(String(t||'')).replace(/\s+/g,' ').slice(0,FMAX);}
  function mOrder(){var a=[],b=[],i;for(i=0;i<mem.f.length;i++)(mem.f[i].p?a:b).push(mem.f[i]);return a.concat(b);}
  function mItem(f){var cut=(W.innerWidth||400)<261?60:200,lg=f.t.length>cut+20,open=mOpen[f.id],txt=lg&&!open?f.t.slice(0,cut)+'\u2026':f.t;
    return '<div class="mi'+(f.p?' pin':'')+'"><span class="mi-t">'+esc(txt)+(lg?' <button type="button" class="mi-more" data-act="more" data-id="'+f.id+'">'+(open?'less':'more')+'</button>':'')+'</span>'+
      '<button type="button" class="ci-b mi-p" data-act="pin" data-id="'+f.id+'" aria-pressed="'+(f.p?'true':'false')+'" aria-label="'+(f.p?'Unpin memory':'Pin memory (always used first)')+'">\uD83D\uDCCC</button>'+
      '<button type="button" class="ci-b" data-act="ed" data-id="'+f.id+'" aria-label="Edit memory">\u270F\uFE0F</button><button type="button" class="ci-b" data-act="del" data-id="'+f.id+'" aria-label="Delete memory">\uD83D\uDDD1\uFE0F</button></div>';}
  function renderMem(){mOn.checked=!!mem.on;var h='',list=mOrder();
    if(!list.length)h='<p class="hd-empty">Nothing yet. Add anything above (even a whole \u201Cabout me\u201D), or say \u201Cremember that\u2026\u201D in a chat.</p>';
    for(var i=0;i<list.length;i++){var f=list[i];
      if(mEdit===f.id){h+='<div class="mi ed"><textarea class="mi-in" rows="'+(f.t.length>90?5:2)+'" maxlength="'+FMAX+'" aria-label="Edit memory" data-id="'+f.id+'">'+esc(f.t)+'</textarea><button type="button" class="ci-b" data-act="ok" data-id="'+f.id+'" aria-label="Save memory">\u2714\uFE0F</button></div>';continue;}
      h+=mItem(f);}
    mList.innerHTML=h;var n=mem.f.length;mN.textContent='\uD83E\uDDE0 '+n+' memor'+(n===1?'y':'ies');mClear.disabled=!n;mClear.textContent='Clear all';clearArm=0;
    mList.className='hd-mem'+(mem.on?'':' off');
    if(mEdit){var inp=mList.querySelector('.mi-in');if(inp)try{inp.focus();}catch(e){}}}
  function fIdx(id){for(var i=0;i<mem.f.length;i++)if(mem.f[i].id===id)return i;return -1;}
  mOn.addEventListener('change',function(){mem.on=!!mOn.checked;saveMem();mSay(mem.on?'\uD83E\uDDE0 Memory is on':'Memory is off (Tabo won\u2019t use or learn facts)');});
  var mBusy=false;
  function addMem(){if(mBusy)return;var t=clean(mIn.value);if(!t)return;
    if(hasFact(t)){mSay('Already remembered!');return;}
    mBusy=true;mSay('\uD83D\uDEE1\uFE0F Checking with the Safety Shield\u2026');
    check('memory',t,function(r,j){mBusy=false;if(r==='ok'){var item={id:uid(),t:j.text||t,s:j.sig||'',a:now()};mem.f.push(item);
      if(commit(function(){var i=fIdx(item.id);if(i>=0)mem.f.splice(i,1);})){mIn.value='';mSay('\u2705 Saved to memory');}else mSay(FULL,true);}else mSay(whyNot(r,'m'),true);});}
  mForm.addEventListener('submit',function(e){e.preventDefault();addMem();});
  mIn.addEventListener('keydown',function(e){if(e.keyCode===13&&!e.shiftKey){e.preventDefault();addMem();}});
  function finishEdit(id){var inp=mList.querySelector('.mi-in'),i=fIdx(id);if(!inp||i<0){mEdit=null;renderMem();return;}
    var t=clean(inp.value);
    if(!t){mEdit=null;delFact(id);return;}
    if(t===mem.f[i].t){mEdit=null;renderMem();return;}
    mSay('\uD83D\uDEE1\uFE0F Checking with the Safety Shield\u2026');
    check('memory',t,function(r,j){var k=fIdx(id);if(r==='ok'&&k>=0){var o=mem.f[k],ot=o.t,os=o.s;o.t=j.text||t;o.s=j.sig||'';o.a=now();mEdit=null;
      if(commit(function(){o.t=ot;o.s=os;}))mSay('\u2705 Memory updated');else mSay(FULL,true);}else if(r!=='ok')mSay(whyNot(r,'m'),true);});}
  function delFact(id){var i=fIdx(id);if(i<0)return;var gone=mem.f.splice(i,1)[0];saveMem();
    toast('\uD83E\uDDE0 Memory deleted',function(){mem.f.splice(Math.min(i,mem.f.length),0,gone);saveMem();});}
  function refocus(act,id){var nb=mList.querySelector('[data-act="'+act+'"][data-id="'+id+'"]');if(nb)try{nb.focus();}catch(e){}}
  mList.addEventListener('click',function(e){var b=e.target;while(b&&b!==mList&&!b.getAttribute('data-act'))b=b.parentNode;if(!b||b===mList)return;
    var a=b.getAttribute('data-act'),id=b.getAttribute('data-id'),i=fIdx(id);if(a==='ed'){mEdit=id;renderMem();}else if(a==='ok')finishEdit(id);else if(a==='del')delFact(id);
    else if(a==='more'){mOpen[id]=!mOpen[id];renderMem();refocus('more',id);}
    else if(a==='pin'&&i>=0){mem.f[i].p=mem.f[i].p?0:1;saveMem();mSay(mem.f[i].p?'\uD83D\uDCCC Pinned: Tabo always uses this one first':'Unpinned');refocus('pin',id);}});
  mList.addEventListener('keydown',function(e){var t=e.target;if(t&&t.className==='mi-in'){if(e.keyCode===13&&!e.shiftKey){e.preventDefault();finishEdit(t.getAttribute('data-id'));}else if(e.keyCode===27){e.preventDefault();if(e.stopPropagation)e.stopPropagation();mEdit=null;renderMem();}}});
  mClear.addEventListener('click',function(){if(!mem.f.length)return;
    if(!clearArm){clearArm=1;mClear.textContent='Tap again to clear all';setTimeout(function(){if(clearArm){clearArm=0;mClear.textContent='Clear all';}},3500);return;}
    var gone=mem.f.slice();mem.f=[];saveMem();toast('\uD83E\uDDE0 Memory cleared',function(){mem.f=gone;saveMem();});});
  function autoMem(f,sig){ /* the server suggests a memory from "remember ...", "my name is ...", "my favorite ... is ..." (that message already passed the Shield) */
    f=clean(f);if(!f||!mem.on||hasFact(f))return;
    var item={id:uid(),t:f,s:sig||'',a:now()};mem.f.push(item);
    if(!commit(function(){var i=fIdx(item.id);if(i>=0)mem.f.splice(i,1);})){toast(FULL);return;}
    toast('\uD83E\uDDE0 Memory updated: \u201C'+(f.length>80?f.slice(0,78)+'\u2026':f)+'\u201D',function(){var i=fIdx(item.id);if(i>=0){mem.f.splice(i,1);saveMem();}});}
  function memFor(model){ /* what goes with a chat: pinned first, then newest, as much as fits (small models get less); the server caps it again */
    var bud=Math.min(MSEND,TINY[model]?MBUD_TINY:MBUD),out=[],used=0,a=[],b=[],i;
    for(i=mem.f.length-1;i>=0;i--)(mem.f[i].p?a:b).push(mem.f[i]);a=a.concat(b);
    for(i=0;i<a.length;i++){var t=a[i].t;if(used+t.length<=bud||!out.length){out.push({t:t,s:a[i].s||''});used+=t.length;}if(used>=bud)break;}
    return out;}

  /* ---------- the little "what's on" bar above the composer ---------- */
  var ctxEl=$('hc-ctx');
  function ctxBar(){var bits=[],pl=persLabel();if(pl)bits.push(pl);if(mem.on&&mem.f.length)bits.push('\uD83E\uDDE0 '+mem.f.length+' memor'+(mem.f.length===1?'y':'ies'));
    if(!bits.length){ctxEl.hidden=true;return;}ctxEl.hidden=false;ctxEl.innerHTML=esc(bits.join('  \u00B7  '))+' <span class="hc-ctx-e">edit</span>';}
  ctxEl.addEventListener('click',function(){openDrawer('hc-cust',ctxEl);});

  /* ---------- drawers ---------- */
  var scrim=$('hc-scrim'),opener=null,openId=null,chatsBtn=$('hc-chats-btn'),custBtn=$('hc-cust-btn');
  function wide(){return (W.innerWidth||D.documentElement.clientWidth)>=1000;}
  var dockPref=true;try{dockPref=localStorage.getItem('hc_dock')!=='0';}catch(e){}
  function isCode(){return /\bhc-codemode\b/.test(D.documentElement.className);} /* v1.2: Code mode has its own projects drawer, no docked chats */
  function dock(){var r=D.documentElement,on=wide()&&dockPref&&!isCode();r.className=r.className.replace(/\s*\bhc-dock\b/g,'')+(on?' hc-dock':'');
    $('hc-chats').setAttribute('aria-hidden',on||openId==='hc-chats'?'false':'true');return on;}
  function openDrawer(id,from){
    if(id==='hc-projs'){closeAll(true);var pe=$(id);if(!pe)return;openId=id;opener=from||null;pe.className=pe.className.replace(/\s*\bopen\b/g,'')+' open';pe.setAttribute('aria-hidden','false');scrim.hidden=false;scrim.className='hc-scrim on';
      chatsBtn.setAttribute('aria-expanded','true');if(W.hcCode)W.hcCode.renderList();setTimeout(function(){var f=pe.querySelector('.hd-new');if(f)try{f.focus();}catch(e){}},60);return;}
    if(id==='hc-chats'&&wide()){dockPref=!dockPref;try{localStorage.setItem('hc_dock',dockPref?'1':'0');}catch(e){}dock();if(dockPref){var f0=$('hc-new2');if(f0)try{f0.focus();}catch(e){}}return;}
    closeAll(true);var el=$(id);if(!el)return;openId=id;opener=from||null;
    el.className=el.className.replace(/\s*\bopen\b/g,'')+' open';el.setAttribute('aria-hidden','false');scrim.hidden=false;scrim.className='hc-scrim on';
    if(id==='hc-chats'){chatsBtn.setAttribute('aria-expanded','true');renderList();}else{custBtn.setAttribute('aria-expanded','true');renderMem();renderPresets();pBox.value=pers.t;pCount();pSay('');mSay('');}
    setTimeout(function(){var f=el.querySelector(id==='hc-chats'?'.hd-new':'.pc.on')||el.querySelector('button');if(f)try{f.focus();}catch(e){}},60);}
  function closeAll(silent){var was=openId;
    var ids=['hc-chats','hc-cust','hc-projs'];for(var i=0;i<ids.length;i++){var el=$(ids[i]);if(el)el.className=el.className.replace(/\s*\bopen\b/g,'');}
    if($('hc-projs'))$('hc-projs').setAttribute('aria-hidden','true');
    $('hc-cust').setAttribute('aria-hidden','true');scrim.className='hc-scrim';scrim.hidden=true;openId=null;dock();
    chatsBtn.setAttribute('aria-expanded','false');custBtn.setAttribute('aria-expanded','false');editing=null;mEdit=null;
    if(was&&!silent&&opener){try{opener.focus();}catch(e){}}opener=null;}
  chatsBtn.addEventListener('click',function(){if(isCode()){if(openId==='hc-projs')closeAll();else openDrawer('hc-projs',chatsBtn);return;}if(openId==='hc-chats')closeAll();else openDrawer('hc-chats',chatsBtn);});
  custBtn.addEventListener('click',function(){if(openId==='hc-cust')closeAll();else openDrawer('hc-cust',custBtn);});
  scrim.addEventListener('click',function(){closeAll();});
  var xs=D.querySelectorAll('[data-close]');for(var xi=0;xi<xs.length;xi++)xs[xi].addEventListener('click',function(){if(openId)closeAll();else if(wide()){dockPref=false;try{localStorage.setItem('hc_dock','0');}catch(e){}dock();try{chatsBtn.focus();}catch(e){}}});
  $('hc-new2').addEventListener('click',newChat);
  var nb=$('hcf-new');if(nb)nb.addEventListener('click',function(){if(isCode()&&W.hcCode)W.hcCode.newProject();else newChat();});
  W.addEventListener('resize',function(){dock();});
  /* keyboard / TV remote: Esc or Back closes a drawer; Up/Down moves between buttons inside it */
  function focusables(el){var all=el.querySelectorAll('button,input,textarea,a[href]'),out=[];for(var i=0;i<all.length;i++){var b=all[i];if(!b.disabled&&b.offsetWidth>0&&b.offsetHeight>0)out.push(b);}return out;}
  D.addEventListener('keydown',function(e){var k=e.keyCode,t=e.target;
    if(openId&&(k===27||k===10009||k===461||e.key==='Escape'||e.key==='GoBack')){if(t&&(t.className==='ci-in'||t.className==='mi-in'))return;e.preventDefault();closeAll();return;}
    var box=openId?$(openId):(D.documentElement.className.indexOf('hc-dock')>=0&&t&&$('hc-chats').contains(t)?$('hc-chats'):null);
    if(box&&(k===38||k===40)&&t&&box.contains(t)&&t.tagName!=='TEXTAREA'){var f=focusables(box),i=-1;for(var j=0;j<f.length;j++)if(f[j]===t)i=j;
      var n=f[i+(k===40?1:-1)];if(n){e.preventDefault();try{n.focus();}catch(e2){}}}
  });

  /* ---------- chat ---------- */
  var busy=false;
  function typing(){var t=add('bot','<span class="typing" aria-label="Tabo AI is typing"><span></span><span></span><span></span></span><span class="tp-st"></span>');t.className+=' tp';
    var st=t.querySelector('.tp-st');t.__t1=setTimeout(function(){if(st)st.textContent='thinking hard\u2026 \uD83E\uDDE0';},5000);
    t.__t2=setTimeout(function(){if(st)st.textContent='if this AI is napping \uD83D\uDCA4 I\u2019ll grab a backup\u2026';},11000);return t;}
  /* v2.1: the reply types itself out (fast), auto-scroll only follows if you're already at the bottom */
  function reveal(el){var nodes=[],w=D.createTreeWalker?D.createTreeWalker(el,4,null,false):null,n,total=0;if(!w)return;
    while((n=w.nextNode())){if(n.parentNode&&/aip-tag|hc-unh-tag|hc-code-b/.test(n.parentNode.className||''))continue;nodes.push([n,n.nodeValue]);total+=n.nodeValue.length;n.nodeValue='';}
    if(!total)return;var shown=0,step=Math.max(2,Math.ceil(total/70)),k=0;setC(el,'hc-typing',true);
    var tm=setInterval(function(){var left=step;while(left>0&&k<nodes.length){var nd=nodes[k],cur=nd[0].nodeValue.length,need=nd[1].length-cur;
        if(need<=left){nd[0].nodeValue=nd[1];left-=need;k++;}else{nd[0].nodeValue=nd[1].slice(0,cur+left);left=0;}}
      shown+=step;toBottom();if(k>=nodes.length){clearInterval(tm);setC(el,'hc-typing',false);toBottom();}},16);
    el.__revealStop=function(){clearInterval(tm);for(var z=0;z<nodes.length;z++)nodes[z][0].nodeValue=nodes[z][1];setC(el,'hc-typing',false);};}
  function setC(el,c,on){if(!el)return;var s=' '+el.className+' ',h=s.indexOf(' '+c+' ')>=0;if(on&&!h)el.className+=' '+c;else if(!on&&h)el.className=s.replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function finish(t,html,anim){var stick=nearBottom();t.className='msg bot';t.innerHTML=html;if(anim)reveal(t);if(stick)log.scrollTop=log.scrollHeight;busy=false;sendBtn.disabled=false;}
  /* v1.9.3: voice.js listens for 'hc:reply' (the finished reply text + its bubble) to read it aloud */
  function fire(d){try{var ev;if(typeof W.CustomEvent==='function')ev=new CustomEvent('hc:reply',{detail:d});else{ev=D.createEvent('CustomEvent');ev.initCustomEvent('hc:reply',false,false,d);}D.dispatchEvent(ev);}catch(e){}}
  var OFF=["Hmm, every AI I tried is napping right now \uD83D\uDCA4 Tap \uD83D\uDD01 Try again, or pick another AI up top!","I couldn\u2019t reach my brain \uD83D\uDE35\u200D\uD83D\uDCAB Check your wifi, then tap \uD83D\uDD01 Try again!"];
  function send(text){text=trim(text).slice(0,30000); /* Tabo v2.9.6: messages up to ~5,000 words */if(!text||busy)return;busy=true;sendBtn.disabled=true;chips.style.display='none';
    clearQR();add('me',esc(text));input.value='';grow();var chat=cur;chat.m.push({r:'user',c:text});if(!chat.t)chat.t=autoTitle(chat);chat.u=now();
    if(chat.m.length>MAXMSG)chat.m=chat.m.slice(-MAXMSG);saveDb();
    var t=typing(),started=now();
    var AI=W.domoAI,aim=AI?AI.model():'sigma',ctrl=('AbortController' in W)?new AbortController():null;
    var msgs=[];for(var i=Math.max(0,chat.m.length-8);i<chat.m.length;i++)msgs.push({role:chat.m[i].r,content:chat.m[i].c});
    var body={messages:msgs};if(aim!=='sigma')body.model=aim; /* v2.9.5 \uD83D\uDD17 backup order */if(W.hcUnhinged&&W.hcUnhinged.on())body.mode='unhinged'; /* v2.0.1 unhinged */
    if(pers.t)body.persona=pers.t;
    if(mem.on){body.mem_auto=true;if(mem.f.length)body.memory=memFor(aim);}
    var timer=setTimeout(function(){if(ctrl)ctrl.abort();},CH?47000:(aim==='sigma'?14000:(AI&&AI.slow&&AI.slow(aim)?45000:20000)));
    function undoUser(){var m=chat.m;if(m.length&&m[m.length-1].r==='user')m.pop();if(!m.length){for(var z=0;z<db.list.length;z++)if(db.list[z].id===chat.id){db.list.splice(z,1);break;}}saveDb();}
    fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:ctrl?ctrl.signal:undefined})
      .then(function(r){return r.json()['catch'](function(){return {};});})
      .then(function(j){clearTimeout(timer);var out=j&&j.reply?String(j.reply):null;var g=out&&AI?AI.tag(j):'';if(out&&j.mode==='unhinged')g='<span class="hc-unh-tag" title="Unhinged mode" aria-label="Unhinged mode">\uD83D\uDE08</span>'+g;
        if(g&&j.fell)g=g.replace(' was busy \u2192 answered by ',' is napping \uD83D\uDCA4 so this came from ');
        var html=out?fmt(out)+g:(esc(OFF[0]));
        if(out){chat.m.push({r:'assistant',c:out,g:g});chat.u=now();if(chat.m.length>MAXMSG)chat.m=chat.m.slice(-MAXMSG);saveDb();}else undoUser();
        clearTimeout(t.__t1);clearTimeout(t.__t2);
        setTimeout(function(){if(chat===cur){finish(t,html,!!out);fire({ok:!!out,text:out||OFF[0],el:t});if(out)showQR(out,t);else failBtn(t,text);}else{busy=false;sendBtn.disabled=false;fire({ok:false,away:true});}
          if(out&&j.memory)autoMem(j.memory,j.memory_sig);
          if(out&&j.ctx_blocked)toast('\uD83D\uDEE1\uFE0F The Safety Shield skipped your personality/memory for that message');},Math.max(0,150-(now()-started)));})
      ['catch'](function(){clearTimeout(timer);clearTimeout(t.__t1);clearTimeout(t.__t2);undoUser();if(chat===cur){finish(t,esc(OFF[1]));fire({ok:false,text:OFF[1],el:t});failBtn(t,text);}else{busy=false;sendBtn.disabled=false;fire({ok:false,away:true});}});
  }
  /* ---------- v2.1 chat extras: quick replies, tap a reply for 📋 Copy / 🔊 Read / 🔁 Retry, code Copy, growing send box + counter ---------- */
  function copyText(t,done){function fb(){try{var ta=D.createElement('textarea');ta.value=t;ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.opacity='0';D.body.appendChild(ta);ta.select();try{ta.setSelectionRange(0,t.length);}catch(e){}D.execCommand('copy');D.body.removeChild(ta);}catch(e){}if(done)done();}
    try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(function(){if(done)done();},fb);return;}}catch(e){}fb();}
  function bubbleText(el){var c=el.cloneNode(true),x=c.querySelectorAll('.aip-tag,.hv-ctl,.hc-acts,.hc-unh-tag,.hc-code-b');for(var i=0;i<x.length;i++)if(x[i].parentNode)x[i].parentNode.removeChild(x[i]);
    var br=c.querySelectorAll('br');for(var j=0;j<br.length;j++)br[j].parentNode.replaceChild(D.createTextNode('\n'),br[j]);
    var li=c.querySelectorAll('li');for(var k=0;k<li.length;k++)li[k].insertBefore(D.createTextNode('\n\u2022 '),li[k].firstChild);
    return trim(c.textContent||'');}
  function prevUser(el){var p=el.previousSibling;while(p){if(p.className&&/\bmsg me\b/.test(p.className))return p.textContent||'';p=p.previousSibling;}return '';}
  function retry(el){if(busy)return;var q=trim(prevUser(el));if(!q){var m=cur.m;for(var i=m.length-1;i>=0;i--)if(m[i].r==='user'){q=m[i].c;break;}}if(!q)return;
    var bots=log.querySelectorAll('.msg.bot'),last=bots[bots.length-1]===el,m2=cur.m;
    if(last&&m2.length&&m2[m2.length-1].r==='assistant'){m2.pop();if(m2.length&&m2[m2.length-1].r==='user')m2.pop();saveDb();paint();}
    else if(last&&m2.length&&m2[m2.length-1].r==='user'){m2.pop();saveDb();paint();}
    send(q);}
  var QR={joke:['Another one \uD83D\uDE02','Explain the joke','Tell a pun'],code:['Explain this code','Make it simpler','Add comments'],list:['Tell me more about #1','Make it shorter','Give an example'],
    q:['Yes!','No thanks','Tell me more'],gen:['Tell me more','Explain it simpler','Give an example']};
  function clearQR(){var q=log.querySelectorAll('.hc-qr');for(var i=0;i<q.length;i++)if(q[i].parentNode)q[i].parentNode.removeChild(q[i]);}
  function showQR(text,el){clearQR();var t=String(text||''),set=QR.gen;
    if(/```/.test(t))set=QR.code;else if(/\bjoke|\bpun\b|knock,? knock|\bhaha|\uD83D\uDE02/i.test(t))set=QR.joke;else if(/\?\s*$|\?\s*[\uD800-\uDBFF][\uDC00-\uDFFF]?\s*$/.test(t))set=QR.q;else if(/(^|\n)\s*(\d+[.)]|[-*\u2022])\s/.test(t))set=QR.list;
    var d=D.createElement('div');d.className='hc-qr';d.setAttribute('aria-label','Quick replies');var h='';for(var i=0;i<set.length;i++)h+='<button type="button" class="chip hc-qrc">'+esc(set[i])+'</button>';d.innerHTML=h;
    var stick=nearBottom();if(el&&el.parentNode===log)log.insertBefore(d,el.nextSibling);else log.appendChild(d);if(stick)toBottom(true);}
  function failBtn(el,q){if(!el)return;var b=D.createElement('div');b.className='hc-acts on';b.innerHTML='<button type="button" class="hc-act" data-a="retry" data-q="'+esc(q)+'">\uD83D\uDD01 Try again</button>';el.appendChild(b);toBottom(true);}
  function actsFor(el){var a=el.querySelector('.hc-acts');if(a){a.parentNode.removeChild(a);return;}
    var x=log.querySelectorAll('.hc-acts:not(.keep)');for(var i=0;i<x.length;i++)if(x[i].parentNode&&!/\bon\b/.test(x[i].className))x[i].parentNode.removeChild(x[i]);
    a=D.createElement('div');a.className='hc-acts';a.innerHTML='<button type="button" class="hc-act" data-a="copy">\uD83D\uDCCB Copy</button>'+(W.hcVoice?'<button type="button" class="hc-act" data-a="read">\uD83D\uDD0A Read</button>':'')+'<button type="button" class="hc-act" data-a="retry">\uD83D\uDD01 Retry</button>';el.appendChild(a);}
  var lpT=null,lpEl=null,lpDone=false;
  log.addEventListener('click',function(e){var b=e.target;
    while(b&&b!==log&&!(b.className&&/\b(hc-act|hc-cp|hc-qrc)\b/.test(b.className))&&!(b.className&&/\bmsg bot\b/.test(b.className)))b=b.parentNode;if(!b||b===log)return;
    var cls=b.className||'';
    if(/\bhc-qrc\b/.test(cls)){if(!busy)send(b.textContent);return;}
    if(/\bhc-cp\b/.test(cls)){var pre=b.parentNode&&b.parentNode.parentNode&&b.parentNode.parentNode.querySelector('pre');if(pre)copyText(pre.textContent||'',function(){b.textContent='\u2705 Copied';setTimeout(function(){b.innerHTML='\uD83D\uDCCB Copy';},1400);});return;}
    if(/\bhc-act\b/.test(cls)){var m=b;while(m&&m!==log&&!/\bmsg bot\b/.test(m.className||''))m=m.parentNode;if(!m||m===log)return;var a=b.getAttribute('data-a');
      if(a==='copy')copyText(bubbleText(m),function(){toast('\uD83D\uDCCB Copied!');});
      else if(a==='read'){if(W.hcVoice&&W.hcVoice.speak)W.hcVoice.speak(bubbleText(m),m,null);}
      else if(a==='retry'){var q=b.getAttribute('data-q');if(q&&!busy){var p=b.parentNode;if(p&&p.parentNode)p.parentNode.removeChild(p);send(q);}else retry(m);}
      return;}
    if(lpDone){lpDone=false;return;}
    if(/\btp\b/.test(cls))return;var tg=e.target;if(tg&&(tg.tagName==='A'||tg.tagName==='BUTTON'))return;
    try{var sel=W.getSelection&&W.getSelection();if(sel&&String(sel).length>0)return;}catch(e2){}
    if(b.__revealStop)b.__revealStop();actsFor(b);});
  log.addEventListener('touchstart',function(e){var b=e.target;while(b&&b!==log&&!(b.className&&/\bmsg bot\b/.test(b.className)))b=b.parentNode;if(!b||b===log)return;lpEl=b;clearTimeout(lpT);
    lpT=setTimeout(function(){if(lpEl){lpDone=true;actsFor(lpEl);try{if(W.domoHaptic)W.domoHaptic('select');}catch(e2){}}},520);},{passive:true});
  log.addEventListener('touchend',function(){clearTimeout(lpT);lpEl=null;},{passive:true});
  log.addEventListener('touchmove',function(){clearTimeout(lpT);lpEl=null;},{passive:true});
  /* growing send box + 200 counter */
  var cnt=D.createElement('span');cnt.className='hc-cnt';cnt.setAttribute('aria-live','polite');form.appendChild(cnt);
  function grow(){if(input.tagName!=='TEXTAREA'){count();return;}input.style.height='auto';var h=Math.min(140,Math.max(50,input.scrollHeight+2));input.style.height=h+'px';setC(form,'hc-tall',h>54);count();}
  function count(){var n=input.value.length,wd=n?trim(input.value).split(/\s+/).length:0;cnt.textContent=n>200?wd+'/5000 words':'';setC(cnt,'warn',n>=29000);setC(cnt,'on',n>200);} /* Tabo v2.9.6 */
  input.addEventListener('input',grow);
  input.addEventListener('keydown',function(e){if((e.keyCode===13||e.key==='Enter')&&!e.shiftKey&&!e.isComposing&&input.tagName==='TEXTAREA'){e.preventDefault();
    var ev;try{ev=new Event('submit',{cancelable:true,bubbles:true});}catch(x){ev=D.createEvent('Event');ev.initEvent('submit',true,true);}form.dispatchEvent(ev);}});
  form.addEventListener('submit',function(e){e.preventDefault();send(input.value);grow();});
  chips.addEventListener('click',function(e){var b=e.target;while(b&&b!==chips&&!(b.className&&/\bchip\b/.test(b.className)))b=b.parentNode;if(b&&b!==chips)send(b.textContent);});

  paint();renderList();renderPresets();renderMem();ctxBar();dock();
  W.hcApp={newChat:newChat,open:openDrawer,close:function(s){closeAll(s);dock();},toast:toast,dock:dock,
    send:function(t){if(busy)return false;send(t);return true;},busy:function(){return busy;},
    /* v2.5 keyboard shortcuts (keys.js): act on the newest reply */
    lastReply:function(){var b=log.querySelectorAll('.msg.bot'),i;for(i=b.length-1;i>=0;i--)if(!/\btp\b/.test(b[i].className))return b[i];return null;},
    copyLast:function(){var m=W.hcApp.lastReply();if(!m)return false;copyText(bubbleText(m),function(){toast('\uD83D\uDCCB Copied!');});return true;},
    readLast:function(){var m=W.hcApp.lastReply();if(!m||!W.hcVoice||!W.hcVoice.speak)return false;W.hcVoice.speak(bubbleText(m),m,null);return true;},
    retryLast:function(){var m=W.hcApp.lastReply();if(!m||busy)return false;var f=m.querySelector('.hc-act[data-a="retry"][data-q]');if(f){f.click();return true;}retry(m);return true;}};
})();
