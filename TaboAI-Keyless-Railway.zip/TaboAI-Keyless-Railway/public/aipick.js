// Tabo AI model picker. Only anonymous keyless gateways are enabled in this build.
(function(){
  'use strict';
  var D=document,LS='domo_ai_model';
  var M=[
    {id:'sigma',n:'Tabo AI',p:'Kilo',b:'hc',v:'GLM-5 free model • default',e:'💜'},
    {id:'faucet',n:'Free Model Router',p:'LLMFaucet',b:'other',v:'Experimental public router • automatic fallback',e:'⚡',slow:1},
    {id:'qwen',n:'AI Horde',p:'AI Horde',b:'other',v:'Community models • anonymous requests may wait',e:'🌐',slow:1}
  ];
  var BY={};for(var i=0;i<M.length;i++)BY[M[i].id]=M[i];
  // Tabo v2.9.4 \uD83E\uDDF9 duplicates merged: old ids -> the one entry (its other providers are server-side backups)
  var AL={'glm-flash':'sigma','deepseek-v41':'sigma','bt-deepseek-v41-flash':'sigma','zai-glm47-flash':'sigma','bt-kimi-k3':'sigma','bt-glm53':'sigma','bt-deepseek-v4-pro':'sigma'};
  function ali(id){return AL.hasOwnProperty(id)?AL[id]:id;}
  function demo(){return /[?&]demo=/.test(location.search)||D.documentElement.className.indexOf('demo-frame')>=0;}
  var hide=[],sel='sigma';
  try{var s0=localStorage.getItem(LS);if(s0&&AL.hasOwnProperty(s0)){s0=AL[s0];if(!demo())localStorage.setItem(LS,s0);}if(s0&&BY[s0])sel=s0;else if(s0&&!demo())localStorage.removeItem(LS);}catch(e){}
  function shown(id){return id==='sigma'||hide.indexOf(id)<0;}
  function cur(){return BY[sel]&&shown(sel)?sel:'sigma';}
  function mOf(id){return BY[id]||BY.sigma;}
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  // styles (no grid/gap/vars; works on old Chrome)
  var css='.aip{position:relative;flex:none;margin:.1rem .1rem .4rem;z-index:5}'+
    '.aip-btn{display:block;width:100%;text-align:left;padding:.45rem .7rem;border-radius:999px;border:2px solid #39ff88;background:rgba(27,24,22,.75);color:#f8f5f3;font:inherit;font-size:.86rem;font-weight:800;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;-webkit-tap-highlight-color:transparent}'+
    '.aip-btn b{color:#7dffb0}.aip-btn .aip-pt{display:inline-block;margin-left:.3rem;padding:.05rem .4rem;border-radius:999px;background:rgba(57,255,136,.18);font-size:.68rem;font-weight:900;vertical-align:.08em}'+
    '.aip-btn .aip-car{float:right;margin-left:.3rem}'+
    '.aip-list{position:absolute;left:0;right:0;top:100%;margin-top:.3rem;max-height:62vh;overflow-y:auto;-webkit-overflow-scrolling:touch;padding:.35rem;border-radius:1rem;border:2px solid #39ff88;background:#12100f;box-shadow:0 10px 30px rgba(0,0,0,.6)}'+
    '.aip-h{margin:.15rem .3rem .35rem;font-size:.72rem;font-weight:900;letter-spacing:.06em;text-transform:uppercase;color:#7dffb0}'+
    '.aip-g{position:-webkit-sticky;position:sticky;top:-.35rem;z-index:1;margin:.35rem 0 .3rem;padding:.3rem .4rem;font-size:.74rem;font-weight:900;letter-spacing:.04em;color:#7dffb0;background:#12100f;border-bottom:1px solid rgba(57,255,136,.3);box-shadow:0 -.45rem 0 #12100f}.aip-g small{opacity:.7;font-weight:800}.aip-cnt{display:inline-block;margin-left:.35rem;padding:.08rem .5rem;border-radius:999px;background:rgba(57,255,136,.18);letter-spacing:.02em;text-transform:none;font-size:.7rem;vertical-align:.05em}html.ui-legacy .aip-cnt{background:#f4f1ed;color:#933914}'+
    'html.ui-legacy .aip-g{color:#933914;background:#fafaf9;border-bottom-color:#ebe4de;box-shadow:0 -.45rem 0 #fafaf9}'+
    '.aip-gb{display:block;width:100%;text-align:left;border:0;border-bottom:1px solid rgba(57,255,136,.3);border-radius:0;font-family:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent;text-transform:none;font-size:.82rem;padding:.5rem .45rem;min-height:2.3rem}.aip-gb .aip-ar{display:inline-block;width:1em;text-align:center}'+
    '.aip-gn{display:inline-block;margin-left:.3rem;padding:.04rem .45rem;border-radius:999px;background:rgba(57,255,136,.18);font-size:.7rem;font-weight:900}.aip-gi{padding:.3rem 0 .1rem}'+
    '.aip-sub{margin-left:.55rem}.aip-sub .aip-gb{position:static;font-size:.76rem;min-height:2rem;padding:.35rem .4rem;box-shadow:none}'+
    '.aip-pxw{margin:.2rem 0 .4rem;padding:0 .3rem .2rem;border:2px dashed rgba(252,200,166,.65);border-radius:.9rem}.aip-pxw>.aip-f>.aip-gb{color:#ffe5d4;background:transparent;box-shadow:none;position:static;border-bottom-color:rgba(252,200,166,.4)}'+
    '.aip-o.aip-px{border-color:rgba(252,200,166,.35);background:rgba(252,200,166,.07)}.aip-o.aip-px.on{border-color:#fcc8a6;background:rgba(252,200,166,.22)}.aip-o.aip-px .aip-pt{background:rgba(252,200,166,.25)}.aip-o.aip-sign{border-style:dashed;border-color:#fcc8a6}.aip-o.aip-off .aip-n{font-size:.82rem}'+
    '.aip-sr{margin:0 .1rem .35rem}.aip-q{display:block;width:100%;box-sizing:border-box;font:inherit;font-size:16px;padding:.4rem .7rem;border-radius:999px;border:2px solid rgba(57,255,136,.45);background:rgba(0,0,0,.35);color:#f8f5f3;-webkit-appearance:none;appearance:none}.aip-q::placeholder{color:rgba(248,245,243,.6)}'+
    'html.ui-legacy .aip-gn{background:#f4f1ed;color:#933914}html.ui-legacy .aip-q{background:#ffffff;color:#403a35;border-color:#fcc8a6}html.ui-legacy .aip-q::placeholder{color:#ee7d45}html.ui-legacy .aip-pxw>.aip-f>.aip-gb{color:#b8481a}html.ui-legacy .aip-o.aip-px{background:#faf8f7;border-color:#ffe5d4;color:#464039}'+
    '.aip-o{display:block;width:100%;text-align:left;margin:0 0 .3rem;padding:.45rem .6rem;border-radius:.8rem;border:2px solid rgba(57,255,136,.25);background:rgba(57,255,136,.06);color:#f8f5f3;font:inherit;cursor:pointer;-webkit-tap-highlight-color:transparent}'+
    '.aip-o.on{border-color:#39ff88;background:rgba(57,255,136,.2)}'+
    '.aip-o .aip-n{display:block;font-weight:900;font-size:.92rem;line-height:1.2}.aip-o .aip-v{display:block;font-size:.76rem;font-weight:700;opacity:.85;line-height:1.25}'+
    '.aip-o .aip-pt{display:inline-block;margin-left:.3rem;padding:.05rem .4rem;border-radius:999px;background:rgba(57,255,136,.18);font-size:.66rem;font-weight:900;vertical-align:.1em}'+
    '.aip-o .aip-ck{float:right;font-weight:900;color:#39ff88}'+
    '.aip-note{margin:.2rem .3rem .1rem;font-size:.7rem;font-weight:700;opacity:.75;color:#f8f5f3}'+
    '.aip-tag{display:block;margin-top:.3rem;font-size:.68rem;font-weight:900;opacity:.75;letter-spacing:.02em}'+
    '.aip-tag.fell{opacity:.9;color:#ffe5d4}'+
    '.aip-new{display:inline-block;margin-left:.3rem;padding:.02rem .35rem;border-radius:999px;background:#ee7d45;color:#ffffff;font-size:.6rem;font-weight:900;letter-spacing:.04em;vertical-align:.1em}'+
    'html.ui-legacy .aip-btn{border-color:#fcc8a6;background:#ffffff;color:#6f2c10}html.ui-legacy .aip-btn b{color:#756b60}html.ui-legacy .aip-btn .aip-pt,html.ui-legacy .aip-o .aip-pt{background:#f4f1ed;color:#933914}'+
    'html.ui-legacy .aip-list{border-color:#fcc8a6;background:#fafaf9;box-shadow:0 10px 30px rgba(69,63,57,.25)}html.ui-legacy .aip-h{color:#933914}'+
    'html.ui-legacy .aip-o{border-color:#ebe4de;background:#ffffff;color:#403a35}html.ui-legacy .aip-o.on{border-color:#2fa84f;background:#fbf9f8}html.ui-legacy .aip-o .aip-ck{color:#2fa84f}'+
    'html.ui-legacy .aip-note{color:#403a35}html.ui-legacy .aip-tag.fell{color:#b8481a}'+
    '.aip-dot{display:inline-block;width:.62rem;height:.62rem;border-radius:50%;margin:0 .35rem 0 0;vertical-align:.03em;background:#938a80;border:1px solid rgba(0,0,0,.35)}'+
    '.aip-dot.g{background:#2bff6e;box-shadow:0 0 5px #2bff6e}.aip-dot.r{background:#ff4b4b;box-shadow:0 0 5px #ff4b4b}.aip-dot.w{background:#d9d5d2}.aip-dot.x{display:none}'+
    '.aip-st{font-weight:900;white-space:nowrap}.aip-st.g{color:#5dff95}.aip-st.r{color:#ff8a8a}.aip-st.w{opacity:.7}'+
    'html.ui-legacy .aip-st.g{color:#138a3d}html.ui-legacy .aip-st.r{color:#c62828}html.ui-legacy .aip-dot.w{background:#c7c2bd}'+
    '.aip-adm{margin:.6rem 0 0;padding:.55rem .65rem;border-radius:.9rem;border:2px dashed rgba(252,200,166,.6)}'+
    '.aip-adm .aip-ar{display:block;margin:.25rem 0;font-weight:800;font-size:.86rem;cursor:pointer}.aip-adm input{margin-right:.4rem;vertical-align:-.1em}'+
    'html.hcf .aip-gn{background:#f5f2ef;color:#933914}html.hcf .aip-q{background:#ffffff;color:#201d1a;border:1px solid #fcc8a6}html.hcf .aip-q::placeholder{color:#b8481a}html.hcf .aip-gb{border-bottom-color:#ffe5d4}'+
    'html.hcf .aip-pxw{border-color:#fcc8a6;background:#fbfaf9}html.hcf .aip-pxw>.aip-f>.aip-gb{color:#b8481a}html.hcf .aip-o.aip-px{background:#faf8f7;border-color:#ffe5d4;color:#201d1a}html.hcf .aip-o.aip-px.on{border-color:#ee7d45;background:#f3eeea}html.hcf .aip-o.aip-px .aip-pt{background:#ffe5d4;color:#933914}html.hcf .aip-o.aip-sign{border-color:#ee7d45}'+
    'html.hw.hcf .aip-gb{color:#fcc8a6;border-bottom-color:#342f2b}html.hw.hcf .aip-gn{background:#312c28;color:#ffe5d4}html.hw.hcf .aip-q{background:#1c1a17;color:#f0ebe7;border-color:#3b3530}html.hw.hcf .aip-q::placeholder{color:#ee7d45}'+
    'html.hw.hcf .aip-pxw{background:transparent;border-color:#dd5e22}html.hw.hcf .aip-pxw>.aip-f>.aip-gb{color:#f6a274}html.hw.hcf .aip-o.aip-px{background:#1e1b19;border-color:#4c453e;color:#f0ebe7}html.hw.hcf .aip-o.aip-px.on{border-color:#ee7d45;background:#302b27}html.hw.hcf .aip-o.aip-px .aip-pt{background:#39342e;color:#ffe5d4}html.hw.hcf .aip-o.aip-sign{border-color:#ee7d45}'+
    '@media (max-width:240px){.aip-g{font-size:.62rem;padding:.2rem .3rem;margin:.25rem 0 .2rem}.aip{margin:.05rem 0 .25rem}.aip-btn{font-size:.7rem;padding:.3rem .5rem}.aip-btn .aip-pt{display:none}.aip-o{padding:.3rem .45rem}.aip-o .aip-n{font-size:.78rem}.aip-o .aip-v{font-size:.64rem}.aip-o .aip-pt{display:none}.aip-tag{font-size:.6rem}.aip-st{display:none}.aip-lg{display:none}.aip-dot{width:.5rem;height:.5rem;margin-right:.25rem}}'+
    '@media (max-height:420px){.aip{margin:.05rem .1rem .25rem}.aip-btn{padding:.3rem .65rem;font-size:.8rem}.aip-list{max-height:70vh}}';
  var st=D.createElement('style');st.appendChild(D.createTextNode(css));(D.head||D.documentElement).appendChild(st);
  var bar,btn,list;
  function label(){var m=mOf(cur());btn.innerHTML='\uD83E\uDDE0 Model: <b>'+esc(m.n)+flagOf(m)+'</b><span class="aip-pt">'+esc(m.p)+'</span><span class="aip-car" aria-hidden="true">\u25BE</span>';btn.setAttribute('aria-label','Tabo AI model: '+m.n+' ('+m.p+'). Tap to change');}
  // v1.8: grouped by BRAND (who made it), each group a tap-to-open folder (open/closed remembered on this device), plus a search box.
  // The provider (who runs it) still shows as the small tag on each model. GR is kept for the admin hide list below.
  var GR=[['Kilo','💜 Kilo Auto Free'],['LLMFaucet','⚡ Free Model Router'],['AI Horde','🌐 AI Horde'],['*','🔓 No key needed']];
  function grp(p){for(var g=0;g<GR.length-1;g++)if(GR[g][0]===p)return g;return GR.length-1;}
  function groups(){var out=[],g,i;for(g=0;g<GR.length;g++)out.push([]);for(i=0;i<M.length;i++)out[grp(M[i].p)].push(M[i]);return out;}
  var BR=[['hc','💜 Tabo (default)'],['other','🌐 Free model gateways']];
  var BRX=[['openai',/\bgpt|openai|\bo[134](-|\b)/],['anthropic',/claude|anthropic/],['google',/gemma|gemini|google/],['meta',/llama|\bmuse\b|meta-/],['mistral',/mistral|ministral|codestral|devstral|magistral|pixtral/],
    ['qwen',/qwen|qwq|alibaba/],['deepseek',/deepseek|\br1\b|cf-r1/],['nvidia',/nemotron|\bnemo-|nvidia/],['xai',/grok|\bxai\b/],['moonshot',/kimi|moonshot/],['zai',/\bglm|z ai|zai-/],['minimax',/minimax/],['cohere',/command|\baya\b|tiny-aya|\bnorth\b|cohere/],['lg',/exaone|\blg-/]];
  function brandOf(m){if(m.id==='sigma')return 'hc';if(m.b)return m.b;var s=(m.id+' '+m.n).toLowerCase();for(var i=0;i<BRX.length;i++)if(BRX[i][1].test(s))return BRX[i][0];return 'other';}
  for(var bi=0;bi<M.length;bi++)M[bi].b=brandOf(M[bi]);
  // v2.9.3: country flag after each AI's name (the user, Nov 9)
  var FLB={hc:'\uD83C\uDDFA\uD83C\uDDF8',openai:'\uD83C\uDDFA\uD83C\uDDF8',anthropic:'\uD83C\uDDFA\uD83C\uDDF8',google:'\uD83C\uDDFA\uD83C\uDDF8',meta:'\uD83C\uDDFA\uD83C\uDDF8',nvidia:'\uD83C\uDDFA\uD83C\uDDF8',xai:'\uD83C\uDDFA\uD83C\uDDF8',mistral:'\uD83C\uDDEB\uD83C\uDDF7',qwen:'\uD83C\uDDE8\uD83C\uDDF3',deepseek:'\uD83C\uDDE8\uD83C\uDDF3',moonshot:'\uD83C\uDDE8\uD83C\uDDF3',zai:'\uD83C\uDDE8\uD83C\uDDF3',minimax:'\uD83C\uDDE8\uD83C\uDDF3',cohere:'\uD83C\uDDE8\uD83C\uDDE6',lg:'\uD83C\uDDF0\uD83C\uDDF7'};
  var FLI={'lfm-mini':'\uD83C\uDDFA\uD83C\uDDF8','allam':'\uD83C\uDDF8\uD83C\uDDE6','step-5':'\uD83C\uDDE8\uD83C\uDDF3','cf-granite':'\uD83C\uDDFA\uD83C\uDDF8','cf-sealion-27b':'\uD83C\uDDF8\uD83C\uDDEC','or-dots3':'\uD83C\uDDE8\uD83C\uDDF3','kilo-ling31-flash':'\uD83C\uDDE8\uD83C\uDDF3','ax-mimo-v26-flash':'\uD83C\uDDE8\uD83C\uDDF3'};
  function flagOf(m){var f=FLI[m.id]||FLB[m.b]||'';return f?' '+f:'';}
  var OK='hc_aip_open',OPN={};try{OPN=JSON.parse(localStorage.getItem(OK)||'{}')||{};}catch(e){OPN={};}
  function isOpen(k){if(OPN.hasOwnProperty(k))return !!OPN[k];var m=mOf(cur());return k==='hc'||k==='lg'||k===m.b;}
  function setOpen(k,v){OPN[k]=!!v;try{localStorage.setItem(OK,JSON.stringify(OPN));}catch(e){}}
  var Q='';
  function hit(m,q){if(!q)return true;return (m.n+' '+m.p+' '+(m.id||'')+' '+m.bl).toLowerCase().indexOf(q)>=0;}
  function opt(m,c,px){return '<button type="button" class="aip-o'+(m.id===c?' on':'')+(px?' aip-px':'')+'" role="option" aria-selected="'+(m.id===c)+'" data-aim="'+esc(m.id)+'">'+(m.id===c?'<span class="aip-ck">\u2713</span>':'')+
    '<span class="aip-n">'+(px?'':'<span class="aip-dot x" data-aid="'+m.id+'"></span>')+esc(m.n)+flagOf(m)+(m.nw?'<span class="aip-new">NEW</span>':'')+'<span class="aip-pt">'+esc(m.p)+'</span></span><span class="aip-v">'+m.v+(px?'':'<span class="aip-st" data-ais="'+m.id+'"></span>')+'</span></button>';}
  function folder(k,title,n,body,sub,forced){var o=forced||isOpen(k);
    return '<div class="aip-f'+(sub?' aip-sub':'')+(o?' open':'')+'"><button type="button" class="aip-g aip-gb" data-gk="'+esc(k)+'" aria-expanded="'+o+'"><span class="aip-ar" aria-hidden="true">'+(o?'\u25BE':'\u25B8')+'</span> '+title+' <span class="aip-gn">'+n+'</span></button>'+
      (o?'<div class="aip-gi">'+body+'</div>':'')+'</div>';}
  function render(keep){var c=cur(),q=Q.toLowerCase().replace(/^\s+|\s+$/g,''),n=0,h='',i,g,B={},bl={};
    for(i=0;i<BR.length;i++){B[BR[i][0]]=[];bl[BR[i][0]]=BR[i][1];}
    for(i=0;i<M.length;i++){var m=M[i];if(!shown(m.id))continue;n++;m.bl=bl[m.b]||'';if(hit(m,q))B[m.b].push(m);}
    for(g=0;g<BR.length;g++){var k=BR[g][0],L=B[k];if(!L.length)continue;var body='';for(i=0;i<L.length;i++)body+=opt(L[i],c);h+=folder(k,BR[g][1],L.length,body,0,!!q);}
    if(!h)h='<p class="aip-note aip-none">No AI matches \u201C'+esc(Q)+'\u201D</p>';
    var top=list.scrollTop;
    if(!list.querySelector('.aip-body'))list.innerHTML='<p class="aip-h">\uD83E\uDDE0 Pick your AI model <span class="aip-cnt"></span></p><div class="aip-sr"><input type="search" class="aip-q" placeholder="\uD83D\uDD0D Find an AI or brand" aria-label="Find an AI or brand" autocomplete="off" enterkeyhint="search"></div><div class="aip-body"></div>';
    list.querySelector('.aip-body').innerHTML=h+
      '<p class="aip-note">Free models can get busy. Tabo tries the backup gateway automatically.</p><p class="aip-note">Don\'t enter passwords, addresses, school details, or other private information.</p><p class="aip-note aip-lg" hidden>\uD83D\uDFE2 free rn \u2022 \uD83D\uDD34 busy last try \u2022 \u26AA not checked lately</p>';
    var ct=list.querySelector('.aip-cnt');if(ct)ct.innerHTML='\uD83D\uDC9C '+n+' models';
    if(keep)list.scrollTop=top;else{var on=list.querySelector('.aip-o.on');if(on&&on.offsetTop+on.offsetHeight>list.clientHeight)list.scrollTop=Math.max(0,on.offsetTop-60);}
    paintDots();}
  function open(on){list.hidden=!on;btn.setAttribute('aria-expanded',on?'true':'false');if(on){render();loadHide();fit();stPoll(true);}else stStop();}
  // v3.0.7 live status dots: the server remembers how each model did on its last real try (or a tiny check) and says so here.
  // green = worked in the last ~10 min, red = busy/failed on its last try, white = not checked lately. Offline -> no dots.
  var ST=null,stAt=0,stT=null,stT2=null;
  function ago(s){s=Math.max(0,Math.round(s));return s<60?'just now':s<3600?Math.floor(s/60)+'m ago':Math.floor(s/3600)+'h ago';}
  function stOf(id){if(!ST)return null;var s=ST[id];if(!s||s.state==='none'||s.ageSec==null)return {c:'w',t:'not checked lately'};
    var a=s.ageSec+(new Date().getTime()-stAt)/1000;
    if(s.state==='ok')return a<=600?{c:'g',t:(a<120?'free rn':'worked '+ago(a))+((s.slow||(BY[id]&&BY[id].slow))&&s.ms>6000?' (slow but ok)':'')}:{c:'w',t:'not checked lately'};
    if(a>1800)return {c:'w',t:'not checked lately'};
    if(s.lim)return {c:'r',t:'daily limit hit'};
    return {c:'r',t:(s.state==='timeout'?'too slow ':s.state==='busy'?'busy ':'failed ')+ago(a)};}
  function paintDots(){if(!list)return;var ds=list.querySelectorAll('[data-aid]'),i,k;
    for(i=0;i<ds.length;i++){k=stOf(ds[i].getAttribute('data-aid'));ds[i].className='aip-dot '+(k?k.c:'x');if(k)ds[i].setAttribute('title',k.t);else ds[i].removeAttribute('title');}
    ds=list.querySelectorAll('[data-ais]');
    for(i=0;i<ds.length;i++){k=stOf(ds[i].getAttribute('data-ais'));ds[i].className='aip-st'+(k?' '+k.c:'');ds[i].innerHTML=k?' \u2022 '+esc(k.t):'';}
    var lg=list.querySelector('.aip-lg');if(lg)lg.hidden=!ST;}
  function stLoad(probe){if(!window.fetch)return;
    fetch('/api/ai/status'+(probe?'?probe=1':''),{cache:'no-store'}).then(function(r){if(!r.ok)throw 0;return r.json();}).then(function(j){
      if(!j||!j.models)throw 0;ST=j.models;stAt=new Date().getTime();paintDots();
      if(probe&&j.probing>0&&list&&!list.hidden){clearTimeout(stT2);stT2=setTimeout(function(){if(list&&!list.hidden)stLoad(false);},8000);}
    })['catch'](function(){ST=null;paintDots();});}
  function stPoll(first){clearTimeout(stT);stLoad(first);stT=setTimeout(function(){if(list&&!list.hidden)stPoll(false);},30000);}
  function stStop(){clearTimeout(stT);clearTimeout(stT2);stT=stT2=null;}
  function fit(){try{list.style.maxHeight='';var r=list.getBoundingClientRect(),vh=window.innerHeight||D.documentElement.clientHeight;var mh=Math.floor(vh-r.top-8);if(r.bottom>vh-8)list.style.maxHeight=Math.max(100,mh)+'px';}catch(e){}}
  function pick(id){id=ali(id);if(!BY[id])return;sel=id;if(!demo()){try{localStorage.setItem(LS,id);}catch(e){}}label();chPaint();open(false);try{if(window.domoHaptic)window.domoHaptic('select');}catch(e){}}
  var hideAt=0;
  function setHide(a){hide=[];if(a&&a.length)for(var i=0;i<a.length;i++)if(BY[a[i]]&&a[i]!=='sigma')hide.push(a[i]);if(btn){label();if(!list.hidden)render();}}
  function loadHide(){var now=new Date().getTime();if(now-hideAt<20000||!window.fetch)return;hideAt=now;
    fetch('/api/site/settings',{cache:'no-store'}).then(function(r){return r.json();}).then(function(j){if(j&&j.settings)setHide(j.settings.aiHide);})['catch'](function(){});}
  function mount(){var c=D.getElementById('chat'),log=D.getElementById('log');if(!c||!log||D.getElementById('aip'))return;
    bar=D.createElement('div');bar.className='aip';bar.id='aip';
    bar.innerHTML='<button type="button" class="aip-btn" aria-haspopup="listbox" aria-expanded="false"></button><div class="aip-list" role="listbox" aria-label="Tabo AI models" hidden></div>';
    log.parentNode.insertBefore(bar,log);btn=bar.firstChild;list=bar.lastChild;label();
    btn.addEventListener('click',function(e){e.stopPropagation();open(list.hidden);});
    list.addEventListener('click',function(e){e.stopPropagation();var t=e.target;
      while(t&&t!==list&&!(t.getAttribute('data-aim')||t.getAttribute('data-gk')))t=t.parentNode;if(!t||t===list)return;
      var gk=t.getAttribute('data-gk');if(gk){if(Q){return;}setOpen(gk,!isOpen(gk));render(true);try{if(window.domoHaptic)window.domoHaptic('select');}catch(x){}return;}
      pick(t.getAttribute('data-aim'));});
    list.addEventListener('input',function(e){var t=e.target;if(t&&t.className==='aip-q'){Q=t.value||'';render(true);if(!Q)list.scrollTop=0;}});
    D.addEventListener('click',function(){if(list&&!list.hidden)open(false);});
    D.addEventListener('keydown',function(e){if((e.key==='Escape'||e.keyCode===27)&&list&&!list.hidden){open(false);if(e.stopPropagation)e.stopPropagation();}},true);
    var ob=D.getElementById('open-chat');if(ob)ob.addEventListener('click',loadHide);
    // The keyless engine handles fallback between Kilo and AI Horde automatically.
  }
  // the tiny "which model answered" line under each AI reply
  function tag(j){if(!j||!j.reply)return '';var a=BY[j.ai]||BY.sigma;var t='<span class="aip-tag'+(j.fell?' fell':'')+'">';
    if(j.fell){var b=j.busy&&j.busy.length?j.busy:[j.asked],w=BY[b[0]]?BY[b[0]].n:'That model',x=b.length>1?' (+'+(b.length-1)+' more)':'';
      return t+esc(w)+x+' was busy \u2192 answered by '+(j.chain_hop?'\uD83D\uDD17 ':'')+a.e+' '+esc(a.n)+(j.who?' ('+esc(j.who)+')':'')+' \u2022 '+esc(j.via?j.via+' (backup)':a.p)+'</span>';} // v3.0.6: next-smartest fallback
    t+=a.e+' '+esc(a.n)+(j.who?' ('+esc(j.who)+')':'')+' \u2022 '+esc(j.via?j.via+' (backup)':a.p);if(j.hidden)t+=' \u2022 (that model is off right now)';return t+'</span>';}
  // admin: show/hide each model for everyone, inside the admin panel's Customize tab (saved with the site settings when he taps Save)
  var oc=window.domoCustom;
  if(typeof oc==='function'){window.domoCustom=function(box,say,call){oc(box,say,call);try{adminSection(box);}catch(e){}};}
  function adminSection(box){var get=box._czd;if(typeof get!=='function')return;var pnl=box.querySelector('.cz-panel')||box;
    var sec=D.createElement('div');sec.className='aip-adm';sec.id='aip-adm';pnl.appendChild(sec);
    var sv=box.querySelector('#cz-save');if(sv&&sv.parentNode&&sv.parentNode.parentNode===pnl){pnl.insertBefore(sec,sv.parentNode);}else if(sv&&sv.parentNode===pnl){pnl.insertBefore(sec,sv);}
    function paint(){var d=get();if(!d)return;if(!d.aiHide||!d.aiHide.length)d.aiHide=d.aiHide&&d.aiHide.slice?d.aiHide:[];
      var h='<p class="cz-lbl">\uD83D\uDC9C Tabo AI models (for everyone)</p>';
      var G=groups();for(var g=0;g<G.length;g++){if(G[g].length)h+='<p class="aip-g" style="position:static;background:none">'+GR[g][1]+'</p>';
      for(var i=0;i<G[g].length;i++){var m=G[g][i],on=m.id==='sigma'||d.aiHide.indexOf(m.id)<0;
        h+='<label class="aip-ar"><input type="checkbox" data-aih="'+m.id+'"'+(on?' checked':'')+(m.id==='sigma'?' disabled':'')+'>'+m.e+' '+esc(m.n)+' <small>('+esc(m.p)+(m.id==='sigma'?', always on':'')+')</small></label>';}}
      h+='<p class="aip-note" style="opacity:.8">Untick to hide a model from the picker. Tap Save to apply.</p>';sec.innerHTML=h;}
    sec.addEventListener('change',function(e){var t=e.target,id=t&&t.getAttribute('data-aih');if(!id||id==='sigma')return;var d=get();if(!d)return;
      var a=(d.aiHide||[]).slice(),k=a.indexOf(id);if(t.checked){if(k>=0)a.splice(k,1);}else if(k<0)a.push(id);d.aiHide=a;});
    paint();
    if(sv)sv.addEventListener('click',function(){setTimeout(paint,1800);setTimeout(function(){paint();var d=get();if(d)setHide(d.aiHide);hideAt=0;},5000);});
    var rs=box.querySelector('#cz-reset');if(rs)rs.addEventListener('click',function(){setTimeout(paint,2500);});
  }

  // Tabo v2.9.5 \uD83D\uDD17 Backup order (the user, Nov 9 9:32 PM): pick up to 5 models to try next (in order) when yours is busy.
  // Saved on this device (localStorage hc_ai_chain). The server checks every id again and keeps all its limits + the Shield. ES5, no drag (iPad).
  var CK='hc_ai_chain',CMAX=5,ch=null,chLine=null,chBtn=null;
  function chLoad(){var o=null;try{o=JSON.parse(localStorage.getItem(CK)||'null');}catch(e){o=null;}
    var l=[],a=true;if(o&&typeof o==='object'){if(o.a===false)a=false;var s=o.l&&o.l.length?o.l:[];for(var i=0;i<s.length&&l.length<CMAX;i++){var id=ali(s[i]);if(BY[id]&&l.indexOf(id)<0)l.push(id);}}
    return {l:l,a:a};}
  function chSave(c){try{if(!c.l.length&&c.a)localStorage.removeItem(CK);else localStorage.setItem(CK,JSON.stringify({l:c.l,a:c.a}));}catch(e){}}
  function chGet(){var c=chLoad(),p=cur(),l=[];for(var i=0;i<c.l.length;i++)if(c.l[i]!==p&&shown(c.l[i]))l.push(c.l[i]);return {ids:l,auto:c.a};}
  function chName(id){var m=mOf(id);return m.e+' '+m.n+flagOf(m);}
  function chPaint(){if(!chLine)return;var g=chGet();
    if(!g.ids.length&&g.auto){chLine.hidden=true;chLine.innerHTML='';if(chBtn)chBtn.className='aip-chb';return;}
    var t=[];for(var i=0;i<g.ids.length;i++)t.push(esc(mOf(g.ids[i]).n));
    chLine.innerHTML='\uD83D\uDD17 Backups: '+(t.length?t.join(' \u2192 '):'none')+(g.auto?' <span class="aip-chau">\u2192 auto</span>':' <span class="aip-chau">(auto off)</span>');chLine.hidden=false;if(chBtn)chBtn.className='aip-chb on';}
  function chOpts(skip){var h='<option value="">\u2795 Add an AI\u2026</option>',bl={},B={},i,g;for(i=0;i<BR.length;i++){B[BR[i][0]]=[];bl[BR[i][0]]=BR[i][1];}
    for(i=0;i<M.length;i++){var m=M[i];if(!shown(m.id)||skip.indexOf(m.id)>=0)continue;(B[m.b]||B.other).push(m);}
    for(g=0;g<BR.length;g++){var L=B[BR[g][0]];if(!L.length)continue;h+='<optgroup label="'+esc(BR[g][1])+'">';for(i=0;i<L.length;i++)h+='<option value="'+esc(L[i].id)+'">'+esc(L[i].n+flagOf(L[i])+' \u2022 '+L[i].p)+'</option>';h+='</optgroup>';}
    return h;}
  function chRender(){if(!ch)return;var c=chLoad(),p=cur(),h='',i;
    h+='<p class="aip-chp">First: <b>'+esc(chName(p))+'</b>'+(BY[p]?' <small>(your pick)</small>':'')+'</p>';
    if(!c.l.length)h+='<p class="aip-chp aip-che">No backups yet. Add up to '+CMAX+' models below \uD83D\uDC47</p>';
    h+='<ol class="aip-chl">';
    for(i=0;i<c.l.length;i++){var id=c.l[i],off=id===p||!shown(id);
      h+='<li class="aip-chr'+(off?' off':'')+'"><span class="aip-chn"><b>'+(i+1)+'.</b> '+esc(chName(id))+(id===p?' <small>(that\u2019s your pick)</small>':(!shown(id)?' <small>(off right now)</small>':''))+'</span>'+
        '<button type="button" class="aip-chx" data-chu="'+i+'" aria-label="Move up"'+(i===0?' disabled':'')+'>\u25B2</button>'+
        '<button type="button" class="aip-chx" data-chd="'+i+'" aria-label="Move down"'+(i===c.l.length-1?' disabled':'')+'>\u25BC</button>'+
        '<button type="button" class="aip-chx aip-chdel" data-chr="'+i+'" aria-label="Remove">\u2715</button></li>';}
    h+='</ol>';
    if(c.l.length<CMAX){var sk=c.l.slice();sk.push(p);h+='<select class="aip-chs" aria-label="Add an AI to the backup order">'+chOpts(sk)+'</select>';}
    else h+='<p class="aip-chp aip-che">That\u2019s the max ('+CMAX+').</p>';
    h+='<label class="aip-cht"><input type="checkbox" class="aip-chauto"'+(c.a?' checked':'')+'><span>If all of these are busy, use the auto chain</span></label>';
    h+='<div class="aip-chf"><button type="button" class="aip-chbtn aip-chreset">\u21BA Reset to auto</button><button type="button" class="aip-chbtn aip-chok">\u2705 Done</button></div>';
    ch.querySelector('.aip-chbd').innerHTML=h;}
  function chOpen(v){if(!ch){ch=D.createElement('div');ch.className='aip-chm';ch.id='aip-chain';ch.setAttribute('role','dialog');ch.setAttribute('aria-modal','true');ch.setAttribute('aria-label','Backup order');
      ch.innerHTML='<div class="aip-chc"><div class="aip-chhd"><b>\uD83D\uDD17 Backup order</b><button type="button" class="aip-chx aip-chclose" aria-label="Close">\u2715</button></div><p class="aip-chsub">If your AI is busy, Tabo tries these next, in this order.</p><div class="aip-chbd"></div></div>';
      D.body.appendChild(ch);
      ch.addEventListener('click',function(e){var t=e.target;if(t===ch){chOpen(false);return;}
        while(t&&t!==ch&&t.nodeName!=='BUTTON')t=t.parentNode;if(!t||t===ch||t.disabled)return;var c=chLoad(),k,x;
        if(t.className.indexOf('aip-chclose')>=0||t.className.indexOf('aip-chok')>=0){chOpen(false);return;}
        if(t.className.indexOf('aip-chreset')>=0){c={l:[],a:true};}
        else if((k=t.getAttribute('data-chu'))!=null){k=+k;if(k>0){x=c.l[k-1];c.l[k-1]=c.l[k];c.l[k]=x;}}
        else if((k=t.getAttribute('data-chd'))!=null){k=+k;if(k<c.l.length-1){x=c.l[k+1];c.l[k+1]=c.l[k];c.l[k]=x;}}
        else if((k=t.getAttribute('data-chr'))!=null){c.l.splice(+k,1);}
        else return;
        chSave(c);chRender();chPaint();try{if(window.domoHaptic)window.domoHaptic('select');}catch(y){}});
      ch.addEventListener('change',function(e){var t=e.target,c=chLoad();
        if(t&&t.className==='aip-chs'){var id=t.value;if(id&&BY[id]&&c.l.indexOf(id)<0&&c.l.length<CMAX){c.l.push(id);chSave(c);}chRender();chPaint();}
        else if(t&&t.className==='aip-chauto'){c.a=!!t.checked;chSave(c);chPaint();}});
      D.addEventListener('keydown',function(e){if((e.key==='Escape'||e.keyCode===27)&&ch&&!ch.hidden)chOpen(false);},true);}
    if(v){if(list&&!list.hidden)open(false);chRender();ch.hidden=false;}else{ch.hidden=true;if(chBtn)try{chBtn.focus();}catch(e){}}}
  function chMount(){if(!bar||D.getElementById('aip-chb'))return;
    chBtn=D.createElement('button');chBtn.type='button';chBtn.className='aip-chb';chBtn.id='aip-chb';chBtn.innerHTML='\uD83D\uDD17 <span>Backup order</span>';chBtn.setAttribute('aria-label','Backup order: pick which models to try next if yours is busy');
    chLine=D.createElement('p');chLine.className='aip-chline';chLine.id='aip-chline';chLine.hidden=true;
    bar.appendChild(chBtn);bar.appendChild(chLine);
    chBtn.addEventListener('click',function(e){e.stopPropagation();chOpen(true);});
    chLine.addEventListener('click',function(e){e.stopPropagation();chOpen(true);});
    chPaint();}
  var chCss='.aip-chb{display:inline-block;margin:.3rem .2rem 0 0;min-height:40px;padding:.35rem .8rem;border-radius:999px;border:2px solid rgba(125,255,176,.55);background:rgba(27,24,22,.6);color:#f8f5f3;font:inherit;font-size:.8rem;font-weight:800;cursor:pointer;-webkit-tap-highlight-color:transparent}'+
    '.aip-chb.on{border-color:#39ff88;background:rgba(57,255,136,.22)}.aip-chline{margin:.25rem .3rem 0;font-size:.74rem;font-weight:700;color:#bfffd8;line-height:1.3;cursor:pointer;word-wrap:break-word}.aip-chline .aip-chau{opacity:.7;font-weight:600}'+
    '.aip-chm{position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483000;background:rgba(0,0,0,.55);display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;padding:12px}'+
    '.aip-chm[hidden]{display:none}.aip-chc{width:100%;max-width:460px;max-height:90%;overflow-y:auto;-webkit-overflow-scrolling:touch;background:#221f1c;border:2px solid #39ff88;border-radius:18px;padding:14px;color:#faf9f7;box-shadow:0 10px 40px rgba(0,0,0,.5);text-align:left}'+
    '.aip-chhd{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:justify;-webkit-justify-content:space-between;justify-content:space-between;font-size:1.05rem}'+
    '.aip-chsub{margin:.3rem 0 .6rem;font-size:.82rem;opacity:.85}.aip-chp{margin:.3rem 0;font-size:.85rem}.aip-che{opacity:.75}'+
    '.aip-chl{list-style:none;margin:.4rem 0;padding:0}.aip-chr{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;margin:0 0 6px;padding:4px 4px 4px 10px;border-radius:12px;background:rgba(57,255,136,.12)}'+
    '.aip-chr.off{opacity:.55}.aip-chn{-webkit-box-flex:1;-webkit-flex:1;flex:1;min-width:0;font-size:.88rem;word-wrap:break-word}'+
    '.aip-chx{-webkit-flex:none;flex:none;width:42px;height:42px;margin-left:4px;border-radius:10px;border:1px solid rgba(125,255,176,.5);background:rgba(0,0,0,.25);color:#f8f5f3;font-size:1rem;font-weight:900;cursor:pointer;-webkit-tap-highlight-color:transparent;padding:0}'+
    '.aip-chx[disabled]{opacity:.3;cursor:default}.aip-chdel{color:#ffb3b3;border-color:rgba(255,140,140,.55)}'+
    '.aip-chs{display:block;width:100%;min-height:44px;margin:.4rem 0;padding:0 10px;border-radius:12px;border:2px solid #39ff88;background:#36312c;color:#faf9f7;font:inherit;font-size:16px}'+
    '.aip-cht{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;min-height:44px;margin:.4rem 0;font-size:.86rem;cursor:pointer}.aip-cht input{width:26px;height:26px;margin:0 10px 0 2px;-webkit-flex:none;flex:none;accent-color:#39ff88}'+
    '.aip-chf{display:-webkit-box;display:-webkit-flex;display:flex;margin-top:.5rem}.aip-chbtn{-webkit-box-flex:1;-webkit-flex:1;flex:1;min-height:44px;margin:0 4px;border-radius:999px;border:2px solid #39ff88;background:rgba(57,255,136,.18);color:#faf9f7;font:inherit;font-size:.88rem;font-weight:800;cursor:pointer}'+
    '.aip-chreset{border-color:rgba(252,200,166,.7);background:rgba(252,200,166,.12)}'+
    'html.hcf .aip-chb{background:#ffffff;border:1px solid #e8e1d9;color:#342f2a;border-radius:14px}html.hcf .aip-chb.on{background:#f0ebe7;border-color:#f6a274;color:#6f2c10}html.hcf .aip-chline{color:#6f2c10}'+
    'html.hcf .aip-chm{background:rgba(41,37,33,.35)}html.hcf .aip-chc{background:#ffffff;border:2px solid #fcc8a6;color:#292521;box-shadow:0 12px 40px rgba(74,30,11,.25)}html.hcf .aip-chr{background:#f5f2ee}'+
    'html.hcf .aip-chx{background:#ffffff;border-color:#dacec2;color:#4a1e0b}html.hcf .aip-chdel{color:#933914;border-color:#e1d8ce}html.hcf .aip-chs{background:#ffffff;border-color:#f6a274;color:#292521}'+
    'html.hcf .aip-cht input{accent-color:#933914}html.hcf .aip-chbtn{background:#933914;border-color:#933914;color:#ffffff}html.hcf .aip-chreset{background:#ffffff;border-color:#dacec2;color:#6f2c10}';
  var chSt=D.createElement('style');chSt.appendChild(D.createTextNode(chCss));(D.head||D.documentElement).appendChild(chSt);
  window.domoAI={brandName:function(b){for(var k=0;k<BR.length;k++)if(BR[k][0]===b)return BR[k];return null;},model:cur,models:M,tag:tag,brands:function(){return BR.slice();},slow:function(id){return !!(BY[id]&&BY[id].slow);},pick:pick,open:function(){if(list)open(true);},setHide:setHide,flag:flagOf,chain:function(){return {ids:[],auto:false};},chainOpen:function(){}};
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',mount);else mount();
})();
