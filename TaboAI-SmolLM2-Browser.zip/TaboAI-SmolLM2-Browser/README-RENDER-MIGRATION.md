# Tabo AI deployment notes

This package combines the full keyless Railway project with the Render startup-layout fix. The `start` script runs `prepare-public.js` before the Node server. That helper repairs a flattened frontend upload when needed and publishes the installed wllama browser runtime into `public/wllama/esm`.

The model picker now includes **SmolLM2 135M (on-device)**. It downloads the approximately 91.7 MB Q4_K_M GGUF from Hugging Face on first selection; the browser caches it for later visits. Chat generation runs in the browser, while prompts, optional personality/memory context, and generated answers are sent to Tabo's server and Safety Shield providers for moderation. This is not fully offline/private chat.

For Render, use Node.js 22+, install dependencies with `npm install`, and start with `npm start`. Do not remove `prepare-public.js` or the `@wllama/wllama` dependency. After deploying, open the model picker and choose **On this device → SmolLM2 135M**. The model weights are fetched only on first use; they are not bundled into this ZIP.
