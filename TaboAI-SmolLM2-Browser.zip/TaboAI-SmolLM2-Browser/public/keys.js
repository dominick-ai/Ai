/* keys.js (Tabo AI v2.5): full keyboard control for keyboards with no mouse (iPad Magic Keyboard, Chromebook, PC).
   One global shortcut layer + ? cheat sheet + skip link + focus rings (:focus-visible only, never on tap) + focus trap in pop-ups.
   Shortcuts never fire while you type, except Esc and Cmd/Ctrl combos. On iPad both Cmd and Ctrl work. ES5 only.
   Secret areas (Dev Lab, Music Studio) have NO shortcut; they are only reachable by tabbing to their buttons. */
(function(){
  var W=window,D=document;if(W.hcKeys)return;
  function $(id){return D.getElementById(id);}
  function has(el,c){return !!(el&&el.className&&typeof el.className==='string'&&(' '+el.className+' ').indexOf(' '+c+' ')>=0);}
  function isApp(){return !!$('chat');}
  var mac=/Mac|iPhone|iPad|iPod/.test(navigator.platform||'')||(/Macintosh/.test(navigator.userAgent||'')&&'ontouchend' in D);
  var MOD=mac?'\u2318':'Ctrl';

  /* ---------- look: focus rings for keyboard users only ---------- */
  var css='.kb-skip{position:fixed;left:12px;top:-80px;z-index:2147483000;padding:10px 16px;border-radius:14px;background:#b8481a;color:#ffffff!important;font:700 15px/1.2 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;text-decoration:none;box-shadow:0 6px 20px rgba(184,72,26,.4)}'+
    '.kb-skip:focus{top:10px;outline:3px solid #ffffff;outline-offset:2px}'+
    '.kb-tipbtn{background:none;border:0;padding:0 2px;font-size:inherit;cursor:pointer;vertical-align:baseline;border-radius:6px}'+
    '.kb-ov{position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147482000;background:rgba(27,25,22,.45);display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;padding:12px;-webkit-animation:kbIn .18s ease;animation:kbIn .18s ease}'+
    '.kb-ov[hidden]{display:none}'+
    '@-webkit-keyframes kbIn{from{opacity:0}to{opacity:1}}@keyframes kbIn{from{opacity:0}to{opacity:1}}'+
    '.kb-card{position:relative;width:100%;max-width:720px;max-height:92vh;max-height:calc(100vh - 24px);overflow-y:auto;-webkit-overflow-scrolling:touch;background:#fdfdfd;border-radius:24px;border:3px solid #f6a274;box-shadow:0 18px 50px rgba(74,30,11,.35);padding:16px 18px 14px;font:15px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;color:#292521}'+
    '.kb-card h2{margin:0 40px 2px 0;font-size:22px;color:#933914}.kb-t{color:#933914}'+
    '.kb-sub{margin:0 0 10px;font-size:13px;color:#933914}'+
    '.kb-x{position:absolute;right:12px;top:12px;width:38px;height:38px;border-radius:50%;border:2px solid #e4dbd3;background:#f7f7f6;font-size:18px;cursor:pointer;color:#6f2c10}'+
    '.kb-grid{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;margin:0 -6px}'+
    '.kb-sec{-webkit-box-flex:1;-webkit-flex:1 1 300px;flex:1 1 300px;margin:0 6px 10px;background:#f7f7f6;border:1px solid #ede7e1;border-radius:16px;padding:8px 12px 6px}'+
    '.kb-sec h3{margin:0 0 4px;font-size:14px;color:#933914}'+
    '.kb-row{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;padding:3px 0;font-size:14px}'+
    '.kb-row span.kb-d{-webkit-box-flex:1;-webkit-flex:1;flex:1}'+
    '.kb-k{display:inline-block;min-width:24px;text-align:center;margin-left:4px;padding:2px 7px;border-radius:8px;background:#ffffff;border:1px solid #d8cbbf;border-bottom-width:3px;font:700 13px/1.3 ui-monospace,Menlo,Consolas,monospace;color:#4a1e0b;white-space:nowrap}'+
    '.kb-foot{margin:4px 0 0;font-size:12.5px;color:#933914;text-align:center}'+
    'html.hw .kb-card{background:#171513;color:#f1ede8;border-color:#ee7d45}html.hw .kb-sec{background:#221f1c;border-color:#3c3731}html.hw .kb-k{background:#171513;color:#ffe5d4;border-color:#933914}html.hw .kb-sec h3,html.hw .kb-sub,html.hw .kb-foot{color:#fcc8a6}'+
    '@media (max-width:480px){.kb-card{padding:14px 12px 10px;border-radius:20px}.kb-card h2{font-size:19px}.kb-row{font-size:13px}}'+
    /* keyboard focus ring (Tabo purple + white halo so it shows on light AND dark screens) */
    ':focus-visible{outline:3px solid #b8481a!important;outline-offset:2px!important;box-shadow:0 0 0 6px rgba(255,255,255,.9)!important}'+
    'html.hw :focus-visible{outline-color:#f6a274!important;box-shadow:0 0 0 6px rgba(16,14,13,.85)!important}'+
    'textarea:focus-visible,input[type=text]:focus-visible,input[type=search]:focus-visible,input[type=password]:focus-visible,input:not([type]):focus-visible,select:focus-visible{outline-offset:0!important}'+
    '.msg.bot[tabindex]:focus-visible{outline-offset:3px!important}'+
    '.kb-ov :focus-visible{box-shadow:0 0 0 6px rgba(246,162,116,.45)!important}';
  /* never a ring after a tap/click (older rules used :focus) */
  var css2='button:focus:not(:focus-visible),a:focus:not(:focus-visible),[tabindex]:focus:not(:focus-visible),select:focus:not(:focus-visible){outline:none!important}';
  function addCss(t){try{var s=D.createElement('style');s.setAttribute('data-kb','1');s.appendChild(D.createTextNode(t));(D.head||D.documentElement).appendChild(s);}catch(e){}}
  addCss(css);addCss(css2);/* separate tag: a browser with no :focus-visible drops only this rule */

  /* ---------- who is using what: keyboard vs touch/mouse ---------- */
  var viaKey=false;
  D.addEventListener('keydown',function(e){if(e.key==='Tab'||e.key==='Escape'||/^Arrow/.test(e.key||'')||e.metaKey||e.ctrlKey||e.altKey||(e.target===D.body||!e.target))viaKey=true;},true);
  function ptr(){viaKey=false;}
  D.addEventListener('mousedown',ptr,true);D.addEventListener('touchstart',ptr,{capture:true,passive:true});D.addEventListener('pointerdown',ptr,true);

  /* ---------- helpers ---------- */
  function vis(el){if(!el||!el.getBoundingClientRect)return false;if(el.offsetWidth<=0&&el.offsetHeight<=0)return false;
    try{var cs=W.getComputedStyle(el);if(cs.visibility==='hidden'||cs.display==='none')return false;}catch(e){}
    var p=el;while(p&&p!==D.body){if(p.hidden||(p.getAttribute&&p.getAttribute('aria-hidden')==='true'&&p.getAttribute('role')==='dialog'))return false;p=p.parentNode;}return true;}
  var FSEL='a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"]),[contenteditable="true"]';
  function focusables(box){var all=box.querySelectorAll(FSEL),out=[];for(var i=0;i<all.length;i++)if(vis(all[i]))out.push(all[i]);return out;}
  function typing(t){if(!t||!t.tagName)return false;var n=t.tagName;if(t.isContentEditable)return true;if(n==='TEXTAREA'||n==='SELECT')return true;
    if(n==='INPUT'){var ty=(t.getAttribute('type')||'text').toLowerCase();return !/^(checkbox|radio|button|submit|reset|range|color|file|image)$/.test(ty);}return false;}
  function click(el){if(!el)return false;try{el.click();}catch(e){return false;}return true;}
  function focus(el){if(!el)return false;try{el.focus({preventScroll:false});}catch(e){try{el.focus();}catch(e2){}}return D.activeElement===el;}
  function toast(m){try{if(W.hcApp&&W.hcApp.toast){W.hcApp.toast(m);return;}}catch(e){}}
  function codeOn(){return /\bhc-codemode\b/.test(D.documentElement.className);}

  /* ---------- pop-ups (dialogs): the top one gets the focus trap + Esc ---------- */
  function dialogs(){var c=D.querySelectorAll('[role=dialog],[aria-modal=true],.kb-ov'),out=[];
    for(var i=0;i<c.length;i++){var d=c[i];if(has(d,'hc-drawer')&&!has(d,'open'))continue;if(d.getAttribute('aria-hidden')==='true')continue;if(!vis(d))continue;out.push(d);}return out;}
  function zOf(el){var z=0;while(el&&el!==D.body&&el.nodeType===1){try{var v=parseInt(W.getComputedStyle(el).zIndex,10);if(!isNaN(v)&&v>z)z=v;}catch(e){}el=el.parentNode;}return z;}
  function topDialog(){var d=dialogs(),best=null,bz=-1;for(var i=0;i<d.length;i++){var z=zOf(d[i]);if(z>=bz){bz=z;best=d[i];}}return best;}
  function closeBtn(d){var q=d.querySelectorAll('button,[role=button]');
    for(var i=0;i<q.length;i++){var b=q[i];if(!vis(b))continue;var l=(b.getAttribute('aria-label')||'')+' '+(b.getAttribute('title')||'');
      if(b.hasAttribute('data-close')||has(b,'hd-x')||has(b,'tt-x')||has(b,'kb-x')||/^\s*(close|exit)\b/i.test(l))return b;}
    for(var j=0;j<q.length;j++){var t=(q[j].textContent||'').replace(/\s+/g,' ').replace(/^\s+|\s+$/g,'');if(vis(q[j])&&/^(\u2715|\u00D7|\u2716\uFE0F?|x|cancel|close|done|\u2715 close|\u2715 exit)$/i.test(t))return q[j];}
    return null;}

  /* remember who opened a pop-up, give focus back when it closes (keyboard users only; touch stays exactly the same) */
  var lastOut=null,stack=[],prevTop=null;
  D.addEventListener('focusin',function(e){var t=e.target;if(t&&t.nodeType===1&&!inDialog(t))lastOut=t;},true);
  function inDialog(t){var d=dialogs();for(var i=0;i<d.length;i++)if(d[i].contains(t))return d[i];return null;}
  function watch(){var top=topDialog();if(top===prevTop)return;
    if(top&&(!prevTop||!top.contains(prevTop))){var known=false;for(var i=0;i<stack.length;i++)if(stack[i].d===top)known=true;
      if(!known){stack.push({d:top,o:(prevTop&&lastFocusIn(prevTop))||lastOut});}
      if(viaKey&&!top.contains(D.activeElement)){var f=focusables(top);var pick=null;for(var k=0;k<f.length;k++)if(!typing(f[k])||f[k].type==='password'||f[k].getAttribute('inputmode')==='numeric'||f[k].type==='search'){pick=f[k];break;}focus(pick||f[0]);}}
    /* drop closed ones, return focus to their opener */
    var ret=null;for(var j=stack.length-1;j>=0;j--){var s=stack[j];if(!D.body.contains(s.d)||dialogs().indexOf(s.d)<0){ret=s.o;stack.splice(j,1);}}
    if(ret&&viaKey){var a=D.activeElement;var lost=!a||a===D.body||!vis(a)||(top&&!top.contains(a));
      if(top&&!top.contains(ret)){ret=null;}
      if(ret&&D.body.contains(ret)&&vis(ret)&&lost)focus(ret);
      else if(lost&&top){var ff=focusables(top);if(ff[0])focus(ff[0]);}}
    prevTop=top;}
  var lastIn={};function lastFocusIn(d){return d.__kbLast||null;}
  D.addEventListener('focusin',function(e){var d=inDialog(e.target);if(d)d.__kbLast=e.target;},true);
  setInterval(watch,200);

  /* ---------- cheat sheet ---------- */
  var SECS=[
    ['\u2328\uFE0F Anywhere',[['Type a message','/'],['Send','Enter'],['New line','Shift + Enter'],['Close / back','Esc'],['Show this list','?']]],
    ['\uD83E\uDDE0 AI + modes',[['Pick an AI (arrows, type to find)',MOD+' K'],['Chat \u00B7 Code \u00B7 Tots \u00B7 Studio \u00B7 Lessons','1 2 3 4 5'],['Same, even while typing',(mac?'\u2325':'Alt')+' 1\u20135'],['\uD83D\uDE08 Unhinged on/off','U']]],
    ['\uD83D\uDCAC Chat',[['New chat','N'],['\uD83D\uDD58 History (arrows + Enter)','H'],['\uD83E\uDEE7 Blob buddy','B'],['\u2699\uFE0F Customize','C'],['\uD83D\uDD0A Read the last reply','R'],['\uD83D\uDD01 Retry the last reply','Shift + R'],['\uD83D\uDCCB Copy the last reply',MOD+' Shift C']]],
    ['\uD83E\uDDD1\u200D\uD83D\uDCBB Code mode',[['Build it / run it',MOD+' Enter'],['\uD83C\uDFAE Full screen','F'],['\u2728 Improve it','I'],['\uD83D\uDD27 Auto-fix a bug','X'],['Leave full screen','Esc']]],
    ['\uD83E\uDDED Moving around',[['Next / back','Tab / Shift + Tab'],['Press a button','Enter or Space'],['Move the highlight anywhere','\u2190 \u2191 \u2192 \u2193'],['Move in lists','\u2191 \u2193'],['Open / close AI folders','\u2190 \u2192']]]];
  var ov=null;
  function buildSheet(){if(ov)return ov;ov=D.createElement('div');ov.className='kb-ov';ov.hidden=true;ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');ov.setAttribute('aria-labelledby','kb-h');
    var app=isApp(),h='<div class="kb-card"><button type="button" class="kb-x" aria-label="Close keyboard shortcuts">\u2715</button><h2 id="kb-h"><span class="kb-e" aria-hidden="true">\u2328\uFE0F</span> <span class="kb-t">Keyboard shortcuts</span></h2><p class="kb-sub">No mouse needed! Shortcuts wait while you\u2019re typing (except Esc and '+MOD+' keys).'+(mac?' On iPad, \u2318 or Ctrl both work.':'')+'</p><div class="kb-grid">';
    for(var i=0;i<SECS.length;i++){if(!app&&i>0&&i<4)continue;h+='<div class="kb-sec"><h3>'+SECS[i][0]+'</h3>';var r=SECS[i][1];
      for(var j=0;j<r.length;j++){if(!app&&i===0&&j>0&&j<3)continue;var ks=r[j][1].split(' / '),kh='';for(var k=0;k<ks.length;k++)kh+=(k?' <span aria-hidden="true">/</span> ':'')+'<span class="kb-k">'+ks[k]+'</span>';
        h+='<div class="kb-row"><span class="kb-d">'+r[j][0]+'</span>'+kh+'</div>';}h+='</div>';}
    h+='</div><p class="kb-foot">Press <span class="kb-k">Esc</span> or <span class="kb-k">?</span> to close</p></div>';
    ov.innerHTML=h;D.body.appendChild(ov);
    ov.addEventListener('click',function(e){if(e.target===ov||(e.target&&(has(e.target,'kb-x'))))sheet(false);});
    return ov;}
  function sheet(on){buildSheet();if(on===undefined)on=ov.hidden;if(on){ov.hidden=false;setTimeout(function(){focus(ov.querySelector('.kb-x'));},20);}else{ov.hidden=true;}}
  function sheetOpen(){return !!(ov&&!ov.hidden);}

  /* ---------- skip link + ⌨️ buttons ---------- */
  function skipTarget(){if(!isApp())return D.querySelector('main')||D.body;return codeOn()?$('cb-msg'):$('msg');}
  function addSkip(){if(D.querySelector('.kb-skip'))return;var a=D.createElement('a');a.className='kb-skip';a.href='#';a.textContent=isApp()?'Skip to chat \u2193':'Skip to the docs \u2193';
    a.addEventListener('click',function(e){e.preventDefault();var t=skipTarget();if(t){if(!t.hasAttribute('tabindex')&&!/^(INPUT|TEXTAREA|BUTTON|A|SELECT)$/.test(t.tagName))t.setAttribute('tabindex','-1');focus(t);}});
    D.body.insertBefore(a,D.body.firstChild);}
  function addTipButtons(){var f=D.querySelectorAll('.fine');for(var i=0;i<f.length;i++){if(f[i].querySelector('.kb-tipbtn'))continue;var hb=f[i].querySelector('.hc-hammer');
      var b=D.createElement('button');b.type='button';b.className='kb-tipbtn';b.title='Keyboard shortcuts (?)';b.setAttribute('aria-label','Keyboard shortcuts');b.innerHTML='\u2328\uFE0F';
      b.addEventListener('click',function(){sheet(true);});if(hb)f[i].insertBefore(b,hb);else f[i].appendChild(b);}}

  /* ---------- tab-reachability fixes (things you could only tap before) ---------- */
  function fixTabs(){
    /* every chat reply: Tab to it, Enter shows 📋 Copy / 🔊 Read / 🔁 Retry */
    var b=D.querySelectorAll('#log .msg.bot:not([tabindex])');for(var i=0;i<b.length;i++){if(has(b[i],'tp'))continue;b[i].setAttribute('tabindex','0');b[i].setAttribute('aria-describedby','kb-reply-hint');}
    if(!$('kb-reply-hint')&&$('log')){var hh=D.createElement('span');hh.id='kb-reply-hint';hh.hidden=true;hh.textContent='Tabo AI reply. Press Enter for copy, read aloud and retry.';D.body.appendChild(hh);}
    /* clickable look-alikes with no keyboard access */
    var q=D.querySelectorAll('[onclick]:not(button):not(a):not(input):not(select):not(textarea):not([tabindex])');
    for(var j=0;j<q.length;j++){q[j].setAttribute('tabindex','0');if(!q[j].getAttribute('role'))q[j].setAttribute('role','button');}
    /* missing names */
    var nm=[['#msg','Message Tabo AI'],['#cb-msg','Tell the coder what to make'],['#cb-ta','Your code'],['#cb-stdin','Program input'],['#hc-pers','Personality'],['#hc-mem-in','Add a memory'],['#tt-name','Tot name'],['#hw-on','Halloween look'],['#tt-on','Show my Tot'],['#tt-on2','Show my Tot'],['#hc-mem-on','Use memory'],['#cb-autoplay','Auto-play after building'],['#hc-ctx','Chat context']];
    for(var k=0;k<nm.length;k++){var e=D.querySelector(nm[k][0]);if(e&&!e.getAttribute('aria-label')&&!(e.id&&D.querySelector('label[for="'+e.id+'"]')))e.setAttribute('aria-label',nm[k][1]);}
    var ub=D.querySelectorAll('button:not([aria-label])');for(var u=0;u<ub.length;u++){var tx=(ub[u].textContent||'').replace(/\s+/g,'');if(!tx&&ub[u].title)ub[u].setAttribute('aria-label',ub[u].title);}
  }
  D.addEventListener('keydown',function(e){var t=e.target;if(!t||!t.className||typeof t.className!=='string')return;
    if((e.key==='Enter'||e.key===' '||e.key==='Spacebar')&&has(t,'msg')&&has(t,'bot')&&t.getAttribute('tabindex')!==null){e.preventDefault();
      try{var ev=D.createEvent('MouseEvents');ev.initMouseEvent('click',true,true,W,1,0,0,0,0,false,false,false,false,0,null);t.dispatchEvent(ev);}catch(x){click(t);}
      setTimeout(function(){var a=t.querySelector('.hc-act');if(a)focus(a);},30);return;}
    if((e.key==='Enter'||e.key===' '||e.key==='Spacebar')&&t.getAttribute('role')==='button'&&t.tagName!=='BUTTON'&&t.tagName!=='A'&&!typing(t)&&!t.__kbOwn){e.preventDefault();click(t);}
  });

  /* ---------- 🧠 model picker by keyboard ---------- */
  function aip(){return D.querySelector('.aip');}
  function aipList(){var a=aip();return a?a.querySelector('.aip-list'):null;}
  function aipOpen(){var l=aipList();return !!(l&&!l.hidden);}
  function aipItems(){var l=aipList();if(!l)return [];var q=l.querySelectorAll('.aip-q,.aip-gb,.aip-o'),o=[];for(var i=0;i<q.length;i++)if(vis(q[i]))o.push(q[i]);return o;}
  function openPicker(){
    if(codeOn()){var s=$('cb-model');if(s&&vis(s)){focus(s);try{if(s.showPicker)s.showPicker();}catch(e){}return true;}}
    var a=aip();if(!a)return false;var b=a.querySelector('.aip-btn');if(!b)return false;if(!aipOpen())click(b);
    setTimeout(function(){var q=a.querySelector('.aip-q');if(q){if(q.value){q.value='';try{var ie=D.createEvent('Event');ie.initEvent('input',true,true);q.dispatchEvent(ie);}catch(e){}}focus(q);}},40);return true;}
  function backToBtn(){setTimeout(function(){var b=D.querySelector('.aip-btn');var a=D.activeElement;if(b&&(!a||a===D.body||!vis(a)||!D.body.contains(a)))focus(b);},40);}
  function refocusGk(k){setTimeout(function(){var l=aipList();if(!l)return;var g=l.querySelector('[data-gk="'+k+'"]');if(g)focus(g);},30);}
  D.addEventListener('keydown',function(e){var l=aipList();if(!l||l.hidden)return;var t=e.target;if(!l.contains(t))return;var k=e.key;
    var it=aipItems(),i=it.indexOf(t);
    if(k==='ArrowDown'||k==='ArrowUp'){e.preventDefault();var n=it[i+(k==='ArrowDown'?1:-1)];if(!n&&k==='ArrowDown')n=it[0];if(!n&&k==='ArrowUp')n=it[it.length-1];if(n){focus(n);if(n.scrollIntoView&&!has(n,'aip-q'))try{n.scrollIntoView({block:'nearest'});}catch(x){}}return;}
    if(k==='Home'&&!has(t,'aip-q')){e.preventDefault();focus(it[0]);return;}if(k==='End'&&!has(t,'aip-q')){e.preventDefault();focus(it[it.length-1]);return;}
    if(has(t,'aip-q')){
      if(k==='Enter'){e.preventDefault();var o=l.querySelector('.aip-o');if((t.value||'').replace(/\s/g,'')&&o){click(o);backToBtn();}else if(it[1])focus(it[1]);}
      return;}
    var gk=t.getAttribute('data-gk');
    if(gk&&(k==='ArrowRight'||k==='ArrowLeft')){e.preventDefault();var op=t.getAttribute('aria-expanded')==='true';
      if(k==='ArrowRight'&&!op){click(t);refocusGk(gk);}else if(k==='ArrowLeft'&&op){click(t);refocusGk(gk);}
      else if(k==='ArrowRight'&&op){var f=t.parentNode&&t.parentNode.querySelector('.aip-o');if(f)focus(f);}
      else{/* left on a closed folder: previous folder */var gs=l.querySelectorAll('.aip-gb'),gi=-1;for(var z=0;z<gs.length;z++)if(gs[z]===t)gi=z;if(gs[gi-1])focus(gs[gi-1]);}
      return;}
    if(gk&&(k==='Enter'||k===' ')){e.preventDefault();click(t);refocusGk(gk);return;}
    if(has(t,'aip-o')&&k==='ArrowLeft'){e.preventDefault();var fb=t.parentNode&&t.parentNode.parentNode&&t.parentNode.parentNode.querySelector('.aip-gb');if(fb)focus(fb);return;}
    if(has(t,'aip-o')&&k==='ArrowRight'){e.preventDefault();var nf=t.parentNode&&t.parentNode.parentNode&&t.parentNode.parentNode.nextSibling;var ng=nf&&nf.querySelector&&nf.querySelector('.aip-gb');if(ng)focus(ng);return;}
    if(has(t,'aip-o')&&(k==='Enter'||k===' ')){e.preventDefault();click(t);backToBtn();return;}
    if(k&&k.length===1&&!e.metaKey&&!e.ctrlKey&&!e.altKey&&/\S/.test(k)){var sq=l.querySelector('.aip-q');if(sq){e.preventDefault();focus(sq);sq.value=(sq.value||'')+k;try{var ie=D.createEvent('Event');ie.initEvent('input',true,true);sq.dispatchEvent(ie);}catch(x){}}}
    if(k==='Backspace'){var sq2=l.querySelector('.aip-q');if(sq2){e.preventDefault();focus(sq2);sq2.value=(sq2.value||'').slice(0,-1);try{var ie2=D.createEvent('Event');ie2.initEvent('input',true,true);sq2.dispatchEvent(ie2);}catch(x){}}}
  });


  /* iPadOS/iOS Safari: with a hardware keyboard, plain Tab only jumps between text boxes (unless a hidden setting is on).
     So there we move focus ourselves, in page order, through every button/link/box (inside the top pop-up if one is open). */
  var IOS=/iPad|iPhone|iPod/.test(navigator.userAgent||'')||(/Macintosh/.test(navigator.userAgent||'')&&(navigator.maxTouchPoints||0)>1);
  try{if(localStorage.getItem('hc_kb_tab')==='1')IOS=true;}catch(e){}
  function tabOrder(box){var all=box.querySelectorAll(FSEL),out=[];for(var i=0;i<all.length;i++){var el=all[i];if(el.tabIndex<0||!vis(el))continue;if(el.type==='radio'&&!el.checked&&el.name){continue;}out.push(el);}return out;}
  W.addEventListener('keydown',function(e){if(!IOS||e.key!=='Tab'||e.metaKey||e.ctrlKey||e.altKey||e.defaultPrevented)return;
    var t=e.target;if(t&&t.tagName==='TEXTAREA'&&(t.id==='cb-ta'||t.id==='ls-ed'||/\bls-/.test(t.className||'')))return;/* code editors type spaces */
    var d=topDialog()||D.body,f=tabOrder(d);if(!f.length)return;var i=f.indexOf(D.activeElement);
    var n=i<0?(e.shiftKey?f[f.length-1]:f[0]):f[(i+(e.shiftKey?-1:1)+f.length)%f.length];
    e.preventDefault();viaKey=true;focus(n);try{if(n.scrollIntoView)n.scrollIntoView({block:'nearest'});}catch(x){}},true);

  function tabOrderAll(){return tabOrder(D.body);}
  /* ---------- the shortcut layer ---------- */
  var escSnap=null;
  W.addEventListener('keydown',function(e){if(e.key==='Escape'||e.keyCode===27){escSnap={dlg:topDialog(),aip:aipOpen(),sheet:sheetOpen()};if(escSnap.aip&&!escSnap.sheet&&aipList().contains(D.activeElement))backToBtn();}
    /* focus trap: Tab stays inside the top pop-up */
    if(e.key==='Tab'&&!e.metaKey&&!e.ctrlKey&&!e.altKey&&!e.defaultPrevented){var d=topDialog();if(!d)return;var f=focusables(d);if(!f.length){e.preventDefault();return;}
      var a=D.activeElement,i=f.indexOf(a);
      if(!d.contains(a)){e.preventDefault();focus(e.shiftKey?f[f.length-1]:f[0]);}
      else if(e.shiftKey&&i===0){e.preventDefault();focus(f[f.length-1]);}
      else if(!e.shiftKey&&i===f.length-1){e.preventDefault();focus(f[0]);}}
  },true);

  function mode(n){var ids=['hc-mode-chat','hc-mode-code','hc-tots-btn','hc-studio-btn','hc-lessons-btn'];var b=$(ids[n-1]);if(!b||!vis(b))return false;
    focus(b);click(b);if(n<=2)setTimeout(function(){focus(b);},30);return true;}
  function history(){var cb=$('hc-chats-btn');if(!cb)return false;
    if(!codeOn()&&/\bhc-dock\b/.test(D.documentElement.className)){var hc=$('hc-chats');if(hc&&!hc.contains(D.activeElement)){var it=hc.querySelector('.ci-o')||$('hc-new2');if(it){focus(it);return true;}}}
    click(cb);setTimeout(function(){var box=codeOn()?$('hc-projs'):$('hc-chats');if(box&&!box.contains(D.activeElement)){var it=box.querySelector('.ci-o')||box.querySelector('.hd-new');if(it)focus(it);}},120);return true;}
  function codeBuild(){var m=$('cb-msg'),f=$('cb-form');if(m&&f&&(m.value||'').replace(/\s/g,'')){var s=f.querySelector('.send');if(s&&!s.disabled)click(s);return true;}var r=$('cb-run');if(r&&vis(r)){click(r);return true;}return false;}
  function improve(){var b=D.querySelectorAll('.cp-imp .cp-ib');for(var i=0;i<b.length;i++)if(vis(b[i])){focus(b[i]);toast('\u2728 Pick an Improve button, then Enter');return true;}toast('Build something first, then you can improve it \u2728');return false;}
  function autofix(){var b=D.querySelector('.cb-fix');if(b&&vis(b)){click(b);return true;}toast('No bugs to fix right now \uD83D\uDC4D');return false;}
  function sendNow(){var f=$('composer');var s=f&&f.querySelector('.send');if(s&&!s.disabled){click(s);return true;}return false;}

  D.addEventListener('keydown',function(e){
    if(e.defaultPrevented&&e.key!=='Escape')return;if(e.isComposing||e.keyCode===229)return;
    var k=e.key||'',t=e.target,ty=typing(t),cmd=e.metaKey||e.ctrlKey,app=isApp();
    var low=k.length===1?k.toLowerCase():k;
    /* ---- Esc: close the top thing, one layer at a time ---- */
    if(k==='Escape'||e.keyCode===27){var s=escSnap||{};escSnap=null;
      if(s.sheet||sheetOpen()){e.preventDefault();sheet(false);return;}
      if(e.defaultPrevented)return;
      if(s.aip)return;
      if(s.dlg){if(dialogs().indexOf(s.dlg)<0)return;/* its own code closed it */var cbt=closeBtn(s.dlg);if(cbt){e.preventDefault();click(cbt);}return;}
      var pv=D.querySelector('.fs');if(pv&&$('cb-fs-x')&&vis($('cb-fs-x'))){e.preventDefault();click($('cb-fs-x'));return;}
      var acts=D.querySelector('#log .hc-acts:not(.on)');if(acts&&acts.contains(t)){var mb=acts.parentNode;acts.parentNode.removeChild(acts);if(mb)focus(mb);e.preventDefault();return;}
      if(t&&t.id==='cb-ta'){var fo=tabOrderAll(),fi=fo.indexOf(t);e.preventDefault();if(fo[fi+1]){viaKey=true;focus(fo[fi+1]);}else t.blur();return;}
      if(ty||(t&&t!==D.body&&t.blur)){try{t.blur();}catch(x){}}return;}
    if(e.repeat)return;
    if(sheetOpen()){if(k==='?'||(k==='/'&&e.shiftKey)||k==='Enter'){e.preventDefault();sheet(false);}return;}
    var dlg=topDialog();
    if(D.getElementById('hc-splash'))return;
    /* ---- ? cheat sheet (works on the docs page too) ---- */
    if(!ty&&!cmd&&!e.altKey&&(k==='?'||(k==='/'&&e.shiftKey))){if(dlg)return;e.preventDefault();sheet(true);return;}
    if(!app||dlg)return;
    /* ---- Cmd/Ctrl combos (also while typing) ---- */
    if(cmd&&!e.altKey){
      if(low==='k'&&!e.shiftKey){e.preventDefault();openPicker();return;}
      if((k==='Enter')&&!e.shiftKey){e.preventDefault();if(codeOn())codeBuild();else sendNow();return;}
      if(low==='c'&&e.shiftKey){e.preventDefault();if(!(W.hcApp&&W.hcApp.copyLast&&W.hcApp.copyLast()))toast('No reply to copy yet');return;}
      return;}
    /* ---- Alt/Option + 1..5: switch modes even while typing ---- */
    var dc=/^Digit([1-9])$/.exec(e.code||'');
    if(e.altKey&&!cmd){var dn=dc?+dc[1]:(/^[1-9]$/.test(k)?+k:0);if(dn>=1&&dn<=5){e.preventDefault();mode(dn);}return;}
    if(ty)return;
    if(cmd||e.altKey)return;
    if(t&&t.tagName==='BUTTON'&&(k===' '||k==='Enter'))return;
    if(/^[1-5]$/.test(k)&&!e.shiftKey){e.preventDefault();mode(+k);return;}
    var code=codeOn();
    if(k==='/'&&!e.shiftKey){var m=skipTarget();if(m){e.preventDefault();focus(m);}return;}
    if(e.shiftKey){if(low==='r'){e.preventDefault();if(!(W.hcApp&&W.hcApp.retryLast&&W.hcApp.retryLast()))toast('Nothing to retry yet');}return;}
    switch(low){
      case 'u':e.preventDefault();if(!click($('hc-unh')))toast('\uD83D\uDE08 Unhinged is only in Chat');break;
      case 'b':e.preventDefault();var vb=D.querySelector('.hv-vc');if(vb&&vis(vb)){focus(vb);click(vb);}else if(W.hcVoice&&W.hcVoice.open)W.hcVoice.open();break;
      case 'c':e.preventDefault();focus($('hc-cust-btn'));click($('hc-cust-btn'));break;
      case 'h':e.preventDefault();history();break;
      case 'n':e.preventDefault();click($('hcf-new'));setTimeout(function(){var m=skipTarget();if(m)focus(m);},80);break;
      case 'r':e.preventDefault();if(!(W.hcApp&&W.hcApp.readLast&&W.hcApp.readLast()))toast('No reply to read yet');break;
      case 'f':if(code){e.preventDefault();var fb=$('cb-fs');if(fb&&vis(fb)){click(fb);setTimeout(function(){var x=$('cb-fs-x');if(x&&vis(x))focus(x);},120);}else toast('Build something first, then F for full screen \uD83C\uDFAE');}break;
      case 'i':if(code){e.preventDefault();improve();}break;
      case 'x':if(code){e.preventDefault();autofix();}break;
    }
  });

  /* ---------- one-time tip for keyboard people ---------- */
  var TIP='hc_kb_tip';
  function tip(){try{if(localStorage.getItem(TIP))return;localStorage.setItem(TIP,'1');}catch(e){return;}setTimeout(function(){toast('\u2328\uFE0F Keyboard shortcuts! Press ? to see them');},400);}
  D.addEventListener('keydown',function(e){if(!isApp())return;if(e.key==='Tab'||((!typing(e.target))&&e.key&&e.key.length===1)||e.metaKey||e.ctrlKey)tip();},true);


  /* ---------- arrow keys: move the highlight to the nearest button in that direction (v2.5.1) ---------- */
  function arrowScope(){var t=topDialog();return t||D.body;}
  D.addEventListener('keydown',function(e){var k=e.key;if(!/^Arrow(Up|Down|Left|Right)$/.test(k||''))return;
    if(e.defaultPrevented||e.metaKey||e.ctrlKey||e.altKey||e.shiftKey)return;
    var t=e.target;if(t&&t.nodeType===1){var tg=t.tagName;if(typing(t)||tg==='SELECT'||tg==='IFRAME'||tg==='CANVAS'||tg==='VIDEO'||tg==='AUDIO'||(tg==='INPUT'&&/range|radio|number/.test(t.type||''))||t.isContentEditable)return;
      if(t.closest&&t.closest('[role=slider],[role=radiogroup],[role=listbox],[data-kb-own-arrows]'))return;}
    var box=arrowScope(),list=tabOrder(box);if(!list.length)return;
    var cur=(D.activeElement&&D.activeElement!==D.body&&box.contains(D.activeElement))?D.activeElement:null;
    if(!cur){e.preventDefault();viaKey=true;focus(list[0]);return;}
    var r=cur.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2,best=null,bs=1e9;
    for(var i=0;i<list.length;i++){var el=list[i];if(el===cur||el.contains(cur)||cur.contains(el))continue;var q=el.getBoundingClientRect();if(!q.width&&!q.height)continue;
      var x=q.left+q.width/2,y=q.top+q.height/2,dx=x-cx,dy=y-cy,main,side;
      if(k==='ArrowRight'){if(q.left<r.right-4&&dx<=4)continue;main=Math.max(0,q.left-r.right);side=Math.abs(dy);}
      else if(k==='ArrowLeft'){if(q.right>r.left+4&&dx>=-4)continue;main=Math.max(0,r.left-q.right);side=Math.abs(dy);}
      else if(k==='ArrowDown'){if(q.top<r.bottom-4&&dy<=4)continue;main=Math.max(0,q.top-r.bottom);side=Math.abs(dx);}
      else{if(q.bottom>r.top+4&&dy>=-4)continue;main=Math.max(0,r.top-q.bottom);side=Math.abs(dx);}
      var s=main+side*2.5;if(s<bs){bs=s;best=el;}}
    if(best){e.preventDefault();viaKey=true;focus(best);try{best.scrollIntoView({block:'nearest',inline:'nearest'});}catch(x){}}
  },false);

  function boot(){addSkip();addTipButtons();fixTabs();
    var lg=$('log');if(lg&&W.MutationObserver)new MutationObserver(function(){fixTabs();}).observe(lg,{childList:true,subtree:true});
    setTimeout(function(){fixTabs();addTipButtons();},1500);}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',boot);else boot();
  W.hcKeys={sheet:sheet,openPicker:openPicker,top:topDialog,version:'2.5'};
})();
