/* hccalc.js (hc v1.9.1) 🧮 Dev Lab calculator + unit converter. Local JS only: a small hand-written parser (no eval, no Function).
   hcCalc.run(text)  -> {ok, kind:'math'|'unit', input, result, text} or {ok:false, message}
   hcCalc.find(text) -> the same for a math expression or "5 miles in km" found inside a longer prompt, or null.
   The same file runs in the browser (window.hcCalc) and inside _worker.js (HC_CALC) for Model Test / Web Research context. */
(function(G){
  'use strict';
  var FN={sqrt:Math.sqrt,cbrt:Math.cbrt,abs:Math.abs,round:Math.round,floor:Math.floor,ceil:Math.ceil,log:function(x){return Math.log10(x);},ln:Math.log,exp:Math.exp,
    sin:function(x){return Math.sin(x*Math.PI/180);},cos:function(x){return Math.cos(x*Math.PI/180);},tan:function(x){return Math.tan(x*Math.PI/180);}};
  var CONST={pi:Math.PI,'\u03c0':Math.PI,e:Math.E,tau:2*Math.PI};
  function words(s){
    return String(s).toLowerCase()
      .replace(/(\d),(?=\d{3}\b)/g,'$1')
      .replace(/\bsquare root of\b/g,'sqrt ').replace(/\bcube root of\b/g,'cbrt ')
      .replace(/\bdivided by\b/g,'/').replace(/\bmultiplied by\b/g,'*').replace(/\btimes\b/g,'*').replace(/\bplus\b/g,'+').replace(/\bminus\b/g,'-')
      .replace(/\bover\b/g,'/').replace(/\bto the power of\b/g,'^').replace(/\bsquared\b/g,'^2').replace(/\bcubed\b/g,'^3').replace(/\bmod\b/g,' mod ')
      .replace(/[\u00d7\u2715\u2716\u22c5\u00b7]/g,'*').replace(/[\u00f7\u2215]/g,'/').replace(/[\u2212\u2013\u2014]/g,'-').replace(/\*\*/g,'^');
  }
  function lex(s){
    var t=[],i=0,m;
    while(i<s.length){
      var c=s[i];
      if(/\s/.test(c)){i++;continue;}
      if((m=/^(\d+\.?\d*|\.\d+)(e[+-]?\d+)?/.exec(s.slice(i)))){t.push({k:'n',v:parseFloat(m[0])});i+=m[0].length;continue;}
      if('+-*/^%()!,'.indexOf(c)>=0){t.push({k:c});i++;continue;}
      if((m=/^[a-z\u03c0]+/.exec(s.slice(i)))){var w=m[0];
        if(w==='x'&&t.length&&(t[t.length-1].k==='n'||t[t.length-1].k===')')){t.push({k:'*'});i++;continue;}
        if(w==='of'){t.push({k:'of'});i+=2;continue;}
        if(w==='mod'){t.push({k:'mod'});i+=3;continue;}
        if(FN[w]){t.push({k:'f',v:w});i+=w.length;continue;}
        if(CONST[w]!=null){t.push({k:'n',v:CONST[w]});i+=w.length;continue;}
        throw new Error('I don\u2019t know "'+w+'"');}
      throw new Error('I can\u2019t read "'+c+'"');
    }
    if(t.length>120)throw new Error('That\u2019s too long');
    return t;
  }
  function parse(toks){
    var p=0,depth=0;
    function peek(){return toks[p];}
    function eat(k){var x=toks[p];if(!x||x.k!==k)throw new Error('Something\u2019s missing'+(k===')'?' (a closing bracket?)':''));p++;return x;}
    function expr(){var v=term();for(;;){var x=peek();if(x&&x.k==='+'){p++;v+=term();}else if(x&&x.k==='-'){p++;v-=term();}else return v;}}
    function term(){var v=unary();for(;;){var x=peek();
      if(x&&x.k==='*'){p++;v*=unary();}
      else if(x&&x.k==='/'){p++;var d=unary();if(d===0)throw new Error('Can\u2019t divide by zero');v/=d;}
      else if(x&&x.k==='mod'){p++;v=v%unary();}
      else if(x&&x.k==='of'){p++;v*=unary();}
      else if(x&&(x.k==='('||x.k==='f'||x.k==='n')){v*=unary();} // 2(3+4), 2pi, 3 sqrt 9
      else return v;}}
    function pow(){var b=post();var x=peek();if(x&&x.k==='^'){p++;var e=unary();return Math.pow(b,e);}return b;}
    function unary(){var x=peek();if(x&&x.k==='-'){p++;return -unary();}if(x&&x.k==='+'){p++;return unary();}return pow();}
    function post(){var v=prim();for(;;){var x=peek();
      if(x&&x.k==='%'){p++;v=v/100;}
      else if(x&&x.k==='!'){p++;if(v<0||v>170||v!==Math.floor(v))throw new Error('Factorial needs a whole number 0\u2013170');var f=1;for(var i=2;i<=v;i++)f*=i;v=f;}
      else return v;}}
    function prim(){var x=peek();if(!x)throw new Error('Something\u2019s missing at the end');
      if(++depth>60)throw new Error('Too many brackets');
      try{
        if(x.k==='n'){p++;return x.v;}
        if(x.k==='('){p++;var v=expr();eat(')');return v;}
        if(x.k==='f'){p++;var a;if(peek()&&peek().k==='('){p++;a=expr();eat(')');}else a=unary();return FN[x.v](a);}
        throw new Error('Unexpected "'+(x.k==='n'?x.v:x.k)+'"');
      }finally{depth--;}}
    var v=expr();if(p<toks.length)throw new Error('Unexpected "'+(toks[p].k==='n'?toks[p].v:toks[p].k)+'"');
    return v;
  }
  function nice(v){if(!isFinite(v))return v>0?'\u221e':(v<0?'-\u221e':'not a number');var r=Number(v.toPrecision(12));if(Math.abs(r)>=1e15||(r!==0&&Math.abs(r)<1e-7))return r.toExponential(6).replace(/\.?0+e/,'e');return String(r);}
  // ---- units ----
  var U={},CAT={};
  function add(cat,f,names){names.split('|').forEach(function(n){U[n]={c:cat,f:f,n:names.split('|')[0]};});}
  add('length',0.001,'mm|millimeter|millimeters|millimetre|millimetres');add('length',0.01,'cm|centimeter|centimeters|centimetre|centimetres');
  add('length',1,'m|meter|meters|metre|metres');add('length',1000,'km|kms|kilometer|kilometers|kilometre|kilometres|kilometer');
  add('length',0.0254,'in|inch|inches');add('length',0.3048,'ft|foot|feet');add('length',0.9144,'yd|yard|yards');add('length',1609.344,'mi|mile|miles');
  add('length',1852,'nmi|nautical mile|nautical miles');
  add('mass',1e-6,'mg|milligram|milligrams');add('mass',0.001,'g|gram|grams|gramme|grammes');add('mass',1,'kg|kgs|kilo|kilos|kilogram|kilograms');
  add('mass',0.028349523125,'oz|ounce|ounces');add('mass',0.45359237,'lb|lbs|pound|pounds');add('mass',6.35029318,'st|stone|stones');
  add('mass',1000,'t|tonne|tonnes|metric ton|metric tons');add('mass',907.18474,'ton|tons|us ton|us tons|short ton|short tons');
  add('volume',0.001,'ml|milliliter|milliliters|millilitre|millilitres');add('volume',1,'l|liter|liters|litre|litres');
  add('volume',0.00492892159375,'tsp|teaspoon|teaspoons');add('volume',0.01478676478125,'tbsp|tablespoon|tablespoons');
  add('volume',0.0295735295625,'fl oz|floz|fluid ounce|fluid ounces');add('volume',0.2365882365,'cup|cups');add('volume',0.473176473,'pt|pint|pints');
  add('volume',0.946352946,'qt|quart|quarts');add('volume',3.785411784,'gal|gallon|gallons');
  add('time',0.001,'ms|millisecond|milliseconds');add('time',1,'s|sec|secs|second|seconds');add('time',60,'min|mins|minute|minutes');
  add('time',3600,'h|hr|hrs|hour|hours');add('time',86400,'day|days');add('time',604800,'week|weeks|wk|wks');add('time',31557600,'year|years|yr|yrs');
  add('speed',1,'m/s|mps|meters per second|metres per second');add('speed',1/3.6,'km/h|kmh|kph|kilometers per hour|kilometres per hour');
  add('speed',0.44704,'mph|miles per hour');add('speed',0.514444444,'knot|knots|kn');add('speed',0.3048,'ft/s|fps|feet per second');
  add('data',1,'b|byte|bytes');add('data',1e3,'kb|kilobyte|kilobytes');add('data',1e6,'mb|megabyte|megabytes');add('data',1e9,'gb|gigabyte|gigabytes');add('data',1e12,'tb|terabyte|terabytes');
  add('area',1,'m2|m\u00b2|sq m|square meter|square meters|square metre|square metres');add('area',1e6,'km2|km\u00b2|sq km|square kilometer|square kilometers|square kilometres');
  add('area',0.09290304,'ft2|ft\u00b2|sq ft|square foot|square feet');add('area',4046.8564224,'acre|acres');add('area',10000,'ha|hectare|hectares');
  add('area',2589988.110336,'mi2|mi\u00b2|sq mi|square mile|square miles');
  var TEMP={c:'c',celsius:'c',centigrade:'c','\u00b0c':'c',f:'f',fahrenheit:'f','\u00b0f':'f',k:'k',kelvin:'k',kelvins:'k'};
  function unit(s){s=String(s||'').toLowerCase().replace(/\./g,'').replace(/^degrees?\s+/,'').replace(/^deg\s+/,'').replace(/\s+/g,' ').trim();
    if(TEMP[s])return {c:'temp',t:TEMP[s],n:{c:'\u00b0C',f:'\u00b0F',k:'K'}[TEMP[s]]};
    if(U[s])return U[s];
    var t=s.replace(/^(\u00b0)/,'');if(TEMP[t])return {c:'temp',t:TEMP[t],n:{c:'\u00b0C',f:'\u00b0F',k:'K'}[TEMP[t]]};
    return null;}
  function toC(v,t){return t==='c'?v:t==='f'?(v-32)*5/9:v-273.15;}
  function fromC(v,t){return t==='c'?v:t==='f'?v*9/5+32:v+273.15;}
  function conv(v,a,b){
    if(a.c!==b.c)throw new Error('Can\u2019t turn '+a.c+' into '+b.c);
    return a.c==='temp'?fromC(toC(v,a.t),b.t):v*a.f/b.f;}
  var UNIT_RX=/(-?\d[\d,]*(?:\.\d+)?|-?\.\d+)\s*((?:[a-z\u00b0\u00b2\/]+\.?)(?:\s+[a-z\u00b0\u00b2\/]+){0,3}?)\s+(?:in|to|into|as)\s+((?:[a-z\u00b0\u00b2\/]+)(?:\s+[a-z\u00b0\u00b2\/]+){0,3})/i;
  function tryUnit(s){
    var m=UNIT_RX.exec(String(s).replace(/(\d),(?=\d{3}\b)/g,'$1'));if(!m)return null;
    var v=parseFloat(m[1]),a=unit(m[2]),bw=m[3].replace(/[?.!,]+$/,'').split(/\s+/),b=null,i;
    if(!a)return null;
    for(i=Math.min(bw.length,4);i>0&&!b;i--)b=unit(bw.slice(0,i).join(' '));
    if(!b)return null;
    var r=conv(v,a,b),an=a.n,bn=b.n;
    return {ok:true,kind:'unit',input:nice(v)+' '+an+' \u2192 '+bn,result:nice(r),text:nice(v)+' '+an+' = '+nice(r)+' '+bn};
  }
  function run(text){
    var s=String(text==null?'':text).trim();if(!s)return {ok:false,message:'Type some math, like 12*7+3, or units, like 5 miles in km.'};
    if(s.length>200)return {ok:false,message:'That\u2019s too long (200 characters max).'};
    try{var u=tryUnit(s);if(u)return u;}catch(e){return {ok:false,message:e.message};}
    var w=words(s).replace(/^(what\s+is|what's|whats|calculate|compute|solve|how\s+much\s+is)\s+/,'').replace(/[=?]+\s*$/,'').trim();
    try{var v=parse(lex(w));if(typeof v!=='number'||isNaN(v))throw new Error('That isn\u2019t a number');
      return {ok:true,kind:'math',input:w,result:nice(v),text:w+' = '+nice(v)};}
    catch(e){return {ok:false,message:'\uD83E\uDDEE '+(e&&e.message||'Can\u2019t work that out')+'. Try something like 12*7+3 or 5 miles in km.'};}
  }
  function find(text){ // a calculation inside a longer prompt, or null
    var s=String(text||'').slice(0,600);
    try{var u=tryUnit(s);if(u)return u;}catch(e){}
    var w=words(s),best='',m,rx=/[\d(.][\d\s+\-*\/^().%!]*[\d)%!]/g;
    while((m=rx.exec(w))){var c=m[0].trim();if(/\d\s*[+\-*\/^%!]\s*[\d(]|\d\s*!|\)\s*[+\-*\/^]/.test(c)&&c.length>best.length)best=c;}
    var f=/\b(sqrt|cbrt)\s*\(?\s*\d+(\.\d+)?\s*\)?/.exec(w);if(!best&&f)best=f[0];
    if(!best)return null;
    if(/^\d{1,2}\s*[\/-]\s*\d{1,2}(\s*[\/-]\s*\d{2,4})$/.test(best))return null; // looks like a date
    var r=run(best);return r.ok?r:null;
  }
  var api={run:run,find:find};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else G.hcCalc=api;
})(typeof window!=='undefined'?window:this);
