/* bday.js: Dom's Birthday 2026. ES5 only, no CSS filters.
   Shows ONLY on Nov 5 2026 in America/Chicago: 2026-11-05T06:00Z up to 2026-11-06T06:00Z (Date.now() check, client side).
   After that it does nothing at all (no cleanup needed). Hidden test override: ?bday=1.
   1) a "It's Dom's Birthday!" ribbon at the top with a small x (hidden for this session when tapped)
   2) a light confetti + balloon animation, once per page load (skipped after the x, lighter with reduced motion)
   window.domoBday = {on, confetti(opts)}  (Tabo's bdaycake.js uses it). */
(function(){
  'use strict';
  var D=document,W=window;
  var T0=Date.UTC(2026,10,5,6,0,0),T1=Date.UTC(2026,10,6,6,0,0);
  var force=/[?&]bday=1(&|$)/.test(location.search);
  var now=Date.now?Date.now():new Date().getTime();
  var on=force||(now>=T0&&now<T1);
  var sc=D.currentScript||(function(){var s=D.getElementsByTagName('script');return s[s.length-1];})();
  var site=(sc&&sc.getAttribute('data-site'))||'domo';
  var framed=false;try{framed=W.top!==W;}catch(e){framed=true;}
  W.domoBday={on:on,site:site,confetti:function(){}};
  if(!on||framed)return;
  var KX='bday26_x';
  function ss(k,v){try{if(v===undefined)return sessionStorage.getItem(k);sessionStorage.setItem(k,v);}catch(e){}return null;}
  var reduce=false;try{reduce=!!(W.matchMedia&&W.matchMedia('(prefers-reduced-motion: reduce)').matches);}catch(e){}
  var raf=W.requestAnimationFrame||W.webkitRequestAnimationFrame||function(f){return setTimeout(function(){f(new Date().getTime());},16);};
  var tabo=site==='tabo';

  var css=
    '.bd-rib{position:relative;z-index:59;display:-webkit-box;display:-webkit-flex;display:flex;-webkit-box-align:center;-webkit-align-items:center;align-items:center;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;'+
      'flex-wrap:wrap;-webkit-flex-wrap:wrap;gap:6px 10px;box-sizing:border-box;width:100%;min-height:42px;padding:7px 44px 7px 12px;margin:0;'+
      'font:800 15px/1.25 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;color:#fff;text-align:center;overflow:hidden;'+
      'background:#ff4fa3;background:-webkit-linear-gradient(left,#ff4fa3,#ffb020,#3fd17a,#3aa7ff,#a35cff,#ff4fa3);background:linear-gradient(90deg,#ff4fa3,#ffb020,#3fd17a,#3aa7ff,#a35cff,#ff4fa3);'+
      'background-size:300% 100%;-webkit-animation:bdShim 9s linear infinite;animation:bdShim 9s linear infinite;text-shadow:0 1px 2px rgba(0,0,0,.35);-webkit-flex:none;flex:none}'+
    '.bd-rib.bd-tabo{min-height:38px;font-size:14px;border-bottom:1px solid #f1e3cc}'+
    '.bd-t{display:inline-block;-webkit-animation:bdPop .7s cubic-bezier(.2,1.6,.4,1) both;animation:bdPop .7s cubic-bezier(.2,1.6,.4,1) both}'+
    '.bd-e{display:inline-block;-webkit-animation:bdBob 1.6s ease-in-out infinite;animation:bdBob 1.6s ease-in-out infinite}'+
    '.bd-e2{-webkit-animation-delay:.4s;animation-delay:.4s}'+
    '.bd-go{-webkit-appearance:none;appearance:none;border:0;cursor:pointer;font-weight:800;font-size:13px;line-height:1;font-family:inherit;color:#7a2a00;background:#fff;border-radius:999px;padding:7px 12px;box-shadow:0 2px 0 rgba(0,0,0,.18);text-decoration:none;text-shadow:none;white-space:nowrap}'+
    '.bd-go:active{-webkit-transform:translateY(1px);transform:translateY(1px)}'+
    '.bd-x{position:absolute;right:6px;top:50%;margin-top:-16px;width:32px;height:32px;-webkit-appearance:none;appearance:none;border:0;border-radius:50%;cursor:pointer;background:rgba(0,0,0,.22);color:#fff;font-weight:700;font-size:15px;line-height:32px;font-family:inherit;padding:0;text-align:center}'+
    '.bd-x:hover{background:rgba(0,0,0,.35)}'+
    '.bd-rib :focus-visible{outline:3px solid #fff;outline-offset:2px}'+
    '.bd-cv{position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;z-index:2147483000}'+
    '@-webkit-keyframes bdShim{0%{background-position:0 0}100%{background-position:300% 0}}@keyframes bdShim{0%{background-position:0 0}100%{background-position:300% 0}}'+
    '@-webkit-keyframes bdPop{0%{-webkit-transform:scale(.6);opacity:0}100%{-webkit-transform:scale(1);opacity:1}}@keyframes bdPop{0%{transform:scale(.6);opacity:0}100%{transform:scale(1);opacity:1}}'+
    '@-webkit-keyframes bdBob{0%,100%{-webkit-transform:translateY(0) rotate(-6deg)}50%{-webkit-transform:translateY(-3px) rotate(6deg)}}@keyframes bdBob{0%,100%{transform:translateY(0) rotate(-6deg)}50%{transform:translateY(-3px) rotate(6deg)}}'+
    '@media (max-width:420px){.bd-rib{font-size:14px;padding-right:40px}.bd-go{font-size:12px;padding:6px 10px}}'+
    '@media (prefers-reduced-motion:reduce){.bd-rib,.bd-e,.bd-t{-webkit-animation:none;animation:none}}';

  /* ---------- confetti + balloons (canvas, removed when done) ---------- */
  var COLS=['#ff4fa3','#ffb020','#3fd17a','#3aa7ff','#a35cff','#ff6b4a','#ffe14a'];
  function confetti(o){
    o=o||{};var n=o.n||(reduce?40:110),dur=o.ms||(reduce?1800:4200),balloons=o.balloons===undefined?(reduce?2:7):o.balloons,burst=!!o.burst;
    var cv=D.createElement('canvas');cv.className='bd-cv';cv.setAttribute('aria-hidden','true');
    var dpr=Math.min(W.devicePixelRatio||1,2),w=W.innerWidth||800,h=W.innerHeight||600;
    cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);
    var c=cv.getContext&&cv.getContext('2d');if(!c)return;
    (D.body||D.documentElement).appendChild(cv);c.scale(dpr,dpr);
    var P=[],B=[],i,cx=o.x==null?w/2:o.x,cy=o.y==null?h*0.45:o.y;
    for(i=0;i<n;i++){
      if(burst){var a=Math.random()*Math.PI*2,sp=4+Math.random()*9;P.push({x:cx,y:cy,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-4,r:Math.random()*6.28,vr:(Math.random()-.5)*.4,s:5+Math.random()*6,c:COLS[i%COLS.length],sh:i%3});}
      else P.push({x:Math.random()*w,y:-20-Math.random()*h*0.6,vx:(Math.random()-.5)*2.2,vy:2+Math.random()*3,r:Math.random()*6.28,vr:(Math.random()-.5)*.3,s:5+Math.random()*6,c:COLS[i%COLS.length],sh:i%3});}
    for(i=0;i<balloons;i++)B.push({x:w*(0.08+0.84*Math.random()),y:h+40+Math.random()*h*0.5,vy:2.2+Math.random()*1.6,ph:Math.random()*6.28,s:22+Math.random()*12,c:COLS[(i*2)%COLS.length]});
    var t0=null,stop=false;
    function balloon(b,t){var x=b.x+Math.sin(t/500+b.ph)*12,y=b.y,s=b.s;
      c.strokeStyle='rgba(80,60,60,.55)';c.lineWidth=1.2;c.beginPath();c.moveTo(x,y+s*1.2);c.quadraticCurveTo(x+6,y+s*1.8,x-2,y+s*2.6);c.stroke();
      c.fillStyle=b.c;c.beginPath();c.ellipse?c.ellipse(x,y,s*0.85,s,0,0,6.283):c.arc(x,y,s,0,6.283);c.fill();
      c.beginPath();c.moveTo(x-4,y+s*1.18);c.lineTo(x+4,y+s*1.18);c.lineTo(x,y+s*0.95);c.closePath();c.fill();
      c.fillStyle='rgba(255,255,255,.45)';c.beginPath();c.arc(x-s*0.32,y-s*0.38,s*0.2,0,6.283);c.fill();}
    function frame(ts){if(stop)return;if(t0===null)t0=ts;var t=ts-t0,k=t>dur-700?Math.max(0,(dur-t)/700):1;
      c.clearRect(0,0,w,h);c.globalAlpha=k;
      for(var j=0;j<P.length;j++){var p=P[j];p.x+=p.vx;p.y+=p.vy;p.r+=p.vr;
        if(burst){p.vx*=0.985;p.vy=p.vy*0.985+0.22;}else{p.vy+=0.02;p.x+=Math.sin((t+j*90)/300)*0.6;}
        if(p.y>h+20)continue;c.save();c.translate(p.x,p.y);c.rotate(p.r);c.fillStyle=p.c;
        if(p.sh===0)c.fillRect(-p.s/2,-p.s/4,p.s,p.s/2);else if(p.sh===1){c.beginPath();c.arc(0,0,p.s/2.6,0,6.283);c.fill();}else{c.beginPath();c.moveTo(0,-p.s/2);c.lineTo(p.s/2,p.s/2);c.lineTo(-p.s/2,p.s/2);c.closePath();c.fill();}
        c.restore();}
      for(var m=0;m<B.length;m++){B[m].y-=B[m].vy;balloon(B[m],t);}
      c.globalAlpha=1;
      if(t<dur)raf(frame);else done();}
    function done(){stop=true;if(cv.parentNode)cv.parentNode.removeChild(cv);}
    raf(frame);setTimeout(done,dur+1500);
  }
  W.domoBday.confetti=confetti;

  /* ---------- the ribbon ---------- */
  function build(){
    var st=D.createElement('style');st.id='bd-css';st.appendChild(D.createTextNode(css));(D.head||D.documentElement).appendChild(st);
    if(ss(KX)==='1')return;
    var r=D.createElement('div');r.className='bd-rib'+(tabo?' bd-tabo':'');r.id='bd-rib';r.setAttribute('role','note');r.setAttribute('aria-label','It\u2019s Dom\u2019s Birthday!');
    var h='<span class="bd-t"><span class="bd-e" aria-hidden="true">\uD83C\uDF82</span> It\u2019s Dom\u2019s Birthday! <span class="bd-e bd-e2" aria-hidden="true">\uD83C\uDF89</span></span>';
    if(tabo)h+='<button type="button" class="bd-go" id="bd-go">\uD83C\uDF82 Blow out the cake</button>';
    else h+='<a class="bd-go" id="bd-go" href="https://taboai.sites.tab.bot/?cake=1" target="_blank" rel="noopener">\uD83C\uDF82 Blow out the cake \u2197</a>';
    h+='<button type="button" class="bd-x" id="bd-x" aria-label="Hide the birthday banner">\u2715</button>';
    r.innerHTML=h;
    var host,ref;
    if(tabo){var app=D.getElementById('app'),top=app&&app.querySelector('header.top');if(top){host=app;ref=top.nextSibling;}}
    if(!host){host=D.body;ref=D.body.firstChild;}
    host.insertBefore(r,ref);
    D.getElementById('bd-x').onclick=function(){ss(KX,'1');if(r.parentNode)r.parentNode.removeChild(r);};
    if(tabo){D.getElementById('bd-go').onclick=function(){if(W.taboCake&&W.taboCake.open)W.taboCake.open(this);};}
    var lite=/\blite\b/.test(D.documentElement.className);
    setTimeout(function(){confetti(lite?{n:45,balloons:2}:{});},tabo?1300:900);
  }
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',build);else build();
})();
