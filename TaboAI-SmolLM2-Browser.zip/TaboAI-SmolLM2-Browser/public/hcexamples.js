/* hcexamples.js (hc v1.9.2, the user Nov 1: "add a button where you can add photos as examples so the ai can mimic it").
   ADMIN ONLY: devgate.js loads this file only after the server accepts the admin pass, so normal visitors never get it.
   In Code mode: "📷 Examples" -> pick 1-3 pictures -> shrunk on this device to max 768 px JPEG -> thumbnails with ✕.
   The pictures live only in this page's memory: never localStorage, never saved on the server. On send, /api/dev/vision
   (admin pass) turns them into a short art-style guide (Dev Lab filter on it), and Code mode puts "Match this art style exactly"
   in front of the prompt. A chip shows "📷 Style from N pictures" with the guide folded inside. */
(function(W,D){
  'use strict';
  if(W.hcCodeLook)return;
  var MAX=3,SIDE=768,imgs=[],seq=0,cache=null,working=false;
  function $(i){return D.getElementById(i);}
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function pass(){try{return W.hcDevGate&&W.hcDevGate.pass?W.hcDevGate.pass():'';}catch(e){return '';}}
  function toast(m){try{if(W.hcApp&&W.hcApp.toast)W.hcApp.toast(m);}catch(e){}}
  function css(){if($('hcx-css'))return;var s=D.createElement('style');s.id='hcx-css';
    s.textContent='.hcx{-webkit-flex:none;flex:none;display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;-webkit-align-items:center;align-items:center;gap:6px;padding:0 0 6px}'+
    '.hcx-b{min-height:36px;padding:6px 12px;border:1px solid #fcc8a6;border-radius:11px;background:#ffffff;color:#5d544c;font:inherit;font-size:13.5px;font-weight:800;cursor:pointer;-webkit-tap-highlight-color:transparent;white-space:nowrap}'+
    '.hcx-b:disabled{opacity:.5;cursor:default}.hcx-b:focus-visible{outline:3px solid #f6a274;outline-offset:1px}'+
    '.hcx-t{position:relative;width:44px;height:44px;border-radius:9px;overflow:hidden;border:2px solid #fcc8a6;background:#f3efeb;-webkit-flex:none;flex:none}'+
    '.hcx-t img{display:block;width:100%;height:100%;object-fit:cover;image-rendering:pixelated}'+
    '.hcx-x{position:absolute;top:1px;right:1px;width:20px;height:20px;padding:0;border:0;border-radius:50%;background:rgba(0,0,0,.65);color:#ffffff;font-size:12px;line-height:20px;text-align:center;cursor:pointer}'+
    '.hcx-n{font-size:12px;font-weight:700;color:#933914}'+
    '.hcx-c{-webkit-flex:1 1 100%;flex:1 1 100%;margin:2px 0 0;border:1px solid #fcc8a6;border-radius:11px;background:#fcfaf9;font-size:13px;color:#201d1a;max-width:100%;box-sizing:border-box}'+
    '.hcx-c summary{cursor:pointer;padding:6px 10px;font-weight:800;color:#5d544c;list-style:none;-webkit-user-select:none;user-select:none}.hcx-c summary::-webkit-details-marker{display:none}'+
    '.hcx-c summary:after{content:" \u25B8";}.hcx-c[open] summary:after{content:" \u25BE";}'+
    '.hcx-c pre{margin:0;padding:0 10px 8px;white-space:pre-wrap;word-break:break-word;font:inherit;font-size:12.5px;line-height:1.4;max-height:30vh;overflow:auto}'+
    '.hcx-sw{display:inline-block;width:12px;height:12px;border-radius:3px;vertical-align:-2px;margin-left:3px;border:1px solid rgba(0,0,0,.25)}'+
    '.hcx-m{font-weight:600;font-size:11.5px;color:#933914;margin-left:4px}'+
    'html.hw .hcx-b{background:#1e1c19;border-color:#3b3530;color:#ffe5d4}html.hw .hcx-t{border-color:#3b3530;background:#191715}html.hw .hcx-n,html.hw .hcx-m{color:#f6a274}'+
    'html.hw .hcx-c{background:#191715;border-color:#3b3530;color:#f0ebe7}html.hw .hcx-c summary{color:#fcc8a6}'+
    '@media (min-width:900px){.code .hcx{max-width:900px;margin-left:auto;margin-right:auto;width:100%}}'+
    '@media (max-width:260px){.hcx{display:none!important}}';
    D.getElementsByTagName('head')[0].appendChild(s);}
  /* ---- pictures: shrink on the device, measure the colors + the pixel size ---- */
  function hex(r,g,b){return '#'+((1<<24)|(r<<16)|(g<<8)|b).toString(16).slice(1).toUpperCase();}
  function palette(list){ // most-used colors across the pictures (nearest-neighbour sample, close colors merged)
    var cnt={},tot=0;
    for(var k=0;k<list.length;k++){var im=list[k].el,w=im.naturalWidth||im.width,h=im.naturalHeight||im.height;if(!w||!h)continue;
      var s=Math.min(1,160/Math.max(w,h)),cw=Math.max(1,Math.round(w*s)),ch=Math.max(1,Math.round(h*s));
      var c=D.createElement('canvas');c.width=cw;c.height=ch;var x=c.getContext('2d');x.imageSmoothingEnabled=false;x.drawImage(im,0,0,cw,ch);
      var d;try{d=x.getImageData(0,0,cw,ch).data;}catch(e){continue;}
      for(var i=0;i<d.length;i+=4){if(d[i+3]<128)continue;var key=(d[i]>>3)+','+(d[i+1]>>3)+','+(d[i+2]>>3);var o=cnt[key];if(!o)o=cnt[key]={n:0,r:0,g:0,b:0};o.n++;o.r+=d[i];o.g+=d[i+1];o.b+=d[i+2];tot++;}}
    var arr=[];for(var q in cnt){var o2=cnt[q];arr.push({n:o2.n,r:o2.r/o2.n,g:o2.g/o2.n,b:o2.b/o2.n});}
    arr.sort(function(a,b){return b.n-a.n;});
    var out=[];for(var j=0;j<arr.length&&out.length<8;j++){var a=arr[j];if(a.n<tot*0.01)break;var near=null;
      for(var m=0;m<out.length;m++){var o3=out[m];if(Math.abs(o3.r-a.r)+Math.abs(o3.g-a.g)+Math.abs(o3.b-a.b)<48){near=o3;break;}}
      if(near)near.n+=a.n;else out.push({n:a.n,r:a.r,g:a.g,b:a.b});}
    return out.map(function(o){return hex(Math.round(o.r),Math.round(o.g),Math.round(o.b));});
  }
  function cellSize(it){ // pixel art scaled up = runs of one color whose lengths share a size (a photo has none)
    var im=it.el,w=im.naturalWidth,h=im.naturalHeight;if(!w||!h||Math.max(w,h)>2400)return null;
    var c=D.createElement('canvas');c.width=w;c.height=h;var x=c.getContext('2d');x.imageSmoothingEnabled=false;x.drawImage(im,0,0);
    var runs=[],rows=Math.min(48,h);
    for(var ri=0;ri<rows;ri++){var y=Math.floor((ri+0.5)*h/rows),d;try{d=x.getImageData(0,y,w,1).data;}catch(e){return null;}
      var st=0;for(var i=1;i<=w;i++){var p=i*4,q=(i-1)*4;
        if(i===w||Math.abs(d[p]-d[q])+Math.abs(d[p+1]-d[q+1])+Math.abs(d[p+2]-d[q+2])>30){var L=i-st;if(st>0&&i<w)runs.push(L);st=i;}}}
    if(runs.length<12)return null;
    runs.sort(function(a,b){return a-b;});if(runs[Math.floor(runs.length/2)]<3)return null;
    for(var cs=64;cs>=4;cs--){var ok=0;for(var k=0;k<runs.length;k++){var r=runs[k]%cs;if(runs[k]>=cs-1&&(r<=1||cs-r<=1))ok++;}
      if(ok>=runs.length*0.85)return {w:w,h:h,cell:cs};}
    return null;
  }
  function shrink(im){var w=im.naturalWidth,h=im.naturalHeight,s=Math.min(1,SIDE/Math.max(w,h)),cw=Math.max(1,Math.round(w*s)),ch=Math.max(1,Math.round(h*s));
    var c=D.createElement('canvas');c.width=cw;c.height=ch;var x=c.getContext('2d');x.fillStyle='#ffffff';x.fillRect(0,0,cw,ch);x.imageSmoothingEnabled=s<0.5;x.drawImage(im,0,0,cw,ch);
    var u=c.toDataURL('image/jpeg',0.86);if(u.length>400000)u=c.toDataURL('image/jpeg',0.7);return u;}
  function addFiles(files){
    var list=[].slice.call(files||[]).filter(function(f){return /^image\//.test(f.type||'')||/\.(png|jpe?g|gif|webp|heic|heif)$/i.test(f.name||'');});
    if(!list.length)return;
    var room=MAX-imgs.length;if(room<=0){toast('\uD83D\uDCF7 Up to 3 pictures');return;}
    if(list.length>room)toast('\uD83D\uDCF7 Only '+MAX+' pictures fit, kept the first '+room);
    list.slice(0,room).forEach(function(f){
      var url=(W.URL||W.webkitURL).createObjectURL(f),im=new Image();
      im.onload=function(){var it={id:++seq,el:im};try{it.cell=cellSize(it);it.data=shrink(im);}catch(e){it.data='';}
        (W.URL||W.webkitURL).revokeObjectURL(url);
        if(!it.data){toast('\uD83D\uDCF7 That picture couldn\u2019t be read');return;}
        if(imgs.length>=MAX)return;imgs.push(it);cache=null;render();};
      im.onerror=function(){(W.URL||W.webkitURL).revokeObjectURL(url);toast('\uD83D\uDCF7 That picture couldn\u2019t be opened. Try a PNG or JPEG.');};
      im.src=url;});
  }
  /* ---- the row next to the prompt box ---- */
  var row=null,btn=null,file=null,thumbs=null,chip=null;
  function build(){
    if(row&&row.parentNode)return true;
    var form=$('cb-form');if(!form||!form.parentNode)return false;css();
    row=D.createElement('div');row.className='hcx';row.id='hcx';
    row.innerHTML='<button type="button" class="hcx-b" id="hcx-b" title="Add 1-3 example pictures so the AI copies their art style">\uD83D\uDCF7 Examples</button>'+
      '<input type="file" id="hcx-f" accept="image/*" multiple hidden><span class="hcx-th" id="hcx-th" style="display:contents"></span><span class="hcx-n" id="hcx-n"></span><div id="hcx-ch" style="display:contents"></div>';
    form.parentNode.insertBefore(row,form);
    btn=$('hcx-b');file=$('hcx-f');thumbs=$('hcx-th');chip=$('hcx-ch');
    btn.addEventListener('click',function(){if(working)return;if(imgs.length>=MAX){toast('\uD83D\uDCF7 Up to 3 pictures. Tap \u2715 to remove one.');return;}file.value='';file.click();});
    file.addEventListener('change',function(){addFiles(file.files);file.value='';});
    thumbs.addEventListener('click',function(e){var b=e.target;if(!b||!b.getAttribute||!b.getAttribute('data-x')||working)return;var id=+b.getAttribute('data-x');
      imgs=imgs.filter(function(x){return x.id!==id;});cache=null;render();});
    render();return true;
  }
  function render(){
    if(!row)return;
    var h='';for(var i=0;i<imgs.length;i++)h+='<span class="hcx-t"><img src="'+imgs[i].data+'" alt="Example picture '+(i+1)+'"><button type="button" class="hcx-x" data-x="'+imgs[i].id+'" aria-label="Remove picture '+(i+1)+'">\u2715</button></span>';
    thumbs.innerHTML=h;
    $('hcx-n').textContent=imgs.length?(imgs.length+'/'+MAX+(cache?'':' \u00B7 style is read when you send')):'';
    btn.disabled=working;btn.textContent=imgs.length?'\uD83D\uDCF7 +':'\uD83D\uDCF7 Examples';btn.setAttribute('aria-label',imgs.length?'Add another example picture':'Add example pictures');
    if(cache&&imgs.length){var pal=(cache.desc.match(/#[0-9A-Fa-f]{6}\b/g)||[]).filter(function(v,i,a){return a.indexOf(v)===i;}).slice(0,8);
      chip.innerHTML='<details class="hcx-c" id="hcx-c"><summary>\uD83D\uDCF7 Style from '+cache.n+(cache.n>1?' pictures':' picture')+pal.map(function(p){return '<span class="hcx-sw" style="background:'+p+'"></span>';}).join('')+
        '<span class="hcx-m">'+esc(cache.model)+'</span></summary><pre>'+esc(cache.desc)+'</pre></details>';}
    else chip.innerHTML='';
  }
  function key(){return imgs.map(function(x){return x.id;}).join(',');}
  function get(){
    var tk=pass();
    if(!tk)return Promise.reject({message:'Admin mode is off. Turn it on with the \uD83D\uDD28 to use example pictures.'});
    if(cache&&cache.key===key())return Promise.resolve({t:cache.desc,sig:cache.sig,n:cache.n,token:tk});
    var px=null;for(var i=0;i<imgs.length&&!px;i++)px=imgs[i].cell||null;
    var body={token:tk,images:imgs.map(function(x){return x.data;}),pal:palette(imgs)};if(px)body.px=px;
    var k=key(),ctrl=('AbortController' in W)?new AbortController():null,timer=setTimeout(function(){if(ctrl)ctrl.abort();},20000);
    return W.fetch('/api/dev/vision',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:ctrl?ctrl.signal:undefined})
      .then(function(r){return r.json().catch(function(){return {ok:false,message:r.status===413?'Those pictures are too big. Try 1 or 2.':'The picture reader had a problem. Try again.'};});},
        function(){throw {message:'Reading the pictures took too long (over 20 s) or the wifi dropped. Try again!'};})
      .then(function(j){clearTimeout(timer);
        if(!j||!j.ok||!j.desc||!j.sig)throw {message:(j&&j.message)||'Couldn\u2019t read the pictures. Try again!'};
        if(k!==key())throw {message:'The pictures changed. Tap send again.'};
        cache={key:k,desc:j.desc,sig:j.sig,n:j.n||imgs.length,model:j.model||''};render();
        return {t:cache.desc,sig:cache.sig,n:cache.n,token:tk};},
        function(e){clearTimeout(timer);throw e;});
  }
  W.hcCodeLook={has:function(){return !!(imgs.length&&W.hcDevGate&&W.hcDevGate.admin&&W.hcDevGate.admin());},count:function(){return imgs.length;},get:get,
    busy:function(b){working=!!b;render();},clear:function(){imgs=[];cache=null;render();},_add:addFiles};
  if(!build()){var tries=0,iv=setInterval(function(){if(build()||++tries>40)clearInterval(iv);},250);}
})(window,document);
