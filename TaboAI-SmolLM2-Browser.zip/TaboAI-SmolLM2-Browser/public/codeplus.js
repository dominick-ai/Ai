/* codeplus.js (Tabo v2.1 "Glow-up", the user Nov 2 6:29 PM: "make coding more cooler and easier and better").
   Adds to Code mode (hccode.js stays as it was): a starter gallery of 8 one-tap templates, "✨ Improve it" buttons after a build,
   clear status steps (Planning → Writing → Testing), friendlier bug messages with a 🔧 Auto-fix that sends the error back to the coder. ES5 only. */
(function(){
  'use strict';
  var W=window,D=document;function $(id){return D.getElementById(id);}
  var empty=$('cb-empty'),busyEl=$('cb-busy'),errEl=$('cb-err'),chips=$('cb-chips'),langSel=$('cb-lang'),form=$('cb-form');
  if(!empty||!busyEl||!W.hcCode)return;
  var HC=W.hcCode; /* lessons.js later replaces window.hcCode with its own object; keep ours and merge it back (fixes the Code-mode 🕘 projects button too) */
  function merge(){var o=W.hcCode;if(o&&o!==HC){for(var k in HC)if(HC.hasOwnProperty(k)&&!(k in o))o[k]=HC[k];}else if(!o)W.hcCode=HC;}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',merge);else setTimeout(merge,0);W.addEventListener('load',merge);
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function setC(el,c,on){if(!el)return;var s=' '+el.className+' ',h=s.indexOf(' '+c+' ')>=0;if(on&&!h)el.className+=' '+c;else if(!on&&h)el.className=s.replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  var TPL=[
    ['\uD83C\uDFC3','Platformer','#ff7ec0','Make a colorful platformer game: a cute round hero that runs with the arrow keys or on-screen buttons and jumps (space or a big jump button), 3 floating platforms per screen, shiny coins to collect, a score counter, simple enemies that walk back and forth, and a goal flag. Works with touch on an iPad.'],
    ['\uD83D\uDC46','Clicker','#ffa557','Make a clicker game: tap a big bouncy cookie to earn points, with a shop of 4 upgrades (auto clicker, double tap, grandma, factory) that cost more each time, a points-per-second counter, fun pop animations and floating +1 numbers. Save progress in localStorage.'],
    ['\uD83D\uDC0D','Snake','#5ee6b4','Make a smooth snake game on a checkerboard grid: a cute rounded snake with eyes, an apple to eat, the snake grows, score + high score (saved), arrow keys plus swipe and on-screen arrows for iPad, speed goes up slowly, a game over screen with Play again.'],
    ['\u2753','Quiz','#6dbbff','Make a fun quiz app with 10 kid-friendly multiple choice questions about space, animals and science. Big colorful answer buttons, green/red feedback, a progress bar, a score at the end with stars and a Play again button.'],
    ['\uD83C\uDFA8','Drawing app','#ad85ff','Make a drawing app: draw with your finger or mouse on a big canvas, a color palette with 10 colors, brush sizes, an eraser, undo, clear, and a Save picture button that downloads a PNG. Works with touch on an iPad.'],
    ['\uD83C\uDFB5','Music maker','#ffd84d','Make a music maker: a 16-step beat grid with 4 drum rows (kick, snare, hi-hat, clap) and a row of piano notes, play/stop, tempo slider, made with the Web Audio API (no sound files). Colorful glowing buttons, tap to toggle steps.'],
    ['\uD83D\uDC36','Pet sim','#ff9a8b','Make a virtual pet game: a cute animated pet with hunger, happiness and energy bars that slowly go down, buttons to Feed, Play and Sleep, the pet changes face with its mood, earn coins to buy hats, and save everything in localStorage.'],
    ['\uD83E\uDDEE','Calculator','#7cd4c5','Make a pretty calculator app with big round buttons, + - \u00D7 \u00F7, decimals, percent, clear and backspace, a history list of past answers, and keyboard support. Do the math safely without eval.']];
  var IMP=[['\uD83D\uDD0A Add sound','Add fun sound effects using the Web Audio API (no sound files): a sound for actions, scoring and game over, plus a mute button.'],
    ['\uD83E\uDDF1 Add levels','Add 3 levels that get harder, with a "Level 2!" message between levels and a level counter.'],
    ['\u2728 Make it prettier','Make it way prettier: bright colorful gradients, rounded shapes, smooth animations, nicer fonts, keep everything working.'],
    ['\uD83C\uDFC6 Add a high score','Add a high score that is saved in localStorage and shown on screen, with a "New high score!" celebration.'],
    ['\uD83D\uDC1B Fix a bug','Find and fix any bugs, make the controls work with touch on an iPad, and make sure nothing breaks.']];
  /* ---- 1. starter gallery ---- */
  var gal=D.createElement('div');gal.className='cp-gal';gal.setAttribute('role','list');
  var gh='<p class="cp-gh">\u2728 Tap a starter to build it:</p><div class="cp-grid">';
  for(var i=0;i<TPL.length;i++)gh+='<button type="button" class="cp-t" role="listitem" data-i="'+i+'" style="--c:'+TPL[i][2]+'"><span class="cp-ti" style="background:'+TPL[i][2]+'">'+TPL[i][0]+'</span><b>'+TPL[i][1]+'</b></button>';
  gal.innerHTML=gh+'</div>';empty.appendChild(gal);
  function toWeb(){if(langSel&&langSel.value!=='web'){var has=false;for(var k=0;k<langSel.options.length;k++)if(langSel.options[k].value==='web')has=true;
      if(has){langSel.value='web';var ev;try{ev=new Event('change',{bubbles:true});}catch(e){ev=D.createEvent('Event');ev.initEvent('change',true,true);}langSel.dispatchEvent(ev);}}}
  gal.addEventListener('click',function(e){var b=e.target;while(b&&b!==gal&&!b.getAttribute('data-i'))b=b.parentNode;if(!b||b===gal)return;var t=TPL[+b.getAttribute('data-i')];
    toWeb();var inp=$('cb-msg');if(inp)inp.value=t[3];setTimeout(function(){HC.ask(t[3]);},30);});
  /* ---- 2. ✨ Improve it, after a build ---- */
  var imp=D.createElement('div');imp.className='cp-imp';imp.hidden=true;var ih='<span class="cp-il">\u2728 Improve it:</span>';
  for(var j=0;j<IMP.length;j++)ih+='<button type="button" class="cp-ib" data-j="'+j+'">'+IMP[j][0]+'</button>';imp.innerHTML=ih;
  if(chips&&chips.parentNode)chips.parentNode.insertBefore(imp,chips);
  imp.addEventListener('click',function(e){var b=e.target;while(b&&b!==imp&&!b.getAttribute('data-j'))b=b.parentNode;if(!b||b===imp)return;HC.ask(IMP[+b.getAttribute('data-j')][1]);});
  function hasCode(){var ta=$('cb-ta');return !!(ta&&/\S/.test(ta.value));}
  function paintImp(){imp.hidden=!(hasCode()&&busyEl.hidden);}
  /* ---- 3. status steps while building ---- */
  var steps=D.createElement('div');steps.className='cp-steps';steps.innerHTML='<span data-s="0">\uD83D\uDCDD Planning</span><i>\u2192</i><span data-s="1">\u270D\uFE0F Writing</span><i>\u2192</i><span data-s="2">\uD83E\uDDEA Testing</span>';
  busyEl.appendChild(steps);var stT=[],t0=0;
  function step(n){var s=steps.querySelectorAll('span');for(var k=0;k<s.length;k++){setC(s[k],'on',k===n);setC(s[k],'done',k<n);}steps.setAttribute('data-step',n);}
  var wasBusy=false;
  function watch(){var b=!busyEl.hidden;
    if(b&&!wasBusy){t0=new Date().getTime();step(0);clearTimeout(stT[0]);clearTimeout(stT[1]);stT[0]=setTimeout(function(){step(1);},3500);imp.hidden=true;}
    if(!b&&wasBusy){clearTimeout(stT[0]);step(2);setC(steps,'fin',true);setTimeout(function(){setC(steps,'fin',false);},1200);setTimeout(paintImp,60);}
    wasBusy=b;}
  /* ---- 4. friendlier bugs + 🔧 Auto-fix ---- */
  function fixErr(){if(!errEl||errEl.hidden)return;var btn=errEl.querySelector('.cb-fix');if(btn&&btn.getAttribute('data-cp')!=='1'){btn.setAttribute('data-cp','1');btn.innerHTML='\uD83D\uDD27 Auto-fix';
      var sp=errEl.querySelector('span');if(sp&&!/^Oops/.test(sp.textContent))sp.textContent='Oops, a little bug \uD83D\uDC1B: '+sp.textContent;}}
  if(W.MutationObserver){var mo=new MutationObserver(function(){watch();fixErr();paintImp();});mo.observe(busyEl,{attributes:true,attributeFilter:['hidden']});
    if(errEl)mo.observe(errEl,{attributes:true,childList:true,subtree:true});var ta=$('cb-ta');if(ta)ta.addEventListener('input',paintImp);
    var em=new MutationObserver(paintImp);em.observe(empty,{attributes:true,attributeFilter:['hidden']});}
  else setInterval(function(){watch();fixErr();paintImp();},500);
  paintImp();
  W.hcCodePlus={templates:TPL.length,improve:IMP.length,state:function(){return {gallery:!!gal.offsetWidth,improve:!imp.hidden,step:steps.getAttribute('data-step')};}};
})();
