/* landing.js (Tabo AI v2.9.8: icons + copy cleaned up, see tabo.css) (was v2.9.7) the user Nov 11 3:29 PM: "make the site more professional ... just a page that shows the blob buddy and it says Tabo ai
   ... a button that goes to the actual chat and a dropdown menu with all the options, make a dark mode".
   The clean home page + ☰ Menu (every feature) + 🌙 dark mode (html.tl-dark, saved, defaults to the device setting). ES5 only. */
(function(){
  'use strict';
  var W=window,D=document,R=D.documentElement;
  function $(id){return D.getElementById(id);}
  function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);if(v===null)localStorage.removeItem(k);else localStorage.setItem(k,v);}catch(e){}return null;}
  function hasC(el,c){return !!el&&(' '+el.className+' ').indexOf(' '+c+' ')>=0;}
  function setC(el,c,v){if(!el)return;var h=hasC(el,c);if(v&&!h)el.className=(el.className?el.className+' ':'')+c;else if(!v&&h)el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function toast(m){try{if(W.hcApp&&W.hcApp.toast)W.hcApp.toast(m);}catch(e){}}

  /* ---------- 🌙 theme ---------- */
  var TK='tl_theme',mq=null;try{mq=W.matchMedia?W.matchMedia('(prefers-color-scheme: dark)'):null;}catch(e){mq=null;}
  function isDark(){return hasC(R,'tl-dark');}
  function paintTheme(){var d=isDark();
    var m=D.querySelector('meta[name="theme-color"]');if(m)m.setAttribute('content',d?'#1d1b19':'#ffffff');
    var bs=D.querySelectorAll('[data-tl-theme]');for(var i=0;i<bs.length;i++){var b=bs[i];b.setAttribute('aria-pressed',d?'true':'false');
      var lb=b.querySelector('.tl-tl');if(lb)lb.textContent=d?'Dark mode: on':'Dark mode: off';else b.innerHTML=W.TaboIcon?W.TaboIcon(d?'sun':'moon'):(d?'Light':'Dark');
      b.title=d?'Switch to light mode':'Switch to dark mode';b.setAttribute('aria-label',b.title);}}
  function setTheme(d,save){setC(R,'tl-dark',!!d);if(save)ls(TK,d?'dark':'light');paintTheme();}
  if(mq){var onMq=function(){if(!ls(TK))setTheme(mq.matches,false);};if(mq.addListener)mq.addListener(onMq);else if(mq.addEventListener)mq.addEventListener('change',onMq);}
  function toggleTheme(){setTheme(!isDark(),true);toast(isDark()?'Dark mode on':'Light mode on');}
  W.hcTheme={dark:isDark,set:function(d){setTheme(d,true);},toggle:toggleTheme,auto:function(){ls(TK,null);setTheme(mq?mq.matches:false,false);}};

  /* ---------- 🫧 the blob buddy (same shape + colors as the 😀 Talking blob, voice.js) ---------- */
  var COLS={bubblegum:['#ffc2e2','#ff7ec0','#ec4f9e'],tangerine:['#ffdcae','#ffa557','#f57a2c'],lemon:['#fff6b8','#ffe066','#f7b928'],mint:['#c4fae3','#5ee6b4','#1fbf88'],
    sky:['#c6e8ff','#6dbbff','#3c86f2'],grape:['#e3d1ff','#ad85ff','#7d4fe0'],cotton:['#ffd0ea','#d9c2ff','#a6d6ff'],rainbow:['#ff6b8b','#ffd166','#5ee6b4','#6dbbff','#b28dff']};
  function blobCol(){var c='bubblegum';try{var b=JSON.parse(ls('hc_blob_v1')||'null');if(b&&COLS[b.col])c=b.col;}catch(e){}return c;}
  var INK='#3b2350';
  function stops(c){var a=COLS[c]||COLS.bubblegum,h='';for(var i=0;i<a.length;i++)h+='<stop offset="'+(a.length>1?(i/(a.length-1)).toFixed(2):0)+'" stop-color="'+a[i]+'"/>';return h;}
  function eye(cx){return '<g class="tlb-eye" transform="translate('+cx+' 100)"><g class="tlb-ein"><ellipse rx="12" ry="14" fill="#fff" stroke="'+INK+'" stroke-width="2.6"/>'+
    '<g clip-path="url(#tlbClip)"><g class="tlb-pup"><circle r="7" fill="#2a1840"/><circle cx="-2.5" cy="-2.8" r="2.5" fill="#fff"/></g></g></g></g>';}
  function blobSVG(){var c=blobCol();
    return '<svg class="tlb-svg" viewBox="0 0 200 200" aria-hidden="true" focusable="false"><defs><linearGradient id="tlbG" x1="0" y1="0" x2="1" y2="1">'+stops(c)+'</linearGradient>'+
      '<radialGradient id="tlbShine" cx="35%" cy="25%" r="60%"><stop offset="0" stop-color="#fff" stop-opacity=".75"/><stop offset=".5" stop-color="#fff" stop-opacity=".12"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>'+
      '<clipPath id="tlbClip"><ellipse rx="12.5" ry="14"/></clipPath></defs>'+
      '<ellipse class="tlb-shadow" cx="100" cy="186" rx="52" ry="7" fill="#7c3aed" opacity=".14"/>'+
      '<g class="tlb-body"><path class="tlb-blob" d="'+blobD(0,1,1,176)+'" fill="url(#tlbG)" stroke="rgba(80,40,110,.18)" stroke-width="2" stroke-linejoin="round"/>'+
      '<path class="tlb-gloss" d="'+blobD(0,1,1,176)+'" fill="url(#tlbShine)"/>'+
      '<ellipse cx="68" cy="66" rx="13" ry="7.5" fill="#fff" opacity=".6" transform="rotate(-28 68 66)"/><circle cx="84" cy="57" r="3.4" fill="#fff" opacity=".7"/>'+
      '<g class="tlb-face"><ellipse cx="58" cy="124" rx="12" ry="7.5" fill="#ff5f99" opacity=".3"/><ellipse cx="142" cy="124" rx="12" ry="7.5" fill="#ff5f99" opacity=".3"/>'+
      eye(74)+eye(126)+'<path class="tlb-mouth" d="'+mouthD(0)+'" fill="#4a1636" stroke="'+INK+'" stroke-width="2.6" stroke-linejoin="round"/></g></g></svg>';}
  function f1(n){return n.toFixed(1);}
  function blobD(t,sx,sy,base){var N=30,pts=[],cx=100,R0=64,cy=base-R0*sy,i;
    for(i=0;i<N;i++){var a=i/N*Math.PI*2,ca=Math.cos(a),sa=Math.sin(a),r=R0*(1+.032*Math.sin(3*a+t*2.1)+.022*Math.sin(5*a-t*1.7));pts.push([cx+ca*r*sx,cy+sa*r*sy]);}
    var d='M'+f1((pts[N-1][0]+pts[0][0])/2)+' '+f1((pts[N-1][1]+pts[0][1])/2);
    for(i=0;i<N;i++){var p=pts[i],q=pts[(i+1)%N];d+='Q'+f1(p[0])+' '+f1(p[1])+' '+f1((p[0]+q[0])/2)+' '+f1((p[1]+q[1])/2);}return d+'Z';}
  function mouthD(o){var y0=128,cx=100,hw=18+o*4,yT=y0+5-2*o,yB=y0+11+24*o*.9;
    return 'M'+f1(cx-hw)+' '+y0+'Q'+cx+' '+f1(yT)+' '+f1(cx+hw)+' '+y0+'Q'+f1(cx+hw*.82)+' '+f1(yB)+' '+cx+' '+f1(yB)+'Q'+f1(cx-hw*.82)+' '+f1(yB)+' '+f1(cx-hw)+' '+y0+'Z';}

  var B={svg:null,blob:null,gloss:null,body:null,face:null,shadow:null,mouth:null,pups:[],eins:[],raf:0,t0:0,last:0,lx:0,ly:0,tx:0,ty:0,nextLook:0,blink:-1e9,nextBlink:0,joy:0,joyT:0,run:false};
  var RAF=W.requestAnimationFrame||function(f){return setTimeout(function(){f(new Date().getTime());},33);};
  var CAF=W.cancelAnimationFrame||clearTimeout;
  var still=false;try{still=!!(W.matchMedia&&W.matchMedia('(prefers-reduced-motion: reduce)').matches);}catch(e){}
  function now(){return new Date().getTime();}
  function frame(){B.raf=0;if(!B.run)return;var n=now();
    if(n-B.last<30){B.raf=RAF(frame);return;}B.last=n;var t=(n-B.t0)/1000;
    var j=0;if(B.joyT){var k=(n-B.joyT)/700;if(k>=1){B.joyT=0;}else j=Math.sin(k*Math.PI);}
    var br=Math.sin(t*2.2)*.022,hop=Math.abs(Math.sin(t*1.6))*4+j*16,sx=1+br*.6+j*.06,sy=1-br*.6-j*.05;
    var d=blobD(t,sx,sy,176);B.blob.setAttribute('d',d);B.gloss.setAttribute('d',d);
    B.body.setAttribute('transform','translate(0 '+f1(-hop)+') rotate('+f1(Math.sin(t*1.3)*2.5)+' 100 150)');
    B.shadow.setAttribute('rx',f1(52*sx*(1-hop/70)));
    if(n>B.nextLook){B.nextLook=n+1200+Math.random()*2200;if(!B.ptr){B.tx=(Math.random()*2-1)*4;B.ty=(Math.random()*2-1)*3;}}
    B.lx+=(B.tx-B.lx)*.18;B.ly+=(B.ty-B.ly)*.18;
    for(var i=0;i<B.pups.length;i++)B.pups[i].setAttribute('transform','translate('+f1(B.lx)+' '+f1(B.ly)+')');
    if(n>B.nextBlink){B.blink=n;B.nextBlink=n+2400+Math.random()*3200;}
    var bt=n-B.blink,ys=bt<160?Math.max(.08,Math.abs(1-bt/80)):1;
    for(var q=0;q<B.eins.length;q++)B.eins[q].setAttribute('transform','scale(1 '+ys.toFixed(2)+')');
    B.face.setAttribute('transform','translate('+f1(B.lx*.6)+' '+f1(B.ly*.5-hop*.1)+')');
    B.mouth.setAttribute('d',mouthD(j*.8+Math.max(0,Math.sin(t*.9))*.08));
    B.raf=RAF(frame);}
  function blobStart(){if(!B.svg||B.run||still)return;B.run=true;if(!B.t0)B.t0=now();B.raf=RAF(frame);}
  function blobStop(){B.run=false;if(B.raf){try{CAF(B.raf);}catch(e){}B.raf=0;}}
  function lookAt(x,y){if(!B.svg)return;var r=B.svg.getBoundingClientRect();if(!r.width)return;var dx=x-(r.left+r.width/2),dy=y-(r.top+r.height*.5),m=Math.sqrt(dx*dx+dy*dy)||1;
    B.tx=dx/m*Math.min(5,m/40);B.ty=dy/m*Math.min(4,m/50);B.ptr=1;clearTimeout(B.ptrT);B.ptrT=setTimeout(function(){B.ptr=0;},2500);}

  /* ---------- the menu: every feature on the site ---------- */
  var SC='https://www.icloud.com/shortcuts/427be77cf54a40ab935f4b6e9c3f2d1e';
  var MENU=[
    ['Chat',[
      ['chat','chat','Chat','Talk to Tabo AI'],
      ['models','models','Pick an AI','3 keyless AI routes'],
      ['history','history','Chat history','Your saved chats'],
      ['newchat','plus','New chat','Start fresh'],
      ['face','face','Talking blob','Talk out loud with your blob buddy'],
      ['unhinged','bolt','Unhinged mode','Roasts + bleeps, still kid-safe']]],
    ['Make + learn',[
      ['code','code','Code mode','Make games + apps with AI'],
      ['lessons','book','Lessons','School subjects K\u201312, code, typing'],
      ['chess','chess','Chess','Play the computer + learn'],
      ['checkers','checkers','Checkers','Play the computer + learn'],
      ['langs','globe','Languages','12 languages with AI role-play'],
      ['tots','sparkle','Tots','Make your own little buddies'],
      ['studio','mic','Song Studio','Write + sing songs'],
      ['music','music','Music Studio Pro','Needs the music pass']]],
    ['You',[
      ['cust','sliders','Customize','Personality, Halloween look + more'],
      ['memory','memory','Memory','What Tabo remembers about you'],
      ['apikey','key','Free API key','Use Tabo in your own apps'],
      ['theme','moon','Dark mode','Light or dark, saved on this device']]],
    ['More',[
      ['l:api.html','doc','API docs','How to use the Tabo API'],
      ['l:get.html','window','Ask Tabo anywhere','Bookmarklet + browser extension'],
      ['l:'+SC,'phone','iPhone Shortcut','Ask Tabo from Siri'],
      ['dev','wrench','Dev Lab','Bug Catcher, keys + admin (PIN)'],
      ['l:https://domotime.sites.tab.bot/','back','Domotime','Back to Dom\u2019s site']]]];
  var LAST_OK={code:1,lessons:1,chess:1,checkers:1,langs:1,tots:1,studio:1,music:1,face:1};
  var NAMES={};(function(){for(var g=0;g<MENU.length;g++)for(var i=0;i<MENU[g][1].length;i++){var it=MENU[g][1][i];NAMES[it[0]]=[it[1],it[2]];}})();

  function menuHTML(id){var h='<div class="tl-menu" id="'+id+'" role="menu" aria-label="All of Tabo" hidden><div class="tl-mscroll">';
    for(var g=0;g<MENU.length;g++){h+='<div class="tl-mg"><div class="tl-mh">'+esc(MENU[g][0])+'</div>';
      for(var i=0;i<MENU[g][1].length;i++){var it=MENU[g][1][i],k=it[0],inner='<span class="tl-mi" aria-hidden="true">'+(W.TaboIcon?W.TaboIcon(it[1]):'')+'</span><span class="tl-mt"><b'+(k==='theme'?' class="tl-tl"':'')+'>'+esc(it[2])+'</b><small>'+esc(it[3])+'</small></span>';
        if(k.indexOf('l:')===0){var u=k.slice(2),ext=/^https?:/.test(u);h+='<a class="tl-mit" role="menuitem" href="'+esc(u)+'"'+(ext||u!=='x'?' target="_blank" rel="noopener"':'')+'>'+inner+'<span class="tl-mx" aria-hidden="true">'+(W.TaboIcon?W.TaboIcon('ext'):'\u2197')+'</span></a>';}
        else h+='<button type="button" class="tl-mit" role="menuitem" data-k="'+k+'"'+(k==='theme'?' data-tl-theme aria-pressed="false"':'')+'>'+inner+(k==='theme'?'<span class="tl-sw"></span>':'')+'</button>';}
      h+='</div>';}
    h+='<label class="tl-skip"><input type="checkbox" class="tl-skipin"> <span>Open straight to chat next time</span></label></div></div>';return h;}

  var home=null,menuOpen=null,opener=null;
  function closeMenus(){var ms=D.querySelectorAll('.tl-menu');for(var i=0;i<ms.length;i++){ms[i].hidden=true;}
    var bs=D.querySelectorAll('[data-tl-menu]');for(var j=0;j<bs.length;j++)bs[j].setAttribute('aria-expanded','false');
    D.removeEventListener('click',outside,true);var o=opener;menuOpen=null;opener=null;return o;}
  function outside(e){if(!menuOpen)return;var n=e.target;while(n){if(n===menuOpen||(n.getAttribute&&n.getAttribute('data-tl-menu')!=null))return;n=n.parentNode;}closeMenus();}
  function openMenu(btn){var id=btn.getAttribute('data-tl-menu'),m=$(id);if(!m)return;if(menuOpen===m){closeMenus();return;}closeMenus();
    m.hidden=false;menuOpen=m;opener=btn;if(id==='tl-cmenu'){try{var rb=btn.getBoundingClientRect();m.style.top=Math.round(rb.bottom+6)+'px';}catch(e){}}btn.setAttribute('aria-expanded','true');paintTheme();
    var cb=m.querySelector('.tl-skipin');if(cb)cb.checked=ls('tl_skip')==='1';
    setTimeout(function(){D.addEventListener('click',outside,true);var f=m.querySelector('.tl-mit');if(f&&W.matchMedia&&W.matchMedia('(hover:hover)').matches)try{f.focus();}catch(e){}},10);}
  function menuKeys(e){if(!menuOpen)return;var k=e.key||'';
    if(k==='Escape'||k==='Esc'){e.preventDefault();e.stopPropagation();var o=closeMenus();if(o)try{o.focus();}catch(x){}return;}
    if(k==='ArrowDown'||k==='ArrowUp'){var its=menuOpen.querySelectorAll('.tl-mit'),ix=-1;for(var i=0;i<its.length;i++)if(its[i]===D.activeElement)ix=i;
      ix=k==='ArrowDown'?(ix+1)%its.length:(ix<=0?its.length-1:ix-1);e.preventDefault();e.stopPropagation();try{its[ix].focus();}catch(x){}}}

  function click(el){if(!el)return false;try{el.click();return true;}catch(e){return false;}}
  function chatMode(){var c=$('hc-mode-chat');if(c&&!hasC(c,'on'))click(c);}
  function codeMode(){var c=$('hc-mode-code');if(c&&!hasC(c,'on'))click(c);}
  function custTo(sel){chatMode();if(W.hcApp&&W.hcApp.open)W.hcApp.open('hc-cust');else click($('hc-cust-btn'));
    if(sel)setTimeout(function(){var b=D.querySelector('#hc-cust .hd-body'),t=D.querySelector(sel);if(b&&t){var hs=b.querySelectorAll('.hd-h');var h=t;
      for(var i=0;i<hs.length;i++){if(hs[i].compareDocumentPosition&&(hs[i].compareDocumentPosition(t)&4))h=hs[i];}
      try{b.scrollTop=Math.max(0,h.offsetTop-12);}catch(e){}}},300);}
  function act(k){
    if(k==='theme'){toggleTheme();return;}
    closeMenus();hide();if(LAST_OK[k])ls('tl_last',k);else if(k==='chat')ls('tl_last',null);
    setTimeout(function(){try{
      if(k==='chat')chatMode();
      else if(k==='newchat'){chatMode();click($('hcf-new'));}
      else if(k==='code')codeMode();
      else if(k==='models'){chatMode();if(!(W.hcKeys&&W.hcKeys.openPicker&&W.hcKeys.openPicker()))click(D.querySelector('#aip .aip-btn'));}
      else if(k==='chain'){chatMode();click($('aip-chb'));}
      else if(k==='history'){chatMode();var hd=$('hc-chats');if(!(hasC(R,'hc-dock')&&hd&&hd.offsetWidth))click($('hc-chats-btn'));}
      else if(k==='face'){chatMode();if(W.hcVoice&&W.hcVoice.open)W.hcVoice.open();}
      else if(k==='unhinged'){chatMode();click($('hc-unh'));}
      else if(k==='lessons'){if(W.hcLessons)W.hcLessons.open();}
      else if(k==='chess'||k==='checkers'){if(W.hcLessons&&W.hcLessons.ext)W.hcLessons.ext.openTo(k==='chess'?'chhome':'ckhome');}
      else if(k==='langs'){if(W.hcLessons&&W.hcLessons.ext)W.hcLessons.ext.openTo('llhome');else click($('hc-ll-open'));}
      else if(k==='tots'){if(W.hcTots&&W.hcTots.open)W.hcTots.open();else click($('hc-tots-btn'));}
      else if(k==='studio'){if(W.hcStudio&&W.hcStudio.open)W.hcStudio.open();else click($('hc-studio-btn'));}
      else if(k==='music'){if(W.hcMusicGate&&W.hcMusicGate.open)W.hcMusicGate.open();}
      else if(k==='dev'){if(W.hcDevGate&&W.hcDevGate.open)W.hcDevGate.open();else click(D.querySelector('.hc-hammer'));}
      else if(k==='cust')custTo(null);
      else if(k==='memory')custTo('#hc-mem-on');
      else if(k==='apikey')custTo('[data-hc-pubkey]');
    }catch(e){}},home?60:0);}
  function onMenuClick(e){var n=e.target;while(n&&n!==D&&!(n.getAttribute&&n.getAttribute('data-k')))n=n.parentNode;if(!n||n===D)return;e.preventDefault();act(n.getAttribute('data-k'));}

  /* ---------- show / hide the home page ---------- */
  function shown(){return !!home&&!home.hidden;}
  function show(){if(!home)return;closeMenus();
    try{if(W.hcLessons&&W.hcLessons.close&&hasC(R,'ls-open'))W.hcLessons.close();}catch(e){}
    try{if(W.hcApp&&W.hcApp.close)W.hcApp.close(true);}catch(e){}
    paintLast();home.hidden=false;void home.offsetWidth;setC(home,'tl-in',true);setC(R,'tl-on',true);blobStart();
    try{var s=$('tl-start');if(s&&W.matchMedia&&W.matchMedia('(hover:hover)').matches)s.focus();}catch(e){}}
  function hide(){if(!home||home.hidden)return;closeMenus();setC(home,'tl-in',false);setC(R,'tl-on',false);blobStop();
    setTimeout(function(){if(!hasC(home,'tl-in'))home.hidden=true;},260);
    try{var s=$('hc-splash');if(s&&s.parentNode)s.parentNode.removeChild(s);}catch(e){}}
  function paintLast(){var c=$('tl-cont');if(!c)return;var k=ls('tl_last');if(k&&LAST_OK[k]&&NAMES[k]){c.hidden=false;c.innerHTML='Continue: '+esc(NAMES[k][1])+' \u2192';c.setAttribute('data-k',k);}else c.hidden=true;}

  function build(){
    home=D.createElement('div');home.id='tl-home';home.className='tl-home';home.setAttribute('role','region');home.setAttribute('aria-label','Tabo AI home');
    home.innerHTML='<header class="tl-top"><div class="tl-brand"><img src="icon-192.png?v=2.9.8" alt="" width="30" height="30"><b>Tabo AI</b></div>'+
      '<div class="tl-tr"><button type="button" class="tl-ib" data-tl-theme aria-pressed="false">\uD83C\uDF19</button>'+
      '<button type="button" class="tl-menub" id="tl-menu-btn" data-tl-menu="tl-menu" aria-haspopup="true" aria-expanded="false" aria-controls="tl-menu"><span class="tl-bars" aria-hidden="true"><i></i><i></i><i></i></span> Menu</button></div>'+menuHTML('tl-menu')+'</header>'+
      '<main class="tl-hero"><button type="button" class="tl-blob" id="tl-blob" aria-label="Your blob buddy says hi">'+blobSVG()+'<span class="tl-say" id="tl-say" aria-live="polite"></span></button>'+
      '<h1 class="tl-h1">Tabo AI</h1><p class="tl-tag">3 keyless AI routes in one chat.</p>'+
      '<p class="tl-sub">Choose a model, make games in Code mode, and learn chess and K\u201312 school subjects. A safety check reads every message.</p>'+
      '<button type="button" class="tl-cta" id="tl-start">Start chatting <span aria-hidden="true">\u2192</span></button>'+
      '<button type="button" class="tl-cont" id="tl-cont" hidden></button></main>'+
      '<footer class="tl-foot">'+(W.TaboIcon?W.TaboIcon('shield'):'')+'Safety Shield is on for every message \u00B7 Made by Domotime</footer>';
    D.body.appendChild(home);
    B.svg=home.querySelector('.tlb-svg');B.blob=home.querySelector('.tlb-blob');B.gloss=home.querySelector('.tlb-gloss');B.body=home.querySelector('.tlb-body');B.face=home.querySelector('.tlb-face');
    B.shadow=home.querySelector('.tlb-shadow');B.mouth=home.querySelector('.tlb-mouth');B.pups=home.querySelectorAll('.tlb-pup');B.eins=home.querySelectorAll('.tlb-ein');
    $('tl-start').onclick=function(){ls('tl_last',null);act('chat');};
    $('tl-cont').onclick=function(){var k=this.getAttribute('data-k');if(k)act(k);};
    var SAY=['Hi! I\u2019m Tabo \uD83D\uDC9C','Ready when you are!','87 AIs, one buddy \uD83E\uDDE0','Wanna play chess? \u265F\uFE0F','Boop! \uD83D\uDE06','Let\u2019s make a game \uD83C\uDFAE','Ask me anything!'],si=0,sayT=0;
    $('tl-blob').onclick=function(){B.joyT=now();var s=$('tl-say');s.textContent=SAY[si%SAY.length];si++;setC(s,'on',true);clearTimeout(sayT);sayT=setTimeout(function(){setC(s,'on',false);},1800);
      try{if(W.domoHaptic)W.domoHaptic('select');}catch(e){}if(still){}};
    home.addEventListener('mousemove',function(e){lookAt(e.clientX,e.clientY);});
    home.addEventListener('touchstart',function(e){var t=e.touches&&e.touches[0];if(t)lookAt(t.clientX,t.clientY);},{passive:true});
    home.addEventListener('keydown',function(e){if(menuOpen)return;var k=e.key||'';var tg=e.target&&e.target.tagName;
      if((k==='Enter')&&(tg!=='BUTTON'&&tg!=='A'&&tg!=='INPUT')){e.preventDefault();act('chat');}});
    paintLast();}

  function chatHooks(){
    var acts=D.querySelector('.top .acts');
    if(acts&&!$('tl-homeb')){var hb=D.createElement('button');hb.type='button';hb.className='tbtn ib tl-homeb';hb.id='tl-homeb';hb.title='Home';hb.setAttribute('aria-label','Home page');
      hb.innerHTML='<span class="tiw">'+(W.TaboIcon?W.TaboIcon('home'):'')+'</span><span class="tw tw-n"> Home</span>';hb.onclick=function(){show();};acts.insertBefore(hb,acts.firstChild);
      var mb=D.createElement('button');mb.type='button';mb.className='tbtn ib tl-cmenu';mb.id='tl-cmenu-btn';mb.setAttribute('data-tl-menu','tl-cmenu');mb.setAttribute('aria-haspopup','true');mb.setAttribute('aria-expanded','false');mb.setAttribute('aria-label','Menu: all of Tabo');mb.title='Menu';
      mb.innerHTML='<span class="tl-bars" aria-hidden="true"><i></i><i></i><i></i></span>';acts.insertBefore(mb,hb.nextSibling);
      var wrap=D.createElement('div');wrap.className='tl-cmw';wrap.innerHTML=menuHTML('tl-cmenu');D.body.appendChild(wrap);}
    var back=D.querySelector('.top .acts a.back');if(back)back.title='Domotime';}

  function wire(){D.addEventListener('click',function(e){var n=e.target;while(n&&n!==D){if(n.getAttribute){if(n.getAttribute('data-tl-menu')!=null){e.preventDefault();openMenu(n);return;}
          if(n.getAttribute('data-tl-theme')!=null&&!(n.getAttribute('data-k'))){e.preventDefault();toggleTheme();return;}}n=n.parentNode;}},false);
    D.addEventListener('click',function(e){var n=e.target;while(n&&n!==D){if(hasC(n,'tl-menu')){onMenuClick(e);
          if(e.target&&e.target.className==='tl-skipin'){}var a=e.target;while(a&&a!==n&&a.tagName!=='A')a=a.parentNode;if(a&&a.tagName==='A')setTimeout(closeMenus,50);return;}n=n.parentNode;}},false);
    D.addEventListener('change',function(e){var t=e.target;if(t&&hasC(t,'tl-skipin')){ls('tl_skip',t.checked?'1':null);toast(t.checked?'Next time Tabo opens straight to the chat':'Next time Tabo opens on the home page');
      var all=D.querySelectorAll('.tl-skipin');for(var i=0;i<all.length;i++)all[i].checked=t.checked;}},false);
    D.addEventListener('keydown',menuKeys,true);
    /* while the home page is up, the chat's keyboard shortcuts stay quiet; Enter or just typing starts the chat */
    W.addEventListener('keydown',function(e){if(!shown()||e.defaultPrevented)return;if(menuOpen){menuKeys(e);return;}var k=e.key||'',tg=e.target,inHome=false,n=tg;
      while(n){if(n===home){inHome=true;break;}n=n.parentNode;}
      if(k==='Tab'||k==='Shift')return;
      if(k==='Enter'&&!(inHome&&tg&&(tg.tagName==='BUTTON'||tg.tagName==='A'||tg.tagName==='INPUT'))){e.preventDefault();e.stopPropagation();act('chat');return;}
      if(k.length===1&&!e.ctrlKey&&!e.metaKey&&!e.altKey&&!(inHome&&tg&&tg.tagName==='INPUT')){e.stopPropagation();act('chat');try{var m=$('msg');if(m){m.focus();}}catch(x){}return;}
      if(!(inHome&&(k==='Enter'||k===' ')))e.stopPropagation();},true);}

  function boot(){build();chatHooks();wire();paintTheme();
    var h=(location.hash||'').toLowerCase(),q=(location.search||'').toLowerCase();
    var skip=ls('tl_skip')==='1'||/^#(chat|code)/.test(h)||/[?&](chat|app|q|prompt|ask)=/.test(q)||/[?&]chat\b/.test(q);
    if(skip){home.hidden=true;try{if(h.indexOf('#code')===0)setTimeout(codeMode,30);}catch(e){}}
    else{home.hidden=false;setC(home,'tl-in',true);setC(R,'tl-on',true);blobStart();}
    W.hcHome={show:show,hide:hide,shown:shown,menu:function(){var b=shown()?$('tl-menu-btn'):$('tl-cmenu-btn');if(b)openMenu(b);},act:act,items:function(){var o=[];for(var k in NAMES)o.push(k);return o;}};
    D.addEventListener('visibilitychange',function(){if(D.hidden)blobStop();else if(shown())blobStart();});}
  if($('app')&&D.body)boot();else D.addEventListener('DOMContentLoaded',boot);
})();
