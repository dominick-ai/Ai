/* Tabo v1.5.4 (💻 Code languages) / v1.5.3 — Tot instructor (reacts in chat, serious in Code, 💡 Brainstorm) + 📚 Lessons (🐍 Python via Pyodide, ⌨️ Typing). Local only, additive. */
(function(){'use strict';
  var W=window,D=document,$=function(id){return D.getElementById(id);};
  var T=W.hcTots;if(!T||!T.buddies)return;
  function now(){return Date.now();}
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function pick(a){return a[Math.floor(Math.random()*a.length)];}
  function hasC(el,c){return (' '+el.className+' ').indexOf(' '+c+' ')>=0;}
  function addC(el,c){if(el&&!hasC(el,c))el.className+=' '+c;}
  function rmC(el,c){if(el)el.className=el.className.replace(new RegExp('\\s*\\b'+c+'\\b','g'),'');}
  function selTot(){var t=null;try{t=T.sel();}catch(e){}return t||{id:'x',n:'Tot',s:'circle',e:'big',m:'smile',c:'#f59e0b',ck:1,a:'none'};}
  function merge(t,o){var r={},k;for(k in t)r[k]=t[k];if(o)for(k in o)r[k]=o[k];return r;}
  var FACES={happy:{e:'happy',m:'open'},laugh:{e:'squint',m:'open'},surprised:{e:'big',m:'o'},sad:{e:'oval',m:'sad'},love:{e:'hearts',m:'u'},confused:{e:'dizzy',m:'flat'},excited:{e:'stars',m:'grin'},sleepy:{e:'sleepy',m:'small'},
    serious:{e:'oval',m:'flat',a:'glasses'},focus:{e:'dots',m:'small',a:'glasses'},proud:{e:'happy',m:'smile',a:'glasses'},oops:{e:'oval',m:'sad',a:'glasses'},pass:{e:'stars',m:'grin'},cheer:{e:'happy',m:'open'}};
  var ANIM={happy:'jump',laugh:'shake',surprised:'pop',sad:'droop',love:'pulse',confused:'tilt',excited:'spin',sleepy:'sway',oops:'shake',pass:'spin',cheer:'jump',proud:'jump',serious:'',focus:''};
  var FX={laugh:'😂',love:'❤️',sad:'💧',sleepy:'💤',confused:'❓',surprised:'❗',excited:'✨',pass:'⭐',oops:'💦',cheer:'✨'};
  /* little floating bubble + particles, fixed so they never push layout */
  function rectOf(el){try{return el.getBoundingClientRect();}catch(e){return null;}}
  function say(anchor,text,cls){var r=rectOf(anchor);if(!r||!r.width)return;var b=D.createElement('div');b.className='tr-say '+(cls||'');b.textContent=text;
    b.style.left=Math.max(6,Math.min(r.left,W.innerWidth-170))+'px';b.style.bottom=(W.innerHeight-r.top+6)+'px';D.body.appendChild(b);
    setTimeout(function(){addC(b,'out');},1700);setTimeout(function(){if(b.parentNode)b.parentNode.removeChild(b);},2300);}
  function burst(anchor,ch,n){var r=rectOf(anchor);if(!r||!r.width||!ch)return;n=n||3;for(var i=0;i<n;i++)(function(i){var p=D.createElement('span');p.className='tr-fx';p.textContent=ch;
    p.style.left=(r.left+r.width/2-9+(i-(n-1)/2)*14)+'px';p.style.top=(r.top+4)+'px';p.style.animationDelay=(i*.12)+'s';p.style.webkitAnimationDelay=(i*.12)+'s';D.body.appendChild(p);
    setTimeout(function(){if(p.parentNode)p.parentNode.removeChild(p);},1700+i*120);})(i);}
  function animate(el,a){if(!el)return;el.className=el.className.replace(/\s*tr-a-\w+/g,'');if(!a)return;void el.offsetWidth;addC(el,'tr-a-'+a);clearTimeout(el._ta);el._ta=setTimeout(function(){el.className=el.className.replace(/\s*tr-a-\w+/g,'');},1600);}


  /* v1.6: hints/explains must never hand over the answer: strip code, keep the idea */
  function hcCodey(t){var s=t.trim();if(!s)return false;
    if(/;\s*$/.test(s)||/^[\{\}\]\)]/.test(s)||/[\{\}]\s*$/.test(s))return true;
    if(/^(print|console\.|System\.|Console\.|std::|cout|cin|printf|puts|let |var |const |def |class |for |while |if .*[:{]\s*$|elif |else\s*[:{]|local |func |fn |int |double |float |bool |boolean |string |String |char |public |private |static |void |#include|using |import |return |end$|then$)/.test(s))return true;
    var sym=(s.match(/[;{}()=<>\[\]"'+*\/]/g)||[]).length;return s.length>5&&sym/s.length>0.16;}
  function hcNoCode(h,x,extra){h=String(h||'').replace(/\*\*/g,'').replace(/```[\s\S]*?(```|$)/g,'\n').replace(/`[^`\n]*`/g,'it');
    var keep=h.split(/\n+/).filter(function(t){return !hcCodey(t);}).join(' ');
    keep=keep.replace(/\b[A-Za-z_][\w.:]*\([^()\n]*[^()\s][^()\n]*\)\s*;?/g,function(m){var sp=(m.match(/\s*$/)||[''])[0];return m.replace(/\([\s\S]*$/,'(…)')+(sp?' ':'');});
    keep=keep.replace(/"[^"\n]{1,60}"/g,function(m){return /[;(){}=]/.test(m)?'"…"':m;});
    var bad=[];if(x){if(x.sol)String(x.sol).split('\n').forEach(function(t){t=t.trim();if(t.length>=4)bad.push(t);});if(x.a&&x.a.join)x.a.forEach(function(t){t=String(t).trim();if(t.length>=3)bad.push(t);});}
    if(extra)bad=bad.concat(extra);bad.forEach(function(t){while(keep.indexOf(t)>=0)keep=keep.replace(t,'…');});
    keep=keep.replace(/\s+([.,!?])/g,'$1').replace(/\s{2,}/g,' ').trim();
    return keep.replace(/[…\s.,:]/g,'').length<12?'':keep.slice(0,400);}
  W.hcNoCode=hcNoCode;
  /* ---------- 1) chat buddy reacts to what you type ---------- */
  function mood(s){var l=String(s||'').toLowerCase(),h=new Date().getHours();
    if(/😂|🤣|😆|\blo+l+\b|\blmao\b|\bha(ha)+h?\b|\bhehe\b|\bxd\b|\brofl\b/.test(l))return 'laugh';
    if(/❤|💕|💖|😍|🥰|😘|<3|\blove\b|\bluv\b|\badorable\b/.test(l))return 'love';
    if(/😢|😭|☹|🙁|😞|💔|\bsad\b|\bcry(ing)?\b|\bupset\b|\bbad day\b|\blonely\b|\bi lost\b/.test(l))return 'sad';
    if(/😴|🥱|\btired\b|\bsleepy\b|\bz{3,}\b|\bbedtime\b|\bgood ?night\b|\bnight night\b|\bgn\b|\byawn/.test(l))return 'sleepy';
    if(/\?\?|🤔|😕|\bhuh\b|\bwhat\?|\bconfus|\bidk\b|\bwdym\b|\bi don.?t get/.test(l))return 'confused';
    if(/!!!|😮|😱|🤯|😲|\bwow+\b|\bomg\b|\bwhoa+\b|\bno way\b|\bwhat!/.test(l))return 'surprised';
    if(/🎉|🔥|🚀|🥳|!!|\byay+\b|\blet.?s go+\b|\bawesome\b|\bhype\b|\bexcited\b|\bcan.?t wait\b|\bepic\b/.test(l))return 'excited';
    return 'happy';}
  var SAYS={happy:['hi! 👋','ooh!','nice 😊','got it!','hehe'],laugh:['LOL 😂','haha!','hehe 🤭','lmao 😆'],surprised:['whoa!','OMG 😮','no way!'],sad:['aw, hugs 🫂','oh no…','here for u 💛'],
    love:['aww ❤️','love it!','🥰🥰'],confused:['huh? 🤔','hmm…','wait what'],excited:['let’s go! 🚀','YESSS','woo! 🎉'],sleepy:['yawn… 💤','sleepy…','zzz']};
  function react(B,face,anim,text,fx,ms){if(!B||!B.el||B.el.hidden)return;B.over=merge(B.base||null,FACES[face]||null);T.refresh();animate(B.el,anim);if(text)say(B.el,text);if(fx)burst(B.el,fx,3);
    clearTimeout(B._rt);B._rt=setTimeout(function(){B.over=B.base||null;T.refresh();},ms||2600);}
  var CB=T.buddies[0],KB=T.buddies[1];
  function chatReact(text){if(!text||!String(text).trim())return;var m=mood(text);react(CB,m,ANIM[m],pick(SAYS[m]),FX[m]);}
  D.addEventListener('submit',function(e){var f=e.target;if(f&&f.id==='composer'){var i=$('msg');if(i)chatReact(i.value);}},true);
  var chipsEl=$('chips');if(chipsEl)chipsEl.addEventListener('click',function(e){var b=e.target;if(b&&b.className&&/\bchip\b/.test(b.className))chatReact(b.textContent);},true);

  /* ---------- 2) serious in Code: glasses, steady, reacts to build speed + bugs ---------- */
  if(KB){KB.base=FACES.serious;KB.over=FACES.serious;KB.cls='tt-serious';T.refresh();}
  var busyEl=$('cb-busy'),errEl=$('cb-err'),bT=0,lastR=0;
  function codeOn(){return /\bhc-codemode\b/.test(D.documentElement.className);}
  function bugCheck(dt){if(!KB||!codeOn())return;var bad=errEl&&!errEl.hidden&&String(errEl.textContent||'').trim();lastR=now();
    if(bad)react(KB,'oops','shake','Bug spotted 🔍','💦',2800);
    else if(dt&&dt<15000)react(KB,'proud','jump','Fast! ⚡ '+Math.max(1,Math.round(dt/1000))+'s','⚡',2600);
    else react(KB,'proud','jump','Clean build ✅','✨',2600);}
  if(W.MutationObserver){
    if(busyEl)new MutationObserver(function(){if(!busyEl.hidden){bT=now();}else if(bT){var dt=now()-bT;bT=0;setTimeout(function(){bugCheck(dt);},1600);}}).observe(busyEl,{attributes:true,attributeFilter:['hidden']});
    if(errEl)new MutationObserver(function(){if(!errEl.hidden&&!bT&&now()-lastR>2500){lastR=now();react(KB,'oops','shake','Bug spotted 🔍','💦',2800);}}).observe(errEl,{attributes:true,attributeFilter:['hidden']});}

  /* 💡 Brainstorm (normal /api/chat, default model + kid prompt) */
  var cbForm=$('cb-form');
  function lvlWord(){var n=pyDone();return n<6?'beginner':n<18?'intermediate':'advanced';}
  var IDEAS={web:['A clicker game with upgrades','A pet that changes mood when you tap it','A quiz about your favorite animals'],py:['A number guessing game','A random joke teller','A times table quiz']};
  if(cbForm){var bw=D.createElement('div');bw.className='tr-bsw';bw.innerHTML='<button type="button" class="tr-bs" id="tr-bs">💡 Brainstorm</button><div class="tr-card" id="tr-card" hidden></div>';
    cbForm.parentNode.insertBefore(bw,cbForm);var bsb=$('tr-bs'),card=$('tr-card');
    function showIdeas(list,lang){var t=selTot();card.innerHTML='<div class="tr-ch"><b>💡 Ideas from '+esc(t.n||'your Tot')+'</b><button type="button" class="tr-cx" aria-label="Close ideas">✕</button></div>'+
      list.map(function(x,i){return '<div class="tr-idea"><span>'+esc(x)+'</span><button type="button" class="tr-build" data-i="'+i+'">Build this</button></div>';}).join('');card.hidden=false;
      card.querySelector('.tr-cx').onclick=function(){card.hidden=true;};
      var bs=card.querySelectorAll('.tr-build');for(var i=0;i<bs.length;i++)bs[i].onclick=function(){var m=$('cb-msg');if(m){m.value=list[+this.getAttribute('data-i')].slice(0,500);try{m.focus();}catch(e){}}card.hidden=true;react(KB,'proud','jump','Let’s build! 🛠️',null,2200);};}
    var srow=$('cb-srow');function placeBs(){if(!srow)return;var vis=srow.offsetParent!==null&&!srow.hidden;if(vis&&bsb.parentNode!==srow){srow.appendChild(bsb);addC(bw,'tr-moved');}else if(!vis&&bsb.parentNode!==bw){bw.insertBefore(bsb,card);rmC(bw,'tr-moved');}}
    if(srow&&W.MutationObserver)new MutationObserver(placeBs).observe(srow,{attributes:true,attributeFilter:['hidden','style','class']});
    var lsel=$('cb-lang');if(lsel)lsel.addEventListener('change',function(){setTimeout(placeBs,50);});W.addEventListener('resize',placeBs);
    var mcb=$('hc-mode-code');if(mcb)mcb.addEventListener('click',function(){setTimeout(placeBs,60);});setTimeout(placeBs,300);
    bsb.addEventListener('click',function(){if(bsb.disabled)return;var ls=$('cb-lang'),lang=ls&&ls.selectedIndex>=0?ls.options[ls.selectedIndex].text.replace(/[^\w+#\s.-]/g,'').trim():'web';
      bsb.disabled=true;bsb.textContent='💡 Thinking…';if(KB&&KB.tot)addC(KB.tot,'tt-think');
      var q='Give me 3 short, fun project ideas I can build in '+(lang||'code')+' with Tabo Code. I am a kid at '+lvlWord()+' level. Reply with exactly 3 lines starting with "- ", each under 10 words, no other text.';
      var done=false,ctrl=('AbortController' in W)?new AbortController():null,tm=setTimeout(function(){if(ctrl)ctrl.abort();},20000);
      function fin(list){if(done)return;done=true;clearTimeout(tm);bsb.disabled=false;bsb.textContent='💡 Brainstorm';if(KB&&KB.tot)rmC(KB.tot,'tt-think');showIdeas(list,lang);}
      fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages:[{role:'user',content:q}]}),signal:ctrl?ctrl.signal:undefined})
        .then(function(r){return r.json();}).then(function(j){var out=String(j&&j.reply||'').split(/\n+/).map(function(l){return l.replace(/^\s*(?:[-*•]|\d+[.)])\s*/,'').replace(/\*\*/g,'').replace(/\s+/g,' ').trim();})
          .filter(function(l){return l.length>3&&l.length<120&&!/^(here|sure|ok)\b/i.test(l);}).slice(0,3);fin(out.length>=2?out:(/python/i.test(lang)?IDEAS.py:IDEAS.web));})
        ['catch'](function(){fin(/python/i.test(lang)?IDEAS.py:IDEAS.web);});});}

  /* ---------- 3) 📚 Lessons ---------- */
  var PY=W.HC_LS_PY||[],TY=W.HC_LS_TY||[],SK='hc_lessons_v1',P={py:{},ty:{}};
  try{var raw=JSON.parse(localStorage.getItem(SK)||'null');if(raw&&typeof raw==='object'){P.py=raw.py||{};P.ty=raw.ty||{};}}catch(e){}
  function saveP(){try{localStorage.setItem(SK,JSON.stringify(P));}catch(e){}}
  function pyDone(){var n=0;for(var k in P.py)if(P.py[k]&&P.py[k].s>0)n++;return n;}
  function pyTotal(){var n=0;for(var i=0;i<PY.length;i++)n+=PY[i].L.length;return n;}
  function pyStars(){var n=0;for(var k in P.py)n+=(P.py[k]&&P.py[k].s)||0;return n;}
  function lvlPassed(i){var L=PY[i]&&PY[i].L;if(!L)return false;for(var j=0;j<L.length;j++)if(!(P.py[L[j].id]&&P.py[L[j].id].s>0))return false;return true;}
  function lvlOpen(i){return i===0||lvlPassed(i-1);}
  function tyOpen(i){return i===0||!!(P.ty[i-1]&&P.ty[i-1].p);}

  /* Python runner (Pyodide in a worker; loads when Lessons opens) */
  var PW=null,pwS='idle',pwQ={},pwId=0,pwLT=0;
  function pyBoot(){if(PW||pwS==='ready')return;pwS='loading';pyUI();try{PW=new Worker('pyworker.js?v=2.7');}catch(e){pwFail();return;}
    PW.onmessage=function(e){var d=e.data||{};if(d.ready){pwS='ready';clearTimeout(pwLT);pyUI();}else if(d.loadfail){pwFail();}else if(d.id&&pwQ[d.id]){var q=pwQ[d.id];delete pwQ[d.id];clearTimeout(q.t);q.f(d);}};
    PW.onerror=function(){if(pwS==='loading')pwFail();};clearTimeout(pwLT);pwLT=setTimeout(function(){if(pwS==='loading')pwFail();},120000);}
  function pwKill(){if(PW){try{PW.terminate();}catch(e){}}PW=null;for(var k in pwQ){var q=pwQ[k];clearTimeout(q.t);delete pwQ[k];}}
  function pwFail(){pwKill();pwS='fail';pyUI();}
  function pyRun(code,inputs,tests,cb){if(pwS!=='ready'){cb({err:'Python is still loading…',wait:1});return;}var id=++pwId;
    pwQ[id]={f:cb,t:setTimeout(function(){delete pwQ[id];pwKill();pwS='idle';pyBoot();cb({err:'Your program ran too long (over 8 seconds). Is there a loop that never stops?',slow:1});},8000)};
    PW.postMessage({id:id,code:code,inputs:inputs||[],tests:tests||''});}
  function nz(s){return String(s==null?'':s).replace(/\r/g,'').split('\n').map(function(l){return l.replace(/\s+$/,'');}).join('\n').replace(/^\n+|\n+$/g,'');}
  function judge(les,code,cb){/* -> {ok, msg, out, err} */
    var c=String(code||'');
    if(les.need&&!new RegExp(les.need).test(c))return cb({ok:false,msg:les.needMsg||'Follow the challenge rules'});
    if(les.ban&&new RegExp(les.ban).test(c.replace(/#.*$/gm,'')))return cb({ok:false,msg:les.banMsg||'That shortcut is not allowed here'});
    if(les.cases){var i=0;(function next(){if(i>=les.cases.length)return cb({ok:true,out:lastOut});var cs=les.cases[i];
        pyRun(c,cs.inp,'',function(r){lastOut=r.out;if(r.err)return cb({ok:false,err:r.err,out:r.out,wait:r.wait});var o=nz(r.out),e=nz(cs.end);
          if(o.length<e.length||o.slice(o.length-e.length)!==e)return cb({ok:false,out:r.out,msg:'When the input is '+cs.inp.join(', ')+' the output should end with:\n'+cs.end+'\n\nYours was:\n'+(o||'(nothing)')});i++;next();});})();var lastOut='';return;}
    pyRun(c,[],les.test||'',function(r){if(r.err)return cb({ok:false,err:r.err,out:r.out,wait:r.wait});
      if(les.out!=null&&nz(r.out)!==nz(les.out))return cb({ok:false,out:r.out,msg:'The output should be:\n'+les.out+'\n\nYours was:\n'+(nz(r.out)||'(nothing)')});
      if(r.fail)return cb({ok:false,out:r.out,msg:r.fail});cb({ok:true,out:r.out});});}
  W.hcLessonsSelfTest=function(cb){var res=[],all=[];PY.forEach(function(l,li){l.L.forEach(function(x){all.push([li,x]);});});var k=0;
    (function n(){if(k>=all.length)return cb(res);var x=all[k][1];judge(x,x.sol,function(r){var bad=null;
      if(x.start&&x.start.trim()){}res.push({id:x.id,ok:!!r.ok,msg:r.msg||r.err||''});k++;n();});})();};
  W.hcLessonsStarterTest=function(cb){var res=[],all=[];PY.forEach(function(l){l.L.forEach(function(x){all.push(x);});});var k=0;
    (function n(){if(k>=all.length)return cb(res);var x=all[k];judge(x,x.start||'',function(r){res.push({id:x.id,ok:!!r.ok});k++;n();});})();};

  /* sheet */
  var sh=null,body=null,ttl=null,backB=null,view='home',stack=[],cur=null;
  function build(){sh=D.createElement('div');sh.className='ls-sheet';sh.id='ls-sheet';sh.hidden=true;sh.setAttribute('role','dialog');sh.setAttribute('aria-label','Lessons');
    sh.innerHTML='<div class="ls-top"><button type="button" class="ls-back" id="ls-back" aria-label="Back">←</button><b class="ls-ttl" id="ls-ttl">📚 Lessons</b><button type="button" class="ls-close" id="ls-x" aria-label="Close lessons">✕</button></div><div class="ls-body" id="ls-body"></div>';
    D.body.appendChild(sh);body=$('ls-body');ttl=$('ls-ttl');backB=$('ls-back');
    $('ls-x').onclick=close;backB.onclick=back;
    sh.addEventListener('keydown',function(e){if(e.key==='Escape'){e.preventDefault();close();}});}
  function open(){if(!sh)build();sh.hidden=false;void sh.offsetWidth;addC(sh,'in');addC(D.documentElement,'ls-open');stack=[];go('home');pyBoot();}
  function close(){if(!sh)return;stopTy();rmC(sh,'in');rmC(D.documentElement,'ls-open');setTimeout(function(){sh.hidden=true;body.innerHTML='';},250);try{var b=$('hc-lessons-btn');if(b)b.focus();}catch(e){}}
  function back(){stopTy();var v=stack.pop();if(!v){close();return;}show(v[0],v[1],true);}
  function go(v,arg){if(view&&sh&&!sh.hidden&&body.innerHTML)stack.push([view,cur&&cur.arg]);show(v,arg);}
  function show(v,arg,isBack){stopTy();view=v;cur={arg:arg};body.innerHTML='';sh.scrollTop=0;backB.style.visibility=(v==='home')?'hidden':'visible';
    if(v==='home')vHome();else if(v==='langs')vLangs();else if(v==='lang')vLang(arg);else if(v==='cles')vCLes(arg);else if(v==='py')vPy();else if(v==='les')vLes(arg);else if(v==='ty')vTy();else if(v==='tyrun')vTyRun(arg);else if(EXT[v])EXT[v](arg);else vHome();}
  /* teacher Tot */
  function teacher(size){var w=D.createElement('div');w.className='ls-teach ls-t'+size;w.innerHTML='<div class="ls-tt"></div><div class="ls-say" aria-live="polite"></div>';body.appendChild(w);var t={w:w,box:w.firstChild,say:w.lastChild};teach(t,'hi');return t;}
  function teach(t,state,text){if(!t)return;var f=FACES[state]||null,el=T.totEl(merge(selTot(),f),'ls-tot'+(state==='serious'||state==='oops'||state==='focus'?' tt-serious':''));t.box.innerHTML='';t.box.appendChild(el);
    if(state==='think')addC(el,'tt-think');animate(t.box,ANIM[state]);if(text!=null){t.say.textContent=text;animate(t.say,'pop');}
    if(FX[state]&&state!=='hi')burst(t.box,FX[state],state==='pass'?5:3);}
  function vHome(){ttl.textContent='📚 Lessons';var tt=teacher('big'),t=selTot();teach(tt,'cheer','Hi! I’m '+(t.n||'your Tot')+', your teacher 🎓 Pick a course!');
    var g=D.createElement('div');g.className='ls-courses';var bw=0,tyP=0;for(var i=0;i<TY.length;i++){if(P.ty[i]){bw=Math.max(bw,P.ty[i].w||0);if(P.ty[i].p)tyP++;}}
    var nl=0;for(var j=0;j<PY.length;j++)if(lvlPassed(j))nl++;
    var cs=codeSum();g.innerHTML='<button type="button" class="ls-course ls-cpy" id="ls-c-code"><span class="ls-ci">💻</span><b>Code</b><span>Python, JavaScript, Lua, Swift, Java, C#, C++ &amp; Rust, easiest to hardest</span><em>'+(pyDone()+cs.d)+'/'+(pyTotal()+cs.n)+' lessons · ⭐ '+(pyStars()+cs.s)+' · 🏅 '+(nl+cs.m)+'</em></button>'+
      '<button type="button" class="ls-course ls-cty" id="ls-c-ty"><span class="ls-ci">⌨️</span><b>Typing</b><span>Home row to pro speed, with accuracy</span><em>'+tyP+'/'+TY.length+' levels · best '+bw+' WPM</em></button>';
    for(var xi=0;xi<EXTcards.length;xi++){try{var xc=EXTcards[xi]();if(!xc)continue;g.insertAdjacentHTML('beforeend',xc.html);addC(g,'ls-c3');var xb=g.querySelector('#'+xc.id);if(xb)xb.onclick=xc.go;}catch(e){}}
    body.appendChild(g);$('ls-c-code').onclick=function(){go('langs');};$('ls-c-ty').onclick=function(){go('ty');};for(var hi=0;hi<EXThome.length;hi++){try{EXThome[hi](g);}catch(e){}} /* v2.9.7 school subjects + grade picker */}
  function vPy(){ttl.textContent='🐍 Python';var tt=teacher('mid');var nx=0;while(nx<PY.length&&lvlPassed(nx))nx++;
    teach(tt,nx>=PY.length?'pass':'cheer',nx>=PY.length?'You mastered Python! 🏆 Legend.':nx===0?'Let’s start with the basics! 🌱':'Level '+(nx+1)+' is next. You got this!');
    pyNote();
    var wrap=D.createElement('div');wrap.className='ls-levels';
    PY.forEach(function(l,i){var op=lvlOpen(i),ps=lvlPassed(i),d=D.createElement('div');d.className='ls-lvl'+(op?'':' locked')+(ps?' done':'');
      d.innerHTML='<div class="ls-lh2"><span class="ls-le">'+(op?l.e:'🔒')+'</span><div><b>Level '+(i+1)+': '+esc(l.n)+'</b><small>'+esc(l.d)+(i===PY.length-1?' · hard!':'')+'</small></div>'+(ps?'<span class="ls-badge" title="Mastered">🏅</span>':'')+'</div>'+
        (op?'<div class="ls-lgrid">'+l.L.map(function(x,j){var s=(P.py[x.id]&&P.py[x.id].s)||0;return '<button type="button" class="ls-lb'+(s?' ok':'')+'" data-l="'+i+'" data-j="'+j+'"><span>'+(j+1)+'. '+esc(x.t)+'</span><i>'+(s?'⭐'.repeat(s):'·')+'</i></button>';}).join('')+'</div>':'<p class="ls-lock">Pass Level '+i+' to unlock</p>');
      wrap.appendChild(d);});body.appendChild(wrap);
    var bs=wrap.querySelectorAll('.ls-lb');for(var k=0;k<bs.length;k++)bs[k].onclick=function(){go('les',[+this.getAttribute('data-l'),+this.getAttribute('data-j')]);};}
  var pyStatEls=[];
  function pyNote(){var p=D.createElement('div');p.className='ls-pystat';body.appendChild(p);pyStatEls=[p];pyUI();}
  function pyUI(){pyStatEls=pyStatEls.filter(function(p){return p&&p.parentNode;});pyStatEls.forEach(function(p){
      if(pwS==='ready'){p.className='ls-pystat ok';p.innerHTML='🐍 Python is ready';}
      else if(pwS==='fail'){p.className='ls-pystat bad';p.innerHTML='😕 Python didn’t load. Check the wifi. <button type="button" class="ls-retry">Try again</button>';p.querySelector('.ls-retry').onclick=function(){pwS='idle';pyBoot();};}
      else{p.className='ls-pystat';p.innerHTML='<span class="ls-spin"></span> loading Python… (first time takes a few seconds)';}});
    var rb=body&&body.querySelectorAll('.ls-need-py');if(rb)for(var i=0;i<rb.length;i++)rb[i].disabled=pwS!=='ready';}
  function vLes(a){var li=a[0],lj=a[1],L=PY[li],x=L&&L.L[lj];if(!x||!lvlOpen(li)){show('py');return;}
    ttl.textContent=L.e+' Level '+(li+1)+' · '+(lj+1)+'/'+L.L.length;var tt=teacher('mid');var t0=now(),fails=0,passed=false,par=x.par||(li>=7?300:150);
    teach(tt,'cheer',pick(['Let’s do this! 🐍','You got this! 💪','Ooh, a fun one!','Ready? Let’s code!']));
    var c=D.createElement('div');c.className='ls-les';
    c.innerHTML='<div class="ls-learn"><h2>'+esc(x.t)+'</h2><p class="ls-x">'+x.x+'</p><div class="ls-eg"><div class="ls-egh"><span>Example</span><button type="button" class="ls-mini ls-need-py" id="ls-try">▶ Try it</button></div><pre class="ls-code">'+esc(x.eg)+'</pre><pre class="ls-out ls-egout" id="ls-egout" hidden></pre></div>'+
      '<div class="ls-task"><b>🎯 Challenge</b><p>'+x.task+'</p>'+(x.cases?'<small>The checker types test input for you.</small>':'')+'</div></div>'+
      '<div class="ls-work"><div class="ls-keys" id="ls-keys"><button type="button" data-k="tab">⇥ Tab</button><button type="button" data-k="():">()</button><button type="button" data-k=":">:</button><button type="button" data-k="&quot;&quot;">""</button><button type="button" data-k="=">=</button><button type="button" data-k="[]">[ ]</button><button type="button" data-k="{}">{ }</button><button type="button" data-k="_">_</button></div>'+
      '<textarea class="ls-ed" id="ls-ed" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" wrap="off" aria-label="Your Python code"></textarea>'+
      '<div class="ls-btns"><button type="button" class="ls-b ls-run ls-need-py" id="ls-run">▶ Run</button><button type="button" class="ls-b ls-chk ls-need-py" id="ls-chk">✅ Check</button><button type="button" class="ls-b ls-hint" id="ls-hint">💡 Hint</button><button type="button" class="ls-b ls-rst" id="ls-rst" aria-label="Start over">↺</button></div>'+
      '<pre class="ls-out" id="ls-out" hidden></pre><div class="ls-res" id="ls-res" hidden></div><div class="ls-hintbox" id="ls-hintbox" hidden></div><button type="button" class="ls-next" id="ls-next" hidden>Next →</button></div>';
    body.appendChild(c);pyNote();body.insertBefore(pyStatEls[0],c);
    var ed=$('ls-ed'),out=$('ls-out'),res=$('ls-res'),hb=$('ls-hintbox'),nextB=$('ls-next'),dk='hc_ls_code_'+x.id;
    var saved=null;try{saved=localStorage.getItem(dk);}catch(e){}ed.value=saved!=null?saved:(x.start||'');
    ed.addEventListener('input',function(){try{localStorage.setItem(dk,ed.value.slice(0,6000));}catch(e){}});
    function ins(txt,back){var s=ed.selectionStart,e=ed.selectionEnd,v=ed.value;ed.value=v.slice(0,s)+txt+v.slice(e);var p=s+txt.length-(back||0);ed.selectionStart=ed.selectionEnd=p;try{localStorage.setItem(dk,ed.value);}catch(x){}}
    ed.addEventListener('keydown',function(e){if(e.key==='Tab'){e.preventDefault();ins('    ');}
      else if(e.key==='Enter'&&!e.shiftKey&&!e.metaKey&&!e.ctrlKey){var s=ed.selectionStart,v=ed.value,ls=v.lastIndexOf('\n',s-1)+1,line=v.slice(ls,s),ind=(line.match(/^[ \t]*/)||[''])[0];if(/:\s*$/.test(line))ind+='    ';if(ind){e.preventDefault();ins('\n'+ind);}}});
    var kb=$('ls-keys');kb.addEventListener('mousedown',function(e){e.preventDefault();});kb.addEventListener('touchstart',function(e){if(e.target&&e.target.tagName==='BUTTON')e.preventDefault();},{passive:false});
    kb.addEventListener('touchend',function(e){var b=e.target;if(b&&b.tagName==='BUTTON'){e.preventDefault();key(b);}});kb.addEventListener('click',function(e){var b=e.target;if(b&&b.tagName==='BUTTON')key(b);});
    function key(b){var k=b.getAttribute('data-k');if(D.activeElement!==ed){try{ed.focus();}catch(x){}}if(k==='tab')ins('    ');else if(k.length===2&&k!=='()')ins(k,1);else if(k==='():')ins('()',1);else ins(k);}
    function showOut(r){out.hidden=false;var o=r.out||'';out.className='ls-out'+(r.err?' err':'');out.textContent=(o?o:'')+(r.err?(o?'\n':'')+'🐞 '+r.err:'')||'(no output)';}
    $('ls-try').onclick=function(){var eo=$('ls-egout');pyRun(x.eg,['Sam','5','5','5','5'],'',function(r){eo.hidden=false;eo.className='ls-out ls-egout'+(r.err?' err':'');eo.textContent=(r.out||'')+(r.err?'🐞 '+r.err:'')||'(no output)';});};
    $('ls-run').onclick=function(){var b=this;b.disabled=true;teach(tt,'focus','Running… 👀');pyRun(ed.value,x.cases?x.cases[0].inp:[],'',function(r){b.disabled=pwS!=='ready';showOut(r);
      if(r.err)teach(tt,'oops',r.slow?'Infinite loop? 🔁 Check your loop!':'Bug spotted 🔍 '+(r.err.match(/^Line \d+/)||['Read the error'])[0]);else teach(tt,'serious',x.cases?'Test input was '+x.cases[0].inp.join(', ')+'. Now ✅ Check!':'Looks good? Press ✅ Check!');});};
    $('ls-chk').onclick=function(){var b=this;b.disabled=true;teach(tt,'focus','Checking… 🧐');judge(x,ed.value,function(r){b.disabled=pwS!=='ready';if(r.wait)return teach(tt,'serious','Python is still loading…');
      if(r.out!=null||r.err)showOut({out:r.out,err:r.err});res.hidden=false;
      if(r.ok){var secs=Math.round((now()-t0)/1000),st=1+(fails===0?1:0)+(secs<=par?1:0),old=P.py[x.id]||{};var first=!(old.s>0);
        P.py[x.id]={s:Math.max(old.s||0,st),t:old.t?Math.min(old.t,secs):secs};var lvlNow=lvlPassed(li);saveP();passed=true;
        res.className='ls-res ok';res.innerHTML='<b>Passed! '+'⭐'.repeat(st)+'</b><span>'+(fails===0?'First try! ':'')+(secs<=par?'⚡ Speed bonus ('+secs+'s)':'Done in '+secs+'s')+'</span>'+(lvlNow&&first?'<div class="ls-master">🏅 Level '+(li+1)+' mastered!'+(li+1<PY.length?' Level '+(li+2)+' unlocked 🔓':' You beat the whole course! 🏆')+'</div>':'');
        teach(tt,'pass',lvlNow&&first?'MASTERED! 🏅🎉':secs<=par?'Fast! ⚡ Nailed it!':pick(['You did it! 🎉','Clean code ✅','Woohoo! ⭐']));
        var nj=lj+1,nli=li;if(nj>=L.L.length){nj=0;nli=li+1;}nextB.hidden=!(nli<PY.length&&lvlOpen(nli));nextB.textContent=nli!==li?'Next level →':'Next lesson →';nextB.onclick=function(){show('les',[nli,nj]);};
        if(nextB.hidden){nextB.hidden=false;nextB.textContent='Back to levels';nextB.onclick=function(){back();};}}
      else{fails++;res.className='ls-res bad';res.innerHTML='<b>'+(r.err?'Bug spotted 🔍':'Not yet!')+'</b><pre>'+esc(r.msg||r.err||'Try again')+'</pre>';
        teach(tt,r.err?'oops':'serious',fails>=2?'Stuck? Tap 💡 Hint, I’ll help.':r.err?'Let’s fix that bug together 🔍':'Almost! Look at what the test wanted.');}
      try{res.scrollIntoView({block:'nearest',behavior:'smooth'});}catch(e){}});};
    $('ls-rst').onclick=function(){if(ed.value!==(x.start||'')&&!confirm('Start this challenge over?'))return;ed.value=x.start||'';try{localStorage.removeItem(dk);}catch(e){}out.hidden=true;res.hidden=true;};
    $('ls-hint').onclick=function(){var b=this;b.disabled=true;teach(tt,'think','Hmm, let me think… 🤔');hb.hidden=false;hb.innerHTML='<span class="ls-spin"></span> thinking of a hint…';
      var task=String(x.task).replace(/<[^>]+>/g,'').replace(/&#39;/g,"'").replace(/&quot;/g,'"').replace(/&amp;/g,'&');var lastErr=out.hidden?'':out.textContent.slice(-80);
      var msgs=[{role:'user',content:('I am a kid doing a Python lesson called "'+x.t+'". The challenge: '+task).slice(0,295)},{role:'assistant',content:'Cool! Show me your code. I will give a hint in plain words, never code or the answer.'},
        {role:'user',content:('My code:\n'+(ed.value.trim()||'(empty)').slice(0,170)+(lastErr?'\nOutput: '+lastErr:'')).slice(0,250)+'\nGive ONE short hint in 2 plain sentences, as an idea. NEVER write code, a code line, a function call or the answer.'}];
      var done=false,ctrl=('AbortController' in W)?new AbortController():null,tm=setTimeout(function(){if(ctrl)ctrl.abort();},20000);
      function fin(h,ai){if(done)return;done=true;clearTimeout(tm);b.disabled=false;hb.innerHTML='<b>💡 '+esc(selTot().n||'Tot')+' says:</b> '+esc(h);teach(tt,'cheer',ai?'Try that! 💪':'Here’s a clue 💡');}
      fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages:msgs}),signal:ctrl?ctrl.signal:undefined}).then(function(r){return r.json();})
        .then(function(j){var h=hcNoCode(j&&j.reply,x);fin(h||x.hint,!!h);})['catch'](function(){fin(x.hint,false);});};
    pyUI();}

  /* ===== v1.5.4: 💻 Code — language picker + more languages ===== */
  var CL=W.HC_LS_CODE||[],CP={};
  function clang(k){for(var i=0;i<CL.length;i++)if(CL[i].k===k)return CL[i];return null;}
  function cp(k){if(!CP[k]){var o=null;try{o=JSON.parse(localStorage.getItem('hc_lang_'+k)||'null');}catch(e){}CP[k]=(o&&typeof o==='object')?o:{};}return CP[k];}
  function cpSave(k){try{localStorage.setItem('hc_lang_'+k,JSON.stringify(CP[k]||{}));}catch(e){}}
  function cTotal(l){var n=0;(l.LV||[]).forEach(function(v){n+=v.L.length;});return n;}
  function cDone(l){var p=cp(l.k),n=0;(l.LV||[]).forEach(function(v){v.L.forEach(function(x){if(p[x.id]&&p[x.id].s>0)n++;});});return n;}
  function cStars(l){var p=cp(l.k),n=0;(l.LV||[]).forEach(function(v){v.L.forEach(function(x){n+=(p[x.id]&&p[x.id].s)||0;});});return n;}
  function cPassed(l,i){var v=l.LV&&l.LV[i],p=cp(l.k);if(!v)return false;for(var j=0;j<v.L.length;j++)if(!(p[v.L[j].id]&&p[v.L[j].id].s>0))return false;return true;}
  function cOpen(l,i){return i===0||cPassed(l,i-1);}
  function cMastered(l){if(l.k==='py'){for(var i=0;i<PY.length;i++)if(!lvlPassed(i))return false;return true;}for(var j=0;j<l.LV.length;j++)if(!cPassed(l,j))return false;return true;}
  function codeSum(){var r={d:0,n:0,s:0,m:0};CL.forEach(function(l){if(!l.LV)return;r.d+=cDone(l);r.n+=cTotal(l);r.s+=cStars(l);for(var i=0;i<l.LV.length;i++)if(cPassed(l,i))r.m++;});return r;}
  var LVC={Easy:'e',Medium:'m',Hard:'h',Expert:'x'};
  function vLangs(){ttl.textContent='💻 Code';var tt=teacher('mid');teach(tt,'cheer','Pick a language! Easiest at the top, hardest at the bottom 🧗');
    var w=D.createElement('div');w.className='ls-langs';
    w.innerHTML=CL.map(function(l,i){var d,n,st,run=l.run?'▶ runs for real':'🧠 Tot-checked';
      if(l.k==='py'){d=pyDone();n=pyTotal();st=pyStars();}else{d=cDone(l);n=cTotal(l);st=cStars(l);}
      return '<button type="button" class="ls-lang" id="ls-c-'+l.k+'" data-k="'+l.k+'"><span class="ls-li">'+l.e+'</span><span class="ls-lt"><b>'+esc(l.n)+(cMastered(l)?' 🏅':'')+'</b><small>'+esc(l.d)+'</small><small class="ls-lm">'+d+'/'+n+' · ⭐ '+st+' · '+run+'</small></span><span class="ls-tag ls-tag-'+LVC[l.lv]+'">'+l.lv+'</span></button>';}).join('');
    body.appendChild(w);var bs=w.querySelectorAll('.ls-lang');for(var k=0;k<bs.length;k++)bs[k].onclick=function(){var kk=this.getAttribute('data-k');if(kk==='py')go('py');else go('lang',kk);};}
  function vLang(k){var l=clang(k);if(!l||!l.LV){show('langs');return;}ttl.textContent=l.e+' '+l.n;var tt=teacher('mid');var nx=0;while(nx<l.LV.length&&cPassed(l,nx))nx++;
    teach(tt,nx>=l.LV.length?'pass':'cheer',nx>=l.LV.length?'You mastered '+l.n+'! 🏅 Legend.':nx===0?'New language! Let’s start easy 🌱':'Level '+(nx+1)+' is next. You got this!');
    var nt=D.createElement('div');nt.className='ls-pystat '+(l.run?'ok':'');nt.innerHTML=l.run?'▶ '+esc(l.n)+' code runs for real right here':'🧠 '+esc(l.n)+' can’t run on an iPad, so these lessons are checked by your Tot, not run';body.appendChild(nt);
    var wrap=D.createElement('div');wrap.className='ls-levels';var p=cp(k);
    l.LV.forEach(function(v,i){var op=cOpen(l,i),ps=cPassed(l,i),d=D.createElement('div');d.className='ls-lvl'+(op?'':' locked')+(ps?' done':'');
      d.innerHTML='<div class="ls-lh2"><span class="ls-le">'+(op?v.e:'🔒')+'</span><div><b>Level '+(i+1)+': '+esc(v.n)+'</b><small>'+esc(v.d)+'</small></div>'+(ps?'<span class="ls-badge" title="Mastered">🏅</span>':'')+'</div>'+
        (op?'<div class="ls-lgrid">'+v.L.map(function(x,j){var s=(p[x.id]&&p[x.id].s)||0;return '<button type="button" class="ls-lb'+(s?' ok':'')+'" data-l="'+i+'" data-j="'+j+'"><span>'+(j+1)+'. '+esc(x.t)+'</span><i>'+(s?'⭐'.repeat(s):'·')+'</i></button>';}).join('')+'</div>':'<p class="ls-lock">Pass Level '+i+' to unlock</p>');
      wrap.appendChild(d);});body.appendChild(wrap);
    var bs=wrap.querySelectorAll('.ls-lb');for(var q=0;q<bs.length;q++)bs[q].onclick=function(){go('cles',[k,+this.getAttribute('data-l'),+this.getAttribute('data-j')]);};}
  /* runner for JS + Lua (worker, killed on endless loops) */
  var CW=null,cwQ={},cwN=0,luaLoaded=false;
  function cwMake(){try{CW=new Worker('cworker.js?v=2.7');}catch(e){CW=null;return;}CW.onmessage=function(ev){var r=ev.data||{},q=cwQ[r.id];if(!q)return;delete cwQ[r.id];clearTimeout(q.tm);if(q.lang==='lua'&&r.err!=='LOAD')luaLoaded=true;if(r.err==='LOAD'){r.err='Lua didn’t load. Check the wifi and try again.';}q.cb(r);};}
  function cRun(lang,code,test,cb){if(!CW)cwMake();if(!CW)return cb({err:'Can’t run code here 😕'});var id=++cwN,ms=(lang==='lua'&&!luaLoaded)?20000:3000;
    cwQ[id]={cb:cb,lang:lang,tm:setTimeout(function(){delete cwQ[id];try{CW.terminate();}catch(e){}CW=null;for(var k in cwQ){var o=cwQ[k];clearTimeout(o.tm);o.cb({err:'stopped'});}cwQ={};cb({err:'Took too long. Endless loop? 🔁',slow:1});},ms)};
    CW.postMessage({id:id,lang:lang,code:String(code),test:test||''});}
  function wsx(s){return String(s==null?'':s).replace(/[\u2018\u2019]/g,"'").replace(/[\u201C\u201D]/g,'"').replace(/\s+/g,'');}
  function cjudge(l,x,ans,cb){
    if(x.k==='mc')return cb({ok:+ans===x.a,msg:'Not that one. Read the code line by line!'});
    if(x.k==='fill'){var a=wsx(ans);if(!a)return cb({ok:false,msg:'Type something in the blank first'});for(var i=0;i<x.a.length;i++)if(wsx(x.a[i])===a)return cb({ok:true});return cb({ok:false,msg:'Not quite. Check the explanation above 👆'});}
    if(x.k==='write'){var c=wsx(ans);if(!c)return cb({ok:false,msg:'Write your code first'});for(var j=0;j<x.re.length;j++){try{if(new RegExp(x.re[j]).test(c))return cb({ok:true});}catch(e){}}
      var m='Not quite yet.';if(/^(public)?static|^func|^fn|^int/.test(wsx(x.sol))&&c.indexOf('return')<0&&/return/.test(x.sol))m='Did you forget return?';else if(/;$/.test(wsx(x.sol))&&!/;\}?$/.test(c))m='Missing a ; semicolon at the end?';else if(/"/.test(x.sol)&&!/"/.test(c))m='Text needs "quotes"';return cb({ok:false,msg:m+' Check spelling and Capital letters too.'});}
    cRun(l.run,ans,x.test,function(r){if(r.err)return cb({ok:false,out:r.out,err:r.err,slow:r.slow});
      if(r.fail)return cb({ok:false,out:r.out,msg:r.fail});
      if(x.has&&!new RegExp(x.has).test(ans))return cb({ok:false,out:r.out,msg:x.hasMsg||'Use what the lesson teaches'});
      if(x.out!=null&&nz(r.out)!==nz(x.out))return cb({ok:false,out:r.out,msg:'Expected:\n'+x.out+'\n\nYou printed:\n'+(r.out||'(nothing)')});
      cb({ok:true,out:r.out});});}
  function cAll(){var a=[];CL.forEach(function(l){(l.LV||[]).forEach(function(v){v.L.forEach(function(x){a.push([l,x]);});});});return a;}
  W.hcCodeSelfTest=function(cb){var all=cAll(),res=[],k=0;(function n(){if(k>=all.length)return cb(res);var l=all[k][0],x=all[k][1];
    var good=x.k==='mc'?x.a:x.k==='fill'?x.a[0]:x.sol,bad=x.k==='mc'?(x.a+1)%x.o.length:x.k==='fill'?x.wrong:(x.wrong!=null?x.wrong:(x.start||''));
    cjudge(l,x,good,function(r1){cjudge(l,x,bad,function(r2){var r3={ok:false};var fin=function(){res.push({lang:l.k,id:x.id,good:!!r1.ok,badFails:!r2.ok,startFails:!r3.ok,info:r1.ok?'':(r1.msg||r1.err||'')});k++;n();};
      if(x.k==='write'||x.k==='run')cjudge(l,x,x.start||'',function(r){r3=r;fin();});else fin();});});})();};
  function vCLes(a){var l=clang(a[0]),li=a[1],lj=a[2],V=l&&l.LV&&l.LV[li],x=V&&V.L[lj];if(!x||!cOpen(l,li)){show('lang',a[0]);return;}
    var k=l.k,p=cp(k),run=!!l.run;ttl.textContent=l.e+' '+l.n+' · L'+(li+1)+' · '+(lj+1)+'/'+V.L.length;var tt=teacher('mid');var t0=now(),fails=0,par=x.par||(x.k==='run'?150:45);
    teach(tt,'cheer',pick(['Let’s do this! '+l.e,'You got this! 💪','Ooh, '+l.n+'!','Ready? Let’s code!']));
    var c=D.createElement('div');c.className='ls-les';var work='';
    if(x.k==='mc')work='<div class="ls-qcode"><pre class="ls-code">'+esc(x.code)+'</pre></div><div class="ls-opts">'+x.o.map(function(o,i){return '<button type="button" class="ls-opt" data-i="'+i+'"><code>'+esc(o)+'</code></button>';}).join('')+'</div>';
    else if(x.k==='fill'){var parts=String(x.code).split('___');work='<pre class="ls-code ls-fillc">'+esc(parts[0])+'<input class="ls-fill" id="ls-fill" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" aria-label="Fill in the blank" placeholder="?" size="6">'+esc(parts.slice(1).join('___'))+'</pre><div class="ls-btns"><button type="button" class="ls-b ls-chk" id="ls-chk">✅ Check</button><button type="button" class="ls-b ls-hint" id="ls-hint">🤖 Explain</button></div>';}
    else{var keys=run?(k==='lua'?['tab','()','""','..','=','{}','[]','~=']:['tab','()','{}','""',';','=','[]','=>']):['tab','()','{}','""',';','=','<<','->'];
      work='<div class="ls-keys" id="ls-keys">'+keys.map(function(kk){return '<button type="button" data-k="'+esc(kk)+'">'+(kk==='tab'?'⇥ Tab':esc(kk))+'</button>';}).join('')+'</div>'+
      '<textarea class="ls-ed" id="ls-ed" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" wrap="off" aria-label="Your '+esc(l.n)+' code"></textarea>'+
      '<div class="ls-btns">'+(run?'<button type="button" class="ls-b ls-run" id="ls-run">▶ Run</button>':'')+'<button type="button" class="ls-b ls-chk" id="ls-chk">✅ Check</button><button type="button" class="ls-b ls-hint" id="ls-hint">'+(run?'💡 Hint':'🤖 Explain')+'</button><button type="button" class="ls-b ls-rst" id="ls-rst" aria-label="Start over">↺</button></div>';}
    c.innerHTML='<div class="ls-learn"><h2>'+esc(x.t)+'</h2><p class="ls-x">'+x.x+'</p><div class="ls-eg"><div class="ls-egh"><span>Example</span>'+(run?'<button type="button" class="ls-mini" id="ls-try">▶ Try it</button>':'')+'</div><pre class="ls-code">'+esc(x.eg)+'</pre><pre class="ls-out ls-egout" id="ls-egout" hidden></pre></div>'+
      '<div class="ls-task"><b>🎯 '+(x.k==='mc'?'Pick one':x.k==='fill'?'Fill in the blank':'Challenge')+'</b><p>'+x.task+'</p></div></div>'+
      '<div class="ls-work">'+(run?'':'<div class="ls-note">🧠 '+esc(l.n)+' is checked by your Tot, not run (it’s too big for an iPad). Real coders use these same skills!</div>')+work+
      '<pre class="ls-out" id="ls-out" hidden></pre><div class="ls-res" id="ls-res" hidden></div><div class="ls-hintbox" id="ls-hintbox" hidden></div><button type="button" class="ls-next" id="ls-next" hidden>Next →</button></div>';
    body.appendChild(c);
    var out=$('ls-out'),res=$('ls-res'),hb=$('ls-hintbox'),nextB=$('ls-next'),ed=$('ls-ed'),dk='hc_cdraft_'+k+'_'+x.id;
    function getAns(){return x.k==='fill'?$('ls-fill').value:ed?ed.value:'';}
    if(ed){var saved=null;try{saved=localStorage.getItem(dk);}catch(e){}ed.value=saved!=null?saved:(x.start||'');
      ed.addEventListener('input',function(){try{localStorage.setItem(dk,ed.value.slice(0,6000));}catch(e){}});
      var ins=function(txt,bk){var s=ed.selectionStart,e=ed.selectionEnd,v=ed.value;ed.value=v.slice(0,s)+txt+v.slice(e);var q=s+txt.length-(bk||0);ed.selectionStart=ed.selectionEnd=q;try{localStorage.setItem(dk,ed.value);}catch(z){}};
      ed.addEventListener('keydown',function(e){if(e.key==='Tab'){e.preventDefault();ins('    ');}
        else if(e.key==='Enter'&&!e.shiftKey&&!e.metaKey&&!e.ctrlKey){var s=ed.selectionStart,v=ed.value,ls=v.lastIndexOf('\n',s-1)+1,line=v.slice(ls,s),ind=(line.match(/^[ \t]*/)||[''])[0];if(/(\{|\bthen|\bdo|\belse)\s*$/.test(line))ind+='    ';if(ind){e.preventDefault();ins('\n'+ind);}}});
      var kb=$('ls-keys'),key=function(b){var kk=b.getAttribute('data-k');if(D.activeElement!==ed){try{ed.focus();}catch(z){}}if(kk==='tab')ins('    ');else if(/^(\(\)|\{\}|""|\[\])$/.test(kk))ins(kk,1);else ins(kk);};
      kb.addEventListener('mousedown',function(e){e.preventDefault();});kb.addEventListener('touchstart',function(e){if(e.target&&e.target.tagName==='BUTTON')e.preventDefault();},{passive:false});
      kb.addEventListener('touchend',function(e){var b=e.target;if(b&&b.tagName==='BUTTON'){e.preventDefault();key(b);}});kb.addEventListener('click',function(e){var b=e.target;if(b&&b.tagName==='BUTTON')key(b);});
      $('ls-rst').onclick=function(){if(ed.value!==(x.start||'')&&!confirm('Start this challenge over?'))return;ed.value=x.start||'';try{localStorage.removeItem(dk);}catch(e){}out.hidden=true;res.hidden=true;};}
    function showOut(r){out.hidden=false;var o=r.out||'';out.className='ls-out'+(r.err?' err':'');out.textContent=(o?o:'')+(r.err?(o?'\n':'')+'🐞 '+r.err:'')||'(no output)';}
    if(run){$('ls-try').onclick=function(){var eo=$('ls-egout');eo.hidden=false;eo.textContent=l.run==='lua'&&!luaLoaded?'loading Lua…':'…';cRun(l.run,x.eg,'',function(r){eo.className='ls-out ls-egout'+(r.err?' err':'');eo.textContent=(r.out||'')+(r.err?'🐞 '+r.err:'')||'(no output)';});};
      $('ls-run').onclick=function(){var b=this;b.disabled=true;teach(tt,'focus',l.run==='lua'&&!luaLoaded?'Loading Lua… 🌙':'Running… 👀');cRun(l.run,ed.value,'',function(r){b.disabled=false;showOut(r);
        if(r.err)teach(tt,'oops',r.slow?'Endless loop? 🔁 Check your loop!':'Bug spotted 🔍 Read the error');else teach(tt,'serious','Looks good? Press ✅ Check!');});};}
    function result(r){res.hidden=false;
      if(r.ok){var secs=Math.round((now()-t0)/1000),st=1+(fails===0?1:0)+(secs<=par?1:0),old=p[x.id]||{},first=!(old.s>0),wasM=cMastered(l);
        p[x.id]={s:Math.max(old.s||0,st),t:old.t?Math.min(old.t,secs):secs};cpSave(k);var lvlNow=cPassed(l,li),allM=!wasM&&cMastered(l);
        res.className='ls-res ok';res.innerHTML='<b>'+(run?'Passed! ':'Correct! ')+'⭐'.repeat(st)+'</b><span>'+(fails===0?'First try! ':'')+(secs<=par?'⚡ Speed bonus ('+secs+'s)':'Done in '+secs+'s')+'</span>'+(lvlNow&&first?'<div class="ls-master">🏅 Level '+(li+1)+' mastered!'+(allM?' You mastered '+esc(l.n)+'! 🏆':li+1<l.LV.length?' Level '+(li+2)+' unlocked 🔓':'')+'</div>':'');
        teach(tt,'pass',allM?l.n+' MASTER! 🏆🎉':lvlNow&&first?'MASTERED! 🏅🎉':secs<=par?'Fast! ⚡ Nailed it!':pick(['You did it! 🎉','Clean code ✅','Woohoo! ⭐']));
        var nj=lj+1,nli=li;if(nj>=V.L.length){nj=0;nli=li+1;}nextB.hidden=!(nli<l.LV.length&&cOpen(l,nli));nextB.textContent=nli!==li?'Next level →':'Next lesson →';nextB.onclick=function(){show('cles',[k,nli,nj]);};
        if(nextB.hidden){nextB.hidden=false;nextB.textContent='Back to levels';nextB.onclick=function(){back();};}}
      else{fails++;res.className='ls-res bad';res.innerHTML='<b>'+(r.err?'Bug spotted 🔍':'Not yet!')+'</b><pre>'+esc(r.msg||r.err||'Try again')+'</pre>';
        teach(tt,r.err?'oops':'serious',fails>=2?(run?'Stuck? Tap 💡 Hint, I’ll help.':'Stuck? Tap 🤖 Explain!'):r.err?'Let’s fix that bug together 🔍':'Almost! Look closely 🧐');}
      try{res.scrollIntoView({block:'nearest',behavior:'smooth'});}catch(e){}}
    if(x.k==='mc'){var ob=c.querySelectorAll('.ls-opt');for(var q=0;q<ob.length;q++)ob[q].onclick=function(){var me=this,i=+me.getAttribute('data-i');cjudge(l,x,i,function(r){if(r.ok){for(var z=0;z<ob.length;z++)ob[z].disabled=true;addC(me,'ok');}else{addC(me,'no');me.disabled=true;}result(r);});};}
    else{$('ls-chk').onclick=function(){var b=this;b.disabled=true;teach(tt,'focus','Checking… 🧐');cjudge(l,x,getAns(),function(r){b.disabled=false;if(run&&(r.out!=null||r.err))showOut({out:r.out,err:r.err});result(r);});};
      if(x.k==='fill')$('ls-fill').addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();$('ls-chk').click();}});
      $('ls-hint').onclick=function(){var b=this;b.disabled=true;teach(tt,'think','Hmm, let me look… 🤔');hb.hidden=false;hb.innerHTML='<span class="ls-spin"></span> '+(run?'thinking of a hint…':'reading your code…');
        var task=String(x.task).replace(/<[^>]+>/g,'').replace(/&#39;/g,"'").replace(/&quot;/g,'"').replace(/&amp;/g,'&').replace(/&gt;/g,'>').replace(/&lt;/g,'<');var mine=x.k==='fill'?String(x.code).replace('___','['+(getAns()||'?')+']'):(ed.value.trim()||'(empty)');
        var fb=run?'Read the example again and copy its pattern 👀':'Compare your code with the example, letter by letter: quotes, ( ), { } and ; all matter 👀';
        var done=false,ctrl=('AbortController' in W)?new AbortController():null,tm=0;
        function fin(h,ai){if(done)return;done=true;clearTimeout(tm);b.disabled=false;hb.innerHTML='<b>'+(run?'💡 ':'🤖 ')+esc(selTot().n||'Tot')+' says:</b> '+esc(h);teach(tt,'cheer',ai?'Try that! 💪':'Here’s a clue 💡');}
        cjudge(l,x,getAns(),function(v){var ok=!!(v&&v.ok);
          /* the lesson's own checker decides right/wrong; the AI only explains */
          var verdict=ok?'The checker says my code is CORRECT.':'The checker says my code is NOT correct yet'+(v&&v.msg?' ('+String(v.msg).split('\n')[0].slice(0,60)+')':'')+'. Do not say it is correct.';
          var msgs=[{role:'user',content:('I am a kid doing a '+l.n+' lesson called "'+x.t+'". The challenge: '+task).slice(0,280)},{role:'assistant',content:'Cool! Show me your code. I will explain in plain words, never code or the answer.'},
            {role:'user',content:('My '+l.n+' code:\n'+mine.slice(0,150)).slice(0,200)+'\n'+verdict+' '+(run?'Give ONE hint':'Explain what to look at')+' in 2 plain sentences. NEVER write code, a code line or the answer.'}];
          tm=setTimeout(function(){if(ctrl)ctrl.abort();},20000);
          fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages:msgs}),signal:ctrl?ctrl.signal:undefined}).then(function(r){return r.json();})
            .then(function(j){var h=hcNoCode(j&&j.reply,x,x.k==='fill'?null:null);
              if(h&&!ok){h=(h.match(/[^.!?]+[.!?]*/g)||[h]).map(function(t){return t.trim();}).filter(function(t){return !/\b(yep|yes|yeah|correct|looks (good|right|great|perfect)|perfect|nailed|well done|great job|that'?s right|good job|right!|no mistakes|is right|works)\b/i.test(t);}).join(' ').trim();
                if(h.length<12)h='';if(h)h='Not quite yet 🔍 '+h;}
              if(!h&&!ok)h=(v&&v.msg?String(v.msg).split('\n')[0]+' ':'')+fb;
              fin(h||fb,!!h);})['catch'](function(){fin(ok?'Your code passes the check! ✅ Press Check to finish.':fb,false);});});};}
  }
  W.hcCodeRunTest=function(lang,code,cb){cRun(lang,code,'',cb);};W.hcCode={langs:function(){return CL.map(function(l){return l.k;});},open:function(v,a){open();go(v,a);}};
  /* typing */
  var tyTimer=0,EXT={},EXTstop=[],EXTcards=[],EXThome=[];function stopTy(){clearInterval(tyTimer);tyTimer=0;for(var q=0;q<EXTstop.length;q++){try{EXTstop[q]();}catch(e){}}}
  function vTy(){ttl.textContent='⌨️ Typing';var tt=teacher('mid');var nx=0;while(nx<TY.length&&P.ty[nx]&&P.ty[nx].p)nx++;
    teach(tt,nx>=TY.length?'pass':'cheer',nx>=TY.length?'Pro typist! 🏆':nx===0?'Fingers on the home row! 🏠':'Level '+(nx+1)+' is ready. Accuracy first! 🎯');
    var w=D.createElement('div');w.className='ls-levels ls-tylv';
    w.innerHTML=TY.map(function(l,i){var op=tyOpen(i),b=P.ty[i]||{};return '<button type="button" class="ls-tyl'+(op?'':' locked')+(b.p?' done':'')+'" data-i="'+i+'"'+(op?'':' disabled')+'><span class="ls-le">'+(op?l.e:'🔒')+'</span><span class="ls-tyn"><b>'+(i+1)+'. '+esc(l.n)+'</b><small>Goal '+l.wpm+' WPM · '+l.acc+'%'+(b.w?' · best '+b.w+' WPM, '+b.a+'%':'')+'</small></span>'+(b.p?'<span class="ls-badge">🏅</span>':'')+'</button>';}).join('');
    body.appendChild(w);var bs=w.querySelectorAll('.ls-tyl');for(var k=0;k<bs.length;k++)bs[k].onclick=function(){if(!this.disabled)go('tyrun',+this.getAttribute('data-i'));};}
  function vTyRun(i){var l=TY[i];if(!l||!tyOpen(i)){show('ty');return;}ttl.textContent=l.e+' '+l.n;var tt=teacher('mid');teach(tt,'cheer',l.tip+' 👆');
    var ti=Math.floor(Math.random()*l.T.length),txt='';
    var c=D.createElement('div');c.className='ls-ty';
    c.innerHTML='<div class="ls-tstats"><div><b id="ty-w">0</b><span>WPM</span></div><div><b id="ty-a">100</b><span>% accuracy</span></div><div><b id="ty-t">0</b><span>seconds</span></div><div class="ls-goal"><b>'+l.wpm+'</b><span>WPM goal · '+l.acc+'%</span></div></div>'+
      '<div class="ls-ttext" id="ty-txt" aria-label="Text to type"></div><textarea class="ls-tin" id="ty-in" rows="2" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" placeholder="Tap here and type the text above…" aria-label="Type here"></textarea>'+
      '<div class="ls-res" id="ty-res" hidden></div><div class="ls-btns"><button type="button" class="ls-b" id="ty-again">↺ Restart</button><button type="button" class="ls-b" id="ty-new">🔀 New text</button><button type="button" class="ls-b ls-chk" id="ty-next" hidden>Next level →</button></div>';
    body.appendChild(c);var tx=$('ty-txt'),inp=$('ty-in'),wE=$('ty-w'),aE=$('ty-a'),tE=$('ty-t'),res=$('ty-res');
    var st=0,total=0,errs=0,prev='',streak=0,recent=[],lastWarn=0,fin=false,spans=[];
    function norm(v){return v.replace(/[\u2018\u2019]/g,"'").replace(/[\u201C\u201D]/g,'"').replace(/\u00A0/g,' ').replace(/\n/g,' ');}
    function reset(nt){stopTy();if(nt)ti=(ti+1)%l.T.length;txt=l.T[ti];tx.innerHTML=txt.split('').map(function(ch){return '<span>'+(ch===' '?' ':esc(ch))+'</span>';}).join('');spans=tx.children;
      st=0;total=0;errs=0;prev='';streak=0;recent=[];fin=false;inp.value='';inp.disabled=false;inp.maxLength=txt.length;res.hidden=true;$('ty-next').hidden=true;wE.textContent='0';aE.textContent='100';tE.textContent='0';paint('');}
    function corr(v){var n=0;for(var k=0;k<v.length;k++)if(v[k]===txt[k])n++;return n;}
    function stats(v){var secs=st?(now()-st)/1000:0,mins=Math.max(secs,1)/60,w=Math.round(corr(v)/5/mins),a=total?Math.round((total-errs)/total*100):100;return {w:st?w:0,a:a,s:Math.round(secs)};}
    function paint(v){for(var k=0;k<spans.length;k++){var cl=k<v.length?(v[k]===txt[k]?'c':'x'+(txt[k]===' '?' sp':'')):(k===v.length?'cur':'');if(spans[k].className!==cl)spans[k].className=cl;}}
    function tick(){if(!st||fin)return;var s=stats(norm(inp.value));wE.textContent=s.w;aE.textContent=s.a;tE.textContent=s.s;}
    inp.addEventListener('paste',function(e){e.preventDefault();});inp.addEventListener('drop',function(e){e.preventDefault();});
    inp.addEventListener('input',function(){if(fin)return;var v=norm(inp.value);if(v.length>txt.length)v=v.slice(0,txt.length);if(v!==inp.value)inp.value=v;
      if(!st&&v.length){st=now();stopTy();tyTimer=setInterval(tick,500);}
      if(v.length>prev.length&&v.slice(0,prev.length)===prev||v.length>prev.length){for(var k=prev.length;k<v.length;k++){total++;var ok=v[k]===txt[k];if(!ok){errs++;streak=0;}else streak++;recent.push(ok?0:1);if(recent.length>12)recent.shift();}
        var badN=recent.reduce(function(a,b){return a+b;},0);
        if(badN>=5&&now()-lastWarn>4000){lastWarn=now();teach(tt,'serious','Slow down, accuracy first 🎯');}
        else if(streak>0&&streak%20===0){teach(tt,'cheer',pick(['Streak! 🔥 '+streak,'On fire! 🔥','So smooth! ✨']));}}
      prev=v;paint(v);tick();
      if(v.length>=txt.length){fin=true;stopTy();var s=stats(v);wE.textContent=s.w;aE.textContent=s.a;tE.textContent=s.s;inp.disabled=true;try{inp.blur();}catch(e){}
        var pass=s.w>=l.wpm&&s.a>=l.acc,b=P.ty[i]||{},firstPass=pass&&!b.p,nb=s.w>(b.w||0);P.ty[i]={w:Math.max(b.w||0,s.w),a:Math.max(b.a||0,s.a),p:b.p||pass};saveP();
        res.hidden=false;res.className='ls-res '+(pass?'ok':'bad');
        res.innerHTML=pass?'<b>Passed! 🏅 '+s.w+' WPM · '+s.a+'%</b><span>'+(nb?'New best! ':'')+(firstPass&&i+1<TY.length?'Level '+(i+2)+' unlocked 🔓':'')+'</span>':'<b>'+s.w+' WPM · '+s.a+'%</b><span>Goal: '+l.wpm+' WPM and '+l.acc+'% accuracy. '+(s.a<l.acc?'Go a bit slower and aim for no mistakes.':'Accuracy is great, now a little faster!')+'</span>';
        teach(tt,pass?'pass':'serious',pass?(s.w>=l.wpm*1.4?'Speed demon! ⚡⚡':'Nailed it! 🎉'):(s.a<l.acc?'Accuracy first, then speed 🎯':'So close! A bit faster 💨'));
        var nbtn=$('ty-next');if(pass&&i+1<TY.length){nbtn.hidden=false;nbtn.onclick=function(){show('tyrun',i+1);};}}});
    $('ty-again').onclick=function(){reset(false);try{inp.focus();}catch(e){}};$('ty-new').onclick=function(){reset(true);try{inp.focus();}catch(e){}};
    tx.addEventListener('click',function(){try{inp.focus();}catch(e){}});
    reset(false);}

  /* entry: 📚 Lessons pill next to Chat / Code / Tots */
  var modes=D.querySelector('.hc-modes');if(modes){var lb=D.createElement('button');lb.type='button';lb.className='hm hm-ls';lb.id='hc-lessons-btn';lb.setAttribute('aria-haspopup','dialog');lb.innerHTML='📚 Lessons';lb.onclick=open;modes.appendChild(lb);addC(modes,'hm4');}
  W.hcLessons={open:open,close:close,react:chatReact,mood:mood,py:function(){return pwS;},judge:judge,
    ext:{reg:function(v,fn){EXT[v]=fn;},stop:function(fn){EXTstop.push(fn);},card:function(fn){EXTcards.push(fn);},home:function(fn){EXThome.push(fn);},body:function(){return body;},ttl:function(){return ttl;},teacher:teacher,teach:teach,go:go,show:show,back:back,esc:esc,isView:function(v){return view===v&&sh&&!sh.hidden;},openTo:function(v,arg){open();go(v,arg);}}};
})();
