/* unhinged.js (Tabo v2.0.1, the user Nov 2 5:31 PM: "make an unhinged mode, not talking about stuff like that").
   A 😈 chip next to the AI picker turns on Unhinged mode: chaotic, roasty, ALL-CAPS meltdowns, swears only BLEEPED (f***, *BLEEP*).
   The chat (and the Talking Face, which sends through the same chat) passes mode:"unhinged"; the server keeps the SAME kid-safe
   prompt + Safety Shield and stars any real swear. Saved on this device (localStorage). Off by default. ES5 only. */
(function(){
  'use strict';
  var W=window,D=document,K='hc_unhinged_v1',on=false,chip=null,PH='say something, I dare you \uD83D\uDE08',ph0=null,tries=0;
  try{on=localStorage.getItem(K)==='1';}catch(e){}
  function root(){return D.documentElement;}
  function setC(el,c,v){if(!el)return;var s=' '+el.className+' ',h=s.indexOf(' '+c+' ')>=0;if(v&&!h)el.className=(el.className?el.className+' ':'')+c;else if(!v&&h)el.className=s.replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  function paint(){setC(root(),'hc-unh',on);
    var inp=D.getElementById('msg');if(inp){if(ph0===null)ph0=inp.getAttribute('placeholder')||'';inp.setAttribute('placeholder',on?PH:ph0);}
    if(chip){chip.setAttribute('aria-pressed',on?'true':'false');chip.title=on?'Unhinged mode is ON (tap to turn off)':'Unhinged mode (tap to turn on)';setC(chip,'on',on);}}
  function set(v){on=!!v;try{localStorage.setItem(K,on?'1':'0');}catch(e){}paint();
    try{if(W.domoHaptic)W.domoHaptic('select');}catch(e){}
    if(W.hcApp&&W.hcApp.toast)W.hcApp.toast(on?'\uD83D\uDE08 Unhinged mode ON: roasts + bleeps, still kid-safe':'\uD83D\uDE07 Unhinged mode off');}
  function mount(){if(chip)return;var bar=D.getElementById('aip'),log=D.getElementById('log');
    if(!bar&&tries++<40){setTimeout(mount,125);return;}
    chip=D.createElement('button');chip.type='button';chip.id='hc-unh';chip.className='hc-unh-chip';chip.setAttribute('aria-label','Unhinged mode');chip.innerHTML='\uD83D\uDE08';
    chip.addEventListener('click',function(e){if(e&&e.stopPropagation)e.stopPropagation();set(!on);});
    if(bar){bar.appendChild(chip);setC(bar,'aip-unh',true);}
    else if(log&&log.parentNode){var w=D.createElement('div');w.className='hc-unh-solo';w.appendChild(chip);log.parentNode.insertBefore(w,log);}
    paint();}
  W.hcUnhinged={on:function(){return on;},set:function(v){set(v);return on;}};
  paint();
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',mount);else mount();
})();
