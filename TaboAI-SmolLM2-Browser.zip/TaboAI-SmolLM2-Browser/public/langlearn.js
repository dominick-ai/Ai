/* 🌍 Languages · Learn with AI (Tabo AI v2.7) — ES5, plugs into lessons.js via window.hcLessons.ext */
(function(){
  var W=window,D=document;
  var X=W.hcLessons&&W.hcLessons.ext;if(!X)return;
  var V='2.7';
  var LANGS=[
    {c:'es',n:'Spanish',nat:'Español',f:'🇪🇸',tts:'es-ES'},
    {c:'fr',n:'French',nat:'Français',f:'🇫🇷',tts:'fr-FR'},
    {c:'de',n:'German',nat:'Deutsch',f:'🇩🇪',tts:'de-DE'},
    {c:'it',n:'Italian',nat:'Italiano',f:'🇮🇹',tts:'it-IT'},
    {c:'pt',n:'Portuguese',nat:'Português',f:'🇧🇷',tts:'pt-BR'},
    {c:'ja',n:'Japanese',nat:'日本語',f:'🇯🇵',tts:'ja-JP',r:1,ns:1},
    {c:'zh',n:'Chinese',nat:'中文',f:'🇨🇳',tts:'zh-CN',r:1,ns:1,sub:'Mandarin · pinyin'},
    {c:'ko',n:'Korean',nat:'한국어',f:'🇰🇷',tts:'ko-KR',r:1},
    {c:'ar',n:'Arabic',nat:'العربية',f:'🇸🇦',tts:'ar-SA',r:1,rtl:1},
    {c:'hi',n:'Hindi',nat:'हिन्दी',f:'🇮🇳',tts:'hi-IN',r:1},
    {c:'ru',n:'Russian',nat:'Русский',f:'🇷🇺',tts:'ru-RU',r:1},
    {c:'tl',n:'Tagalog',nat:'Tagalog',f:'🇵🇭',tts:'fil-PH',alt:['tl','fil']}
  ];
  var BYC={};for(var i=0;i<LANGS.length;i++)BYC[LANGS[i].c]=LANGS[i];
  var KINDS=[
    {k:'listen',e:'🔊',n:'Listen & repeat',h:'A'},
    {k:'pick',e:'🧩',n:'Pick the meaning',h:'A'},
    {k:'build',e:'🔤',n:'Build the sentence',h:'A'},
    {k:'listen',e:'🔊',n:'Listen & repeat',h:'B'},
    {k:'pick',e:'🧩',n:'Pick the meaning',h:'B'},
    {k:'build',e:'🔤',n:'Build the sentence',h:'B'},
    {k:'type',e:'✍️',n:'Type it',h:'all'},
    {k:'say',e:'🎤',n:'Say it',h:'all'},
    {k:'role',e:'💬',n:'Role-play with AI',h:'all'}
  ];
  var esc=X.esc,$=function(id){return D.getElementById(id);};
  function pick(a){return a[Math.floor(Math.random()*a.length)];}
  function shuffle(a){a=a.slice();for(var i=a.length-1;i>0;i--){var j=Math.floor(Math.random()*(i+1)),t=a[i];a[i]=a[j];a[j]=t;}return a;}
  function el(tag,cls,html){var e=D.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e;}

  /* ---------- progress (localStorage, per language) ---------- */
  var KEY='hc_ll_v1',P=null;
  function today(){var d=new Date();return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();}
  function yday(){var d=new Date(Date.now()-864e5);return d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate();}
  function load(){if(P)return P;try{P=JSON.parse(localStorage.getItem(KEY)||'null');}catch(e){P=null;}
    if(!P||typeof P!=='object')P={};if(!P.L)P.L={};if(!P.book)P.book=[];P.xp=P.xp||0;P.streak=P.streak||0;P.best=P.best||0;return P;}
  function save(){try{localStorage.setItem(KEY,JSON.stringify(P));}catch(e){}}
  function LP(c){load();if(!P.L[c])P.L[c]={xp:0,s:{}};return P.L[c];}
  function streakNow(){load();if(P.day===today()||P.day===yday())return P.streak;return 0;}
  function bumpStreak(){load();var t=today();if(P.day===t)return false;P.streak=(P.day===yday())?P.streak+1:1;P.day=t;if(P.streak>P.best)P.best=P.streak;return true;}
  function lesStars(c,u,k){var s=LP(c).s[u+'.'+k];return s||0;}
  function unitDone(c,u){var n=0;for(var k=0;k<KINDS.length;k++)if(lesStars(c,u,k))n++;return n;}
  function unitMastered(c,u){for(var k=0;k<8;k++)if(!lesStars(c,u,k))return false;return true;}
  function langSum(c){var lp=LP(c),st=0,d=0,m=0;for(var key in lp.s)if(lp.s.hasOwnProperty(key)){st+=lp.s[key];d++;}
    if(DATA[c])for(var u=0;u<DATA[c].units.length;u++)if(unitMastered(c,DATA[c].units[u].id))m++;else{}
    else{var seen={};for(var key2 in lp.s)if(lp.s.hasOwnProperty(key2)){var uu=key2.split('.')[0];if(!seen[uu]){seen[uu]=1;if(unitMastered(c,uu))m++;}}}
    return {s:st,d:d,m:m,xp:lp.xp||0};}
  function allSum(){load();var s=0,d=0,m=0,n=0;for(var c in P.L)if(P.L.hasOwnProperty(c)){var q=langSum(c);s+=q.s;d+=q.d;m+=q.m;if(q.d)n++;}return {s:s,d:d,m:m,n:n};}
  function inBook(c,id){load();for(var i=0;i<P.book.length;i++)if(P.book[i].l===c&&P.book[i].id===id)return i;return -1;}
  function toggleBook(c,id){var i=inBook(c,id);if(i>=0)P.book.splice(i,1);else P.book.unshift({l:c,id:id,at:Date.now()});save();return i<0;}

  /* ---------- data: static, verified phrase files lang/<code>.json ---------- */
  var DATA={},LOADING={};
  function getLang(c,cb){if(DATA[c]){cb(DATA[c]);return;}if(LOADING[c]){LOADING[c].push(cb);return;}LOADING[c]=[cb];
    var x=new XMLHttpRequest();x.open('GET','lang/'+c+'.json?v='+V,true);x.timeout=15000;
    function done(d){var q=LOADING[c]||[];delete LOADING[c];if(d)DATA[c]=d;for(var i=0;i<q.length;i++)q[i](d);}
    x.onload=function(){var d=null;if(x.status===200){try{d=JSON.parse(x.responseText);}catch(e){}}done(d&&d.units?prep(d):null);};
    x.onerror=x.ontimeout=function(){done(null);};x.send();}
  function prep(d){d.map={};for(var u=0;u<d.units.length;u++){var U=d.units[u];for(var i=0;i<U.p.length;i++){U.p[i].u=U.id;U.p[i].i=i;d.map[U.p[i].id]=U.p[i];}}return d;}
  function unitById(d,id){for(var i=0;i<d.units.length;i++)if(d.units[i].id===id)return d.units[i];return null;}

  /* ---------- 🔊 voice (speechSynthesis) ---------- */
  var SS=W.speechSynthesis||null,voices=[];
  function loadVoices(){try{voices=SS?SS.getVoices()||[]:[];}catch(e){voices=[];}}
  if(SS){loadVoices();try{SS.addEventListener?SS.addEventListener('voiceschanged',loadVoices):(SS.onvoiceschanged=loadVoices);}catch(e){}}
  function voiceFor(L){if(!SS)return null;loadVoices();var want=[L.tts.toLowerCase()].concat(L.alt||[L.c]),best=null;
    for(var i=0;i<voices.length;i++){var vl=String(voices[i].lang||'').toLowerCase().replace('_','-');
      if(vl===want[0])return voices[i];
      for(var j=0;j<want.length;j++){var w=want[j].split('-')[0];if(vl===w||vl.indexOf(w+'-')===0){if(!best||voices[i].localService)best=voices[i];}}}
    return best;}
  function canSpeak(L){if(!SS||!W.SpeechSynthesisUtterance)return false;loadVoices();if(!voices.length)return 'maybe';return !!voiceFor(L);}
  function speak(L,text,slow,onend){if(!SS||!W.SpeechSynthesisUtterance){if(onend)onend(false);return false;}
    var v=voiceFor(L);if(voices.length&&!v){if(onend)onend(false);return false;}
    try{SS.cancel();var u=new SpeechSynthesisUtterance(text);u.lang=L.tts;if(v)u.voice=v;u.rate=slow?0.55:0.9;u.pitch=1.05;
      if(onend){u.onend=function(){onend(true);};u.onerror=function(){onend(false);};}SS.speak(u);return true;}catch(e){if(onend)onend(false);return false;}}
  function hush(){try{if(SS)SS.cancel();}catch(e){}}

  /* ---------- 🎤 speech recognition ---------- */
  var SR=W.SpeechRecognition||W.webkitSpeechRecognition||null,rec=null;
  function stopRec(){if(rec){try{rec.onresult=rec.onerror=rec.onend=null;rec.abort();}catch(e){}rec=null;}}
  X.stop(function(){hush();stopRec();stopKeys();});

  /* ---------- answer checking (accent tolerant) ---------- */
  function fold(s,L){s=String(s||'').toLowerCase();
    if(s.normalize)s=s.normalize('NFKD');
    s=s.replace(/[\u0300-\u036f]/g,'').replace(/[\u064B-\u065F\u0670\u0640]/g,'').replace(/[أإآٱ]/g,'ا').replace(/ة/g,'ه').replace(/ى/g,'ي').replace(/ß/g,'ss').replace(/ё/g,'е');
    s=s.replace(/[.,!?¿¡;:"“”‘’'«»()\-–—…。、！？，．：；「」『』·・।٫،؟]/g,' ').replace(/\s+/g,' ').trim();
    if(L&&L.c==='ja')s=s.replace(/ou/g,'o').replace(/uu/g,'u').replace(/oo/g,'o');
    return s;}
  function lev(a,b){if(a===b)return 0;var m=a.length,n=b.length;if(!m)return n;if(!n)return m;var p=[],q,i,j;for(j=0;j<=n;j++)p[j]=j;
    for(i=1;i<=m;i++){q=[i];for(j=1;j<=n;j++)q[j]=Math.min(p[j]+1,q[j-1]+1,p[j-1]+(a.charAt(i-1)===b.charAt(j-1)?0:1));p=q;}return p[n];}
  function sim(a,b){var x=a.replace(/ /g,''),y=b.replace(/ /g,'');var mx=Math.max(x.length,y.length);if(!mx)return 1;return 1-lev(x,y)/mx;}
  function judge(input,p,L){var raw=String(input||'').trim();if(!raw)return {ok:false,empty:1};
    var cands=[p.t].concat(p.alt||[]),exact=false,best=0,fi=fold(raw,L);
    for(var i=0;i<cands.length;i++){if(raw.replace(/\s+/g,' ')===cands[i])exact=true;var s=sim(fi,fold(cands[i],L));if(s>best)best=s;}
    if(p.r){var rs=sim(fi,fold(p.r,L));if(rs>best)best=rs;}
    if(exact)return {ok:true,exact:true};
    if(best>=0.999)return {ok:true,accent:true};
    if(best>=0.84)return {ok:true,close:true,score:best};
    return {ok:false,score:best};}

  /* ---------- views ---------- */
  var curL=null;
  function L0(){load();return BYC[P.lang]||null;}
  function card(){var a=allSum(),st=streakNow();
    return {html:'<button type="button" class="ls-course ls-clang" id="ls-c-lang"><span class="ls-ci">🌍</span><b>Languages <span class="ll-newpill">NEW</span></b><span>Learn with AI: 12 languages, real sentences for daily life, AI role-play</span><em>'+(a.d?a.d+' lessons · ⭐ '+a.s+' · 🏅 '+a.m+(st?' · 🔥 '+st:''):'Spanish, Japanese, Arabic & more')+'</em></button>',
      id:'ls-c-lang',go:function(){X.go('llhome');}};}
  X.card(card);

  function statsBar(){var st=streakNow(),a=load();return '<div class="ll-stats"><span title="Day streak">🔥 <b>'+st+'</b> day'+(st===1?'':'s')+'</span><span title="XP">⚡ <b>'+(a.xp||0)+'</b> XP</span><button type="button" class="ll-bookb" id="ll-book">📒 Phrasebook <b>'+a.book.length+'</b></button></div>';}
  function wireStats(){var b=$('ll-book');if(b)b.onclick=function(){X.go('llbook');};}

  function vHome(){try{localStorage.setItem('hc_ll_new','1');var pb=D.getElementById('hc-lessons-btn');if(pb)pb.className=pb.className.replace(/\s*ll-dot/g,'');}catch(e){}X.ttl().textContent='🌍 Languages';var tt=X.teacher('big');
    X.teach(tt,'cheer','Hola! Bonjour! こんにちは! Pick a language and let’s talk like real life 🌍');
    var B=X.body();B.appendChild(el('div','',statsBar()));wireStats();
    var g=el('div','ll-langs');var h='';
    for(var i=0;i<LANGS.length;i++){var L=LANGS[i],q=langSum(L.c);
      h+='<button type="button" class="ll-lang'+(q.d?' started':'')+'" data-c="'+L.c+'" lang="'+L.c+'"><span class="ll-flag">'+L.f+'</span><b'+(L.rtl?' dir="rtl"':'')+'>'+esc(L.nat)+'</b><small>'+esc(L.n)+(L.sub?' · '+esc(L.sub.split(' · ')[0]):'')+'</small><i>'+(q.d?'⭐ '+q.s+(q.m?' · 🏅 '+q.m:''):'Start →')+'</i></button>';}
    g.innerHTML=h;B.appendChild(g);
    B.appendChild(el('p','ll-note','Every course teaches the same 10 real-life topics: greetings, numbers, ordering food, shopping, directions, school, family, weather, help and travel. Progress saves on this device.'));
    var bs=g.querySelectorAll('.ll-lang');for(var k=0;k<bs.length;k++)bs[k].onclick=function(){var c=this.getAttribute('data-c');load();P.lang=c;save();X.go('llang',c);};}

  function loadingInto(B,txt){var w=el('div','ll-loading','<span class="ls-spin"></span> '+esc(txt||'Loading…'));B.appendChild(w);return w;}

  function vLang(c){var L=BYC[c];if(!L){X.show('llhome');return;}curL=L;X.ttl().textContent=L.f+' '+L.nat;var tt=X.teacher('mid');X.teach(tt,'cheer','…');
    var B=X.body();var ld=loadingInto(B,'Loading '+L.n+'…');
    getLang(c,function(d){if(!X.isView('llang'))return;if(ld.parentNode)ld.parentNode.removeChild(ld);
      if(!d){X.teach(tt,'oops','Hmm, I couldn’t load '+L.n+'. Check the internet and try again 📶');var rb=el('button','ls-b','↺ Try again');rb.onclick=function(){X.show('llang',c);};B.appendChild(rb);return;}
      var hi=d.hello||{};X.teach(tt,'cheer',(hi.t||'')+(hi.r&&hi.r!==hi.t?' ('+hi.r+')':'')+': '+(hi.e||('Let’s learn '+L.n+'!')));
      sayDir(tt.say,L);
      B.appendChild(el('div','',statsBar()));wireStats();
      var vc=canSpeak(L);if(vc===false)B.appendChild(el('p','ll-warn','🔇 This device has no '+esc(L.n)+' voice, so 🔊 buttons stay quiet. Read the '+(L.r?'romanization':'words')+' out loud instead! (iPad: Settings → Accessibility → Spoken Content → Voices can add one.)'));
      var w=el('div','ls-levels ll-units');var h='';
      for(var u=0;u<d.units.length;u++){var U=d.units[u],dn=unitDone(c,U.id),ms=unitMastered(c,U.id);
        h+='<div class="ls-lvl ll-unit'+(ms?' done':'')+'"><div class="ls-lh2"><span class="ls-le">'+U.e+'</span><span class="ll-un"><b>'+(u+1)+'. '+esc(U.n)+'</b><small>'+dn+'/'+KINDS.length+' lessons'+(ms?' · mastered!':'')+'</small></span>'+(ms?'<span class="ls-badge" title="Unit mastered">🏅</span>':'')+'</div><div class="ls-lgrid ll-lgrid">';
        for(var k=0;k<KINDS.length;k++){var K=KINDS[k],s=lesStars(c,U.id,k);
          h+='<button type="button" class="ls-lb ll-lb'+(s?' ok':'')+'" data-u="'+U.id+'" data-k="'+k+'"><span>'+K.e+' '+esc(K.n)+(K.h==='B'?' 2':'')+'</span><i>'+(s?stars(s):'')+'</i></button>';}
        h+='</div></div>';}
      w.innerHTML=h;B.appendChild(w);
      var bs=w.querySelectorAll('.ll-lb');for(var j=0;j<bs.length;j++)bs[j].onclick=function(){X.go('llrun',{c:c,u:this.getAttribute('data-u'),k:+this.getAttribute('data-k')});};});}
  function stars(n){return n>=3?'⭐⭐⭐':n===2?'⭐⭐':'⭐';}
  function sayDir(node,L){try{node.setAttribute('dir','auto');}catch(e){}}

  /* phrase display */
  function phraseHTML(p,L,o){o=o||{};return '<div class="ll-ph'+(o.big?' big':'')+'"><div class="ll-t" lang="'+L.c+'"'+(L.rtl?' dir="rtl"':'')+'>'+esc(p.t)+'</div>'+(p.r&&!o.noR?'<div class="ll-r">'+esc(p.r)+'</div>':'')+(o.noE?'':'<div class="ll-e">'+esc(p.e)+'</div>')+'</div>';}
  function audioBtns(id){return '<button type="button" class="ls-b ll-say" id="'+id+'-p">🔊 Play</button><button type="button" class="ls-b ll-slow" id="'+id+'-s">🐢 Slow</button>';}
  function wireAudio(id,L,text){var a=$(id+'-p'),b=$(id+'-s');if(a)a.onclick=function(){if(!speak(L,text,false))noVoice(L);};if(b)b.onclick=function(){if(!speak(L,text,true))noVoice(L);};}
  var nvShown=0;function noVoice(L){var n=$('ll-nv');if(n){n.hidden=false;return;}}

  /* ---------- the lesson runner ---------- */
  var RUN=null,keyH=null;
  function stopKeys(){if(keyH){D.removeEventListener('keydown',keyH,true);keyH=null;}}
  function vRun(a){if(!a||!BYC[a.c]){X.show('llhome');return;}var L=BYC[a.c];curL=L;var K=KINDS[a.k];if(!K){X.show('llang',a.c);return;}
    X.ttl().textContent=L.f+' '+K.e+' '+K.n;var B=X.body();var ld=loadingInto(B,'Getting your lesson ready…');
    getLang(a.c,function(d){if(!X.isView('llrun'))return;if(ld.parentNode)ld.parentNode.removeChild(ld);if(!d){X.show('llang',a.c);return;}
      var U=unitById(d,a.u);if(!U){X.show('llang',a.c);return;}
      var tt=X.teacher('mid');
      var head=el('div','ll-head','<span class="ll-uchip">'+U.e+' '+esc(U.n)+'</span><div class="ll-bar" role="progressbar" aria-label="Lesson progress" aria-valuemin="0" aria-valuemax="100"><i id="ll-bar"></i></div><span class="ll-xp" id="ll-xp">⚡ 0</span>');
      B.appendChild(head);
      B.appendChild(el('p','ll-warn','🔇 No '+esc(L.n)+' voice on this device, so read it out loud yourself!')).id='ll-nv';$('ll-nv').hidden=true;
      var stage=el('div','ll-stage');stage.id='ll-stage';B.appendChild(stage);
      RUN={L:L,d:d,U:U,k:a.k,K:K,tt:tt,stage:stage,steps:[],pos:0,miss:0,good:0,xp:0,retry:{},done:false};
      var ps=U.p.slice(0),A=ps.slice(0,6),Bh=ps.slice(6,12),set=K.h==='A'?A:K.h==='B'?Bh:ps;
      if(K.k==='role'){X.teach(tt,'cheer',pick(d.cheers||[{t:'¡Vamos!'}]).t+' Let’s practice for real! 💬');role(U);return;}
      RUN.steps=makeSteps(K.k,set,ps,L);
      X.teach(tt,'cheer',intro(K.k,L));
      next();});}
  function intro(k,L){return k==='listen'?'Listen, then say it out loud with me! 🔊':k==='pick'?'Tap what it means 🧩':k==='build'?'Tap the tiles in the right order 🔤':k==='type'?'Type it! Accents are OK to skip ✍️':k==='say'?'Say it out loud, I’m listening 🎤':'';}
  function makeSteps(k,set,all,L){var s=[];
    if(k==='listen'){for(var i=0;i<set.length;i++)s.push({t:'card',p:set[i]});var q=shuffle(set).slice(0,3);for(var j=0;j<q.length;j++)s.push({t:'hear',p:q[j]});}
    else if(k==='pick'){var o=shuffle(set);for(var i2=0;i2<o.length;i2++)s.push({t:i2%3===2?'pickR':'pick',p:o[i2]});}
    else if(k==='build'){var b=set.filter(function(p){return p.w&&p.w.length>1;});if(b.length<5){var more=all.filter(function(p){return p.w&&p.w.length>1&&b.indexOf(p)<0;});b=b.concat(shuffle(more).slice(0,5-b.length));}
      b=shuffle(b).slice(0,6);for(var i3=0;i3<b.length;i3++)s.push({t:'build',p:b[i3]});}
    else if(k==='type'){var t=shuffle(all.filter(function(p){return String(p.t).length<=(L.ns?16:34);})).slice(0,6);for(var i4=0;i4<t.length;i4++)s.push({t:'type',p:t[i4]});}
    else if(k==='say'){var y=shuffle(all).slice(0,5);for(var i5=0;i5<y.length;i5++)s.push({t:'say',p:y[i5]});}
    return s;}
  function prog(){if(!RUN)return;var n=RUN.steps.length,b=$('ll-bar');if(b)b.style.width=Math.round(100*RUN.pos/Math.max(1,n))+'%';var x=$('ll-xp');if(x)x.textContent='⚡ '+RUN.xp;}
  function next(){if(!RUN)return;hush();stopRec();stopKeys();prog();if(RUN.pos>=RUN.steps.length){finish();return;}var st=RUN.steps[RUN.pos];RUN.stage.innerHTML='';
    ({card:sCard,hear:sHear,pick:sPick,pickR:sPick,build:sBuild,type:sType,say:sSay})[st.t](st);prog();}
  function cheer(){var c=RUN.d.cheers||[];var x=c.length?pick(c):{t:'👍',e:'Great!'};X.teach(RUN.tt,Math.random()<0.5?'pass':'cheer',x.t+(x.r&&x.r!==x.t?' ('+x.r+')':'')+(x.e?': '+x.e:''));sayDir(RUN.tt.say,RUN.L);}
  function oops(){var a=RUN.d.again||{t:'Try again!'};X.teach(RUN.tt,'oops',a.t+(a.r&&a.r!==a.t?' ('+a.r+')':'')+'. No worries, it’ll come back later 💪');}
  /* feedback + continue */
  function verdict(ok,p,extra,first){var st=RUN.steps[RUN.pos];var key=st.t+':'+p.id;
    if(ok){RUN.good++;var g=RUN.retry[key]?5:10;RUN.xp+=g;cheer();}else{RUN.miss++;oops();if(!RUN.retry[key]){RUN.retry[key]=1;RUN.steps.push(st);}}
    var f=el('div','ll-fb '+(ok?'ok':'bad'),'<b>'+(ok?'✅ '+(extra||'Correct!'):'❌ '+(extra||'Not quite.'))+'</b>'+phraseHTML(p,RUN.L)+(p.tip?'<p class="ll-tip">💡 '+esc(p.tip)+'</p>':'')+
      '<div class="ls-btns">'+audioBtns('fb')+'<button type="button" class="ls-b ll-star" id="fb-bk" aria-pressed="'+(inBook(RUN.L.c,p.id)>=0)+'">'+(inBook(RUN.L.c,p.id)>=0?'⭐ Saved':'☆ Save')+'</button><button type="button" class="ls-b ls-chk" id="fb-go">Continue ➜</button></div>');
    RUN.stage.appendChild(f);wireAudio('fb',RUN.L,p.t);wireBook('fb-bk',p);
    var go=$('fb-go');go.onclick=function(){RUN.pos++;next();};
    if(ok)speak(RUN.L,p.t,false);
    setTimeout(function(){try{go.focus({preventScroll:true});}catch(e){try{go.focus();}catch(x){}}try{f.scrollIntoView({block:'nearest',behavior:'smooth'});}catch(e){}},30);
    prog();}
  function wireBook(id,p){var b=$(id);if(!b)return;b.onclick=function(){var on=toggleBook(RUN?RUN.L.c:curL.c,p.id);b.textContent=on?'⭐ Saved':'☆ Save';b.setAttribute('aria-pressed',on);if(on)X.teach(RUN?RUN.tt:null,'love','Saved to your Phrasebook 📒');};}
  function enterGo(btnId){keyH=function(e){if(e.key==='Enter'&&!e.shiftKey&&!e.metaKey&&!e.ctrlKey){var t=e.target,b=$(btnId);if(!b||b.disabled)return;if(t&&t.tagName==='BUTTON'&&t!==b)return;e.preventDefault();e.stopPropagation();b.click();}};D.addEventListener('keydown',keyH,true);}

  function sCard(st){var p=st.p,L=RUN.L,inb=inBook(L.c,p.id)>=0;
    var c=el('div','ll-card','<span class="ll-kind">🔊 New phrase · '+(RUN.pos+1)+'/'+RUN.steps.filter(function(s){return s.t==='card';}).length+'</span>'+phraseHTML(p,L,{big:1})+(p.tip?'<p class="ll-tip">💡 '+esc(p.tip)+'</p>':'')+
      '<p class="ll-rep">👄 Now you: say it out loud 2 times!</p><div class="ls-btns">'+audioBtns('cd')+'<button type="button" class="ls-b ll-star" id="cd-bk" aria-pressed="'+inb+'">'+(inb?'⭐ Saved':'☆ Save')+'</button><button type="button" class="ls-b ls-chk" id="cd-go">Next ➜</button></div>');
    RUN.stage.appendChild(c);wireAudio('cd',L,p.t);wireBook('cd-bk',p);
    $('cd-go').onclick=function(){RUN.good++;RUN.xp+=5;RUN.pos++;next();};
    if(!speak(L,p.t,false)&&canSpeak(L)===false)$('ll-nv').hidden=false;
    enterGo('cd-go');focusFirst('cd-go');}
  function sHear(st){var p=st.p,L=RUN.L,opts=distract(p,3,'t');
    var c=el('div','ll-card','<span class="ll-kind">👂 Which one did you hear?</span><div class="ls-btns ll-center">'+audioBtns('hr')+'</div><div class="ll-opts" id="ll-opts"></div>');
    RUN.stage.appendChild(c);wireAudio('hr',L,p.t);
    var spoke=speak(L,p.t,false);if(!spoke){$('ll-nv').hidden=false;c.querySelector('.ll-kind').innerHTML='👀 No voice here, so read it: which one says <b>“'+esc(p.e)+'”</b>?';}
    opts2(opts,p,function(o){return '<span lang="'+L.c+'"'+(L.rtl?' dir="rtl"':'')+'>'+esc(o.t)+'</span>'+(o.r?'<small>'+esc(o.r)+'</small>':'');});}
  function sPick(st){var p=st.p,L=RUN.L,rev=st.t==='pickR';
    var c=el('div','ll-card',rev?'<span class="ll-kind">🧩 How do you say…</span><div class="ll-ph big"><div class="ll-e big">“'+esc(p.e)+'”</div></div><div class="ll-opts" id="ll-opts"></div>':
      '<span class="ll-kind">🧩 What does this mean?</span>'+phraseHTML(p,L,{big:1,noE:1})+'<div class="ls-btns ll-center">'+audioBtns('pk')+'</div><div class="ll-opts" id="ll-opts"></div>');
    RUN.stage.appendChild(c);if(!rev){wireAudio('pk',L,p.t);speak(L,p.t,false);}
    var opts=distract(p,3,rev?'t':'e');
    opts2(opts,p,rev?function(o){return '<span lang="'+L.c+'"'+(L.rtl?' dir="rtl"':'')+'>'+esc(o.t)+'</span>'+(o.r?'<small>'+esc(o.r)+'</small>':'');}:function(o){return esc(o.e);});}
  function distract(p,n,field){var pool=[],U=RUN.U.p,all=RUN.d.units;for(var i=0;i<U.length;i++)if(U[i]!==p)pool.push(U[i]);pool=shuffle(pool);
    var out=[p],seen={};seen[p[field]]=1;for(var j=0;j<pool.length&&out.length<n+1;j++){if(!seen[pool[j][field]]){seen[pool[j][field]]=1;out.push(pool[j]);}}
    return shuffle(out);}
  function opts2(opts,p,lab){var box=$('ll-opts'),h='';for(var i=0;i<opts.length;i++)h+='<button type="button" class="ll-opt" data-i="'+i+'"><kbd>'+(i+1)+'</kbd>'+lab(opts[i])+'</button>';box.innerHTML=h;
    var bs=box.querySelectorAll('.ll-opt'),answered=false;
    function choose(i){if(answered)return;answered=true;stopKeys();var ok=opts[i]===p;for(var k=0;k<bs.length;k++){bs[k].disabled=true;if(opts[k]===p)bs[k].className+=' right';}if(!ok)bs[i].className+=' wrong';verdict(ok,p);}
    for(var k=0;k<bs.length;k++)bs[k].onclick=function(){choose(+this.getAttribute('data-i'));};
    keyH=function(e){if(e.metaKey||e.ctrlKey||e.altKey)return;var n=parseInt(e.key,10);if(n>=1&&n<=opts.length&&!(e.target&&/INPUT|TEXTAREA/.test(e.target.tagName))){e.preventDefault();e.stopPropagation();choose(n-1);}};D.addEventListener('keydown',keyH,true);
    focusFirst(null,bs[0]);}
  function focusFirst(id,elx){var e=elx||$(id);if(!e)return;setTimeout(function(){try{if(W.matchMedia&&W.matchMedia('(hover:hover)').matches)e.focus({preventScroll:true});}catch(x){}},40);}

  function sBuild(st){var p=st.p,L=RUN.L,tiles=p.w.slice(0);
    var extra=[];var others=shuffle(RUN.U.p.filter(function(q){return q!==p&&q.w&&q.w.length;}));
    for(var i=0;i<others.length&&extra.length<(tiles.length>=5?1:2);i++){var cand=pick(others[i].w);if(tiles.indexOf(cand)<0&&extra.indexOf(cand)<0)extra.push(cand);}
    var bank=shuffle(tiles.concat(extra).map(function(t,ix){return {t:t,id:ix};}));
    var c=el('div','ll-card','<span class="ll-kind">🔤 Build: <b>“'+esc(p.e)+'”</b></span><div class="ll-ans" id="ll-ans" lang="'+L.c+'"'+(L.rtl?' dir="rtl"':'')+' aria-label="Your sentence"><span class="ll-ph0">Tap the tiles below ⬇️</span></div><div class="ll-bank" id="ll-bank" lang="'+L.c+'"'+(L.rtl?' dir="rtl"':'')+'></div>'+
      '<div class="ls-btns"><button type="button" class="ls-b" id="bd-clr">↺ Clear</button><button type="button" class="ls-b" id="bd-hint">💡 Hint</button><button type="button" class="ls-b ls-chk" id="bd-ok" disabled>Check ✓</button></div>');
    RUN.stage.appendChild(c);var ans=[],ansEl=$('ll-ans'),bankEl=$('ll-bank'),okB=$('bd-ok'),hinted=false,lastT=0;
    function paint(){var h='';for(var i=0;i<bank.length;i++){var used=ans.indexOf(bank[i])>=0;h+='<button type="button" class="ll-tile'+(used?' used':'')+'" data-b="'+i+'"'+(used?' disabled aria-hidden="true" tabindex="-1"':'')+'>'+esc(bank[i].t)+'</button>';}bankEl.innerHTML=h;
      if(!ans.length)ansEl.innerHTML='<span class="ll-ph0">Tap the tiles below ⬇️</span>';else{var a='';for(var j=0;j<ans.length;j++)a+='<button type="button" class="ll-tile in" data-a="'+j+'" aria-label="Remove '+esc(ans[j].t)+'">'+esc(ans[j].t)+'</button>';ansEl.innerHTML=a;}
      okB.disabled=!ans.length;
      var bb=bankEl.querySelectorAll('.ll-tile');for(var k=0;k<bb.length;k++)bb[k].onclick=function(ev){if(ev&&ev.detail===0&&Date.now()-lastT<160)return;lastT=Date.now();var b=bank[+this.getAttribute('data-b')];if(ans.indexOf(b)<0){ans.push(b);var nxt=this;paint();refocus('b');}};
      var ab=ansEl.querySelectorAll('.ll-tile');for(var m=0;m<ab.length;m++)ab[m].onclick=function(ev){if(ev&&ev.detail===0&&Date.now()-lastT<160)return;lastT=Date.now();ans.splice(+this.getAttribute('data-a'),1);paint();refocus('a');};}
    function refocus(where){if(!(W.matchMedia&&W.matchMedia('(hover:hover)').matches))return;var f=bankEl.querySelector('.ll-tile:not(.used)')||okB;try{f.focus({preventScroll:true});}catch(e){}}
    $('bd-clr').onclick=function(){ans=[];paint();};
    $('bd-hint').onclick=function(){if(!hinted){hinted=true;}var n=0;while(n<ans.length&&n<tiles.length&&ans[n].t===tiles[n])n++;ans=ans.slice(0,n);
      if(n<tiles.length){for(var i=0;i<bank.length;i++)if(bank[i].t===tiles[n]&&ans.indexOf(bank[i])<0){ans.push(bank[i]);break;}}paint();X.teach(RUN.tt,'think','Here’s the next tile 💡');speak(L,p.t,true);};
    okB.onclick=function(){var got=ans.map(function(a){return a.t;}).join(L.ns?'':' ');var ok=got===p.t;var b2=c.querySelectorAll('button');for(var i=0;i<b2.length;i++)b2[i].disabled=true;
      ansEl.className+=ok?' right':' wrong';verdict(ok,p,ok?(hinted?'Correct (with a hint)!':'Correct!'):'Not quite. The right order is:');};
    paint();enterGo('bd-ok');refocus();}

  var ACC={es:'á é í ó ú ü ñ ¿ ¡',fr:'é è ê à â ç ô î ù ë ï œ',de:'ä ö ü ß',it:'à è é ì ò ù',pt:'á à â ã é ê í ó ô õ ú ç',tl:'ñ'};
  function sType(st){var p=st.p,L=RUN.L;
    var c=el('div','ll-card','<span class="ll-kind">✍️ Type this in '+esc(L.n)+':</span><div class="ll-ph big"><div class="ll-e big">“'+esc(p.e)+'”</div></div>'+
      '<input type="text" class="ll-in" id="ty-in2" lang="'+L.c+'"'+(L.rtl?' dir="rtl"':'')+' autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="'+(L.r?'Type in '+esc(L.nat)+' or in English letters…':'Type it here…')+'" aria-label="Your answer">'+
      (ACC[L.c]?'<div class="ll-acc" id="ll-acc">'+ACC[L.c].split(' ').map(function(ch){return '<button type="button" class="ll-k" tabindex="-1">'+ch+'</button>';}).join('')+'</div>':'')+
      (L.r?'<p class="ll-note">Tip: English letters work too, like <i>'+esc(RUN.U.p[0].r)+'</i></p>':'')+
      '<div class="ls-btns"><button type="button" class="ls-b" id="tp-hint">💡 Hint</button><button type="button" class="ls-b" id="tp-skip">🙈 Show me</button><button type="button" class="ls-b ls-chk" id="tp-ok">Check ✓</button></div>');
    RUN.stage.appendChild(c);var inp=$('ty-in2'),hn=0;
    var ks=c.querySelectorAll('.ll-k');for(var i=0;i<ks.length;i++){ks[i].onmousedown=function(e){e.preventDefault();};ks[i].onclick=function(){var s=inp.selectionStart==null?inp.value.length:inp.selectionStart,e2=inp.selectionEnd==null?s:inp.selectionEnd;inp.value=inp.value.slice(0,s)+this.textContent+inp.value.slice(e2);try{inp.focus();inp.setSelectionRange(s+1,s+1);}catch(x){}};}
    $('tp-hint').onclick=function(){hn++;var src=L.r?p.r:p.t;var w=src.split(' ');var show=w.slice(0,Math.min(w.length,hn)).join(' ');X.teach(RUN.tt,'think','It starts with: “'+show+'…”');if(hn===1)speak(L,p.t,true);};
    function done(ok,msg){inp.disabled=true;var b2=c.querySelectorAll('button');for(var i=0;i<b2.length;i++)b2[i].disabled=true;verdict(ok,p,msg);}
    $('tp-skip').onclick=function(){done(false,'Here it is:');};
    $('tp-ok').onclick=function(){var r=judge(inp.value,p,L);if(r.empty){X.teach(RUN.tt,'think','Type your answer first ✍️');try{inp.focus();}catch(e){}return;}
      done(r.ok,r.exact?'Perfect!':r.accent?'Correct! Watch the accents/spelling:':r.close?'Almost perfect! Tiny typo, here’s the exact way:':'Not quite. It’s:');};
    inp.addEventListener('keydown',function(e){if(e.key==='Enter'&&!e.isComposing&&e.keyCode!==229){e.preventDefault();e.stopPropagation();$('tp-ok').click();}});
    setTimeout(function(){try{inp.focus({preventScroll:true});}catch(e){}},60);}

  function sSay(st){var p=st.p,L=RUN.L,tries=0;
    var c=el('div','ll-card','<span class="ll-kind">🎤 Say this out loud:</span>'+phraseHTML(p,L,{big:1})+'<div class="ls-btns ll-center">'+audioBtns('sy')+'</div><div class="ll-mic" id="ll-mic"></div><p class="ll-heard" id="ll-heard" aria-live="polite"></p>');
    RUN.stage.appendChild(c);wireAudio('sy',L,p.t);var mic=$('ll-mic'),heard=$('ll-heard');
    function selfCheck(why){mic.innerHTML='<p class="ll-note">'+esc(why)+'</p><div class="ls-btns"><button type="button" class="ls-b" id="sy-skip">⏭️ Skip</button><button type="button" class="ls-b ls-chk" id="sy-did">✅ I said it!</button></div>';
      $('sy-did').onclick=function(){verdict(true,p,'Nice! You said it 🗣️');};$('sy-skip').onclick=function(){RUN.pos++;next();};enterGo('sy-did');focusFirst('sy-did');}
    if(!SR){selfCheck('🎤 This browser can’t listen here, so say it out loud yourself (try copying the 🔊 voice), then tap “I said it!”');return;}
    mic.innerHTML='<div class="ls-btns"><button type="button" class="ls-b" id="sy-skip">⏭️ Skip</button><button type="button" class="ls-b ls-chk ll-micb" id="sy-go">🎤 Tap & speak</button></div>';
    $('sy-skip').onclick=function(){stopRec();RUN.pos++;next();};
    var go=$('sy-go');enterGo('sy-go');
    go.onclick=function(){stopRec();hush();try{rec=new SR();}catch(e){selfCheck('🎤 The microphone isn’t available. Say it out loud, then tap “I said it!”');return;}
      rec.lang=L.tts;rec.interimResults=false;rec.maxAlternatives=5;var got=false;
      go.disabled=true;go.textContent='👂 Listening…';heard.textContent='';
      rec.onresult=function(ev){got=true;var alts=[],r=ev.results[0];for(var i=0;i<r.length;i++)alts.push(r[i].transcript);var best=0,said=alts[0]||'';
        for(var j=0;j<alts.length;j++){var s=sim(fold(alts[j],L),fold(p.t,L));for(var a=0;a<(p.alt||[]).length;a++)s=Math.max(s,sim(fold(alts[j],L),fold(p.alt[a],L)));if(s>best){best=s;said=alts[j];}}
        heard.textContent='I heard: “'+said+'”';tries++;
        if(best>=0.6){stopRec();verdict(true,p,best>=0.85?'Perfect pronunciation! 🗣️':'Nice, I understood you! 🗣️');}
        else if(tries>=3){stopRec();verdict(true,p,'Good try! Keep practicing this one 🗣️');}
        else{X.teach(RUN.tt,'think','Close! Listen once more and try again 👂');go.disabled=false;go.textContent='🎤 Try again';}};
      rec.onerror=function(ev){var er=ev&&ev.error;stopRec();if(er==='not-allowed'||er==='service-not-allowed'||er==='audio-capture'||er==='language-not-supported'){selfCheck('🎤 I can’t use the microphone here ('+(er==='language-not-supported'?'no '+L.n+' listening on this device':'mic is blocked')+'). Say it out loud, then tap “I said it!”');}
        else{go.disabled=false;go.textContent='🎤 Try again';heard.textContent=er==='no-speech'?'I didn’t hear anything. Tap and speak a bit louder!':'Hmm, try again.';}};
      rec.onend=function(){if(!got&&go&&go.disabled){go.disabled=false;go.textContent='🎤 Tap & speak';}};
      try{rec.start();}catch(e){selfCheck('🎤 The microphone isn’t available. Say it out loud, then tap “I said it!”');}};}

  function finish(){if(!RUN||RUN.done)return;RUN.done=true;var c=RUN.L.c,key=RUN.U.id+'.'+RUN.k,lp=LP(c);
    var s=RUN.miss===0?3:RUN.miss<=2?2:1,prev=lp.s[key]||0,firstM=!unitMastered(c,RUN.U.id);
    lp.s[key]=Math.max(prev,s);var bonus=20;RUN.xp+=bonus;lp.xp=(lp.xp||0)+RUN.xp;load();P.xp=(P.xp||0)+RUN.xp;var newDay=bumpStreak();save();
    var mastered=firstM&&unitMastered(c,RUN.U.id);prog();var bar=$('ll-bar');if(bar)bar.style.width='100%';
    X.teach(RUN.tt,mastered?'pass':'pass',(pick(RUN.d.cheers||[{t:'🎉'}]).t)+(mastered?' 🏅 Unit mastered!':' Lesson done! 🎉'));
    var nk=RUN.k+1<KINDS.length?RUN.k+1:-1;
    RUN.stage.innerHTML='<div class="ls-res ok ll-done"><b>'+(mastered?'🏅 You mastered “'+esc(RUN.U.n)+'”!':'🎉 Lesson complete!')+'</b><div class="ll-big">'+stars(s)+'</div><span>⚡ +'+RUN.xp+' XP · 🔥 '+P.streak+' day streak'+(newDay&&P.streak>1?' (+1 today!)':'')+(RUN.miss?' · '+RUN.miss+' mistake'+(RUN.miss>1?'s':''):' · no mistakes!')+'</span></div>'+
      '<div class="ls-btns"><button type="button" class="ls-b" id="ll-again">↺ Again</button><button type="button" class="ls-b" id="ll-units">🗂️ Units</button>'+(nk>=0?'<button type="button" class="ls-b ls-chk" id="ll-next">Next: '+KINDS[nk].e+' '+esc(KINDS[nk].n)+' ➜</button>':'')+'</div>';
    var a={c:c,u:RUN.U.id,k:RUN.k};$('ll-again').onclick=function(){X.show('llrun',a);};$('ll-units').onclick=function(){X.back();};
    if(nk>=0){$('ll-next').onclick=function(){X.show('llrun',{c:c,u:a.u,k:nk});};enterGo('ll-next');focusFirst('ll-next');}else{enterGo('ll-units');focusFirst('ll-units');}
    if(mastered){try{var fx=el('div','ll-conf');for(var i=0;i<18;i++){var sp=el('i','',pick(['🏅','⭐','🎉','✨']));sp.style.left=(Math.random()*100)+'%';sp.style.animationDelay=(Math.random()*0.6)+'s';fx.appendChild(sp);}RUN.stage.appendChild(fx);setTimeout(function(){if(fx.parentNode)fx.parentNode.removeChild(fx);},2600);}catch(e){}}}

  /* ---------- 💬 role-play with AI (through /api/chat + Safety Shield) ---------- */
  var SCN={greet:['a friendly kid at the park','🧒'],num:['a classmate planning a weekend meetup','🧑‍🎓'],food:['a friendly waiter at a restaurant','🧑‍🍳'],shop:['a kind shopkeeper','🛍️'],dir:['a helpful person on the street','🧭'],
    school:['a new classmate on the first school day','🎒'],home:['a pen pal curious about my family and home','✉️'],weather:['a friendly neighbor','🏡'],help:['a kind shop helper (I feel sick or I am lost)','🩺'],travel:['a friendly hotel receptionist','🛎️']};
  function role(U){var L=RUN.L,d=RUN.d,sc=SCN[U.id]||['a friendly person','🙂'],hist=[],turns=0,busy=false;RUN.steps=[{t:'role'}];
    var c=el('div','ll-card ll-role','<span class="ll-kind">💬 Role-play: you’re talking to '+esc(sc[0])+' '+sc[1]+'</span><p class="ll-note">Reply in '+esc(L.n)+(L.r?' (English letters are OK)':'')+'. Stuck? Tap a phrase below or ask in English. The Safety Shield is on 🛡️</p>'+
      '<div class="ll-chat" id="ll-chat" aria-live="polite"></div><div class="ll-sug" id="ll-sug"></div>'+
      '<form class="ll-form" id="ll-form" autocomplete="off"><input type="text" class="ll-in" id="ll-rin" maxlength="140" lang="'+L.c+'"'+(L.rtl?' dir="auto"':'')+' autocorrect="off" autocapitalize="off" spellcheck="false" placeholder="Your reply in '+esc(L.n)+'…" aria-label="Your reply"><button type="submit" class="ls-b ls-chk" id="ll-send">Send ➤</button></form>'+
      '<div class="ls-btns"><button type="button" class="ls-b" id="ll-rnew">↺ New chat</button><button type="button" class="ls-b ls-chk" id="ll-rdone" disabled>🎉 Finish (reply 3 times)</button></div>');
    RUN.stage.appendChild(c);var chat=$('ll-chat'),inp=$('ll-rin'),sug=$('ll-sug'),send=$('ll-send'),fin=$('ll-rdone');
    function sugg(){var s=shuffle(U.p).slice(0,3);sug.innerHTML=s.map(function(p){return '<button type="button" class="ll-sb" lang="'+L.c+'"'+(L.rtl?' dir="rtl"':'')+' title="'+esc(p.e)+'">'+esc(p.t)+'<small>'+esc(p.e)+'</small></button>';}).join('');
      var bs=sug.querySelectorAll('.ll-sb');for(var i=0;i<bs.length;i++)bs[i].onclick=function(){inp.value=this.firstChild.nodeValue;try{inp.focus();}catch(e){}};}
    function bubble(who,html){var b=el('div','ll-msg '+who,html);chat.appendChild(b);try{chat.scrollTop=chat.scrollHeight;b.scrollIntoView({block:'nearest',behavior:'smooth'});}catch(e){}return b;}
    function parse(txt){txt=String(txt||'').replace(/\*\*/g,'').replace(/^#+\s*/gm,'');var lines=txt.split(/\n+/),tl=[],en=[],fix=[];
      for(var i=0;i<lines.length;i++){var ln=lines[i].trim();if(!ln)continue;var m;
        if((m=ln.match(/^(?:EN|English)\s*[:：]\s*(.*)$/i)))en.push(m[1]);else if((m=ln.match(/^(?:✏️|✏|FIX|Fix|Tip)\s*[:：]?\s*(.*)$/)))fix.push(m[1]);else if(en.length||fix.length)(fix.length?fix:en).push(ln);else tl.push(ln.replace(/^(?:[A-Za-z ]{2,14}|[^\s:]{1,8})\s*[:：]\s*/,function(s){return /^(EN|English)/i.test(s)?s:(s.length<16&&!/[\u0600-\u06ff\u3040-\u30ff\u4e00-\u9fff]/.test(s)?'':s);}));}
      return {t:tl.join(' '),e:en.join(' '),f:(/^\W*(none|no mistakes?|no errors?|nothing to fix|n\/a|-|perfect|correct|great job)\b/i.test(fix.join(' '))||/no (mistakes?|errors?) (detected|found|made)/i.test(fix.join(' '))?'':fix.join(' '))};}
    function aiSay(o){var b=bubble('ai','<span class="ll-who">'+sc[1]+'</span><div class="ll-mt" lang="'+L.c+'" dir="auto">'+esc(o.t||'…')+'</div>'+(o.e?'<div class="ll-me">'+esc(o.e)+'</div>':'')+(o.f?'<div class="ll-mf">✏️ '+esc(o.f)+'</div>':'')+'<button type="button" class="ll-mplay" aria-label="Play">🔊</button>');
      var pb=b.querySelector('.ll-mplay');pb.onclick=function(){if(!speak(L,o.t,false))$('ll-nv').hidden=false;};speak(L,o.t,false);}
    function setup(){var role0="Role-play: I'm a kid learning "+L.n+'. You are '+sc[0]+'. Stay in character, keep chatting, don\'t echo me. Reply: line 1 = max 15 easy '+L.n+' words'+(L.r?' (native script)':'')+'. Line 2 = "EN: " + English. If I made a mistake, line 3 = "✏️ " + my fixed sentence.';
      return [{role:'user',content:role0.slice(0,298)}];}
    function ask(userText){if(busy)return;busy=true;send.disabled=true;inp.disabled=true;var th=bubble('ai th','<span class="ls-spin"></span> '+esc(sc[1])+' is typing…');
      var msgs=setup();var tail=hist.slice(-8);for(var i=0;i<tail.length;i++)msgs.push(tail[i]);
      if(userText!=null){msgs.push({role:'user',content:(userText.slice(0,140)+'\n(Answer in character: '+L.n+' line, then EN: line, then ✏️ line only if I made a mistake.)').slice(0,298)});}
      var ctrl=('AbortController' in W)?new AbortController():null,tm=setTimeout(function(){if(ctrl)ctrl.abort();},25000),finished=false;
      function end(o,err){if(finished)return;finished=true;clearTimeout(tm);busy=false;send.disabled=false;inp.disabled=false;if(th.parentNode)th.parentNode.removeChild(th);
        if(err){bubble('sys',esc(err)+' <button type="button" class="ll-retry">↺ Retry</button>');var rb=chat.querySelector('.ll-msg.sys:last-child .ll-retry');if(rb)rb.onclick=function(){var pr=rb.parentNode;pr.parentNode.removeChild(pr);if(userText!=null)hist.pop();ask(userText);if(userText!=null)hist.push({role:'user',content:userText.slice(0,140)});};return;}
        hist.push({role:'assistant',content:(o.t+(o.e?'\nEN: '+o.e:'')).slice(0,290)});aiSay(o);if(turns>=1&&o.f)X.teach(RUN.tt,'think','Little fix: '+o.f);else if(turns>=1)cheer();sugg();
        if(W.matchMedia&&W.matchMedia('(hover:hover)').matches)try{inp.focus({preventScroll:true});}catch(e){}}
      fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({messages:msgs,model:'gpt-oss-120b'}),signal:ctrl?ctrl.signal:undefined}).then(function(r){return r.json().then(function(j){return [r.status,j];});})
        .then(function(a){var j=a[1]||{};if(a[0]===429||j.error==='rate_limited'){end(null,'⏳ '+(j.reply||'Too many messages. Wait a minute, then retry.'));return;}if(j.blocked||j.shield||j.flagged){end(null,'🛡️ The Safety Shield stopped that one. Try saying something else!');return;}
          var rep=j.reply||j.text||'';if(!rep||a[0]>=400){end(null,'😴 The AI is napping. Try again in a moment.');return;}var o=parse(rep);if(!o.t){o.t=rep.slice(0,200);}end(o);})
        ['catch'](function(){end(null,'📶 Couldn’t reach the AI. Check the internet and retry.');});}
    $('ll-form').onsubmit=function(e){e.preventDefault();var v=inp.value.trim();if(!v||busy)return;inp.value='';bubble('me','<div class="ll-mt" dir="auto">'+esc(v)+'</div>');var u=v;
      ask(u);hist.push({role:'user',content:u.slice(0,140)});turns++;RUN.good++;RUN.xp+=10;prog2();};
    function prog2(){var b=$('ll-bar');if(b)b.style.width=Math.min(100,Math.round(turns/3*100))+'%';var x=$('ll-xp');if(x)x.textContent='⚡ '+RUN.xp;if(turns>=3){fin.disabled=false;fin.textContent='🎉 Finish role-play';}else fin.textContent='🎉 Finish (reply '+(3-turns)+' more)';}
    $('ll-rnew').onclick=function(){hist=[];turns=0;chat.innerHTML='';prog2();ask(null);};
    fin.onclick=function(){RUN.miss=0;finish();};
    sugg();prog2();ask(null);}

  /* ---------- 📒 Phrasebook ---------- */
  function vBook(){X.ttl().textContent='📒 Phrasebook';var tt=X.teacher('mid');load();var B=X.body();
    if(!P.book.length){X.teach(tt,'cheer','Tap ☆ Save on any phrase in a lesson and it shows up here 📒');B.appendChild(el('p','ll-note','Your saved phrases live on this device.'));return;}
    X.teach(tt,'love','Your saved phrases! Tap 🔊 to hear them 📒');
    var byL={},order=[];for(var i=0;i<P.book.length;i++){var b=P.book[i];if(!byL[b.l]){byL[b.l]=[];order.push(b.l);}byL[b.l].push(b.id);}
    var w=el('div','ll-book');B.appendChild(w);var pend=order.length;
    order.forEach(function(c){var L=BYC[c];if(!L){pend--;return;}var sec=el('div','ls-lvl ll-bsec','<div class="ls-lh2"><span class="ls-le">'+L.f+'</span><b>'+esc(L.nat)+' · '+esc(L.n)+'</b></div><div class="ll-blist"><span class="ls-spin"></span></div>');w.appendChild(sec);
      getLang(c,function(d){var list=sec.querySelector('.ll-blist');if(!d){list.textContent='Couldn’t load this language.';return;}var h='';
        byL[c].forEach(function(id){var p=d.map[id];if(!p)return;h+='<div class="ll-bi" data-id="'+esc(id)+'">'+phraseHTML(p,L)+'<div class="ll-bb"><button type="button" class="ls-b ll-bp" aria-label="Play">🔊</button><button type="button" class="ls-b ll-bs" aria-label="Play slowly">🐢</button><button type="button" class="ls-b ll-bx" aria-label="Remove from phrasebook">🗑️</button></div></div>';});
        list.innerHTML=h||'<p class="ll-note">Nothing here.</p>';
        var items=list.querySelectorAll('.ll-bi');for(var k=0;k<items.length;k++)(function(it){var p=d.map[it.getAttribute('data-id')];
          it.querySelector('.ll-bp').onclick=function(){if(!speak(L,p.t,false))X.teach(tt,'oops','No '+L.n+' voice on this device 🔇');};
          it.querySelector('.ll-bs').onclick=function(){if(!speak(L,p.t,true))X.teach(tt,'oops','No '+L.n+' voice on this device 🔇');};
          it.querySelector('.ll-bx').onclick=function(){toggleBook(c,p.id);it.parentNode.removeChild(it);};})(items[k]);});});}

  X.reg('llhome',vHome);X.reg('llang',vLang);X.reg('llrun',vRun);X.reg('llbook',vBook);
  W.hcLang={langs:LANGS,judge:judge,fold:fold,load:getLang,progress:function(){return load();},speakable:canSpeak,kinds:KINDS,__run:function(){return RUN;}};

  /* ---------- 🌍 NEW note (first-run style, once) + entry points ---------- */
  (function(){var NK='hc_ll_new';
    function seen(){try{return !!localStorage.getItem(NK);}catch(e){return true;}}
    function mark(){try{localStorage.setItem(NK,'1');}catch(e){}var p=D.getElementById('hc-lessons-btn');if(p)p.className=p.className.replace(/\s*ll-dot/g,'');}
    function openLang(){mark();var t=D.querySelector('.ll-newtip');if(t&&t.parentNode)t.parentNode.removeChild(t);X.openTo('llhome');}
    W.hcLang.open=openLang;
    var ob=D.getElementById('hc-ll-open');if(ob)ob.onclick=function(){try{var c=D.querySelector('#hc-cust .hd-x');if(c)c.click();}catch(e){}openLang();};
    var lb=D.getElementById('hc-lessons-btn');
    if(lb&&!seen()){lb.className+=' ll-dot';
      setTimeout(function(){if(seen()||D.documentElement.className.indexOf('ls-open')>=0||D.getElementById('hc-splash'))return;
        var t=D.createElement('div');t.className='ll-newtip';t.setAttribute('role','status');
        t.innerHTML='<span>🌍 <b>NEW: learn languages!</b> Spanish, Japanese, Arabic & 9 more, with AI role-play</span><button type="button" class="ll-nt-go">Try it</button><button type="button" class="ll-nt-x" aria-label="Dismiss">✕</button>';
        D.body.appendChild(t);t.querySelector('.ll-nt-go').onclick=openLang;t.querySelector('.ll-nt-x').onclick=function(){mark();if(t.parentNode)t.parentNode.removeChild(t);};
        setTimeout(function(){if(t.parentNode){t.className+=' out';setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t);},400);}},12000);},1800);}
    var _go=X.go;})();
})();
