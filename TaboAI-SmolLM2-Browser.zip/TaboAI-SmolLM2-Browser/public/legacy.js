/* legacy.js — loads first. Old-browser support for small Android players (old Chrome / WebView):
   on-screen error box, polyfills, and a touch/mouse -> Pointer Events shim (Chrome < 55 has no pointer events).
   Visit ?debug=1 for a diagnostics screen. ES5 only. */
(function(){
  var W=window,D=document,de=D.documentElement;
  // ---------- on-screen error catcher ----------
  var errs=W.__domoErrs=[],box=null;
  function short(f){f=String(f||'');var m=f.match(/[^\/?#]+(?:\?[^#]*)?$/);return m?m[0].replace(/\?.*$/,''):f;}
  function showErr(msg){errs.push(msg);if(errs.length>20)errs.shift();
    if(/[?&]debug=1/.test(location.search)&&W.__domoDbgRender)W.__domoDbgRender();
    if(!D.body){setTimeout(function(){showErr2(msg);},300);return;}showErr2(msg);}
  var shown=0;
  function showErr2(msg){if(W.hcBugs&&!/[?&]debug=1/.test(location.search))return; /* hc v2.3: bugcatch.js logs it quietly instead (and shows a friendly 🔧 toast for startup trouble) */
    if(!D.body||shown>=3)return;shown++;
    if(!box){box=D.createElement('div');box.id='domo-err';
      box.setAttribute('style','position:fixed;left:6px;right:6px;top:6px;z-index:2147483647;background:#c8102e;color:#fff;font:600 13px/1.35 sans-serif;padding:8px 34px 8px 10px;border-radius:10px;box-shadow:0 4px 14px rgba(0,0,0,.4);word-wrap:break-word;max-height:40%;overflow:auto;-webkit-transform:translateZ(0)');
      var x=D.createElement('button');x.type='button';x.innerHTML='&#10005;';x.setAttribute('aria-label','Close');
      x.setAttribute('style','position:absolute;right:4px;top:4px;width:28px;height:28px;border:0;border-radius:14px;background:rgba(255,255,255,.25);color:#fff;font:700 15px sans-serif;padding:0');
      x.onclick=function(){box.parentNode&&box.parentNode.removeChild(box);box=null;};box.appendChild(x);D.body.appendChild(box);}
    var p=D.createElement('div');p.textContent='Oops: '+msg;box.appendChild(p);}
  W.onerror=function(m,f,l,c,e){try{if(/^Script error\.?$/.test(String(m))&&!f)return;showErr(String(m).replace(/^Uncaught /,'')+' ('+short(f)+':'+(l||0)+(c?':'+c:'')+')');}catch(x){}};
  W.addEventListener&&W.addEventListener('unhandledrejection',function(e){try{var r=e&&e.reason;if(r&&/abort|NotAllowed|play\(\)|interrupted/i.test(String(r.name||'')+String(r.message||r)))return;showErr('promise: '+String(r&&r.message||r));}catch(x){}});

  // ---------- small polyfills ----------
  function def(o,k,v){if(o&&!o[k])try{Object.defineProperty(o,k,{value:v,writable:true,configurable:true});}catch(e){o[k]=v;}}
  var AP=Array.prototype,SP=String.prototype,EP=W.Element&&Element.prototype;
  if(W.NodeList)def(NodeList.prototype,'forEach',AP.forEach);
  if(W.HTMLCollection)def(HTMLCollection.prototype,'forEach',AP.forEach);
  if(EP){def(EP,'matches',EP.webkitMatchesSelector||EP.msMatchesSelector||function(s){var m=(this.ownerDocument||D).querySelectorAll(s),i=0;while(m[i]&&m[i]!==this)i++;return !!m[i];});
    def(EP,'closest',function(s){var e=this;while(e&&e.nodeType===1){if(e.matches(s))return e;e=e.parentNode;}return null;});
    def(EP,'remove',function(){if(this.parentNode)this.parentNode.removeChild(this);});
    def(EP,'append',function(){for(var i=0;i<arguments.length;i++){var n=arguments[i];this.appendChild(typeof n==='object'?n:D.createTextNode(n));}});
    def(EP,'prepend',function(){for(var i=arguments.length-1;i>=0;i--){var n=arguments[i];this.insertBefore(typeof n==='object'?n:D.createTextNode(n),this.firstChild);}});}
  if(W.CharacterData)def(CharacterData.prototype,'remove',function(){if(this.parentNode)this.parentNode.removeChild(this);});
  def(Array,'from',function(a,f,t){var o=[],n=a&&a.length>>>0,i;if(n===undefined||isNaN(n)){if(a&&typeof a.forEach==='function'){a.forEach(function(v){o.push(v);});n=o.length;}else n=0;}else for(i=0;i<n;i++)o.push(a[i]);if(f)for(i=0;i<o.length;i++)o[i]=f.call(t,o[i],i);return o;});
  def(Array,'of',function(){return AP.slice.call(arguments);});
  def(AP,'fill',function(v,s,e){var n=this.length>>>0;s=s|0;e=e===undefined?n:e|0;if(s<0)s=Math.max(n+s,0);if(e<0)e=n+e;for(var i=s;i<Math.min(e,n);i++)this[i]=v;return this;});
  def(AP,'find',function(f,t){for(var i=0;i<this.length;i++)if(f.call(t,this[i],i,this))return this[i];});
  def(AP,'findIndex',function(f,t){for(var i=0;i<this.length;i++)if(f.call(t,this[i],i,this))return i;return -1;});
  def(AP,'includes',function(v,s){for(var i=s|0;i<this.length;i++)if(this[i]===v||(v!==v&&this[i]!==this[i]))return true;return false;});
  def(Object,'assign',function(t){t=Object(t);for(var i=1;i<arguments.length;i++){var s=arguments[i];if(s!=null)for(var k in s)if(Object.prototype.hasOwnProperty.call(s,k))t[k]=s[k];}return t;});
  def(Object,'values',function(o){return Object.keys(o).map(function(k){return o[k];});});
  def(Object,'entries',function(o){return Object.keys(o).map(function(k){return [k,o[k]];});});
  def(Math,'hypot',function(){var s=0;for(var i=0;i<arguments.length;i++)s+=arguments[i]*arguments[i];return Math.sqrt(s);});
  def(Math,'sign',function(x){x=+x;return x>0?1:x<0?-1:x;});
  def(Math,'trunc',function(x){return x<0?Math.ceil(x):Math.floor(x);});
  def(Math,'log10',function(x){return Math.log(x)/Math.LN10;});
  def(Number,'isFinite',function(x){return typeof x==='number'&&isFinite(x);});
  def(Number,'isNaN',function(x){return x!==x;});
  def(Number,'isInteger',function(x){return typeof x==='number'&&isFinite(x)&&Math.floor(x)===x;});
  def(SP,'includes',function(s,i){return this.indexOf(s,i)!==-1;});
  def(SP,'startsWith',function(s,i){i=i|0;return this.substr(i,String(s).length)===String(s);});
  def(SP,'endsWith',function(s,e){var t=String(this);e=e===undefined?t.length:e;s=String(s);return t.substring(e-s.length,e)===s;});
  def(SP,'repeat',function(n){var o='',s=String(this);n=n|0;while(n-->0)o+=s;return o;});
  def(SP,'padStart',function(n,p){var s=String(this);p=p===undefined?' ':String(p);while(s.length<n)s=p+s;return s.length>n&&p.length>1?s.slice(s.length-n):s;});
  def(SP,'padEnd',function(n,p){var s=String(this);p=p===undefined?' ':String(p);while(s.length<n)s+=p;return s.slice(0,Math.max(n,String(this).length));});
  if(!Date.now)Date.now=function(){return new Date().getTime();};
  if(!W.performance)W.performance={};
  if(!W.performance.now){var t0=Date.now();W.performance.now=function(){return Date.now()-t0;};}
  if(!W.requestAnimationFrame){W.requestAnimationFrame=W.webkitRequestAnimationFrame||function(cb){return setTimeout(function(){cb(performance.now());},16);};
    W.cancelAnimationFrame=W.webkitCancelAnimationFrame||W.webkitCancelRequestAnimationFrame||clearTimeout;}
  if(!W.cancelAnimationFrame)W.cancelAnimationFrame=W.webkitCancelAnimationFrame||clearTimeout;
  if(!W.AudioContext&&W.webkitAudioContext)W.AudioContext=W.webkitAudioContext;
  if(W.CanvasRenderingContext2D){var CP=CanvasRenderingContext2D.prototype;
    def(CP,'ellipse',function(x,y,rx,ry,rot,a0,a1,ccw){this.save();this.translate(x,y);this.rotate(rot||0);this.scale(rx||1e-6,ry||1e-6);this.arc(0,0,1,a0,a1,ccw);this.restore();});
    def(CP,'setLineDash',function(){});
    def(CP,'roundRect',function(x,y,w,h,r){r=typeof r==='number'?r:(r&&r[0])||0;r=Math.min(r,Math.abs(w)/2,Math.abs(h)/2);this.moveTo(x+r,y);this.arcTo(x+w,y,x+w,y+h,r);this.arcTo(x+w,y+h,x,y+h,r);this.arcTo(x,y+h,x,y,r);this.arcTo(x,y,x+w,y,r);this.closePath();});}
  // Promise (tiny, enough for then/catch/resolve/reject/all/race)
  if(typeof W.Promise!=='function'){(function(){
    function P(fn){var s=0,v,q=[],self=this;function fin(n,x){if(s)return;s=n;v=x;setTimeout(function(){q.forEach(run);q=null;},0);}
      function res(x){if(x===self)return fin(2,new TypeError('cycle'));if(x&&(typeof x==='object'||typeof x==='function')){var th;try{th=x.then;}catch(e){return fin(2,e);}if(typeof th==='function'){var c=0;try{th.call(x,function(y){if(!c++)res(y);},function(y){if(!c++)fin(2,y);});}catch(e){if(!c++)fin(2,e);}return;}}fin(1,x);}
      function run(h){var cb=s===1?h.f:h.r;if(typeof cb!=='function'){(s===1?h.res:h.rej)(v);return;}var o;try{o=cb(v);}catch(e){h.rej(e);return;}h.res(o);}
      this.then=function(f,r){return new P(function(res2,rej2){var h={f:f,r:r,res:res2,rej:rej2};if(q)q.push(h);else setTimeout(function(){run(h);},0);});};
      try{fn(res,function(x){fin(2,x);});}catch(e){fin(2,e);}}
    P.prototype['catch']=function(r){return this.then(null,r);};
    P.resolve=function(x){return x instanceof P?x:new P(function(r){r(x);});};
    P.reject=function(x){return new P(function(a,r){r(x);});};
    P.all=function(a){return new P(function(res,rej){var o=[],n=a.length;if(!n)return res(o);a.forEach(function(p,i){P.resolve(p).then(function(v){o[i]=v;if(!--n)res(o);},rej);});});};
    P.race=function(a){return new P(function(res,rej){a.forEach(function(p){P.resolve(p).then(res,rej);});});};
    W.Promise=P;})();}
  // fetch over XHR (Chrome < 42)
  if(!W.fetch){W.fetch=function(url,o){o=o||{};return new Promise(function(res,rej){var x=new XMLHttpRequest();x.open(o.method||'GET',String(url),true);
      var h=o.headers||{};if(typeof h.forEach==='function'&&!(h instanceof Array))h.forEach(function(v,k){x.setRequestHeader(k,v);});else for(var k in h)if(h.hasOwnProperty(k))x.setRequestHeader(k,h[k]);
      if(o.credentials==='include')x.withCredentials=true;
      x.onload=function(){var t=x.responseText;res({ok:x.status>=200&&x.status<300,status:x.status,statusText:x.statusText,url:String(url),
        headers:{get:function(n){return x.getResponseHeader(n);}},text:function(){return Promise.resolve(t);},json:function(){return new Promise(function(a,b){try{a(JSON.parse(t));}catch(e){b(e);}});},clone:function(){return this;}});};
      x.onerror=function(){rej(new TypeError('Network request failed'));};x.ontimeout=x.onerror;x.send(o.body==null?null:o.body);});};}
  // addEventListener options objects ({passive:false}) on engines that only know a boolean capture flag
  var passiveOK=false;try{var po=Object.defineProperty({},'passive',{get:function(){passiveOK=true;return false;}});W.addEventListener('x-test',null,po);W.removeEventListener('x-test',null,po);}catch(e){}
  if(!passiveOK){[W.EventTarget&&EventTarget.prototype,W.Node&&Node.prototype,W.Window&&Window.prototype,W.XMLHttpRequest&&XMLHttpRequest.prototype,W.Screen&&Screen.prototype].forEach(function(p){
      if(!p||!p.hasOwnProperty('addEventListener'))return;var a=p.addEventListener,r=p.removeEventListener;
      p.addEventListener=function(t,f,o){return a.call(this,t,f,typeof o==='object'&&o!==null?!!o.capture:o);};
      p.removeEventListener=function(t,f,o){return r.call(this,t,f,typeof o==='object'&&o!==null?!!o.capture:o);};});}
  // KeyboardEvent.key from keyCode (Chrome < 51) — for players with hardware buttons / d-pads
  if(W.KeyboardEvent&&!('key' in KeyboardEvent.prototype)){var KM={8:'Backspace',9:'Tab',13:'Enter',27:'Escape',32:' ',37:'ArrowLeft',38:'ArrowUp',39:'ArrowRight',40:'ArrowDown',46:'Delete',16:'Shift',17:'Control',18:'Alt'};
    try{Object.defineProperty(KeyboardEvent.prototype,'key',{configurable:true,get:function(){var c=this.keyCode||this.which;if(KM[c])return KM[c];
      if(c>=65&&c<=90){var s=String.fromCharCode(c);return this.shiftKey?s:s.toLowerCase();}if(c>=48&&c<=57)return String.fromCharCode(c);if(c>=96&&c<=105)return String(c-96);return 'Unidentified';}});}catch(e){}}

  // ---------- Pointer Events shim (touch + mouse -> pointerdown/move/up/cancel) ----------
  if(!W.PointerEvent){
    W.__domoPointerShim=true;de.className+=' no-pe';
    var caps={},lastTouch=0,mouseDown=0,addL=W.addEventListener;
    def(EP,'setPointerCapture',function(id){caps[id]=this;});
    def(EP,'releasePointerCapture',function(id){if(caps[id]===this)delete caps[id];});
    def(EP,'hasPointerCapture',function(id){return caps[id]===this;});
    var noBubble={pointerenter:1,pointerleave:1},noCancel={pointercancel:1,pointerenter:1,pointerleave:1,pointerout:1};
    function fire(type,target,src,id,ptype,button,buttons,primary,te){
      if(!target)return false;if(target.nodeType===3)target=target.parentNode;
      var ev=D.createEvent('Event');ev.initEvent(type,!noBubble[type],!noCancel[type]);
      ev.pointerId=id;ev.pointerType=ptype;ev.isPrimary=primary;ev.button=button;ev.buttons=buttons;
      ev.clientX=src.clientX;ev.clientY=src.clientY;ev.pageX=src.pageX;ev.pageY=src.pageY;ev.screenX=src.screenX;ev.screenY=src.screenY;
      ev.width=src.radiusX?src.radiusX*2:1;ev.height=src.radiusY?src.radiusY*2:1;ev.pressure=buttons?.5:0;
      ev.shiftKey=!!(te&&te.shiftKey);ev.ctrlKey=!!(te&&te.ctrlKey);ev.altKey=!!(te&&te.altKey);ev.metaKey=!!(te&&te.metaKey);
      ev.getCoalescedEvents=function(){return [ev];};
      target.dispatchEvent(ev);return ev.defaultPrevented;}
    var opt=passiveOK?{capture:true,passive:false}:true;
    function onTouch(e){lastTouch=Date.now();var map={touchstart:'pointerdown',touchmove:'pointermove',touchend:'pointerup',touchcancel:'pointercancel'},type=map[e.type],ch=e.changedTouches,prevent=false;
      for(var i=0;i<ch.length;i++){var t=ch[i],id=t.identifier+2,primary=e.touches.length<=1&&i===0;
        var tgt=caps[id]||(e.type==='touchstart'?t.target:t.target);
        if(type==='pointerdown')fire('pointerover',tgt,t,id,'touch',0,1,primary,e);
        var p=fire(type,tgt,t,id,'touch',type==='pointermove'?-1:0,(type==='pointerup'||type==='pointercancel')?0:1,primary,e);
        if(type==='pointermove'&&p)prevent=true;
        if(type==='pointerup'||type==='pointercancel'){fire('pointerout',tgt,t,id,'touch',0,0,primary,e);fire('pointerleave',tgt,t,id,'touch',0,0,primary,e);delete caps[id];}}
      if(prevent&&e.cancelable!==false)e.preventDefault();}
    ['touchstart','touchmove','touchend','touchcancel'].forEach(function(n){D.addEventListener(n,onTouch,opt);});
    function onMouse(e){if(Date.now()-lastTouch<1000)return;var type={mousedown:'pointerdown',mousemove:'pointermove',mouseup:'pointerup'}[e.type];
      if(type==='pointerdown')mouseDown|=(1<<e.button);if(type==='pointerup')mouseDown&=~(1<<e.button);
      var tgt=caps[1]||e.target,b=mouseDown?(mouseDown&1?1:0)|(mouseDown&4?2:0)|(mouseDown&2?4:0):0;
      var p=fire(type,tgt,e,1,'mouse',type==='pointermove'?-1:e.button,b,true,e);
      if(type==='pointerup')delete caps[1];
      if(p&&type!=='pointerdown')e.preventDefault();}
    ['mousedown','mousemove','mouseup'].forEach(function(n){D.addEventListener(n,onMouse,true);});
  }
  // CSS grid support flag (Chrome < 57 has none) + a JS landscape flag (html.land / html.port) kept fresh on resize
  (function(){var s=D.createElement('div').style;try{s.display='grid';}catch(e){}if(s.display!=='grid')de.className+=' nogrid';
    function o(){var l=W.innerWidth>W.innerHeight,c=' '+de.className+' ';c=c.replace(/ (land|port) /g,' ');de.className=(c+(l?'land':'port')).replace(/^\s+|\s+$/g,'').replace(/\s+/g,' ');}
    o();W.addEventListener('resize',o);W.addEventListener('orientationchange',function(){o();setTimeout(o,300);});})();
  // touch-screen hint for engines without the (pointer: coarse) media query
  W.__domoTouch=('ontouchstart' in W)||((navigator.maxTouchPoints||navigator.msMaxTouchPoints||0)>0)||!!(W.matchMedia&&matchMedia('(pointer: coarse)').matches);

  // ---------- ?debug=1 diagnostics ----------
  if(/[?&]debug=1/.test(location.search)){
    function css(p,v){var s=D.createElement('div').style;if(v===undefined)return p in s||('webkit'+p.charAt(0).toUpperCase()+p.slice(1)) in s;try{if(W.CSS&&CSS.supports)return CSS.supports(p,v);}catch(e){}s.cssText=p+':'+v;return !!s.length;}
    function flexGap(){var d=D.createElement('div');d.style.cssText='display:flex;flex-direction:column;row-gap:1px;position:absolute;visibility:hidden';d.appendChild(D.createElement('div'));d.appendChild(D.createElement('div'));D.body.appendChild(d);var r=d.scrollHeight===1;D.body.removeChild(d);return r;}
    W.__domoDbgRender=function(){var b=D.getElementById('domo-dbg');if(!b||!D.body)return;var y='\u2705',n='\u274C',so=W.screen&&screen.orientation;
      var rows=[['Browser',navigator.userAgent],['Chrome version',(navigator.userAgent.match(/Chrome\/([\d.]+)/)||[0,'?'])[1]],
        ['Screen',screen.width+' x '+screen.height],['Window (inner)',W.innerWidth+' x '+W.innerHeight],['Page (client)',de.clientWidth+' x '+de.clientHeight],
        ['Pixel ratio',W.devicePixelRatio],['Orientation',(so&&so.type)||W.orientation||'?'],
        ['PointerEvent',W.__domoPointerShim?n+' (using touch shim)':y],['Touch events',('ontouchstart' in W)?y:n],['Touch points',navigator.maxTouchPoints===undefined?'?':navigator.maxTouchPoints],
        ['Fullscreen API',(de.requestFullscreen?y+' std':de.webkitRequestFullscreen?y+' webkit':n)],['orientation.lock',(so&&so.lock)?y:n],
        ['CSS grid',css('display','grid')?y:n],['flex gap',flexGap()?y:n],['inset',css('inset','0')?y:n],['dvh units',css('height','100dvh')?y:n],
        ['aspect-ratio',css('aspect-ratio','1')?y:n],['NodeList.forEach',W.NodeList&&NodeList.prototype.forEach===AP.forEach&&!('__x' in {})?'ok':'?'],
        ['fetch',(''+W.fetch).indexOf('[native code]')>0?y:'polyfill'],['Promise',(''+W.Promise).indexOf('[native code]')>0?y:'polyfill'],
        ['AudioContext',(W.AudioContext||W.webkitAudioContext)?y:n],['localStorage',(function(){try{localStorage.setItem('_t','1');localStorage.removeItem('_t');return y;}catch(e){return n;}})()],
        ['Errors',errs.length?errs.join(' | '):'none']];
      var h='<button type="button" id="domo-dbg-x" style="float:right;font:700 20px sans-serif;padding:6px 14px;border-radius:10px;border:0;background:#fff;color:#000">Close</button><div style="font:900 22px sans-serif;margin:4px 0 10px">Domotime debug</div>';
      for(var i=0;i<rows.length;i++)h+='<div style="padding:5px 0;border-top:1px solid rgba(255,255,255,.25)"><b style="color:#7fd3ff">'+rows[i][0]+':</b> '+String(rows[i][1]).replace(/</g,'&lt;')+'</div>';
      b.innerHTML=h;D.getElementById('domo-dbg-x').onclick=function(){b.parentNode.removeChild(b);};};
    function showDbg(){if(D.getElementById('domo-dbg'))return;var b=D.createElement('div');b.id='domo-dbg';
      b.setAttribute('style','position:fixed;left:0;top:0;right:0;bottom:0;width:100%;height:100%;z-index:2147483646;background:#0b1330;color:#fff;font:600 17px/1.35 sans-serif;padding:12px;box-sizing:border-box;overflow:auto;-webkit-overflow-scrolling:touch;word-wrap:break-word');
      D.body.appendChild(b);W.__domoDbgRender();W.addEventListener('resize',W.__domoDbgRender);}
    if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',showDbg);else showDbg();
  }
})();
