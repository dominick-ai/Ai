/* devgate.js (hc v1.9.2: admin mode also loads hcexamples.js (📷 example pictures in Code mode); hc v1.9: the Dev Lab is a developer toolbox now (key tester, model test, web research); the hammer menu is Open Dev Lab / Turn off admin mode / Close;
   v1.8: the right PIN turns on ADMIN MODE on this device (a 30-day server-signed pass in localStorage, re-checked by the server every visit);
   v1.7.3: a small 🔨 button at the very bottom opens the same PIN prompt) hidden 🛠️ Dev Lab door: long-press the 💜 logo ~2 s, tap 🔨, or open ?dev.
   The PIN is checked on the server only. Nothing else loads for normal visitors: devlab.js / devlab.css / devsafe.js / hccalc.js load only after the server accepts the PIN or the pass. */
(function(W,D){
  'use strict';
  var K='hc_dev_tok',KA='hc_admin',busy=0,loaded=0,adm=0;
  function live(t){return typeof t==='string'&&+t.split('.')[0]>new Date().getTime();}
  function tok(){try{var t=W.sessionStorage.getItem(K)||'';if(live(t))return t;t=W.localStorage.getItem(KA)||'';return live(t)?t:'';}catch(e){return '';}}
  function post(b){return W.fetch('/api/dev/check',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)}).then(function(r){return r.json().catch(function(){return {ok:false,net:1};});});}
  function el(t,c,h){var e=D.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;}
  function css(){if(D.getElementById('hcdg-css'))return;var s=el('style');s.id='hcdg-css';
    s.textContent='.hc-hammer{display:inline-block;vertical-align:middle;width:26px;height:26px;margin:0 0 0 4px;padding:0;border:1px solid #ffe5d4;border-radius:50%;background:#ffffff;font-size:13px;line-height:24px;text-align:center;cursor:pointer;opacity:.8;-webkit-tap-highlight-color:transparent;font-family:inherit}'+
    '.hc-hammer:hover,.hc-hammer:focus-visible{opacity:1;border-color:#ee7d45}.hc-hammer:active{-webkit-transform:scale(.92);transform:scale(.92)}'+
    'html.hw .hc-hammer{background:#23201d;border-color:#312c28}html.hw .hc-hammer:hover,html.hw .hc-hammer:focus-visible{border-color:#dd5e22}'+
    '.hcdg{position:fixed;top:0;left:0;right:0;bottom:0;z-index:20000;background:rgba(20,18,16,.55);display:flex;align-items:center;justify-content:center;padding:16px}'+
    '.hcdg-b{background:#ffffff;color:#201d1a;border-radius:18px;padding:20px 18px 16px;width:100%;max-width:330px;box-shadow:0 12px 40px rgba(0,0,0,.35);text-align:center;font-family:inherit}'+
    '.hcdg-b h2{margin:0 0 4px;font-size:19px}.hcdg-b p{margin:0 0 12px;font-size:13px;color:#933914}'+
    '.hcdg-b input{width:100%;font-size:22px;letter-spacing:6px;text-align:center;padding:10px;border:2px solid #ffe5d4;border-radius:12px;box-sizing:border-box;margin-bottom:8px}'+
    '.hcdg-e{min-height:18px;font-size:13px;color:#b91c1c;font-weight:700;margin-bottom:6px}'+
    '.hcdg-r button{font:inherit;font-weight:800;font-size:15px;border-radius:12px;padding:10px 14px;margin:0 4px;border:1px solid #ffe5d4;background:#ffffff;color:#5d544c}'+
    '.hcdg-r .go{background:#ee7d45;border-color:#ee7d45;color:#ffffff}'+
    'html.hw .hcdg-b{background:#171513;color:#f0ebe7}html.hw .hcdg-b p{color:#fcc8a6}html.hw .hcdg-b input{background:#0f0d0c;color:#f0ebe7;border-color:#312c28}html.hw .hcdg-r button{background:#23201d;color:#f0ebe7;border-color:#312c28}html.hw .hcdg-r .go{background:#dd5e22;border-color:#dd5e22}'+
    '.hcdg-m button{display:block;width:100%;font:inherit;font-weight:800;font-size:15px;border-radius:12px;padding:11px 14px;margin:0 0 8px;border:1px solid #ffe5d4;background:#ffffff;color:#5d544c;cursor:pointer}.hcdg-m .go{background:#ee7d45;border-color:#ee7d45;color:#ffffff}.hcdg-m .warn{color:#b91c1c}'+
    'html.hw .hcdg-m button{background:#23201d;color:#f0ebe7;border-color:#312c28}html.hw .hcdg-m .go{background:#dd5e22;border-color:#dd5e22;color:#ffffff}html.hw .hcdg-m .warn{color:#fca5a5}'+
    'html.hc-admin .hc-hammer{opacity:1;border-color:#ee7d45;background:#f9f7f5}html.hw.hc-admin .hc-hammer{border-color:#dd5e22;background:#312c28}';
    D.getElementsByTagName('head')[0].appendChild(s);}
  function safeJs(ok,bad){if(W.hcDevSafe){ok();return;}var a=el('script');a.src='devsafe.js?v=2.7';a.onload=ok;a.onerror=bad||function(){};D.body.appendChild(a);}
  function lab(t){
    if(W.hcDevLab){W.hcDevLab.open(t);return;}
    if(loaded)return;loaded=1;
    var l=el('link');l.rel='stylesheet';l.href='devlab.css?v=2.8';D.getElementsByTagName('head')[0].appendChild(l);
    safeJs(function(){if(!W.hcCalc){var c=el('script');c.src='hccalc.js?v=1.9.1';D.body.appendChild(c);}var s=el('script');s.src='devlab.js?v=2.8';s.onload=function(){if(W.hcDevLab)W.hcDevLab.open(t);};s.onerror=function(){loaded=0;};D.body.appendChild(s);},function(){loaded=0;});
  }
  function prompt(from){
    if(D.getElementById('hcdg'))return;css();
    var o=el('div','hcdg');o.id='hcdg';o.setAttribute('role','dialog');o.setAttribute('aria-modal','true');
    o.innerHTML='<form class="hcdg-b" autocomplete="off"><h2>🛠️ Dev Lab</h2><p>Developer only. Type the admin PIN.</p>'+
      '<input type="password" inputmode="numeric" pattern="[0-9]*" maxlength="8" aria-label="Admin PIN" id="hcdg-pin">'+
      '<div class="hcdg-e" id="hcdg-e"></div><div class="hcdg-r"><button type="button" class="no">Cancel</button><button type="submit" class="go">Unlock</button></div></form>';
    D.body.appendChild(o);
    var f=o.getElementsByTagName('form')[0],i=D.getElementById('hcdg-pin'),er=D.getElementById('hcdg-e');
    function close(){if(o.parentNode)o.parentNode.removeChild(o);}
    o.querySelector('.no').onclick=close;
    f.onsubmit=function(ev){ev.preventDefault();if(busy)return;var p=(i.value||'').replace(/\D/g,'');if(!p){er.textContent='Type the PIN.';return;}
      busy=1;er.textContent='Checking…';
      post({pin:p,remember:true}).then(function(j){busy=0;
        if(j&&j.ok&&j.token){try{W.sessionStorage.setItem(K,j.token);W.localStorage.setItem(KA,j.token);}catch(e){}close();adminOn(true);
          say('🔨 Admin mode on (30 days on this device)');lab(j.token);}
        else{er.textContent=(j&&j.message)||'Wrong PIN.';i.value='';i.focus();}
      },function(){busy=0;er.textContent='Could not reach the server.';});};
    setTimeout(function(){try{i.focus();}catch(e){}},50);
  }
  function open(from){
    var t=tok();
    if(!t){prompt(from);return;}
    post({token:t}).then(function(j){if(j&&j.ok){adminOn();lab(t);}else{try{W.sessionStorage.removeItem(K);W.localStorage.removeItem(KA);}catch(e){}prompt(from);}},function(){prompt(from);});
  }
  function say(m){try{if(W.hcApp&&W.hcApp.toast)W.hcApp.toast(m);}catch(e){}}
  function adminOn(){
    if(adm)return;adm=1;W.hcAdminOn=true;
    if(D.documentElement.className.indexOf('hc-admin')<0)D.documentElement.className+=' hc-admin';
    var hb=D.querySelectorAll('.hc-hammer');for(var i=0;i<hb.length;i++){hb[i].title='Admin mode on';hb[i].setAttribute('aria-label','Admin mode on: menu');}
    if(!W.hcCodeLook&&!D.getElementById('hcx-js')){var xs=el('script');xs.id='hcx-js';xs.src='hcexamples.js?v=1.9.2';D.body.appendChild(xs);} // v1.9.2 📷 example pictures in Code mode (admin only)
  }
  function off(){
    try{W.sessionStorage.removeItem(K);W.localStorage.removeItem(KA);W.localStorage.removeItem('hc_dev_back');}catch(e){}
    var u=W.location.pathname+(W.location.search||'').replace(/([?&])dev(=[^&]*)?(&|$)/,'$1').replace(/[?&]$/,'')+(W.location.hash||'');
    try{W.location.replace(u);}catch(e){W.location.reload();}
  }
  function menu(){
    if(D.getElementById('hcdg'))return;css();
    var o=el('div','hcdg');o.id='hcdg';o.setAttribute('role','dialog');o.setAttribute('aria-modal','true');
    o.innerHTML='<div class="hcdg-b"><h2>🔨 Admin mode on</h2><p>Only on this device. The Dev Lab has the key tester, model test and web research.</p>'+
      '<div class="hcdg-m"><button type="button" class="go" data-a="lab">🛠️ Open Dev Lab</button><button type="button" class="warn" data-a="off">Turn off admin mode</button><button type="button" data-a="x">Close</button></div></div>';
    D.body.appendChild(o);
    function close(){if(o.parentNode)o.parentNode.removeChild(o);}
    o.addEventListener('click',function(e){var b=e.target;while(b&&b!==o&&!b.getAttribute('data-a'))b=b.parentNode;
      if(!b||b===o){if(e.target===o)close();return;}var a=b.getAttribute('data-a');close();
      if(a==='lab')open();else if(a==='off')off();});
    setTimeout(function(){try{o.querySelector('.go').focus();}catch(e){}},50);
  }
  function boot(){var t='';try{t=W.localStorage.getItem(KA)||'';W.localStorage.removeItem('hc_dev_back');}catch(e){}
    if(!t)return;if(!live(t)){try{W.localStorage.removeItem(KA);}catch(e){}return;}
    // the server must agree first: nothing admin loads until it says this pass is real
    post({token:t}).then(function(j){if(j&&j.ok)adminOn();else if(j&&j.ok===false&&!j.net&&!j.error){try{W.localStorage.removeItem(KA);W.sessionStorage.removeItem(K);}catch(e){}}},function(){});}
  W.hcDevGate={open:open,admin:function(){return !!adm;},off:off,lock:off,pass:function(){return tok();}};
  function hook(){
    css();
    var hb=D.querySelectorAll('.hc-hammer');
    for(var hi=0;hi<hb.length;hi++)hb[hi].addEventListener('click',function(e){e.preventDefault();if(adm)menu();else open('hammer');});
    var img=D.querySelector('.brand img');
    if(img){
      img.style.webkitTouchCallout='none';img.style.webkitUserSelect='none';img.style.userSelect='none';img.setAttribute('draggable','false');
      var tm=null,sx=0,sy=0;
      function start(e){var p=e.touches?e.touches[0]:e;sx=p.clientX;sy=p.clientY;clearTimeout(tm);tm=setTimeout(function(){tm=null;open();},1900);}
      function move(e){if(!tm)return;var p=e.touches?e.touches[0]:e;if(Math.abs(p.clientX-sx)>12||Math.abs(p.clientY-sy)>12){clearTimeout(tm);tm=null;}}
      function stop(){clearTimeout(tm);tm=null;}
      img.addEventListener('touchstart',start,{passive:true});img.addEventListener('touchmove',move,{passive:true});
      img.addEventListener('touchend',stop);img.addEventListener('touchcancel',stop);
      img.addEventListener('mousedown',function(e){if(e.button===0)start(e);});img.addEventListener('mousemove',move);
      img.addEventListener('mouseup',stop);img.addEventListener('mouseleave',stop);
      img.addEventListener('contextmenu',function(e){e.preventDefault();});
    }
    if(/(^|[?&])dev(=|&|$)/.test(W.location.search||''))setTimeout(open,600);
    boot();
  }
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',hook);else hook();
})(window,document);
