/* Tabo 📚 Lessons: real Python (Pyodide) in a worker, so a stuck loop can be stopped (v1.5.3) */
var PYV='0.26.4',BASE='https://cdn.jsdelivr.net/pyodide/v'+PYV+'/full/';
var HARNESS=[
'import sys, io, traceback',
'class _NoMoreInput(Exception): pass',
'def __hc_run(code, inputs, tests):',
'    buf = io.StringIO()',
'    ins = list(inputs)',
'    def _inp(prompt=""):',
'        buf.write(str(prompt))',
'        if not ins:',
'            raise _NoMoreInput("Your program asked for input() more times than the test typed")',
'        return ins.pop(0)',
'    g = {"__name__": "__main__", "input": _inp}',
'    old = sys.stdout, sys.stderr',
'    sys.stdout = buf; sys.stderr = buf',
'    err = ""; fail = ""',
'    try:',
'        exec(compile(code, "my_code.py", "exec"), g)',
'    except SystemExit:',
'        pass',
'    except _NoMoreInput as e:',
'        err = str(e)',
'    except BaseException as e:',
'        ln = None',
'        for fr in traceback.extract_tb(e.__traceback__):',
'            if fr.filename == "my_code.py": ln = fr.lineno',
'        if isinstance(e, SyntaxError): ln = e.lineno',
'        err = type(e).__name__ + ": " + str(e)',
'        if ln: err = "Line " + str(ln) + ": " + err',
'    finally:',
'        sys.stdout, sys.stderr = old',
'    out = buf.getvalue()',
'    if not err and tests:',
'        g["__out__"] = out',
'        b2 = io.StringIO(); sys.stdout = b2',
'        try:',
'            exec(compile(tests, "checker.py", "exec"), g)',
'        except AssertionError as e:',
'            fail = str(e) or "A test did not pass"',
'        except BaseException as e:',
'            fail = type(e).__name__ + ": " + str(e)',
'        finally:',
'            sys.stdout = old[0]',
'    return [out[:20000], err, fail]'
].join('\n');
var py=null,ready=null;
function boot(){
  try{importScripts(BASE+'pyodide.js');}catch(e){postMessage({loadfail:'load'});return;}
  ready=loadPyodide({indexURL:BASE}).then(function(p){py=p;py.runPython(HARNESS);postMessage({ready:1});})['catch'](function(e){postMessage({loadfail:String(e&&e.message||e).slice(0,200)});});
}
boot();
onmessage=function(e){var d=e.data||{};if(!ready)return;ready.then(function(){if(!py)return;var r,a;
  try{var f=py.globals.get('__hc_run');r=f(String(d.code||''),py.toPy(d.inputs||[]),String(d.tests||''));a=r.toJs();r.destroy();f.destroy();
    postMessage({id:d.id,out:String(a[0]||''),err:String(a[1]||''),fail:String(a[2]||'')});}
  catch(x){postMessage({id:d.id,out:'',err:String(x&&x.message||x).split('\n').slice(-2).join(' ').slice(0,300),fail:''});}});};
