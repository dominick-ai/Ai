/* pubkey.js (Tabo AI v2.8) 🎟️ Get a free API key with your Domotime account + the public 🧪 key tester. ES5.
   Renders into every [data-hc-pubkey] box (api.html + ⚙️ Customize). The PIN lives only in this page's memory while you use the card;
   it is sent to Tabo's server over HTTPS, which checks it with Domotime. Nothing is saved on the device except nothing: no key, no PIN. */
(function(){var W=window,D=document;if(W.hcPubKeyLoaded)return;W.hcPubKeyLoaded=1;
  var ORIGIN=(W.location&&/^https?:/.test(W.location.origin||'')?W.location.origin:'https://taboai.sites.tab.bot');
  var DOMO='https://domotime.sites.tab.bot/?lock=1',uid=0;
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function post(path,body){return W.fetch(ORIGIN+path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}).then(function(r){
      return r.json().catch(function(){return{ok:false,message:'Server hiccup ('+r.status+'). Try again.'};}).then(function(j){j=j||{};j._s=r.status;return j;});},
    function(){return{ok:false,_s:0,message:'Couldn\u2019t reach Tabo. Check the internet.'};});}
  function day(t){if(!t)return'';try{return new Date(t).toLocaleDateString(undefined,{month:'short',day:'numeric'});}catch(e){return'';}}
  function copy(txt,btn){function ok(){var o=btn.textContent;btn.textContent='\u2705 Copied!';setTimeout(function(){btn.textContent=o;},1600);}
    function old(){var t=D.createElement('textarea');t.value=txt;t.setAttribute('readonly','');t.style.position='fixed';t.style.top='-1000px';D.body.appendChild(t);t.select();try{t.setSelectionRange(0,txt.length);}catch(e){}var r=false;try{r=D.execCommand('copy');}catch(e){}D.body.removeChild(t);if(r)ok();else btn.textContent='Select + copy it';}
    try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(txt).then(ok,old);return;}}catch(e){}old();}
  function build(box){var n=++uid,p='hpk'+n+'-',S={name:'',pin:'',st:null},arm={};
    box.className+=' hpk';box.innerHTML=''+
    '<div class="hpk-hd"><span class="hpk-ic" aria-hidden="true">\uD83C\uDF9F\uFE0F</span><div><h3 class="hpk-h">Get your free key</h3><p class="hpk-sub">Sign in with your <b>Domotime</b> name + PIN. No email, no phone, no real name.</p></div></div>'+
    '<form class="hpk-in" id="'+p+'form" autocomplete="off" novalidate>'+
      '<div class="hpk-f"><label for="'+p+'nm">Domotime name</label><input id="'+p+'nm" maxlength="16" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="your leaderboard name"></div>'+
      '<div class="hpk-f hpk-fp"><label for="'+p+'pin">PIN</label><input id="'+p+'pin" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" placeholder="4\u20136 numbers" data-lpignore="true" data-1p-ignore></div>'+
      '<button type="submit" class="hpk-b hpk-pri" id="'+p+'go">\uD83D\uDD13 Sign in</button>'+
    '</form>'+
    '<a class="hpk-mk" href="'+DOMO+'" target="_blank" rel="noopener">Don\u2019t have one? Make one on Domotime \u2197</a>'+
    '<div class="hpk-me" id="'+p+'me" hidden></div>'+
    '<div class="hpk-new" id="'+p+'new" hidden><div class="hpk-warn">\u26A0\uFE0F This is the only time you\u2019ll see this key. Copy it and keep it secret!</div><code class="hpk-key" id="'+p+'key"></code>'+
      '<div class="hpk-row"><button type="button" class="hpk-b hpk-pri" id="'+p+'cp">\uD83D\uDCCB Copy key</button><button type="button" class="hpk-b" id="'+p+'saved">\u2713 I saved it</button></div></div>'+
    '<p class="hpk-msg" id="'+p+'msg" role="status" aria-live="polite"></p>'+
    '<details class="hpk-tst"><summary>\uD83E\uDDEA Test a key <span class="hpk-pill">no PIN needed</span></summary>'+
      '<div class="hpk-f"><label for="'+p+'tk">Paste a Tabo key</label><input id="'+p+'tk" type="password" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="hc-pub-\u2026" data-lpignore="true" data-1p-ignore></div>'+
      '<label class="hpk-chk"><input type="checkbox" id="'+p+'smp" checked> Get a sample reply (uses 1 request)</label>'+
      '<button type="button" class="hpk-b hpk-pri" id="'+p+'tgo">\uD83E\uDDEA Test it</button><div class="hpk-tout" id="'+p+'tout" aria-live="polite"></div></details>'+
    '<p class="hpk-fine">Free keys: <b>50 requests a day</b> (resets at midnight, Chicago time), 10 a minute, short replies, \uD83D\uDEE1\uFE0F Safety Shield always on. They work on <code>/v1/chat/completions</code>, <code>/api/ask</code> and <code>/api/chat</code>.</p>';
    function $(id){return D.getElementById(p+id);}
    function msg(t,bad){var m=$('msg');m.textContent=t||'';m.className='hpk-msg'+(bad?' bad':'');}
    function me(){var j=S.st,el=$('me');if(!j){el.hidden=true;$('form').hidden=false;return;}
      $('form').hidden=true;el.hidden=false;var pct=Math.round(100*j.used_today/Math.max(1,j.limit));
      el.innerHTML='<div class="hpk-who">\uD83D\uDC4B Signed in as <b>'+esc(j.name)+'</b> <button type="button" class="hpk-lnk" data-a="out">Sign out</button></div>'+
        (j.has_key?'<div class="hpk-kl">Your key: <code>'+esc(j.hint)+'</code>'+(j.key_made?' <span class="hpk-dim">made '+esc(day(j.key_made))+'</span>':'')+'</div>':'<div class="hpk-kl">You don\u2019t have a key yet.</div>')+
        '<div class="hpk-bar" role="img" aria-label="'+j.used_today+' of '+j.limit+' used today"><i style="width:'+Math.min(100,pct)+'%"></i></div><div class="hpk-dim">'+j.used_today+' of '+j.limit+' used today \u00B7 resets '+esc(j.resets||'at midnight')+'</div>'+
        '<div class="hpk-row">'+(j.has_key?'<button type="button" class="hpk-b" data-a="regen">\uD83D\uDD01 Regenerate</button><button type="button" class="hpk-b hpk-warnb" data-a="delete">\uD83D\uDDD1\uFE0F Delete</button>':'<button type="button" class="hpk-b hpk-pri" data-a="create">\uD83C\uDF9F\uFE0F Get my free key</button>')+'</div>';
      var bs=el.querySelectorAll('[data-a]');for(var i=0;i<bs.length;i++)bs[i].onclick=act;}
    function call(action){return post('/api/pubkey',{action:action,name:S.name,pin:S.pin});}
    function signOut(){S.name='';S.pin='';S.st=null;$('pin').value='';$('new').hidden=true;$('key').textContent='';me();msg('');}
    function act(e){var b=e.currentTarget,a=b.getAttribute('data-a');if(a==='out'){signOut();return;}
      if(a==='regen'||a==='delete'){if(!arm[a]){arm[a]=1;var o=b.textContent;b.textContent=a==='regen'?'\uD83D\uDD01 Tap again: old key stops working':'\uD83D\uDDD1\uFE0F Tap again to delete';b.className+=' armed';
          setTimeout(function(){arm[a]=0;if(b.parentNode){b.textContent=o;b.className=b.className.replace(/\s*armed/g,'');}},4000);return;}arm[a]=0;}
      b.disabled=true;msg('\u23F3 Working\u2026');
      call(a).then(function(j){b.disabled=false;if(j.ok===false&&j.error!=='has_key'){msg(j.message||'Hmm, that didn\u2019t work.',true);if(j._s===403||j._s===404||j._s===429){S.st=null;S.pin='';me();}return;}
        S.st=j;me();
        if(j.key){$('key').textContent=j.key;$('new').hidden=false;msg(j.regenerated?'\uD83D\uDD01 New key made. The old one stopped working.':'\uD83C\uDF89 Your free key is ready!');try{$('cp').focus();}catch(x){}}
        else if(j.deleted){$('new').hidden=true;$('key').textContent='';msg('\uD83D\uDDD1\uFE0F Key deleted. It stopped working.');}
        else msg(j.message||'');});}
    $('form').onsubmit=function(e){e.preventDefault();var nm=$('nm').value.replace(/\s+/g,' ').trim(),pin=$('pin').value.replace(/\s/g,'');
      if(nm.length<2){msg('Type your Domotime name first.',true);$('nm').focus();return;}
      if(!/^[0-9]{4,6}$/.test(pin)){msg('Your PIN is 4 to 6 numbers.',true);$('pin').focus();return;}
      var go=$('go');go.disabled=true;msg('\u23F3 Checking with Domotime\u2026');S.name=nm;S.pin=pin;
      call('status').then(function(j){go.disabled=false;if(!j.ok){S.pin='';msg(j.message||'Couldn\u2019t sign in.',true);return;}S.st=j;$('pin').value='';me();msg(j.has_key?'':'Tap \uD83C\uDF9F\uFE0F Get my free key!');});};
    $('cp').onclick=function(){copy($('key').textContent,this);};
    $('saved').onclick=function(){$('new').hidden=true;$('key').textContent='';msg('\uD83D\uDC4D Key hidden. Keep it secret!');};
    $('tgo').onclick=function(){var k=$('tk').value.trim(),o=$('tout'),b=this;if(!k){o.innerHTML='<div class="hpk-res bad">Paste a key first.</div>';return;}
      b.disabled=true;o.innerHTML='<div class="hpk-res">\u23F3 Testing\u2026</div>';
      post('/api/keytest',{key:k,sample:$('smp').checked}).then(function(j){b.disabled=false;
        if(!j.ok||!j.valid){o.innerHTML='<div class="hpk-res bad">'+esc(j.message||'\u274C Not a working key.')+'</div>';return;}
        o.innerHTML='<div class="hpk-res good"><b>\u2705 Valid!</b> '+esc(j.kind_label||'')+'<br>'+j.left_today+' of '+j.limit+' requests left today'+(j.per_minute?' \u00B7 '+j.per_minute+'/min':'')+'<br><span class="hpk-dim">Resets '+esc(j.resets||'')+'</span>'+
          (j.sample?'<div class="hpk-smp">\uD83D\uDCAC '+esc(j.sample)+(j.sample_ai?'<span class="hpk-dim"> \u00B7 '+esc(j.sample_ai)+'</span>':'')+'</div>':'')+(j.sample_error?'<div class="hpk-dim">'+esc(j.sample_error)+'</div>':'')+'</div>';});};
  }
  function init(){var bs=D.querySelectorAll('[data-hc-pubkey]');for(var i=0;i<bs.length;i++){if(!bs[i].getAttribute('data-hpk-on')){bs[i].setAttribute('data-hpk-on','1');build(bs[i]);}}}
  W.hcPubKey={init:init};
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',init);else init();
  /* 🎟️ NEW note on the main app (once), after the languages note */
  if(D.getElementById('hc-cust')){(function(){var NK='hc_pk_new';function seen(){try{return !!localStorage.getItem(NK);}catch(e){return true;}}
    function mark(){try{localStorage.setItem(NK,'1');}catch(e){}}
    if(seen())return;var tries=0;
    function show(){if(seen())return;if(D.querySelector('.ll-newtip')||D.getElementById('hc-splash')||D.documentElement.className.indexOf('ls-open')>=0){if(++tries<40)setTimeout(show,3000);return;}
      var t=D.createElement('div');t.className='ll-newtip hpk-tip';t.setAttribute('role','status');
      t.innerHTML='<span>\uD83C\uDF9F\uFE0F <b>NEW: free API keys</b> with your Domotime account</span><a class="ll-nt-go" href="api.html#getkey">Get one</a><button type="button" class="ll-nt-x" aria-label="Dismiss">\u2715</button>';
      D.body.appendChild(t);t.querySelector('.ll-nt-go').onclick=mark;t.querySelector('.ll-nt-x').onclick=function(){mark();if(t.parentNode)t.parentNode.removeChild(t);};
      setTimeout(function(){if(t.parentNode){mark();t.className+=' out';setTimeout(function(){if(t.parentNode)t.parentNode.removeChild(t);},400);}},12000);}
    setTimeout(show,2600);})();}
})();
