/* tots.js (hc v1.5.2, the user Oct 30: "Tots" = cute characters made of shapes, our OWN design). Maker (shape, eyes, mouth,
   color, cheeks, accessory, name through the kid-safe name filter), gallery of up to 12 saved Tots (localStorage only, nothing
   uploads), and your Tot as a chat buddy by the message box (thinks while the AI answers, bounces when it lands). SVG + CSS
   transforms only. ES5 only. */
(function(){
  'use strict';
  var W=window,D=document;
  function $(id){return D.getElementById(id);}
  var K='hc_tots_v1',MAX=12,NS='http://www.w3.org/2000/svg',uidN=0;
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function rnd(a){return a[Math.floor(Math.random()*a.length)];}
  function id(){return 't'+new Date().getTime().toString(36)+Math.floor(Math.random()*1e4).toString(36);}

  /* ---------- geometry ---------- */
  function rpoly(pts,r){ /* polygon with soft rounded corners */
    var n=pts.length,d='';
    for(var i=0;i<n;i++){
      var p=pts[i],a=pts[(i-1+n)%n],b=pts[(i+1)%n];
      var la=Math.sqrt((a[0]-p[0])*(a[0]-p[0])+(a[1]-p[1])*(a[1]-p[1])),lb=Math.sqrt((b[0]-p[0])*(b[0]-p[0])+(b[1]-p[1])*(b[1]-p[1]));
      var rr=Math.min(r,la/2.2,lb/2.2);
      var s=[p[0]+(a[0]-p[0])*rr/la,p[1]+(a[1]-p[1])*rr/la],e=[p[0]+(b[0]-p[0])*rr/lb,p[1]+(b[1]-p[1])*rr/lb];
      d+=(i?'L':'M')+s[0].toFixed(1)+','+s[1].toFixed(1)+'Q'+p[0].toFixed(1)+','+p[1].toFixed(1)+' '+e[0].toFixed(1)+','+e[1].toFixed(1);
    }
    return d+'Z';
  }
  function ngon(n,cx,cy,R,rot){var p=[];for(var i=0;i<n;i++){var t=(rot||-90)*Math.PI/180+i*2*Math.PI/n;p.push([cx+R*Math.cos(t),cy+R*Math.sin(t)]);}return p;}
  function star(cx,cy,R,r){var p=[];for(var i=0;i<10;i++){var t=-Math.PI/2+i*Math.PI/5,q=i%2?r:R;p.push([cx+q*Math.cos(t),cy+q*Math.sin(t)]);}return p;}
  /* each shape: d (body path), f = face centre + scale, top = where accessories sit */
  var SHAPES={
    triangle:{n:'Triangle',s:1,d:rpoly([[60,10],[110,100],[10,100]],17),f:[60,70,.82],top:[60,22],g:[50,52]},
    bubble:{n:'Bubble',d:rpoly([[14,16],[106,16],[106,86],[14,86]],34)+rpoly([[20,70],[46,82],[16,104]],5),f:[60,52,1],top:[60,17],g:[42,30]},
    square:{n:'Square',d:rpoly([[14,14],[106,14],[106,104],[14,104]],30),f:[60,58,1.05],top:[60,15],g:[40,32]},
    pentagon:{n:'Pentagon',d:rpoly(ngon(5,60,62,52),15),f:[60,64,.95],top:[60,14],g:[44,36]},
    circle:{n:'Circle',d:'M60,12A48,48 0 1 1 59.9,12Z',f:[60,60,1.05],top:[60,13],g:[42,32]},
    star:{n:'Star',s:1,d:rpoly(star(60,62,54,27),6),f:[60,66,.72],top:[60,12],g:[48,46]},
    heart:{n:'Heart',d:'M60,104C52,97 12,74 12,44C12,26 25,15 39,15C49,15 56,21 60,29C64,21 71,15 81,15C95,15 108,26 108,44C108,74 68,97 60,104Z',f:[60,52,.9],top:[60,30],g:[38,32]},
    hexagon:{n:'Hexagon',d:rpoly(ngon(6,60,59,51,-90),14),f:[60,60,1],top:[60,10],g:[42,32]},
    blob:{n:'Blob',d:'M60,12C88,12 106,30 106,58C106,90 86,106 60,106C32,106 14,92 14,62C14,32 32,12 60,12Z',f:[60,60,1.05],top:[60,13],g:[42,32]},
    ghost:{n:'Ghost',d:'M18,58C18,32 36,14 60,14C84,14 102,32 102,58L102,100Q96,108 89,100Q82,92 75,100Q68,108 60,100Q52,92 45,100Q38,108 31,100Q24,92 18,100Z',f:[60,54,1],top:[60,15],g:[42,34]}
  };
  var SHAPE_ORDER=['triangle','bubble','square','pentagon','circle','star','heart','hexagon','blob','ghost'];

  /* ---------- eyes (drawn at 0,0; side -1 = left, 1 = right) ---------- */
  function shine(x,y,r){return '<circle cx="'+x+'" cy="'+y+'" r="'+r+'" fill="#fff"/>';}
  var EYES={
    squint:{n:'><',f:function(s,k){return '<path d="'+(s<0?'M-6,-7L5,0L-6,7':'M6,-7L-5,0L6,7')+'" fill="none" stroke="'+k+'" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/>';},nb:1},
    oval:{n:'Ovals',f:function(s,k){return '<ellipse rx="5.6" ry="8.2" fill="'+k+'"/>'+shine(-1.8,-3.6,2.1);}},
    sparkle:{n:'Sparkly',f:function(s,k){return '<circle r="11.5" fill="#fff" stroke="'+k+'" stroke-width="2.6"/><circle cx="'+(s*1)+'" cy="1" r="7" fill="'+k+'"/>'+shine(s*1-2.6,-2.2,2.7)+shine(s*1+2.4,3.2,1.2);}},
    big:{n:'Big shiny',f:function(s,k){return '<ellipse rx="8.5" ry="10" fill="'+k+'"/>'+shine(-2.8,-4.2,3.2)+shine(3,3.6,1.5);}},
    wink:{n:'Wink',f:function(s,k){return s<0?'<ellipse rx="5.6" ry="8.2" fill="'+k+'"/>'+shine(-1.8,-3.6,2.1):'<path d="M-7,1Q0,-6 7,1" fill="none" stroke="'+k+'" stroke-width="4.6" stroke-linecap="round"/>';},nb:1},
    sleepy:{n:'Sleepy',f:function(s,k){return '<path d="M-7,-1Q0,6 7,-1" fill="none" stroke="'+k+'" stroke-width="4.4" stroke-linecap="round"/><path d="M'+(s*7)+',-1L'+(s*10)+',2" stroke="'+k+'" stroke-width="2.6" stroke-linecap="round"/>';},nb:1},
    happy:{n:'Happy',f:function(s,k){return '<path d="M-7,3Q0,-8 7,3" fill="none" stroke="'+k+'" stroke-width="4.8" stroke-linecap="round"/>';},nb:1},
    dots:{n:'Dots',f:function(s,k){return '<circle r="4.6" fill="'+k+'"/>'+shine(-1.4,-1.6,1.4);}},
    hearts:{n:'Hearts',f:function(s,k){return '<path d="M0,7C-3,5 -9,1 -9,-3.5C-9,-6.5 -6.8,-8.5 -4.4,-8.5C-2.4,-8.5 -0.9,-7.2 0,-5.6C0.9,-7.2 2.4,-8.5 4.4,-8.5C6.8,-8.5 9,-6.5 9,-3.5C9,1 3,5 0,7Z" fill="#ff3b6b" stroke="'+k+'" stroke-width="1.4"/>'+shine(-4,-4.5,1.7);}},
    stars:{n:'Stars',f:function(s,k){return '<path d="'+rpoly(star(0,0.5,10,4.6),1.2)+'" fill="#ffd23f" stroke="'+k+'" stroke-width="1.4" stroke-linejoin="round"/>'+shine(-2,-2.5,1.4);}},
    dizzy:{n:'Swirly',f:function(s,k){return '<path d="M0,0m-1,0a1,1 0 1 1 2,0a3,3 0 1 1 -5,0a5,5 0 1 1 9,0a7,7 0 1 1 -13,0" fill="none" stroke="'+k+'" stroke-width="2.4" stroke-linecap="round"/>';}}
  };
  var EYE_ORDER=['squint','oval','sparkle','wink','big','dots','hearts','stars','happy','sleepy','dizzy'];

  /* ---------- mouths (drawn at 0,0) ---------- */
  var MOUTHS={
    open:{n:'Big smile',f:function(k){return '<path d="M-12,-3Q0,-1 12,-3Q12,13 0,14Q-12,13 -12,-3Z" fill="#3a0f22" stroke="'+k+'" stroke-width="2" stroke-linejoin="round"/><path d="M-6.5,10.2Q0,5.5 6.5,10.2Q3,13.4 0,13.5Q-3,13.4 -6.5,10.2Z" fill="#ff7a9c"/><path d="M-9,-1.6L9,-1.6" stroke="#fff" stroke-opacity=".85" stroke-width="2" stroke-linecap="round"/>';}},
    u:{n:'U smile',f:function(k){return '<path d="M-9,-3Q-9,9 0,9Q9,9 9,-3" fill="none" stroke="'+k+'" stroke-width="4.4" stroke-linecap="round"/>';}},
    smile:{n:'Smile',f:function(k){return '<path d="M-12,-2Q0,10 12,-2" fill="none" stroke="'+k+'" stroke-width="4.2" stroke-linecap="round"/>';}},
    small:{n:'Small',f:function(k){return '<path d="M-5.5,0Q0,4.5 5.5,0" fill="none" stroke="'+k+'" stroke-width="3.8" stroke-linecap="round"/>';}},
    o:{n:':o',f:function(k){return '<ellipse cy="2" rx="5" ry="6.2" fill="#3a0f22" stroke="'+k+'" stroke-width="2"/><ellipse cx="-1.6" cy="-.4" rx="1.6" ry="1.2" fill="#fff" fill-opacity=".5"/>';}},
    tongue:{n:'Tongue',f:function(k){return '<path d="M-3.6,3.5L-3.6,8.5Q0,13.5 3.6,8.5L3.6,3.5Z" fill="#ff6f93" stroke="'+k+'" stroke-width="1.8" stroke-linejoin="round"/><path d="M0,4.5L0,8" stroke="#d94a72" stroke-width="1.2" stroke-linecap="round"/><path d="M-10,-1Q0,8 10,-1" fill="none" stroke="'+k+'" stroke-width="4" stroke-linecap="round"/>';}},
    cat:{n:'Cat :3',f:function(k){return '<path d="M-9,-1Q-4.5,6 0,0Q4.5,6 9,-1" fill="none" stroke="'+k+'" stroke-width="3.6" stroke-linecap="round" stroke-linejoin="round"/>';}},
    flat:{n:'Flat',f:function(k){return '<path d="M-6.5,1L6.5,1" stroke="'+k+'" stroke-width="4" stroke-linecap="round"/>';}},
    grin:{n:'Grin',f:function(k){return '<path d="M-12,-3L12,-3Q12,9 0,9Q-12,9 -12,-3Z" fill="#fff" stroke="'+k+'" stroke-width="2.6" stroke-linejoin="round"/><path d="M-11,1.5L11,1.5M-4,-3L-4,8.5M4,-3L4,8.5" stroke="'+k+'" stroke-width="1.5" stroke-opacity=".55"/>';}},
    sad:{n:'Wobbly',f:function(k){return '<path d="M-8,4Q0,-3 8,4" fill="none" stroke="'+k+'" stroke-width="4" stroke-linecap="round"/>';}}
  };
  var MOUTH_ORDER=['open','u','smile','small','o','tongue','cat','flat','grin','sad'];

  var ACCS={none:{n:'None'},bow:{n:'Bow'},hat:{n:'Party hat'},glasses:{n:'Glasses'},antenna:{n:'Antenna'},crown:{n:'Crown'},leaf:{n:'Leaf'},witch:{n:'Witch hat'},pumpkin:{n:'Pumpkin'}};
  var ACC_ORDER=['none','bow','hat','glasses','antenna','crown','leaf'];
  var COLORS=['#ff5fa2','#34d27b','#3b82f6','#8b5cf6','#ffc53d','#ff8a3d','#ff4d5a','#22c3c9','#a3e635','#f472b6','#94a3b8','#f5efe4','#3a3550'];

  /* ---------- color math ---------- */
  function hex(c){c=String(c||'').replace('#','');if(c.length===3)c=c.charAt(0)+c.charAt(0)+c.charAt(1)+c.charAt(1)+c.charAt(2)+c.charAt(2);var n=parseInt(c,16);if(!/^[0-9a-f]{6}$/i.test(c))n=0x8b5cf6;return [(n>>16)&255,(n>>8)&255,n&255];}
  function toHex(a){var s='#';for(var i=0;i<3;i++){var v=Math.max(0,Math.min(255,Math.round(a[i]))).toString(16);s+=(v.length<2?'0':'')+v;}return s;}
  function mix(c,t,p){var a=hex(c),b=hex(t);return toHex([a[0]+(b[0]-a[0])*p,a[1]+(b[1]-a[1])*p,a[2]+(b[2]-a[2])*p]);}
  function lum(c){var a=hex(c);return (0.299*a[0]+0.587*a[1]+0.114*a[2])/255;}
  function okColor(c){return /^#[0-9a-f]{6}$/i.test(String(c||''))?String(c).toLowerCase():'#8b5cf6';}

  /* ---------- render one Tot as SVG markup ---------- */
  function svg(t,opt){
    opt=opt||{};var u='tt'+(++uidN),sh=SHAPES[t.s]||SHAPES.circle,c=okColor(t.c),L=lum(c);
    var lite=mix(c,'#ffffff',.42),dark=mix(c,'#000000',L>.75?.3:.36),deep=mix(c,'#000000',.55),ink=L<.2?'#f6f3ff':'#1d1530';
    var gx=sh.g[0],gy=sh.g[1],fx=sh.f[0],fy=sh.f[1],fs=sh.f[2],ex=15,ey=-5,my=10;
    var h='<svg class="tt-svg" viewBox="-6 -16 132 136" xmlns="'+NS+'" aria-hidden="true" focusable="false"><defs>'+
      '<radialGradient id="'+u+'b" gradientUnits="userSpaceOnUse" cx="44" cy="34" r="84" fx="40" fy="28"><stop offset="0" stop-color="'+lite+'"/><stop offset=".5" stop-color="'+c+'"/><stop offset="1" stop-color="'+dark+'"/></radialGradient>'+
      '<linearGradient id="'+u+'g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff" stop-opacity=".78"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></linearGradient>'+
      '<radialGradient id="'+u+'s"><stop offset="0" stop-color="#000" stop-opacity=".42"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient>'+
      '<radialGradient id="'+u+'k"><stop offset="0" stop-color="#ff6b9a" stop-opacity=".75"/><stop offset="1" stop-color="#ff6b9a" stop-opacity="0"/></radialGradient>'+
      '<clipPath id="'+u+'c"><path d="'+sh.d+'"/></clipPath></defs>'+
      '<ellipse class="tt-shadow" cx="60" cy="113" rx="40" ry="6.5" fill="url(#'+u+'s)"/>'+
      '<g class="tt-body">';
    if(t.a==='antenna')h+='<path d="M'+sh.top[0]+','+(sh.top[1]+4)+'Q'+(sh.top[0]+3)+','+(sh.top[1]-8)+' '+(sh.top[0]+8)+','+(sh.top[1]-16)+'" fill="none" stroke="'+deep+'" stroke-width="3" stroke-linecap="round"/><circle cx="'+(sh.top[0]+8)+'" cy="'+(sh.top[1]-17)+'" r="5" fill="#ffd23f" stroke="'+deep+'" stroke-width="1.5"/>'+shine(sh.top[0]+6.5,sh.top[1]-18.6,1.5);
    if(t.a==='leaf')h+='<path d="M'+sh.top[0]+','+(sh.top[1]+3)+'L'+(sh.top[0]+1)+','+(sh.top[1]-9)+'" stroke="#6b3f1d" stroke-width="3.4" stroke-linecap="round"/><path d="M'+(sh.top[0]+1)+','+(sh.top[1]-7)+'C'+(sh.top[0]+8)+','+(sh.top[1]-19)+' '+(sh.top[0]+22)+','+(sh.top[1]-16)+' '+(sh.top[0]+24)+','+(sh.top[1]-13)+'C'+(sh.top[0]+18)+','+(sh.top[1]-4)+' '+(sh.top[0]+8)+','+(sh.top[1]-4)+' '+(sh.top[0]+1)+','+(sh.top[1]-7)+'Z" fill="#3fbf5a"/>';
    h+='<path d="'+sh.d+'" fill="url(#'+u+'b)"/>'+
      '<g clip-path="url(#'+u+'c)"><path d="'+sh.d+'" fill="none" stroke="'+deep+'" stroke-opacity=".35" stroke-width="7" transform="translate(0,3)"/>'+
      '<ellipse cx="'+gx+'" cy="'+gy+'" rx="'+(sh.s?18:28)+'" ry="'+(sh.s?10:14)+'" fill="url(#'+u+'g)" transform="rotate(-24 '+gx+' '+gy+')"/>'+
      '<path d="'+sh.d+'" fill="none" stroke="#fff" stroke-opacity=".22" stroke-width="3"/></g>'+
      '<circle cx="'+(gx-14)+'" cy="'+(gy-1)+'" r="3.2" fill="#fff" fill-opacity=".9" clip-path="url(#'+u+'c)"/>';
    h+='<g class="tt-face" transform="translate('+fx+','+fy+') scale('+fs+')"><g class="tt-look">';
    if(t.ck)h+='<ellipse cx="-24" cy="6" rx="9" ry="6" fill="url(#'+u+'k)"/><ellipse cx="24" cy="6" rx="9" ry="6" fill="url(#'+u+'k)"/>';
    var E=EYES[t.e]||EYES.oval,M=MOUTHS[t.m]||MOUTHS.smile;
    for(var si=-1;si<=1;si+=2)h+='<g transform="translate('+(si*ex)+','+ey+')"><g class="tt-eye'+(E.nb?' nb':'')+'">'+E.f(si,ink)+'</g></g>';
    h+='<g transform="translate(0,'+my+')">'+M.f(ink)+'</g>';
    if(t.a==='glasses')h+='<g fill="none" stroke="'+(L<.2?'#f6f3ff':'#20182c')+'" stroke-width="2.6"><circle cx="-15" cy="-5" r="11" fill="#fff" fill-opacity=".14"/><circle cx="15" cy="-5" r="11" fill="#fff" fill-opacity=".14"/><path d="M-4,-6Q0,-9 4,-6M-26,-7L-32,-10M26,-7L32,-10"/></g>';
    h+='</g></g>';
    var tx=sh.top[0],ty=sh.top[1];
    if(t.a==='bow')h+='<g transform="translate('+(tx+16)+','+(ty+4)+') rotate(-14)"><path d="M0,0C-6,-9 -18,-10 -18,0C-18,10 -6,9 0,0C6,-9 18,-10 18,0C18,10 6,9 0,0Z" fill="#ff3d7f" stroke="#b3124d" stroke-width="1.6" stroke-linejoin="round"/><circle r="4.4" fill="#ff6aa0" stroke="#b3124d" stroke-width="1.6"/>'+shine(-10,-3,2)+'</g>';
    if(t.a==='hat')h+='<g transform="translate('+tx+','+(ty+5)+') rotate(8)"><path d="M-14,0L0,-30L14,0Q0,5 -14,0Z" fill="#ffd23f" stroke="#c98a00" stroke-width="1.6" stroke-linejoin="round"/><path d="M-9.5,-9L9.5,-9M-5,-19L5,-19" stroke="#ff4d7d" stroke-width="3.4" stroke-linecap="round"/><circle cy="-31" r="4.6" fill="#ff4d7d"/></g>';
    if(t.a==='witch')h+='<g transform="translate('+tx+','+(ty+5)+') rotate(-6)"><ellipse cx="0" cy="0" rx="24" ry="5.5" fill="#2b1543" stroke="#140a22" stroke-width="1.6"/><path d="M-13,-1C-10,-14 -4,-26 6,-34C5,-28 8,-24 13,-21L13,-1Z" fill="#3b1d5c" stroke="#140a22" stroke-width="1.6" stroke-linejoin="round"/><path d="M-12.5,-6L13,-6" stroke="#f97316" stroke-width="4"/><rect x="-3" y="-9" width="6" height="6" rx="1" fill="none" stroke="#ffd23f" stroke-width="1.6"/></g>';
    if(t.a==='pumpkin')h+='<g transform="translate('+(tx+14)+','+(ty+2)+') rotate(12)"><path d="M0,-15C1,-19 3,-21 6,-22" stroke="#4d7c0f" stroke-width="3" fill="none" stroke-linecap="round"/><ellipse cx="-6" cy="-6" rx="8" ry="9" fill="#ea580c"/><ellipse cx="6" cy="-6" rx="8" ry="9" fill="#ea580c"/><ellipse cx="0" cy="-6" rx="7" ry="10" fill="#f97316" stroke="#c2410c" stroke-width="1.2"/><path d="M-7,-8l3,-3 2,3z M7,-8l-3,-3 -2,3z M-5,-2Q0,2 5,-2" fill="#ffe066" stroke="#ffe066" stroke-width=".8"/></g>';
    if(t.a==='crown')h+='<g transform="translate('+tx+','+(ty+4)+')"><path d="M-16,0L-18,-18L-8,-9L0,-22L8,-9L18,-18L16,0Z" fill="#ffd23f" stroke="#c98a00" stroke-width="1.8" stroke-linejoin="round"/><circle cx="0" cy="-6" r="2.6" fill="#ff4d5a"/>'+shine(-9,-5,1.6)+'</g>';
    h+='</g></svg>';
    return h;
  }

  /* ---------- data ---------- */
  var STARTERS=[
    {id:'s1',n:'Pinky',s:'triangle',e:'squint',m:'open',c:'#ff5fa2',ck:1,a:'none'},
    {id:'s2',n:'Chatty',s:'bubble',e:'oval',m:'smile',c:'#34d27b',ck:0,a:'none'},
    {id:'s3',n:'Blu',s:'square',e:'sparkle',m:'u',c:'#3b82f6',ck:0,a:'none'},
    {id:'s4',n:'Winky',s:'pentagon',e:'wink',m:'small',c:'#8b5cf6',ck:1,a:'none'}];
  var NAMES=['Bloop','Mochi','Pip','Ziggy','Nugget','Boba','Sprout','Tofu','Pixel','Jelly','Bean','Zap','Gummy','Noodle','Biscuit','Pebble','Sunny','Bubbles','Cosmo','Waffles','Pudding','Taco','Ripple','Doodle'];
  function clean(t){if(!t||typeof t!=='object')return null;return {id:String(t.id||id()).slice(0,24),n:String(t.n||'Tot').slice(0,16),s:SHAPES[t.s]?t.s:'circle',e:EYES[t.e]?t.e:'oval',m:MOUTHS[t.m]?t.m:'smile',c:okColor(t.c),ck:t.ck?1:0,a:ACCS[t.a]?t.a:'none'};}
  function copy(t){return clean(JSON.parse(JSON.stringify(t)));}
  var db=null;
  function load(){try{db=JSON.parse(localStorage.getItem(K)||'null');}catch(e){db=null;}
    if(!db||!db.list||!db.list.length&&!db.seen){db={list:STARTERS.map(copy),sel:'s1',on:true,seen:1};save();}
    var l=[];for(var i=0;i<db.list.length&&l.length<MAX;i++){var c=clean(db.list[i]);if(c)l.push(c);}db.list=l;if(db.on!==false)db.on=true;}
  function save(){try{localStorage.setItem(K,JSON.stringify(db));}catch(e){}}
  function find(i){for(var k=0;k<db.list.length;k++)if(db.list[k].id===i)return db.list[k];return null;}
  function selTot(){return find(db.sel)||db.list[0]||null;}
  load();

  /* ---------- tot element ---------- */
  function totEl(t,cls){var d=D.createElement('div');d.className='tt '+(cls||'');d.innerHTML=svg(t);
    var e=d.querySelectorAll('.tt-eye');for(var i=0;i<e.length;i++)e[i].style.animationDelay=(-(Math.random()*4.5)).toFixed(2)+'s';
    d.style.animationDelay=(-(Math.random()*3)).toFixed(2)+'s';return d;}
  function boing(el){if(!el)return;el.className=el.className.replace(/\s*tt-boing/g,'');void el.offsetWidth;el.className+=' tt-boing';
    clearTimeout(el._bt);el._bt=setTimeout(function(){el.className=el.className.replace(/\s*tt-boing/g,'');},650);}
  function haptic(){try{if(W.domoHaptic)W.domoHaptic('light');}catch(e){}}

  /* ---------- maker sheet ---------- */
  var sheet=D.createElement('div');sheet.id='tt-sheet';sheet.className='tt-sheet';sheet.setAttribute('role','dialog');sheet.setAttribute('aria-modal','true');sheet.setAttribute('aria-label','Tots maker');sheet.hidden=true;
  sheet.innerHTML='<div class="tt-top"><b class="tt-title">\uD83E\uDEE7 Tots</b><span class="tt-sub">make your own little buddy</span><button type="button" class="tt-x" id="tt-x" aria-label="Close Tots">\u2715</button></div>'+
    '<div class="tt-main"><div class="tt-left">'+
      '<div class="tt-stage" id="tt-stage"><div class="tt-big" id="tt-big" role="button" tabindex="0" aria-label="Your Tot. Tap to boop!"></div><div class="tt-nm" id="tt-nm"></div></div>'+
      '<div class="tt-namerow"><label class="sr-only" for="tt-name">Tot name</label><input id="tt-name" type="text" maxlength="16" placeholder="Name your Tot" autocomplete="off" enterkeyhint="done"><button type="button" class="tt-b" id="tt-rand" aria-label="Random Tot">\uD83C\uDFB2</button></div>'+
      '<div class="tt-acts"><button type="button" class="tt-b pri" id="tt-save">\uD83D\uDCBE Save</button><button type="button" class="tt-b" id="tt-new">\uFF0B New</button><button type="button" class="tt-b warn" id="tt-del">\uD83D\uDDD1\uFE0F</button></div>'+
      '<p class="tt-msg" id="tt-msg" aria-live="polite"></p>'+
    '</div><div class="tt-right">'+
      '<div class="tt-tabs" role="tablist" aria-label="Customize"><button type="button" class="tt-tab on" data-k="s">Shape</button><button type="button" class="tt-tab" data-k="e">Eyes</button><button type="button" class="tt-tab" data-k="m">Mouth</button><button type="button" class="tt-tab" data-k="c">Color</button><button type="button" class="tt-tab" data-k="x">Extras</button></div>'+
      '<div class="tt-opts" id="tt-opts"></div>'+
    '</div></div>'+
    '<div class="tt-gal-w"><div class="tt-gh"><b>My Tots</b><span id="tt-cnt"></span></div><div class="tt-gal" id="tt-gal"></div>'+
    '<label class="tt-sw"><input type="checkbox" id="tt-on"><span class="sw"></span><span>Show my Tot in chat <small>(it thinks while the AI answers)</small></span></label>'+
    '<p class="tt-note">\uD83D\uDD12 Tots are saved on this device only (up to 12). Nothing uploads.</p></div>';
  D.body.appendChild(sheet);
  var draft=null,editing=null,tab='s',nameOk=null,lastFocus=null;
  var big=$('tt-big'),nm=$('tt-nm'),nameIn=$('tt-name'),opts=$('tt-opts'),gal=$('tt-gal'),msg=$('tt-msg'),onIn=$('tt-on'),delBtn=$('tt-del'),saveBtn=$('tt-save');
  function say(t,bad){msg.textContent=t||'';msg.className='tt-msg'+(bad?' bad':(t?' ok':''));}
  function drawBig(b){big.innerHTML='';var el=totEl(draft,'tt-live');big.appendChild(el);nm.textContent=draft.n||'Tot';if(b)boing(el);}
  function optHTML(){var h='',i,t,k;
    if(tab==='s'){for(i=0;i<SHAPE_ORDER.length;i++){k=SHAPE_ORDER[i];t=copy(draft);t.s=k;t.a='none';h+=opt('s',k,SHAPES[k].n,t);}}
    else if(tab==='e'){for(i=0;i<EYE_ORDER.length;i++){k=EYE_ORDER[i];t=copy(draft);t.e=k;t.a='none';h+=opt('e',k,EYES[k].n,t);}}
    else if(tab==='m'){for(i=0;i<MOUTH_ORDER.length;i++){k=MOUTH_ORDER[i];t=copy(draft);t.m=k;t.a='none';h+=opt('m',k,MOUTHS[k].n,t);}}
    else if(tab==='c'){h+='<div class="tt-cols">';for(i=0;i<COLORS.length;i++)h+='<button type="button" class="tt-col'+(draft.c===COLORS[i]?' on':'')+'" data-c="'+COLORS[i]+'" style="background:'+COLORS[i]+'" aria-label="Color '+COLORS[i]+'"></button>';
      h+='<label class="tt-pick"><input type="color" id="tt-color" value="'+draft.c+'" aria-label="Pick any color"><span>\uD83C\uDFA8 Any color</span></label></div>';}
    else{h+='<label class="tt-sw tt-ck"><input type="checkbox" id="tt-cheeks"'+(draft.ck?' checked':'')+'><span class="sw"></span><span>\uD83D\uDE0A Blushy cheeks</span></label><div class="tt-gh2">Accessory</div>';
      var AO=/\bhw\b/.test(D.documentElement.className)?ACC_ORDER.concat(['witch','pumpkin']):ACC_ORDER;for(i=0;i<AO.length;i++){k=AO[i];t=copy(draft);t.a=k;h+=opt('a',k,ACCS[k].n,t);}}
    return h;}
  function opt(f,k,label,t){var on=draft[f]===k;return '<button type="button" class="tt-o'+(on?' on':'')+'" data-f="'+f+'" data-v="'+k+'" aria-pressed="'+on+'" aria-label="'+esc(label)+'"><span class="tt tt-static">'+svg(t)+'</span><span class="tt-ol">'+esc(label)+'</span></button>';}
  function drawOpts(){opts.innerHTML=optHTML();var tb=sheet.querySelectorAll('.tt-tab');for(var i=0;i<tb.length;i++){var on=tb[i].getAttribute('data-k')===tab;tb[i].className='tt-tab'+(on?' on':'');tb[i].setAttribute('aria-selected',on?'true':'false');}
    var ci=$('tt-color');if(ci){var f=function(){draft.c=okColor(ci.value);drawBig(false);var cs=opts.querySelectorAll('.tt-col');for(var j=0;j<cs.length;j++)cs[j].className='tt-col';};ci.addEventListener('input',f);ci.addEventListener('change',f);}
    var ck=$('tt-cheeks');if(ck)ck.addEventListener('change',function(){draft.ck=ck.checked?1:0;drawBig(true);drawOpts();});}
  function drawGal(){var h='';for(var i=0;i<db.list.length;i++){var t=db.list[i],me=t.id===db.sel,ed=editing&&editing===t.id;
      h+='<button type="button" class="tt-card'+(ed?' ed':'')+'" data-id="'+t.id+'" aria-label="'+esc(t.n)+(me?', your chat buddy':'')+'. Tap to edit"><span class="tt-cw"></span><span class="tt-cn">'+esc(t.n)+'</span>'+(me?'<span class="tt-star" title="Chat buddy">\u2B50</span>':'')+'</button>';}
    gal.innerHTML=h;var cards=gal.querySelectorAll('.tt-card');for(var j=0;j<cards.length;j++){var t2=find(cards[j].getAttribute('data-id'));if(t2)cards[j].querySelector('.tt-cw').appendChild(totEl(t2,'tt-g'));}
    $('tt-cnt').textContent=db.list.length+'/'+MAX;onIn.checked=db.on!==false;delBtn.hidden=!editing;
    saveBtn.textContent=editing?'\uD83D\uDCBE Save':'\uD83D\uDCBE Save new';}
  function setDraft(t,ed){draft=copy(t);editing=ed||null;nameIn.value=draft.n;nameOk=draft.n;say('');drawBig(true);drawOpts();drawGal();}
  function randomTot(){return {id:'',n:rnd(NAMES),s:rnd(SHAPE_ORDER),e:rnd(EYE_ORDER),m:rnd(MOUTH_ORDER),c:Math.random()<.85?rnd(COLORS):toHex([Math.random()*255,Math.random()*255,Math.random()*255]),ck:Math.random()<.5?1:0,a:Math.random()<.4?rnd(ACC_ORDER.slice(1)):'none'};}
  function okName(n){for(var i=0;i<NAMES.length;i++)if(NAMES[i]===n)return true;for(var j=0;j<STARTERS.length;j++)if(STARTERS[j].n===n)return true;return n===nameOk;}
  function checkName(n,cb){ /* the site's kid-safe name filter, on the server */
    var done=0,tm=setTimeout(function(){if(!done){done=1;cb(false,'Couldn\u2019t check that name (wifi?). Try again!');}},8000);
    fetch('/api/hc/totname',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({name:n})})
      .then(function(r){return r.json()['catch'](function(){return {};});})
      .then(function(j){if(done)return;done=1;clearTimeout(tm);if(j&&j.ok)cb(true,j.name);else cb(false,(j&&j.msg)||(j&&j.error==='rate_limited'?'Slow down a sec, then try again!':'Let\u2019s pick a different name \uD83D\uDE42'));})
      ['catch'](function(){if(done)return;done=1;clearTimeout(tm);cb(false,'Couldn\u2019t check that name (wifi?). Try again!');});}
  function doSave(){var n=String(nameIn.value||'').replace(/\s+/g,' ').replace(/^\s+|\s+$/g,'').slice(0,16)||'Tot';
    function commit(nn){draft.n=nn;nameOk=nn;nameIn.value=nn;var t=copy(draft);
      if(editing&&find(editing)){t.id=editing;for(var i=0;i<db.list.length;i++)if(db.list[i].id===editing)db.list[i]=t;}
      else{if(db.list.length>=MAX){say('You have 12 Tots (the max). Delete one to save a new one!',true);return;}t.id=id();db.list.push(t);editing=t.id;}
      db.sel=t.id;save();drawBig(true);drawGal();buddyAll();say('\u2705 Saved! '+t.n+' is your chat buddy now');haptic();}
    if(n==='Tot'||okName(n)){commit(n);return;}
    saveBtn.disabled=true;say('\uD83D\uDEE1\uFE0F Checking the name\u2026');
    checkName(n,function(ok,v){saveBtn.disabled=false;if(ok)commit(v);else{say(v,true);try{nameIn.focus();}catch(e){}}});}
  function open(){lastFocus=D.activeElement;var s=selTot();setDraft(s||STARTERS[0],s?s.id:null);sheet.hidden=false;D.documentElement.className+=' tt-open';
    setTimeout(function(){sheet.className='tt-sheet in';try{$('tt-x').focus();}catch(e){}},20);}
  function close(){sheet.className='tt-sheet';D.documentElement.className=D.documentElement.className.replace(/\s*tt-open/g,'');setTimeout(function(){sheet.hidden=true;big.innerHTML='';gal.innerHTML='';opts.innerHTML='';},200);
    try{if(lastFocus&&lastFocus.focus)lastFocus.focus();}catch(e){}}
  $('tt-x').addEventListener('click',close);
  sheet.addEventListener('keydown',function(e){if((e.keyCode||e.which)===27){e.preventDefault();close();}});
  big.addEventListener('click',function(){boing(big.firstChild);haptic();});
  big.addEventListener('keydown',function(e){var k=e.keyCode||e.which;if(k===13||k===32){e.preventDefault();boing(big.firstChild);}});
  nameIn.addEventListener('input',function(){draft.n=nameIn.value.slice(0,16);nm.textContent=draft.n||'Tot';});
  nameIn.addEventListener('keydown',function(e){if((e.keyCode||e.which)===13){e.preventDefault();doSave();}});
  $('tt-rand').addEventListener('click',function(){var r=randomTot();draft=r;nameIn.value=r.n;drawBig(true);drawOpts();say('\uD83C\uDFB2 Tap Save to keep '+r.n+'!');haptic();});
  saveBtn.addEventListener('click',doSave);
  $('tt-new').addEventListener('click',function(){var r=randomTot();setDraft(r,null);say('\u2728 A new Tot! Change anything, then Save');});
  delBtn.addEventListener('click',function(){if(!editing)return;var t=find(editing);if(!t)return;if(!W.confirm('Delete '+t.n+'?'))return;
    for(var i=0;i<db.list.length;i++)if(db.list[i].id===editing){db.list.splice(i,1);break;}
    if(db.sel===editing)db.sel=db.list.length?db.list[0].id:null;save();var s=selTot();if(s)setDraft(s,s.id);else setDraft(randomTot(),null);buddyAll();say('\uD83D\uDDD1\uFE0F Deleted '+t.n);});
  sheet.querySelector('.tt-tabs').addEventListener('click',function(e){var b=e.target;while(b&&b!==this&&!b.getAttribute('data-k'))b=b.parentNode;if(b&&b!==this){tab=b.getAttribute('data-k');drawOpts();}});
  opts.addEventListener('click',function(e){var b=e.target;while(b&&b!==opts&&!(b.getAttribute&&(b.getAttribute('data-f')||b.getAttribute('data-c'))))b=b.parentNode;if(!b||b===opts)return;
    if(b.getAttribute('data-c'))draft.c=b.getAttribute('data-c');else draft[b.getAttribute('data-f')]=b.getAttribute('data-v');
    drawBig(true);drawOpts();haptic();});
  gal.addEventListener('click',function(e){var b=e.target;while(b&&b!==gal&&!(b.getAttribute&&b.getAttribute('data-id')))b=b.parentNode;if(!b||b===gal)return;
    var t=find(b.getAttribute('data-id'));if(!t)return;db.sel=t.id;save();setDraft(t,t.id);buddyAll();say('\u2B50 '+t.n+' is your chat buddy');haptic();});
  onIn.addEventListener('change',function(){db.on=!!onIn.checked;save();buddyAll();syncCust();});

  /* ---------- chat buddy ---------- */
  var buddies=[];
  function mkBuddy(form){if(!form)return null;var b=D.createElement('button');b.type='button';b.className='tt-buddy';b.setAttribute('aria-label','Your Tot. Tap to open Tots');
    b.addEventListener('click',function(e){e.preventDefault();open();});form.insertBefore(b,form.firstChild);return {el:b,form:form};}
  function buddyAll(){var t=selTot(),on=db.on!==false&&!!t;
    for(var i=0;i<buddies.length;i++){var B=buddies[i];if(!B)continue;
      B.form.className=B.form.className.replace(/\s*tt-has/g,'')+(on?' tt-has':'');B.el.hidden=!on;B.el.innerHTML='';
      if(on){var tt=t;if(B.over){tt={};for(var k1 in t)tt[k1]=t[k1];for(var k2 in B.over)tt[k2]=B.over[k2];}var el=totEl(tt,'tt-mini'+(B.cls?' '+B.cls:''));B.el.appendChild(el);B.el.setAttribute('aria-label',t.n+', your Tot. Tap to open Tots');B.tot=el;if(B.think)el.className+=' tt-think';}}}
  function setThink(B,on){if(!B||!B.tot)return;var was=!!B.think;B.think=on;var el=B.tot;el.className=el.className.replace(/\s*tt-(think|happy)/g,'');
    if(on)el.className+=' tt-think';else if(was){void el.offsetWidth;el.className+=' tt-happy';clearTimeout(B.ht);B.ht=setTimeout(function(){el.className=el.className.replace(/\s*tt-happy/g,'');},1500);}}
  buddies.push(mkBuddy($('composer')));buddies.push(mkBuddy($('cb-form')));buddyAll();
  /* thinking = the chat's typing bubble is showing / Code is building (watched, hcf.js + hccode.js untouched) */
  var log=$('log'),cbBusy=$('cb-busy');
  function watch(){var a=!!(log&&log.querySelector('.tp')),b=!!(cbBusy&&!cbBusy.hidden);
    if(buddies[0]&&a!==!!buddies[0].think)setThink(buddies[0],a);if(buddies[1]&&b!==!!buddies[1].think)setThink(buddies[1],b);}
  if(W.MutationObserver){var mo=new MutationObserver(watch);if(log)mo.observe(log,{childList:true,subtree:true,attributes:true,attributeFilter:['class']});if(cbBusy)mo.observe(cbBusy,{attributes:true,attributeFilter:['hidden']});}
  else setInterval(watch,400);

  /* ---------- entry points: the Tots tab + Customize ---------- */
  var tb=$('hc-tots-btn');if(tb)tb.addEventListener('click',open);
  var cust=D.querySelector('#hc-cust .hd-body'),cOn=null;
  if(cust){var sec=D.createElement('div');sec.className='tt-cust';sec.innerHTML='<h2 class="hd-h">\uD83E\uDEE7 Tots</h2><label class="hd-sw"><input type="checkbox" id="tt-on2"><span class="sw"></span><span>Show my Tot in chat</span></label><button type="button" class="hd-btn pri" id="tt-open2">\uD83E\uDEE7 Make &amp; pick Tots</button>';
    cust.insertBefore(sec,cust.firstChild);cOn=$('tt-on2');cOn.addEventListener('change',function(){db.on=!!cOn.checked;save();buddyAll();});
    $('tt-open2').addEventListener('click',function(){try{if(W.hcApp)W.hcApp.close();}catch(e){}open();});}
  function syncCust(){if(cOn)cOn.checked=db.on!==false;}syncCust();
  W.hcTots={open:open,close:close,svg:svg,think:function(on){setThink(buddies[0],!!on);},buddies:buddies,refresh:buddyAll,totEl:totEl,sel:selTot};
})();
