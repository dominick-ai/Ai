// v1.9.2 body tunnel: the site's host was crashing on requests that carry a body (POST), so /api/ POSTs go out as GET
// with the JSON body URI-encoded in x-domo-b* headers; the worker turns them back into the same POST. Nothing goes in the URL.
// v2.0.6: when the browser's fetch itself fails to reach the server ("Failed to fetch", seen on a smart-TV browser),
// the same request is tried again over XMLHttpRequest, then (for a POST) as a plain POST, before giving up with a clear message.
(function(W){
  'use strict';
  var F=W.fetch;if(!F||F._domoTun)return;
  var PART=6000,MAXP=8;
  function apiPath(u){u=String(u);var o=W.location&&W.location.protocol+'//'+W.location.host,base=String(W.TABO_API_BASE||'').replace(/\/+$/,'');if(o&&u.indexOf(o+'/')===0)u=u.slice(o.length);if(base&&/^\/api\//.test(u))u=base+u;return /^https?:\/\/[^/]+\/api\//.test(u)||/^\/api\//.test(u)?u:null;}
  function stamp(){return (new Date().getTime())+''+Math.floor(Math.random()*1e6);}
  function note(m){try{var a=W.__domoErrs;if(a&&a.push){a.push('net: '+m);if(a.length>20)a.shift();}W.__domoNet=m;}catch(e){}}
  function hdrs(o){var h={},x=o&&o.headers;if(!x)return h;
    if(typeof x.forEach==='function'&&!(x instanceof Array))x.forEach(function(v,k){h[k]=v;});else for(var k in x)if(x.hasOwnProperty(k))h[k]=x[k];return h;}
  function resp(x){var t=x.responseText||'',st=x.status,ct=x.getResponseHeader('content-type')||'application/json';
    if(W.Response&&st>=200&&st!==204&&st!==205&&st!==304){try{return new W.Response(t,{status:st,headers:{'content-type':ct}});}catch(e){}}
    return {ok:st>=200&&st<300,status:st,statusText:'',headers:{get:function(n){return x.getResponseHeader(n);}},
      text:function(){return Promise.resolve(t);},json:function(){return new Promise(function(r,j){try{r(JSON.parse(t));}catch(e){j(e);}});},clone:function(){return resp(x);}};}
  function xhr(method,url,h,body){return new Promise(function(res,rej){var x;try{x=new XMLHttpRequest();x.open(method,url,true);
      for(var k in h)if(h.hasOwnProperty(k))x.setRequestHeader(k,h[k]);
      try{x.timeout=20000;}catch(e){}
      x.onload=function(){if(!x.status)rej(new TypeError('xhr status 0'));else res(resp(x));};
      x.onerror=function(){rej(new TypeError('xhr error'));};x.ontimeout=function(){rej(new TypeError('xhr timeout'));};
      x.send(body===undefined?null:body);}catch(e){rej(e);}});}
  function wait(ms){return new Promise(function(r){setTimeout(r,ms);});}
  function friendly(){var e=new TypeError('Couldn\u2019t reach the server, try again in a sec.');e.domoNet=true;return e;}
  var T=function(url,o){
    var m=String((o&&o.method)||'GET').toUpperCase(),p=typeof url==='string'?apiPath(url):null;
    if(!p)return F.apply(W,arguments);
    var post=m==='POST'&&o&&typeof o.body==='string',tun=null;
    if(post){var enc=encodeURIComponent(o.body),n=Math.ceil(enc.length/PART)||1;
      if(n<=MAXP){var h={'x-domo-bn':String(n)};for(var i=0;i<n;i++)h['x-domo-b'+i]=enc.slice(i*PART,(i+1)*PART);tun=h;}}
    var sep=p.indexOf('?')<0?'?':'&',first;
    if(tun){var q={method:'GET',headers:tun,cache:'no-store'};if(o.credentials)q.credentials=o.credentials;first=F.call(W,p+sep+'_tn='+stamp(),q);}
    else first=F.apply(W,arguments);
    return first.then(null,function(err){
      if(err&&err.name==='AbortError')throw err;
      note('fetch '+p.split('?')[0]+': '+(err&&err.message));
      var h2=tun||hdrs(o);
      // 2nd try: the same request over XMLHttpRequest
      return xhr(tun?'GET':m,tun?p+sep+'_tn='+stamp():String(url),h2,tun?undefined:(o&&o.body)).then(null,function(e2){
        note('xhr '+p.split('?')[0]+': '+(e2&&e2.message));
        // 3rd try: a POST as a plain POST (the host takes bodies again); a GET once more after a moment
        var last=post?xhr('POST',p,{'content-type':'application/json'},o.body):wait(700).then(function(){return xhr(m,String(url),h2,undefined);});
        return last.then(null,function(e3){note('last '+p.split('?')[0]+': '+(e3&&e3.message));throw friendly();});
      });
    });
  };
  T._domoTun=true;W.fetch=T;
})(window);
