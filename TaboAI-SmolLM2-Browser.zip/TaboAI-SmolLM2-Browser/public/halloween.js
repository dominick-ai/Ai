/* Tabo v2.1: the Halloween look is an OPT-IN toggle for everyone (off by default), cute only (candy + pumpkins). v1.6 Halloween: countdown strip, Oct 31 animation, Halloween look unlocked forever (localStorage).
   ?halloween=test  -> animation + look for this load only (nothing saved)
   ?halloween=count -> countdown from 10 s, then the animation + look preview (nothing saved) */
(function(){
  var W=window,D=document,H=D.documentElement,LS=null;try{LS=W.localStorage;}catch(e){}
  var K_UN='hc_hw_unlocked',K_ON='hc_hw_on',K_ON2='hc_hw_on2';
  function get(k){try{return LS?LS.getItem(k):null;}catch(e){return null;}}
  function set(k,v){try{if(LS)LS.setItem(k,v);}catch(e){}}
  var q=(location.search.match(/[?&]halloween=(\w+)/)||[])[1]||'';
  var TEST=q==='test',COUNT=q==='count',PREVIEW=TEST||COUNT;
  var T0=new Date(2026,9,31,0,0,0).getTime(),T1=new Date(2026,10,1,0,0,0).getTime();
  if(COUNT)T0=Date.now()+10500;
  var unlocked=get(K_UN)==='1',tmp=false;
  function isOn(){return get(K_ON2)==='1'||tmp;} /* v2.1: opt-in for everyone, OFF by default (Halloween is over) */
  var APPLE='data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48ZGVmcz48cmFkaWFsR3JhZGllbnQgaWQ9ImciIGN4PSIzOCUiIGN5PSIzNSUiIHI9IjcwJSI+PHN0b3Agb2Zmc2V0PSIwIiBzdG9wLWNvbG9yPSIjZmZjMDZiIi8+PHN0b3Agb2Zmc2V0PSIuNTUiIHN0b3AtY29sb3I9IiNmNzdmMDAiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNiODQzMGEiLz48L3JhZGlhbEdyYWRpZW50PjxyYWRpYWxHcmFkaWVudCBpZD0ibCIgY3g9IjUwJSIgY3k9IjUwJSIgcj0iNjAlIj48c3RvcCBvZmZzZXQ9IjAiIHN0b3AtY29sb3I9IiNmZmY2YjAiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNmZmI2MjciLz48L3JhZGlhbEdyYWRpZW50PjwvZGVmcz48cGF0aCBkPSJNNTAgMjlDMzkgMTkgMTMgMjEgMTMgNTBjMCAyNSAxOCA0MyAzMSA0MSAzLS42IDktLjYgMTIgMCAxMyAyIDMxLTE2IDMxLTQxIDAtMjktMjYtMzEtMzctMjF6IiBmaWxsPSJ1cmwoI2cpIiBzdHJva2U9IiM4YTJmMDUiIHN0cm9rZS13aWR0aD0iMiIvPjxwYXRoIGQ9Ik01MCAzMGMwLTkgMi0xNSA2LTIwIiBzdHJva2U9IiM1YjNhMWEiIHN0cm9rZS13aWR0aD0iNC41IiBmaWxsPSJub25lIiBzdHJva2UtbGluZWNhcD0icm91bmQiLz48cGF0aCBkPSJNNTQgMThjNi0xMCAxOS0xMCAyMy02LTcgNy0xNSA5LTIzIDZ6IiBmaWxsPSIjM2ZhMzRkIi8+PGVsbGlwc2UgY3g9IjM0IiBjeT0iMzgiIHJ4PSI5IiByeT0iNSIgZmlsbD0iI2ZmZiIgb3BhY2l0eT0iLjI4IiB0cmFuc2Zvcm09InJvdGF0ZSgtMjUgMzQgMzgpIi8+PHBhdGggZD0iTTI3IDUwbDEwLTExIDYgMTN6IE03MyA1MGwtMTAtMTEtNiAxM3ogTTUwIDU0bC01IDhoMTB6IE0yNiA2NmMxMCAxNSAzOCAxNSA0OCAwbC02IDItNC01LTUgNy01LTUtNCA1LTUtNS00IDUtNS03LTQgNXoiIGZpbGw9InVybCgjbCkiIHN0cm9rZT0iIzZiMjIwMyIgc3Ryb2tlLXdpZHRoPSIxLjYiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz48L3N2Zz4=',brandImg=null,brandSrc='';
  function apply(){var on=isOn();
    if(on){if(!/\bhw\b/.test(H.className))H.className+=' hw';}else H.className=H.className.replace(/\s*\bhw\b/g,'');
    brandImg=brandImg||D.querySelector('.brand img');if(brandImg){if(!brandSrc)brandSrc=brandImg.getAttribute('src');brandImg.setAttribute('src',brandSrc);}
    var m=D.querySelector('meta[name="theme-color"]');if(m)m.setAttribute('content',on?'#fff1e2':'#fbf4ff');
    deco(on);toggleUI();try{if(W.hcTots&&W.hcTots.refresh)W.hcTots.refresh();}catch(e){}}
  /* ---- floating bats/ghosts + cobwebs (CSS transforms only) ---- */
  var dc=null;
  function deco(on){if(!on){if(dc){dc.parentNode.removeChild(dc);dc=null;}return;}if(dc)return;
    dc=D.createElement('div');dc.className='hw-deco';dc.setAttribute('aria-hidden','true');
    var web='<svg viewBox="0 0 100 100"><g fill="none" stroke="currentColor" stroke-width=".9"><path d="M0 0L100 100M0 0L100 38M0 0L38 100M0 0L100 0M0 0L0 100"/><path d="M22 0Q20 9 0 22M44 0Q38 17 0 44M66 0Q57 26 0 66M88 0Q76 36 0 88"/><path d="M22 0Q24 10 16 16Q10 24 0 22M44 0Q47 20 31 31Q20 47 0 44M66 0Q70 30 47 47Q30 70 0 66"/></g></svg>';
    dc.innerHTML='<b class="hw-f hw-f1">🍬</b><b class="hw-f hw-f2">🎃</b><b class="hw-f hw-f3">🍭</b><b class="hw-f hw-f4">🍫</b>'; /* v2.1 cute: candy + pumpkins, no cobwebs/bats */
    D.body.insertBefore(dc,D.body.firstChild);}
  /* ---- menu toggle (Customize drawer) ---- */
  var tg=null;
  function toggleUI(){var body=D.querySelector('#hc-cust .hd-body');if(!body)return;
    if(!tg){tg=D.createElement('div');tg.className='hw-tg';
      tg.innerHTML='<h2 class="hd-h">🎃 Halloween</h2><label class="hd-sw"><input type="checkbox" id="hw-on"><span class="sw"></span><span>🎃 Halloween look <small>(cute pumpkins + candy, off by default)</small></span></label>';
      body.insertBefore(tg,body.firstChild);
      D.getElementById('hw-on').onchange=function(){if(!PREVIEW){set(K_ON2,this.checked?'1':'0');tmp=false;}else tmp=this.checked;apply();};}
    D.getElementById('hw-on').checked=isOn();}
  /* ---- toast ---- */
  function toast(t){var el=D.createElement('div');el.className='hw-toast';el.setAttribute('role','status');el.textContent=t;D.body.appendChild(el);
    setTimeout(function(){el.className+=' in';},30);setTimeout(function(){el.className=el.className.replace(' in','');setTimeout(function(){if(el.parentNode)el.parentNode.removeChild(el);},500);},3600);}
  /* ---- the big animation ---- */
  var playing=false;
  function anim(done){if(playing)return;playing=true;
    var o=D.createElement('div');o.className='hw-ov';o.setAttribute('role','dialog');o.setAttribute('aria-label','Happy Halloween! Tap to skip');
    var h='<div class="hw-moon"></div>',i;
    for(i=0;i<9;i++)h+='<span class="hw-bat" style="top:'+(6+((i*37)%62))+'%;-webkit-animation-delay:'+(i*0.28).toFixed(2)+'s;animation-delay:'+(i*0.28).toFixed(2)+'s;font-size:'+(22+(i%3)*10)+'px">🦇</span>';
    for(i=0;i<6;i++)h+='<span class="hw-pk" style="left:'+(4+i*16)+'%;-webkit-animation-delay:'+(1.1+i*0.18).toFixed(2)+'s;animation-delay:'+(1.1+i*0.18).toFixed(2)+'s">🎃</span>';
    for(i=0;i<22;i++)h+='<span class="hw-cn" style="left:'+((i*47)%97)+'%;-webkit-animation-delay:'+(1.4+(i%8)*0.22).toFixed(2)+'s;animation-delay:'+(1.4+(i%8)*0.22).toFixed(2)+'s">'+['🍬','🍭','🍫','🍬'][i%4]+'</span>';
    h+='<span class="hw-gh">👻</span><span class="hw-gh hw-gh2">👻</span>';
    h+='<div class="hw-mid"><div class="hw-ap"><img class="hw-a1" src="'+(brandSrc||'icon-192.png?v=2.5')+'" alt=""><img class="hw-a2" src="'+APPLE+'" alt=""></div><div class="hw-txt">HAPPY<br>HALLOWEEN 🎃</div></div><div class="hw-skip">tap to skip</div>';
    o.innerHTML=h;D.body.appendChild(o);
    var fin=false;function end(){if(fin)return;fin=true;clearTimeout(t1);o.className+=' out';setTimeout(function(){if(o.parentNode)o.parentNode.removeChild(o);playing=false;},450);if(done)done();}
    var t1=setTimeout(end,5400);o.onclick=end;o.addEventListener('touchend',function(e){e.preventDefault();end();});
    D.addEventListener('keydown',function k(e){if(e.key==='Escape'||e.key==='Enter'||e.key===' '){D.removeEventListener('keydown',k);end();}});}
  function unlockNow(){anim(function(){if(PREVIEW){tmp=true;}else{unlocked=true;set(K_UN,'1');set(K_ON2,'1');}apply();toast('🎃 Halloween UI unlocked forever!');});}
  /* ---- countdown strip ---- */
  var st=null,stT=null,timer=0,fired=false;
  function pad(n){return (n<10?'0':'')+n;}
  function tick(){var now=Date.now();
    if(now>=T1&&!PREVIEW){if(st){st.parentNode.removeChild(st);st=null;}clearInterval(timer);return;}
    if(!st){st=D.createElement('div');st.className='hw-strip';st.setAttribute('role','status');st.innerHTML='<span class="hw-st-t"></span>';stT=st.firstChild;
      var app=D.getElementById('app'),top=app&&app.querySelector('.top');if(top&&top.nextSibling)app.insertBefore(st,top.nextSibling);else if(app)app.insertBefore(st,app.firstChild);}
    if(now<T0){var s=Math.ceil((T0-now)/1000),d=Math.floor(s/86400),hh=Math.floor(s%86400/3600),mm=Math.floor(s%3600/60),ss=s%60;
      stT.textContent='🎃 Halloween in '+(d?d+'d '+hh+'h '+mm+'m':(hh?hh+'h ':'')+pad(mm)+'m '+pad(ss)+'s');H.className.indexOf('hw-cd')<0&&(H.className+=' hw-cd');}
    else{stT.textContent='🎃 Happy Halloween!';if(st.className.indexOf('hw-hh')<0)st.className+=' hw-hh';
      if(!fired){fired=true;var today=new Date(),okDay=today.getFullYear()===2026&&today.getMonth()===9&&today.getDate()===31;
        if(PREVIEW||(okDay&&!unlocked))unlockNow();}}}
  function start(){apply();
    if(TEST){fired=true;T0=Date.now()-1;tick();unlockNow();}
    tick();timer=setInterval(tick,1000);
    W.hcHalloween={test:function(){PREVIEW=true;tmp=false;unlockNow();},state:function(){return {unlocked:unlocked,on:isOn(),preview:PREVIEW};}};}
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',start);else start();
})();
