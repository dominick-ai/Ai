/* boards.js (Tabo AI v2.9.7) ♟️ Chess + 🔴 Checkers in 📚 Lessons (the user Nov 11 3:29 PM: "in lessons make chess checkers ...").
   Real rules (legal moves only: check, castling, en passant, promotion; checkers forced jumps + multi-jumps + kings), a computer
   opponent whose strength follows the grade picker (or Easy/Medium/Hard), beginner lessons + mate-in-1 puzzles. All on this device. ES5. */
(function(){
  'use strict';
  var W=window,D=document;
  var X=W.hcLessons&&W.hcLessons.ext;if(!X)return;
  function $(id){return D.getElementById(id);}
  function el(t,c,h){var e=D.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;}
  var esc=X.esc;
  function ls(k,v){try{if(v===undefined)return localStorage.getItem(k);localStorage.setItem(k,v);}catch(e){}return null;}
  function grade(){var g=parseInt(ls('hc_grade'),10);return isNaN(g)?5:Math.max(0,Math.min(12,g));}
  function gradeName(g){return g===0?'K':String(g);}
  function lvlFor(kind){var o=ls('hc_'+kind+'_lvl');if(o==='1'||o==='2'||o==='3')return parseInt(o,10);var g=grade();return g<=3?1:(g<=8?2:3);}
  var LVN={1:'\uD83D\uDE0A Easy',2:'\uD83D\uDE42 Medium',3:'\uD83D\uDE24 Hard'};
  function stats(kind){var s={w:0,l:0,d:0};try{var o=JSON.parse(ls('hc_'+kind+'_st')||'null');if(o)s=o;}catch(e){}return s;}
  function addStat(kind,k){var s=stats(kind);s[k]=(s[k]||0)+1;ls('hc_'+kind+'_st',JSON.stringify(s));}
  var later=W.setTimeout;

  /* ======================= ♟️ CHESS ENGINE ======================= */
  var N=-8,S=8,E=1,Wd=-1;
  function C(){}
  function color(p){return !p?'':(p===p.toUpperCase()?'w':'b');}
  function opp(c){return c==='w'?'b':'w';}
  function rc(i){return [i>>3,i&7];}
  function onB(r,c){return r>=0&&r<8&&c>=0&&c<8;}
  function fromFEN(f){var p=f.split(' '),rows=p[0].split('/'),b=[],i,j;
    for(i=0;i<8;i++){var row=rows[i];for(j=0;j<row.length;j++){var ch=row.charAt(j);if(/\d/.test(ch)){for(var k=0;k<+ch;k++)b.push('');}else b.push(ch);}}
    var cs=p[2]||'-';var ep=-1;if(p[3]&&p[3]!=='-'){ep=(8-parseInt(p[3].charAt(1),10))*8+(p[3].charCodeAt(0)-97);}
    return {b:b,turn:p[1]||'w',cK:cs.indexOf('K')>=0,cQ:cs.indexOf('Q')>=0,ck:cs.indexOf('k')>=0,cq:cs.indexOf('q')>=0,ep:ep,half:+(p[4]||0)};}
  var START='rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  var KN=[[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]],KG=[[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]],
      DI=[[-1,-1],[-1,1],[1,-1],[1,1]],OR=[[-1,0],[1,0],[0,-1],[0,1]];
  function attacked(b,sq,by){var r=sq>>3,c=sq&7,i,rr,cc,p;
    var pr=by==='w'?r+1:r-1,pw=by==='w'?'P':'p';
    if(pr>=0&&pr<8){if(c>0&&b[pr*8+c-1]===pw)return true;if(c<7&&b[pr*8+c+1]===pw)return true;}
    var kn=by==='w'?'N':'n',kg=by==='w'?'K':'k';
    for(i=0;i<8;i++){rr=r+KN[i][0];cc=c+KN[i][1];if(onB(rr,cc)&&b[rr*8+cc]===kn)return true;rr=r+KG[i][0];cc=c+KG[i][1];if(onB(rr,cc)&&b[rr*8+cc]===kg)return true;}
    var bq=by==='w'?'BQ':'bq',rq=by==='w'?'RQ':'rq';
    for(i=0;i<4;i++){rr=r+DI[i][0];cc=c+DI[i][1];while(onB(rr,cc)){p=b[rr*8+cc];if(p){if(bq.indexOf(p)>=0)return true;break;}rr+=DI[i][0];cc+=DI[i][1];}
      rr=r+OR[i][0];cc=c+OR[i][1];while(onB(rr,cc)){p=b[rr*8+cc];if(p){if(rq.indexOf(p)>=0)return true;break;}rr+=OR[i][0];cc+=OR[i][1];}}
    return false;}
  function kingSq(b,c){var k=c==='w'?'K':'k';for(var i=0;i<64;i++)if(b[i]===k)return i;return -1;}
  function inCheck(s,c){var k=kingSq(s.b,c);return k>=0&&attacked(s.b,k,opp(c));}
  function pseudo(s){var b=s.b,me=s.turn,mv=[],i,j,r,c,rr,cc,p,t;
    function add(f,to,x){var m={f:f,t:to};if(x)for(var k in x)m[k]=x[k];m.cap=b[to]||(m.ep?'p':'');mv.push(m);}
    for(i=0;i<64;i++){p=b[i];if(!p||color(p)!==me)continue;r=i>>3;c=i&7;var u=p.toUpperCase();
      if(u==='P'){var d=me==='w'?-1:1,sr=me==='w'?6:1,lr=me==='w'?0:7;rr=r+d;
        if(onB(rr,c)&&!b[rr*8+c]){if(rr===lr){add(i,rr*8+c,{pr:'q'});add(i,rr*8+c,{pr:'n'});add(i,rr*8+c,{pr:'r'});add(i,rr*8+c,{pr:'b'});}else add(i,rr*8+c);
          if(r===sr&&!b[(r+2*d)*8+c])add(i,(r+2*d)*8+c,{dbl:1});}
        for(j=-1;j<=1;j+=2){cc=c+j;if(!onB(rr,cc))continue;t=rr*8+cc;
          if(b[t]&&color(b[t])!==me){if(rr===lr){add(i,t,{pr:'q'});add(i,t,{pr:'n'});add(i,t,{pr:'r'});add(i,t,{pr:'b'});}else add(i,t);}
          else if(t===s.ep)add(i,t,{ep:1});}}
      else if(u==='N'||u==='K'){var L=u==='N'?KN:KG;for(j=0;j<8;j++){rr=r+L[j][0];cc=c+L[j][1];if(!onB(rr,cc))continue;t=rr*8+cc;if(!b[t]||color(b[t])!==me)add(i,t);}
        if(u==='K'){var home=me==='w'?60:4;if(i===home&&!attacked(b,i,opp(me))){
          if((me==='w'?s.cK:s.ck)&&!b[i+1]&&!b[i+2]&&b[i+3]===(me==='w'?'R':'r')&&!attacked(b,i+1,opp(me))&&!attacked(b,i+2,opp(me)))add(i,i+2,{cs:'k'});
          if((me==='w'?s.cQ:s.cq)&&!b[i-1]&&!b[i-2]&&!b[i-3]&&b[i-4]===(me==='w'?'R':'r')&&!attacked(b,i-1,opp(me))&&!attacked(b,i-2,opp(me)))add(i,i-2,{cs:'q'});}}}
      else{var dirs=u==='B'?DI:(u==='R'?OR:DI.concat(OR));for(j=0;j<dirs.length;j++){rr=r+dirs[j][0];cc=c+dirs[j][1];
          while(onB(rr,cc)){t=rr*8+cc;if(b[t]){if(color(b[t])!==me)add(i,t);break;}add(i,t);rr+=dirs[j][0];cc+=dirs[j][1];}}}}
    return mv;}
  function make(s,m){var b=s.b.slice(),p=b[m.f],me=s.turn;b[m.t]=p;b[m.f]='';
    if(m.ep)b[m.t+(me==='w'?8:-8)]='';
    if(m.pr)b[m.t]=me==='w'?m.pr.toUpperCase():m.pr;
    if(m.cs==='k'){b[m.t-1]=b[m.t+1];b[m.t+1]='';}if(m.cs==='q'){b[m.t+1]=b[m.t-2];b[m.t-2]='';}
    var n={b:b,turn:opp(me),cK:s.cK,cQ:s.cQ,ck:s.ck,cq:s.cq,ep:m.dbl?(m.f+m.t)/2:-1,half:(p.toUpperCase()==='P'||m.cap)?0:s.half+1};
    if(p==='K'){n.cK=n.cQ=false;}if(p==='k'){n.ck=n.cq=false;}
    if(m.f===63||m.t===63)n.cK=false;if(m.f===56||m.t===56)n.cQ=false;if(m.f===7||m.t===7)n.ck=false;if(m.f===0||m.t===0)n.cq=false;
    return n;}
  function legal(s){var ps=pseudo(s),out=[];for(var i=0;i<ps.length;i++){var n=make(s,ps[i]);if(!inCheck(n,s.turn))out.push(ps[i]);}return out;}
  function insufficient(b){var minor=0;for(var i=0;i<64;i++){var p=b[i];if(!p)continue;var u=p.toUpperCase();if(u==='K')continue;if(u==='B'||u==='N'){minor++;continue;}return false;}return minor<=1;}
  function outcome(s,lm){if(!lm)lm=legal(s);if(!lm.length)return inCheck(s,s.turn)?'mate':'stale';if(s.half>=100)return 'fifty';if(insufficient(s.b))return 'material';return '';}
  var VAL={P:100,N:300,B:320,R:500,Q:900,K:0};
  function center(i){var r=i>>3,c=i&7;return 6-(Math.abs(3.5-r)+Math.abs(3.5-c));}
  function evalW(s){var sc=0,b=s.b;for(var i=0;i<64;i++){var p=b[i];if(!p)continue;var u=p.toUpperCase(),w=p===u?1:-1,v=VAL[u];
      if(u==='N'||u==='B')v+=center(i)*4;else if(u==='P'){var adv=p==='P'?6-(i>>3):(i>>3)-1;v+=adv*6+((i&7)>=2&&(i&7)<=5?center(i)*2:0);}else if(u==='Q')v+=center(i);
      sc+=w*v;}return sc;}
  function order(ms){for(var i=0;i<ms.length;i++){var m=ms[i];m.o=(m.cap?10*VAL[m.cap.toUpperCase()||'P']+5:0)+(m.pr==='q'?800:0);}ms.sort(function(a,b){return b.o-a.o;});return ms;}
  var nodes=0;
  function ab(s,d,a,bt,ply){nodes++;if(d<=0){var e=evalW(s);return s.turn==='w'?e:-e;}var ms=legal(s);if(!ms.length)return inCheck(s,s.turn)?-100000+ply:0;
    order(ms);for(var i=0;i<ms.length;i++){var v=-ab(make(s,ms[i]),d-1,-bt,-a,ply+1);if(v>a)a=v;if(a>=bt)break;if(nodes>60000)break;}return a;}
  function bestMove(s,lvl){var ms=legal(s);if(!ms.length)return null;nodes=0;
    if(lvl===1){/* easy: grabs free stuff sometimes, otherwise random-ish */var best=null,bv=-1e9;
      for(var i=0;i<ms.length;i++){var n=make(s,ms[i]);var v=(ms[i].cap?VAL[ms[i].cap.toUpperCase()]:0)*(Math.random()<.6?1:0)+Math.random()*120;if(!legal(n).length&&inCheck(n,n.turn))v+=5000;if(v>bv){bv=v;best=ms[i];}}return best;}
    var depth=lvl===2?2:3;order(ms);var best2=ms[0],a=-1e9;
    for(var j=0;j<ms.length;j++){var v2=-ab(make(s,ms[j]),depth-1,-1e9,-a,1)+(lvl===2?Math.random()*30:Math.random()*6);if(v2>a){a=v2;best2=ms[j];}}
    return best2;}
  var GLY={k:'\u265A',q:'\u265B',r:'\u265C',b:'\u265D',n:'\u265E',p:'\u265F'};
  function glyph(p){return p?GLY[p.toLowerCase()]+'\uFE0E':'';}
  function sqName(i){return String.fromCharCode(97+(i&7))+(8-(i>>3));}
  C.fromFEN=fromFEN;C.legal=legal;C.make=make;C.outcome=outcome;C.inCheck=inCheck;C.best=bestMove;C.START=START;
  W.hcChess=C;

  /* board UI shared by play / puzzles / lessons */
  function chessBoard(host,opt){var st=opt.s,sel=-1,targets=[],flip=!!opt.flip,last=opt.last||null,busy=false;
    var g=el('div','bd-board bd-chess');host.appendChild(g);var cells=[];
    for(var i=0;i<64;i++){var b=el('button','bd-sq');b.type='button';b.setAttribute('data-i',i);cells.push(b);g.appendChild(b);}
    function idx(v){return flip?63-v:v;}
    function paint(){var ck=C.inCheck(st,st.turn)?kingSq(st.b,st.turn):-1;
      for(var v=0;v<64;v++){var i=idx(v),b=cells[v],p=st.b[i],r=i>>3,c=i&7,cl='bd-sq '+(((r+c)&1)?'bd-dk':'bd-lt');
        if(i===sel)cl+=' bd-sel';if(last&&(i===last.f||i===last.t))cl+=' bd-last';if(i===ck)cl+=' bd-chk';
        var tg=false;for(var k=0;k<targets.length;k++)if(targets[k].t===i){tg=true;break;}if(tg)cl+=p?' bd-cap':' bd-dot';
        if(opt.mark&&opt.mark===i)cl+=' bd-star';
        b.className=cl;b.innerHTML=p?'<span class="bd-pc '+(color(p)==='w'?'bd-w':'bd-b')+'">'+glyph(p)+'</span>':'';
        b.setAttribute('aria-label',sqName(i)+(p?' '+(color(p)==='w'?'white ':'black ')+({k:'king',q:'queen',r:'rook',b:'bishop',n:'knight',p:'pawn'})[p.toLowerCase()]:''));}}
    g.onclick=function(e){var n=e.target;while(n&&n!==g&&!n.getAttribute('data-i'))n=n.parentNode;if(!n||n===g||busy)return;
      var i=idx(+n.getAttribute('data-i'));if(opt.canMove&&!opt.canMove())return;
      for(var k=0;k<targets.length;k++){if(targets[k].t===i){var m=targets[k];if(m.pr){for(var q=0;q<targets.length;q++)if(targets[q].t===i&&targets[q].pr==='q'){m=targets[q];break;}}
          sel=-1;targets=[];opt.onMove(m);return;}}
      var p=st.b[i];if(p&&color(p)===st.turn&&(!opt.side||opt.side===st.turn)){sel=i;targets=[];var lm=C.legal(st);for(var j=0;j<lm.length;j++)if(lm[j].f===i)targets.push(lm[j]);}else{sel=-1;targets=[];}
      paint();};
    paint();
    return {set:function(s2,lm){st=s2;last=lm||last;sel=-1;targets=[];paint();},flip:function(){flip=!flip;paint();},busy:function(v){busy=v;},el:g,state:function(){return st;}};}

  function lvlRow(kind){var cur=lvlFor(kind),o=ls('hc_'+kind+'_lvl'),h='<div class="bd-lv" role="group" aria-label="Computer strength"><span>\uD83E\uDD16 Computer:</span>';
    for(var l=1;l<=3;l++)h+='<button type="button" class="bd-lvb'+(cur===l?' on':'')+'" data-lv="'+l+'">'+LVN[l]+'</button>';
    h+='<small>'+(o?'you picked it':'set by grade '+gradeName(grade()))+'</small></div>';return h;}
  function wireLv(box,kind,cb){var bs=box.querySelectorAll('.bd-lvb');for(var i=0;i<bs.length;i++)bs[i].onclick=function(){ls('hc_'+kind+'_lvl',this.getAttribute('data-lv'));cb();};}

  /* ---- views ---- */
  function chHome(){X.ttl().textContent='\u265F\uFE0F Chess';var tt=X.teacher('mid'),st=stats('chess');
    X.teach(tt,'cheer','Let\u2019s play chess! Learn the moves, solve puzzles, then beat the computer \uD83D\uDE0E');
    var b=X.body(),w=el('div','bd-menu');
    w.innerHTML='<button type="button" class="ls-course bd-c1" id="bd-ch-play"><span class="ls-ci">\uD83E\uDD16</span><b>Play the computer</b><span>You are white. '+LVN[lvlFor('chess')]+'</span><em>\uD83C\uDFC6 '+st.w+' wins \u00B7 '+st.l+' losses \u00B7 '+st.d+' draws</em></button>'+
      '<button type="button" class="ls-course bd-c2" id="bd-ch-les"><span class="ls-ci">\uD83C\uDF93</span><b>Beginner lessons</b><span>How every piece moves, check + checkmate, tactics</span><em>'+CH_LES.length+' lessons</em></button>'+
      '<button type="button" class="ls-course bd-c3" id="bd-ch-puz"><span class="ls-ci">\uD83E\uDDE9</span><b>Mate-in-1 puzzles</b><span>Find the move that wins right away</span><em>'+puzDone()+'/'+PUZ.length+' solved</em></button>';
    b.appendChild(w);$('bd-ch-play').onclick=function(){X.go('chplay');};$('bd-ch-les').onclick=function(){X.go('chles',0);};$('bd-ch-puz').onclick=function(){X.go('chpuz',firstPuz());};}
  var game=null;
  function chPlay(){X.ttl().textContent='\u265F\uFE0F Chess vs computer';var b=X.body();
    var top=el('div','bd-top');top.innerHTML=lvlRow('chess');b.appendChild(top);wireLv(top,'chess',function(){X.show('chplay');});
    var stl=el('p','bd-st','');stl.setAttribute('aria-live','polite');b.appendChild(stl);
    var wrap=el('div','bd-wrap');b.appendChild(wrap);
    var btns=el('div','ls-btns','<button type="button" class="ls-b" id="bd-new">\u21BA New game</button><button type="button" class="ls-b" id="bd-undo">\u21B6 Undo</button><button type="button" class="ls-b" id="bd-flip">\u21C5 Flip board</button>');b.appendChild(btns);
    var note=el('p','bd-note','Tap a piece, then tap a dot. Pawns that reach the end become a queen \uD83D\uDC51');b.appendChild(note);
    if(!game||game.over)game={hist:[],s:C.fromFEN(START),last:null,over:''};
    var lvl=lvlFor('chess'),bd;
    function say(){var lm=C.legal(game.s),o=C.outcome(game.s,lm);
      if(o){if(!game.over){game.over=o;if(o==='mate'){if(game.s.turn==='b')addStat('chess','w');else addStat('chess','l');}else addStat('chess','d');}
        stl.innerHTML=o==='mate'?(game.s.turn==='b'?'\uD83C\uDFC6 <b>Checkmate! You win!</b>':'\uD83D\uDE35 <b>Checkmate.</b> The computer wins this time.'):'\uD83E\uDD1D <b>Draw</b> ('+({stale:'stalemate: no legal moves',fifty:'50 moves with no capture',material:'not enough pieces to checkmate'})[o]+')';return;}
      stl.innerHTML=game.s.turn==='w'?(C.inCheck(game.s,'w')?'\u26A0\uFE0F <b>Check!</b> Save your king.':'Your move (white)'):'\uD83E\uDD16 Thinking\u2026';}
    function cpu(){if(game.over||game.s.turn!=='b')return;bd.busy(true);say();later(function(){var m=C.best(game.s,lvl);if(m&&X.isView('chplay')){game.hist.push(game.s);game.s=C.make(game.s,m);game.last=m;bd.set(game.s,m);}bd.busy(false);say();},260);}
    bd=chessBoard(wrap,{s:game.s,last:game.last,side:'w',onMove:function(m){game.hist.push(game.s);game.s=C.make(game.s,m);game.last=m;bd.set(game.s,m);say();later(cpu,40);}});
    say();if(game.s.turn==='b')cpu();
    $('bd-new').onclick=function(){game={hist:[],s:C.fromFEN(START),last:null,over:''};X.show('chplay');};
    $('bd-undo').onclick=function(){if(game.s.turn!=='w'&&!game.over)return;var n=game.s.turn==='w'?2:1;while(n-->0&&game.hist.length)game.s=game.hist.pop();game.over='';game.last=null;bd.set(game.s,null);say();};
    $('bd-flip').onclick=function(){bd.flip();};}
  /* lessons: each has words + a little board you can try on */
  var CH_LES=[
    {t:'\u265F\uFE0F The pawn',x:'Pawns move <b>straight forward one square</b>. On their very first move they may jump <b>two</b>. They capture <b>one square diagonally forward</b>. A pawn that reaches the last row turns into a queen (or another piece)!',f:'8/8/8/8/8/8/4P3/8 w - - 0 1',goal:'Move the pawn two squares forward.',chk:function(m){return m.f===52&&m.t===36;}},
    {t:'\u265C The rook',x:'Rooks slide in <b>straight lines</b>: up, down, left or right, as far as they want, but they can\u2019t jump over pieces.',f:'8/8/8/8/3R4/8/8/8 w - - 0 1',goal:'Slide the rook all the way to the top row.',chk:function(m){return m.f===35&&(m.t>>3)===0;}},
    {t:'\u265D The bishop',x:'Bishops slide <b>diagonally</b> as far as they want. A bishop stays on its color forever: a light-square bishop never touches a dark square.',f:'8/8/8/8/8/8/8/2B5 w - - 0 1',goal:'Move the bishop as far as it can go (to the corner h6).',chk:function(m){return m.t===23;}},
    {t:'\u265B The queen',x:'The queen is the strongest piece. She moves like a rook <b>and</b> a bishop: straight or diagonal, as far as she wants.',f:'8/8/8/8/3Q4/8/8/8 w - - 0 1',goal:'Move the queen diagonally to a corner.',chk:function(m){return m.t===0||m.t===7||m.t===56||m.t===63;}},
    {t:'\u265E The knight',x:'Knights move in an <b>L shape</b>: two squares one way, then one square to the side. They are the only piece that can <b>jump over</b> other pieces!',f:'8/8/8/8/8/2PPP3/2PNP3/8 w - - 0 1',goal:'Jump the knight over the pawns.',chk:function(m){return m.f===51;}},
    {t:'\u265A The king',x:'The king moves <b>one square</b> in any direction. He can never move into check. Protect him: if he gets trapped, the game is over!',f:'8/8/8/8/4K3/8/8/8 w - - 0 1',goal:'Move the king one square.',chk:function(m){return m.f===36;}},
    {t:'\u26A0\uFE0F Check + checkmate',x:'<b>Check</b> means the king is being attacked. You must fix it: move the king, block, or capture the attacker. <b>Checkmate</b> means there is no way to fix it, and that player loses.',f:'6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1',goal:'Checkmate! Move the rook to the back row.',chk:function(m,n){return C.outcome(n)==='mate';}},
    {t:'\uD83C\uDFF0 Castling',x:'Once per game the king can castle: he moves <b>two squares</b> toward a rook and the rook hops over him. Only if neither has moved, nothing is between them, and the king is not in check.',f:'8/8/8/8/8/8/8/4K2R w K - 0 1',goal:'Castle: move the king two squares to the right.',chk:function(m){return m.cs==='k';}},
    {t:'\uD83C\uDF74 Tactic: the fork',x:'A <b>fork</b> is one piece attacking <b>two</b> enemy pieces at once. They can only save one! Knights are great at forks.',f:'r3k3/8/8/1N6/8/8/8/4K3 w - - 0 1',goal:'Move the knight to attack the king AND the rook at once.',chk:function(m){return m.f===25&&m.t===10;}},
    {t:'\uD83D\uDCCC Tactic: the pin',x:'A <b>pin</b> is when a piece can\u2019t move because something more valuable is behind it. Bishops, rooks and queens make pins.',f:'4k3/8/2n5/8/8/8/8/3QKB2 w - - 0 1',goal:'Pin the black knight to its king: bishop to b5 (or queen to a4).',chk:function(m){return m.t===25||m.t===32;}},
    {t:'\uD83D\uDCA1 Opening tips',x:'1) Control the <b>center</b> with pawns. 2) Bring out <b>knights and bishops</b> early. 3) <b>Castle</b> to keep your king safe. 4) Don\u2019t move the queen out too soon.',f:START,goal:'Make a good first move: push a center pawn (e2-e4 or d2-d4).',chk:function(m){return (m.f===52&&(m.t===36||m.t===44))||(m.f===51&&(m.t===35||m.t===43));}}];
  function chLes(ix){ix=ix||0;var L=CH_LES[ix];X.ttl().textContent='\uD83C\uDF93 Chess '+(ix+1)+'/'+CH_LES.length;var b=X.body();
    var tt=X.teacher('mid');X.teach(tt,'focus',L.t);
    b.appendChild(el('div','bd-les','<h3>'+L.t+'</h3><p class="ls-x">'+L.x+'</p><p class="bd-goal">\uD83C\uDFAF '+esc(L.goal)+'</p>'));
    var wrap=el('div','bd-wrap bd-small');b.appendChild(wrap);var stl=el('p','bd-st','');b.appendChild(stl);
    var s=C.fromFEN(L.f),bd=chessBoard(wrap,{s:s,side:'w',onMove:function(m){var n=C.make(s,m);n.turn='w';n.ep=-1;s=n;bd.set(n,m);
        if(L.chk(m,C.make(C.fromFEN(L.f),m))){stl.innerHTML='\u2705 <b>Nice!</b> You got it.';X.teach(tt,'pass','Great job! \uD83C\uDF89');var d=lesDone();d[ix]=1;ls('hc_chless',JSON.stringify(d));}
        else{stl.innerHTML='Good move! Try the goal above \uD83D\uDC46';}}});
    var btns=el('div','ls-btns','<button type="button" class="ls-b" id="bd-prev"'+(ix?'':' disabled')+'>\u2190 Back</button><button type="button" class="ls-b" id="bd-rst">\u21BA Reset</button><button type="button" class="ls-b ls-chk" id="bd-nx">'+(ix<CH_LES.length-1?'Next lesson \u2192':'\uD83E\uDD16 Play the computer')+'</button>');b.appendChild(btns);
    $('bd-prev').onclick=function(){if(ix)X.show('chles',ix-1);};$('bd-rst').onclick=function(){X.show('chles',ix);};
    $('bd-nx').onclick=function(){if(ix<CH_LES.length-1)X.show('chles',ix+1);else X.show('chplay');};}
  function lesDone(){try{return JSON.parse(ls('hc_chless')||'{}')||{};}catch(e){return {};}}
  /* mate-in-1 puzzles (white to move; any move that checkmates is right) */
  var PUZ=[
    {f:'6k1/5ppp/8/8/8/8/8/3R2K1 w - - 0 1',h:'The black king is stuck behind his own pawns\u2026'},
    {f:'k7/8/1K6/8/8/8/7Q/8 w - - 0 1',h:'Your king already guards a7 and b7. The queen needs the 8th row.'},
    {f:'r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5Q2/PPPP1PPP/RNB1K1NR w KQkq - 0 1',h:'The f7 pawn is only protected by the king.'},
    {f:'7k/5Q2/6K1/8/8/8/8/8 w - - 0 1',h:'Put the queen right next to the king, protected by your king.'},
    {f:'6k1/5ppp/8/8/8/2B5/8/K5Q1 w - - 0 1',h:'Your queen and your bishop both look at g7.'},
    {f:'6rk/6pp/8/6N1/8/8/8/K7 w - - 0 1',h:'Knights love smothered kings.'},
    {f:'3k4/8/3K4/8/8/8/8/R7 w - - 0 1',h:'Kings face each other. The rook does the rest.'},
    {f:'k7/pp6/8/8/8/8/8/K5R1 w - - 0 1',h:'The black king is boxed in by his own pawns.'}];
  function puzDoneMap(){try{return JSON.parse(ls('hc_chpuz')||'{}')||{};}catch(e){return {};}}
  function puzDone(){var m=puzDoneMap(),n=0;for(var k in m)if(m[k])n++;return n;}
  function firstPuz(){var m=puzDoneMap();for(var i=0;i<PUZ.length;i++)if(!m[i])return i;return 0;}
  function chPuz(ix){ix=ix||0;var P=PUZ[ix];X.ttl().textContent='\uD83E\uDDE9 Puzzle '+(ix+1)+'/'+PUZ.length;var b=X.body();var tt=X.teacher('mid');X.teach(tt,'think','White to move. Find checkmate in ONE move!');
    var wrap=el('div','bd-wrap');b.appendChild(wrap);var stl=el('p','bd-st','');stl.setAttribute('aria-live','polite');b.appendChild(stl);
    var s0=C.fromFEN(P.f),done=false,bd=chessBoard(wrap,{s:s0,side:'w',canMove:function(){return !done;},onMove:function(m){var n=C.make(s0,m);bd.set(n,m);
        if(C.outcome(n)==='mate'){done=true;stl.innerHTML='\u2705 <b>Checkmate!</b> Puzzle solved.';X.teach(tt,'pass','You found it! \uD83E\uDDE0');var mp=puzDoneMap();mp[ix]=1;ls('hc_chpuz',JSON.stringify(mp));}
        else{stl.innerHTML='\u274C Not checkmate. Tap \u21BA Try again. \uD83D\uDCA1 '+esc(P.h);X.teach(tt,'oops','So close! Try again.');done=true;}}});
    var btns=el('div','ls-btns','<button type="button" class="ls-b" id="bd-rst">\u21BA Try again</button><button type="button" class="ls-b ls-chk" id="bd-nx">Next puzzle \u2192</button>');b.appendChild(btns);
    $('bd-rst').onclick=function(){X.show('chpuz',ix);};$('bd-nx').onclick=function(){X.show('chpuz',(ix+1)%PUZ.length);};}
  C.PUZ=PUZ;C.LES=CH_LES;
  X.reg('chhome',chHome);X.reg('chplay',chPlay);X.reg('chles',chLes);X.reg('chpuz',chPuz);

  /* ======================= 🔴 CHECKERS ======================= */
  /* board: 64 cells; 'r' red man (you, moving up), 'R' red king, 'b' black man (computer, moving down), 'B' black king */
  function ckStart(){var b=[];for(var i=0;i<64;i++){var r=i>>3,c=i&7,dk=(r+c)&1;b.push(dk&&r<3?'b':(dk&&r>4?'r':''));}return {b:b,turn:'r',quiet:0};}
  function ckSide(p){return !p?'':(p.toLowerCase());}
  function ckDirs(p){return p==='r'?[[-1,-1],[-1,1]]:(p==='b'?[[1,-1],[1,1]]:[[-1,-1],[-1,1],[1,-1],[1,1]]);}
  function ckJumps(b,i,p,path,capd,out){var r=i>>3,c=i&7,ds=ckDirs(p),found=false;
    for(var k=0;k<4&&k<ds.length;k++){var mr=r+ds[k][0],mc=c+ds[k][1],lr=r+2*ds[k][0],lc=c+2*ds[k][1];if(!onB(lr,lc))continue;var mi=mr*8+mc,li=lr*8+lc,mp=b[mi];
      if(mp&&ckSide(mp)!==ckSide(p)&&capd.indexOf(mi)<0&&!b[li]){found=true;var nb=b.slice();nb[li]=p;nb[i]='';
        var crown=(p==='r'&&lr===0)||(p==='b'&&lr===7);var np=crown?p.toUpperCase():p;
        if(crown)out.push({path:path.concat([li]),caps:capd.concat([mi])});else ckJumps(nb,li,np,path.concat([li]),capd.concat([mi]),out);}}
    if(!found&&capd.length)out.push({path:path,caps:capd});}
  function ckMoves(s){var b=s.b,me=s.turn,jumps=[],steps=[];
    for(var i=0;i<64;i++){var p=b[i];if(!p||ckSide(p)!==me)continue;var o=[];ckJumps(b,i,p,[i],[],o);for(var k=0;k<o.length;k++)if(o[k].caps.length)jumps.push(o[k]);
      if(!jumps.length){var r=i>>3,c=i&7,ds=ckDirs(p);for(var d=0;d<ds.length;d++){var rr=r+ds[d][0],cc=c+ds[d][1];if(onB(rr,cc)&&!b[rr*8+cc])steps.push({path:[i,rr*8+cc],caps:[]});}}}
    return jumps.length?jumps:steps;}
  function ckMake(s,m){var b=s.b.slice(),f=m.path[0],t=m.path[m.path.length-1],p=b[f];b[f]='';for(var i=0;i<m.caps.length;i++)b[m.caps[i]]='';
    if((p==='r'&&(t>>3)===0)||(p==='b'&&(t>>3)===7))p=p.toUpperCase();b[t]=p;return {b:b,turn:s.turn==='r'?'b':'r',quiet:(m.caps.length||p===p.toLowerCase())?0:s.quiet+1};}
  function ckEval(s){var v=0;for(var i=0;i<64;i++){var p=s.b[i];if(!p)continue;var r=i>>3,c=i&7,w=(p==='b'||p==='B')?1:-1,x=(p==='b'||p==='r')?100:165;
      if(p==='b')x+=r*4;if(p==='r')x+=(7-r)*4;if(c===0||c===7)x+=4;v+=w*x;}return v;}/* + = good for black (computer) */
  var cnodes=0;
  function ckAB(s,d,a,bt){cnodes++;var ms=ckMoves(s);if(!ms.length)return -100000-d;if(d<=0||cnodes>40000){var e=ckEval(s);return s.turn==='b'?e:-e;}
    for(var i=0;i<ms.length;i++){var v=-ckAB(ckMake(s,ms[i]),d-1,-bt,-a);if(v>a)a=v;if(a>=bt)break;}return a;}
  function ckBest(s,lvl){var ms=ckMoves(s);if(!ms.length)return null;cnodes=0;if(lvl===1&&Math.random()<.55)return ms[Math.floor(Math.random()*ms.length)];
    var d=lvl===1?1:(lvl===2?3:6),best=ms[0],a=-1e9;for(var i=0;i<ms.length;i++){var v=-ckAB(ckMake(s,ms[i]),d-1,-1e9,-a)+Math.random()*(lvl===3?2:12);if(v>a){a=v;best=ms[i];}}return best;}
  W.hcCheckers={start:ckStart,moves:ckMoves,make:ckMake,best:ckBest};
  var ck=null;
  function ckBoard(host,opt){var st=opt.s,sel=-1,cand=[],part=[],busy=false,last=null;var g=el('div','bd-board bd-ck');host.appendChild(g);var cells=[];
    for(var i=0;i<64;i++){var b=el('button','bd-sq');b.type='button';b.setAttribute('data-i',i);cells.push(b);g.appendChild(b);}
    function nexts(){/* squares reachable as the next hop from the current partial path */var o=[];for(var k=0;k<cand.length;k++){var pth=cand[k].path,ok=true;for(var j=0;j<part.length;j++)if(pth[j]!==part[j]){ok=false;break;}if(ok&&pth.length>part.length)o.push(pth[part.length]);}return o;}
    function paint(){var nx=sel>=0?nexts():[],mv=ckMoves(st),movable={};for(var q=0;q<mv.length;q++)movable[mv[q].path[0]]=1;
      for(var i=0;i<64;i++){var p=st.b[i],r=i>>3,c=i&7,cl='bd-sq '+(((r+c)&1)?'bd-dk':'bd-lt');
        if(i===sel||part.indexOf(i)>0)cl+=' bd-sel';if(last&&last.indexOf(i)>=0)cl+=' bd-last';if(nx.indexOf(i)>=0)cl+=' bd-dot';
        if(st.turn==='r'&&!busy&&sel<0&&movable[i]&&opt.hintMovable)cl+=' bd-can';
        cells[i].className=cl;var cur=i;if(sel>=0&&part.length>1&&i===part[part.length-1]){p=st.b[sel];}if(sel>=0&&part.length>1&&i===sel)p='';
        cells[i].innerHTML=p?'<span class="bd-ckp '+(ckSide(p)==='r'?'bd-red':'bd-blk')+'">'+(p===p.toUpperCase()?'\uD83D\uDC51\uFE0E':'')+'</span>':'';}}
    g.onclick=function(e){var n=e.target;while(n&&n!==g&&!n.getAttribute('data-i'))n=n.parentNode;if(!n||n===g||busy||st.turn!=='r')return;var i=+n.getAttribute('data-i');
      if(sel>=0){var nx=nexts();if(nx.indexOf(i)>=0){part.push(i);var done=null;for(var k=0;k<cand.length;k++){var pth=cand[k].path;if(pth.length===part.length){var ok=true;for(var j=0;j<part.length;j++)if(pth[j]!==part[j]){ok=false;break;}if(ok){done=cand[k];break;}}}
          var more=nexts();if(done&&!more.length){var m=done;sel=-1;cand=[];part=[];opt.onMove(m);return;}paint();return;}}
      var p=st.b[i];if(p&&ckSide(p)==='r'){var all=ckMoves(st);cand=[];for(var q=0;q<all.length;q++)if(all[q].path[0]===i)cand.push(all[q]);
        if(!cand.length){if(opt.onNote)opt.onNote(all.length&&all[0].caps.length?'You have to jump! Find the piece that can capture.':'That piece can\u2019t move.');sel=-1;part=[];}else{sel=i;part=[i];}}
      else{sel=-1;cand=[];part=[];}paint();};
    paint();return {set:function(s2,lp){st=s2;last=lp||null;sel=-1;cand=[];part=[];paint();},busy:function(v){busy=v;paint();}};}
  function ckHome(){X.ttl().textContent='\uD83D\uDD34 Checkers';var tt=X.teacher('mid'),st=stats('checkers');X.teach(tt,'cheer','Checkers time! Jump the computer\u2019s pieces and get kings \uD83D\uDC51');
    var w=el('div','bd-menu');w.innerHTML='<button type="button" class="ls-course bd-c4" id="bd-ck-play"><span class="ls-ci">\uD83E\uDD16</span><b>Play the computer</b><span>You are red. '+LVN[lvlFor('checkers')]+'</span><em>\uD83C\uDFC6 '+st.w+' wins \u00B7 '+st.l+' losses \u00B7 '+st.d+' draws</em></button>'+
      '<button type="button" class="ls-course bd-c2" id="bd-ck-les"><span class="ls-ci">\uD83C\uDF93</span><b>How to play</b><span>Moves, jumps, kings + winning tips</span><em>'+CK_LES.length+' lessons</em></button>';
    X.body().appendChild(w);$('bd-ck-play').onclick=function(){X.go('ckplay');};$('bd-ck-les').onclick=function(){X.go('ckles',0);};}
  function ckPlay(){X.ttl().textContent='\uD83D\uDD34 Checkers vs computer';var b=X.body();var top=el('div','bd-top');top.innerHTML=lvlRow('checkers');b.appendChild(top);wireLv(top,'checkers',function(){X.show('ckplay');});
    var stl=el('p','bd-st','');stl.setAttribute('aria-live','polite');b.appendChild(stl);var wrap=el('div','bd-wrap');b.appendChild(wrap);
    b.appendChild(el('div','ls-btns','<button type="button" class="ls-b" id="bd-new">\u21BA New game</button><button type="button" class="ls-b" id="bd-undo">\u21B6 Undo</button>'));
    b.appendChild(el('p','bd-note','Tap your red piece, then tap where to go. Jumps are a must! For a double jump, tap each landing square.'));
    if(!ck||ck.over)ck={s:ckStart(),hist:[],over:'',last:null};var lvl=lvlFor('checkers'),bd;
    function say(){var ms=ckMoves(ck.s);if(!ms.length||ck.s.quiet>=80){if(!ck.over){ck.over=ck.s.quiet>=80?'d':(ck.s.turn==='r'?'l':'w');addStat('checkers',ck.over);}
        stl.innerHTML=ck.over==='w'?'\uD83C\uDFC6 <b>You win!</b> The computer has no moves left.':(ck.over==='l'?'\uD83D\uDE35 <b>The computer wins.</b> Try again!':'\uD83E\uDD1D <b>Draw</b> (40 moves each with no capture).');return;}
      stl.innerHTML=ck.s.turn==='r'?(ms[0].caps.length?'\u26A1 <b>You must jump!</b>':'Your move (red)'):'\uD83E\uDD16 Thinking\u2026';}
    function cpu(){if(ck.over||ck.s.turn!=='b')return;bd.busy(true);say();later(function(){var m=ckBest(ck.s,lvl);if(m&&X.isView('ckplay')){ck.hist.push(ck.s);ck.s=ckMake(ck.s,m);ck.last=m.path;bd.set(ck.s,m.path);}bd.busy(false);say();},380);}
    bd=ckBoard(wrap,{s:ck.s,hintMovable:true,onNote:function(t){stl.innerHTML='\u26A1 '+esc(t);},onMove:function(m){ck.hist.push(ck.s);ck.s=ckMake(ck.s,m);ck.last=m.path;bd.set(ck.s,m.path);say();later(cpu,60);}});
    if(ck.last)bd.set(ck.s,ck.last);say();if(ck.s.turn==='b')cpu();
    $('bd-new').onclick=function(){ck={s:ckStart(),hist:[],over:'',last:null};X.show('ckplay');};
    $('bd-undo').onclick=function(){if(ck.s.turn!=='r'&&!ck.over)return;var n=ck.s.turn==='r'?2:1;while(n-->0&&ck.hist.length)ck.s=ck.hist.pop();if(ck.s.turn==='b'&&ck.hist.length)ck.s=ck.hist.pop();ck.over='';ck.last=null;bd.set(ck.s,null);say();};}
  var CK_LES=[
    {t:'\uD83D\uDD34 Setting up + moving',x:'Checkers is played on the <b>dark squares</b> only. Each player starts with 12 pieces. Regular pieces move <b>one square diagonally forward</b>. Red goes first.'},
    {t:'\uD83E\uDD98 Jumping',x:'If an enemy piece is diagonally next to you and the square behind it is empty, you <b>jump over it</b> and take it off the board. <b>If you can jump, you must jump!</b>'},
    {t:'\u26A1 Double jumps',x:'After a jump, if you can jump <b>again</b> from where you landed, you keep going in the same turn. Chains of 2, 3 or more jumps are legal and super strong.'},
    {t:'\uD83D\uDC51 Kings',x:'When your piece reaches the far row it becomes a <b>king</b>. Kings can move and jump diagonally <b>forward and backward</b>. They are worth a lot, so get kings!'},
    {t:'\uD83C\uDFC6 How to win',x:'You win when the other player has <b>no pieces left</b> or <b>no legal moves</b>. If nobody can make progress for a long time, it\u2019s a draw.'},
    {t:'\uD83D\uDCA1 Winning tips',x:'1) Keep your <b>back row</b> filled so the computer can\u2019t get kings easily. 2) Pieces on the <b>edges</b> are safe because they can\u2019t be jumped. 3) Move in <b>pairs</b> so pieces protect each other. 4) Before moving, check: can they jump me after this?'}];
  function ckLes(ix){ix=ix||0;var L=CK_LES[ix];X.ttl().textContent='\uD83C\uDF93 Checkers '+(ix+1)+'/'+CK_LES.length;var b=X.body();var tt=X.teacher('mid');X.teach(tt,'focus',L.t);
    b.appendChild(el('div','bd-les','<h3>'+L.t+'</h3><p class="ls-x">'+L.x+'</p>'));
    var demo=el('div','bd-wrap bd-small');b.appendChild(demo);var s=ckStart();if(ix===1||ix===2){s={b:[],turn:'r',quiet:0};for(var i=0;i<64;i++)s.b.push('');s.b[45]='r';s.b[36]='b';s.b[20]='b';s.b[3]='b';}
    if(ix===3){s={b:[],turn:'r',quiet:0};for(var j=0;j<64;j++)s.b.push('');s.b[10]='r';s.b[44]='R';}
    var stl=el('p','bd-st',ix===1?'\uD83C\uDFAF Try it: jump the black piece!':(ix===2?'\uD83C\uDFAF Try a double jump: tap each landing square.':(ix===3?'\uD83C\uDFAF Move the red piece to the top row to make a king.':'\uD83C\uDFAF Try a move!')));b.appendChild(stl);
    var bd=ckBoard(demo,{s:s,onNote:function(t){stl.textContent='\u26A1 '+t;},onMove:function(m){var n=ckMake(s,m);n.turn='r';s=n;bd.set(n,m.path);stl.innerHTML=m.caps.length>1?'\u2705 <b>Double jump!</b> Awesome.':(m.caps.length?'\u2705 <b>Nice jump!</b>':(n.b[m.path[m.path.length-1]]==='R'&&ix===3?'\u2705 <b>King me!</b> \uD83D\uDC51':'\uD83D\uDC4D Good move.'));
      if(m.caps.length||ix===0||ix>=3)X.teach(tt,'pass','Great job! \uD83C\uDF89');}});
    b.appendChild(el('div','ls-btns','<button type="button" class="ls-b" id="bd-prev"'+(ix?'':' disabled')+'>\u2190 Back</button><button type="button" class="ls-b" id="bd-rst">\u21BA Reset</button><button type="button" class="ls-b ls-chk" id="bd-nx">'+(ix<CK_LES.length-1?'Next lesson \u2192':'\uD83E\uDD16 Play the computer')+'</button>'));
    $('bd-prev').onclick=function(){if(ix)X.show('ckles',ix-1);};$('bd-rst').onclick=function(){X.show('ckles',ix);};$('bd-nx').onclick=function(){if(ix<CK_LES.length-1)X.show('ckles',ix+1);else X.show('ckplay');};}
  X.reg('ckhome',ckHome);X.reg('ckplay',ckPlay);X.reg('ckles',ckLes);
})();
