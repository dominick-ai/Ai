/* Tabo AI is served from one Render origin; API requests stay same-origin. */
window.TABO_API_BASE = "";
