/* get.js: Ask Tabo install page (v2.6). Copy button + which device you're on. ES5. */
(function(W,D){
var ta=D.getElementById('g-code'),btn=D.getElementById('g-copy'),msg=D.getElementById('g-copied');
var ua=navigator.userAgent||'',ios=/iPad|iPhone|iPod/.test(ua)||(/Macintosh/.test(ua)&&navigator.maxTouchPoints>1);
D.getElementById(ios?'you-ios':'you-pc').hidden=false;
if(!ios){var sec=D.getElementById('computer'),ip=D.getElementById('ipad');if(sec&&ip&&ip.parentNode)ip.parentNode.insertBefore(sec,ip);var j=D.querySelector('.g-jump');if(j)j.insertBefore(D.getElementById('j-pc'),D.getElementById('j-ipad'));}
function done(ok){msg.textContent=ok?'\u2705 Copied! Now do step 2 \uD83D\uDC47':'Select the code below and copy it \uD83D\uDC47';if(!ok){var d=D.querySelector('.g-code');if(d)d.open=true;ta.focus();ta.select();}}
function fb(){var ok=false;try{ta.removeAttribute('readonly');ta.focus();ta.select();try{ta.setSelectionRange(0,ta.value.length);}catch(e){}ok=D.execCommand('copy');ta.setAttribute('readonly','');ta.blur();}catch(e){}done(ok);}
btn.onclick=function(){var t=ta.value;try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(function(){done(true);},fb);return;}}catch(e){}fb();};
var dr=D.getElementById('g-drag');if(dr)dr.addEventListener('click',function(){/* clicking it here just runs it on this page: a fine demo */},false);
})(window,document);
