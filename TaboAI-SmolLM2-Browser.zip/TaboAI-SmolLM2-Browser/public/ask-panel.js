/* ask-panel.js: Tabo AI v2.6 "💜 Ask Tabo anywhere" panel. ES5.
   Gets the page context (title, url, selection or readable text) from:
   1) the 💜 Ask Tabo bookmark / extension popup, by postMessage (only from window.parent; replies only to that origin), or
   2) the CSP fallback window: #c=<json> in the URL (moved into sessionStorage, then the hash is cleared).
   Answers through the normal /api/chat (Safety Shield on, never unhinged) with {page:{...}}. Nothing is stored server-side. */
(function(W,D){
'use strict';
var $=function(id){return D.getElementById(id);};
var log=$('ap-log'),inp=$('ap-in'),form=$('ap-form'),ctxEl=$('ap-ctx'),onEl=$('ap-on'),langs=$('ap-langs');
var inFrame=false;try{inFrame=W.parent&&W.parent!==W;}catch(e){inFrame=true;}
var parentOrigin=null,ctx=null,busy=false,hist=[],got=false,waitCtx=false;
var Q={
  sum:{t:'\uD83D\uDCDD Summarize this page',p:'Summarize this page for me in 3-5 short bullet points.'},
  eli:{t:'\uD83E\uDDD2 Explain like I\u2019m 10',p:'Explain what this page is about like I\u2019m 10 years old. Keep it short and fun.'},
  quiz:{t:'\u2753 Quiz me',p:'Make a quick 3-question multiple choice quiz (A/B/C) about this page. Put the correct answers at the very end on a line that starts with "Answers:".'}
};
var LANGS=[['Spanish','\uD83C\uDDEA\uD83C\uDDF8 Spanish'],['French','\uD83C\uDDEB\uD83C\uDDF7 French'],['Chinese','\uD83C\uDDE8\uD83C\uDDF3 Chinese'],['Hindi','\uD83C\uDDEE\uD83C\uDDF3 Hindi'],['Arabic','\uD83C\uDDF8\uD83C\uDDE6 Arabic'],['Portuguese','\uD83C\uDDE7\uD83C\uDDF7 Portuguese'],['German','\uD83C\uDDE9\uD83C\uDDEA German'],['Japanese','\uD83C\uDDEF\uD83C\uDDF5 Japanese'],['Korean','\uD83C\uDDF0\uD83C\uDDF7 Korean'],['English','\uD83C\uDDFA\uD83C\uDDF8 English']];
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');}
function trim(s){return String(s==null?'':s).replace(/^\s+|\s+$/g,'');}
function fmt(t){ /* tiny safe markdown: **bold**, *italic*, `code`, bullets, numbered lists, paragraphs */
  var lines=esc(t).split(/\n/),out=[],list=null;
  function close(){if(list){out.push('</'+list+'>');list=null;}}
  for(var i=0;i<lines.length;i++){var l=lines[i].replace(/^\s+|\s+$/g,''),m;
    l=l.replace(/\*\*([^*]+)\*\*/g,'<b>$1</b>').replace(/(^|[^*])\*([^*\n]+)\*(?!\*)/g,'$1<i>$2</i>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/^#{1,6}\s+/,'');
    if((m=/^[-\u2022*]\s+(.*)$/.exec(l))){if(list!=='ul'){close();out.push('<ul>');list='ul';}out.push('<li>'+m[1]+'</li>');}
    else if((m=/^\d+[.)]\s+(.*)$/.exec(l))){if(list!=='ol'){close();out.push('<ol>');list='ol';}out.push('<li>'+m[1]+'</li>');}
    else if(!l){close();}
    else{close();out.push('<p>'+l+'</p>');}}
  close();return out.join('');}
function bottom(){log.scrollTop=log.scrollHeight;}
function add(cls,html){var d=D.createElement('div');d.className='m '+cls;d.innerHTML=html;log.appendChild(d);bottom();return d;}
function host(u){var m=/^https?:\/\/([^\/?#]+)/i.exec(u||'');return m?m[1].replace(/^www\./,''):'';}
function showCtx(){
  if(!ctx||!ctx.x){ctxEl.className='ap-ctx warn';ctxEl.innerHTML='\uD83D\uDCC4 I can\u2019t read this page, but you can still ask me anything!';onEl.textContent=ctx&&ctx.u?host(ctx.u):'on any page';return;}
  ctxEl.className='ap-ctx';
  ctxEl.innerHTML=(ctx.s?'\u2702\uFE0F Your selection ('+ctx.x.length+' letters)':'\uD83D\uDCC4 Reading: <b>'+esc(ctx.t||host(ctx.u)||'this page')+'</b>');
  ctxEl.title=ctx.t||'';onEl.textContent=host(ctx.u)||'this page';}
function hello(){if(log.childNodes.length)return;var d=D.createElement('div');d.className='ap-hi';
  d.innerHTML='Hi! I\u2019m <b>Tabo</b> \uD83D\uDC9C Tap a button or ask me anything about this page.';log.appendChild(d);}
function setBusy(b){busy=b;var bs=D.querySelectorAll('.ap-q,.ap-l,.ap-send');for(var i=0;i<bs.length;i++)bs[i].disabled=b||(waitCtx&&bs[i].className.indexOf('ap-send')<0);}
function clean(c){if(!c||typeof c!=='object')return null;var x=trim(c.x).slice(0,6000);
  return {t:trim(c.t).slice(0,150),u:/^https?:\/\//i.test(String(c.u||''))?String(c.u).slice(0,300):'',x:x,s:!!c.s&&!!x};}
function setCtx(c){var n=clean(c);if(!n)return;var changed=!ctx||ctx.u!==n.u||ctx.x!==n.x;ctx=n;got=true;if(waitCtx){waitCtx=false;setBusy(busy);}showCtx();
  if(changed&&hist.length){hist=[];var d=D.createElement('div');d.className='ap-hi';d.textContent=n.s?'\u2702\uFE0F New selection! Ask away.':'\uD83D\uDCC4 New page! Ask away.';log.appendChild(d);bottom();}hello();}
function ask(prompt,label){
  prompt=trim(prompt).slice(0,280);if(!prompt||busy)return;setBusy(true);
  add('me',esc(label||prompt));hist.push({role:'user',content:prompt});if(hist.length>6)hist=hist.slice(-6);
  var t=add('bot','<span class="dots" aria-label="Tabo is thinking"><i></i><i></i><i></i></span>');
  var body={messages:hist.slice(-6)};if(ctx&&ctx.x)body.page={title:ctx.t,url:ctx.u,text:ctx.x,sel:ctx.s};
  var ctrl=('AbortController' in W)?new AbortController():null,timer=setTimeout(function(){if(ctrl)ctrl.abort();},30000);
  function fail(msg){clearTimeout(timer);hist.pop();t.className='m bot err';t.innerHTML=esc(msg);setBusy(false);bottom();}
  try{
  fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:ctrl?ctrl.signal:undefined})
   .then(function(r){return r.json()['catch'](function(){return {};});})
   .then(function(j){clearTimeout(timer);var out=j&&j.reply?String(j.reply):'';
     if(!out){fail(j&&j.error==='rate_limited'?'Whoa, slow down a little \uD83D\uDE05 Try again in a minute!':'Hmm, I couldn\u2019t answer that one \uD83D\uDCA4 Try again!');return;}
     hist.push({role:'assistant',content:out.slice(0,1200)});
     var ans='',m=/\n\s*\**\s*answers?\s*:?\**\s*:?([\s\S]*)$/i.exec(out);
     if(m&&/quiz/i.test(prompt)&&trim(m[1])){ans=trim(m[1]);out=out.slice(0,m.index);}
     var h=fmt(out);
     if(ans)h+='<div class="ap-ans"><button type="button" class="ap-ansb" aria-expanded="false">\uD83D\uDC40 Show answers</button><div class="ap-ansx" hidden>'+fmt(ans)+'</div></div>';
     if(j.page_blocked)h+='<span class="ap-tag">\uD83D\uDEE1\uFE0F The Safety Shield skipped this page\u2019s text</span>';
     t.className='m bot';t.innerHTML=h;setBusy(false);
     var b=t.querySelector('.ap-ansb');if(b)b.onclick=function(){var x=t.querySelector('.ap-ansx');x.hidden=!x.hidden;b.setAttribute('aria-expanded',x.hidden?'false':'true');b.textContent=x.hidden?'\uD83D\uDC40 Show answers':'\uD83D\uDE48 Hide answers';bottom();};
     t.scrollIntoView?log.scrollTop=Math.max(0,t.offsetTop-log.offsetTop-8):bottom();})
   ['catch'](function(){fail('I couldn\u2019t reach my brain \uD83D\uDE35 Check your wifi and try again!');});
  }catch(e){fail('Something went wrong, try again!');}
}
/* quick buttons */
var qs=D.querySelectorAll('.ap-q');
for(var i=0;i<qs.length;i++)(function(b){b.onclick=function(){var k=b.getAttribute('data-q');
  if(k==='tr'){var open=langs.hidden;langs.hidden=!open;b.setAttribute('aria-expanded',open?'true':'false');if(open){var f=langs.querySelector('button');if(f&&kb)f.focus();}return;}
  langs.hidden=true;ask(Q[k].p,Q[k].t);};})(qs[i]);
for(var j=0;j<LANGS.length;j++)(function(L){var b=D.createElement('button');b.type='button';b.className='ap-l';b.textContent=L[1];
  b.onclick=function(){langs.hidden=true;$('ap-quick').querySelector('[data-q=tr]').setAttribute('aria-expanded','false');
    ask('Translate '+(ctx&&ctx.s?'the selected text':'the main idea of this page (a short summary, then translate it)')+' into '+L[0]+'. Keep it short.','\uD83C\uDF0D Translate to '+L[0]);};
  langs.appendChild(b);})(LANGS[j]);
/* typing box */
function grow(){inp.style.height='auto';inp.style.height=Math.min(110,inp.scrollHeight+2)+'px';}
inp.oninput=grow;
inp.onkeydown=function(e){if((e.key==='Enter'||e.keyCode===13)&&!e.shiftKey&&!e.isComposing){e.preventDefault();submit();}};
function submit(){var v=trim(inp.value);if(!v||busy)return;inp.value='';grow();ask(v);}
form.onsubmit=function(e){e.preventDefault();submit();};
/* close: tell the page (bookmark/extension) to hide us; a popup window closes itself */
function closeMe(){
  if(inFrame&&parentOrigin){try{W.parent.postMessage({tabo:'close'},parentOrigin);}catch(e){}return;}
  if(inFrame){try{W.parent.postMessage({tabo:'close'},'*');}catch(e){}return;}
  try{W.close();}catch(e){}
  if(!W.closed)location.href='https://taboai.sites.tab.bot/';}
$('ap-x').onclick=closeMe;
var kb=false;
D.addEventListener('keydown',function(e){kb=true;if(e.key==='Escape'||e.keyCode===27){
  if(!langs.hidden){langs.hidden=true;var tb=$('ap-quick').querySelector('[data-q=tr]');tb.setAttribute('aria-expanded','false');tb.focus();e.preventDefault();return;}
  e.preventDefault();closeMe();}},true);
D.addEventListener('mousedown',function(){kb=false;},true);D.addEventListener('touchstart',function(){kb=false;},true);
/* the "Open in Tabo AI" link opens the full app (in the extension popup it needs a new tab) */
/* 1) postMessage from the page that opened us (bookmark iframe or extension popup) */
W.addEventListener('message',function(e){
  if(!inFrame||e.source!==W.parent)return;var d=e.data;if(!d||typeof d!=='object'||d.tabo!=='ctx')return;
  if(parentOrigin&&e.origin!==parentOrigin)return;parentOrigin=e.origin;setCtx(d.ctx);
  if(d.focus){var f=D.querySelector('.ap-q');if(f)try{f.focus();}catch(x){}}
});
/* 2) the CSP fallback window: #c=<json> (or what we saved from it in this tab) */
function fromHash(){var h=location.hash||'',c=null;
  if(h.indexOf('#c=')===0){try{c=JSON.parse(decodeURIComponent(h.slice(3)));}catch(e){c=null;}
    try{sessionStorage.setItem('tabo_ask_ctx',JSON.stringify(clean(c)));}catch(e){}
    try{history.replaceState(null,'',location.pathname+location.search);}catch(e){}}
  if(!c){try{c=JSON.parse(sessionStorage.getItem('tabo_ask_ctx')||'null');}catch(e){c=null;}}
  return c;}
var hc=fromHash();
if(hc)setCtx(hc);
if(inFrame&&!hc){waitCtx=true;ctxEl.className='ap-ctx';ctxEl.innerHTML='<span class="ap-spin" aria-hidden="true"></span> \uD83D\uDCC4 Reading\u2026';setBusy(false);}
if(inFrame){var tries=0;(function ping(){if(got)return;try{W.parent.postMessage({tabo:'ready'},'*');}catch(e){}if(++tries<80)setTimeout(ping,250);else if(!got){waitCtx=false;setBusy(busy);ctx=null;showCtx();hello();}})();}
else if(!hc){ctx=null;got=true;showCtx();ctxEl.innerHTML='\uD83D\uDC9C Tip: use the <b>Ask Tabo</b> bookmark on any website and I\u2019ll read that page!';hello();}
W.taboAsk={ask:ask,ctx:function(){return ctx;}}; /* test hook */
})(window,document);
