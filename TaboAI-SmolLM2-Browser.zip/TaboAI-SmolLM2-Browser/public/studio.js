/* studio.js (Tabo v1.9.6): 🎤 SONG STUDIO, an UTAU-style singing toy. the user Nov 1 7:13 PM: "the Good News voice sounds like a UTAU potential,
   make a studio where you can mess around with that voice and make songs, adjusted to the best setting for the song, just put in lyrics and boom".
   100% in the browser: Web Speech (speechSynthesis) sings, Web Audio plays the beat. No keys, no server, no audio stored anywhere.
   ✨ Auto reads the lyrics (syllables, lines, a happy/sad/spooky/calm/hype word scorer) and picks style, key and tempo; sliders/chips tweak it.
   Normal voices: one utterance per word, pitch from the melody note, rate from the note length, fired on the beat by our own timer.
   Singing novelty voices (Good News, Bad News, Cellos, Bells, Organ): they already sing, so one utterance per LINE, lined up with the bar.
   The beat runs on the AudioContext clock; speech re-syncs at the start of every line (leftovers are cancelled) so the backing never drifts.
   Karaoke + bouncing apple (pumpkin in the Halloween look) are driven by our timer, because iOS often skips speech boundary events.
   🎲 Write me lyrics = ONE /api/chat call (same Safety Shield, same picked model). 💾 Save keeps 10 songs in localStorage. ES5 only. */
(function(W,D){
  'use strict';
  var SS=function(){return W.speechSynthesis||null;};
  var PK='hc_studio_v1',SK='hc_studio_songs_v1',MAXC=300,MAXSONGS=10;
  var SINGERS=['good news','bad news','cellos','bells','organ','pipe organ'];
  var NOVELTY=['good news','bad news','cellos','bells','organ','pipe organ','superstar','boing','bubbles','jester','trinoids','whisper','wobble','zarvox','albert','fred','junior','ralph','kathy','hysterical','bahh'];
  var STYLES={
    pop:{n:'Pop',e:'\uD83C\uDFB5',bpm:112,mode:'maj',spv:1,chords:[0,4,5,3],
      mel:[0,2,4,4,5,4,2,1,2,4,5,7,5,4,2,0],range:1,
      kick:[1,0,0,0,1,0,1,0],snare:[0,0,1,0,0,0,1,0],hat:[1,1,1,1,1,1,1,1],bass:[1,0,0,1,1,0,1,0],pad:'triangle',pv:.05},
    lullaby:{n:'Lullaby',e:'\uD83C\uDF19',bpm:82,mode:'maj',spv:2,chords:[0,3,0,4],
      mel:[4,2,0,2,4,4,4,3,1,3,4,2,1,0],range:1,
      kick:[1,0,0,0,0,0,0,0],snare:[0,0,0,0,0,0,0,0],hat:[0,0,1,0,0,0,1,0],bass:[1,0,0,0,1,0,0,0],pad:'sine',pv:.07},
    rock:{n:'Rock',e:'\uD83C\uDFB8',bpm:134,mode:'maj',spv:1,chords:[0,3,4,3],
      mel:[0,0,2,0,4,4,2,0,5,5,4,2,4,2,0,0],range:1,
      kick:[1,0,0,1,1,0,0,0],snare:[0,0,1,0,0,0,1,0],hat:[1,1,1,1,1,1,1,1],bass:[1,1,1,1,1,1,1,1],pad:'sawtooth',pv:.025},
    spooky:{n:'Spooky',e:'\uD83D\uDC7B',bpm:96,mode:'min',spv:1,chords:[0,5,3,4],
      mel:[0,1,0,-1,0,2,1,0,4,3,2,1,0,-1,-2,0],range:1,
      kick:[1,0,0,0,0,1,0,0],snare:[0,0,0,0,1,0,0,0],hat:[0,1,0,1,0,1,0,1],bass:[1,0,0,0,1,0,0,1],pad:'square',pv:.022},
    rap:{n:'Rap',e:'\uD83C\uDFA4',bpm:92,mode:'min',spv:1,chords:[0,5,2,6],
      mel:[0,0,0,1,0,0,2,0],range:.4,
      kick:[1,0,0,1,0,1,0,0],snare:[0,0,1,0,0,0,1,0],hat:[1,1,1,1,1,1,1,1],bass:[1,0,0,1,0,1,0,0],pad:'triangle',pv:.03}
  };
  var SORDER=['pop','lullaby','rock','spooky','rap'];
  var KEYS=['C maj','D maj','E maj','F maj','G maj','A maj','A min','B min','C min','D min','E min','G min'];
  var NOTE={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
  var SCALE={maj:[0,2,4,5,7,9,11],min:[0,2,3,5,7,8,10]};
  var MOODW={
    happy:/\b(happy|fun|love|loves?|sun|sunny|smile|smiles|dance|dancing|play|playing|yay|party|friends?|joy|awesome|best|cool|sing|bright|good|great|candy|pizza|cake|laugh|hooray|win|wins|yeah|sweet|shine|summer|gold|golden)\b/g,
    sad:/\b(sad|cry|cries|crying|tears?|alone|lonely|miss|missing|lost|goodbye|bye|rain|raining|gone|broken|sorry|hurt|gray|grey|cold|nobody|empty|sigh|blue)\b/g,
    spooky:/\b(ghosts?|spooky|boo|witch(es)?|skeletons?|zombies?|haunted|pumpkins?|bats?|creepy|monsters?|dark|darkness|fog|howl|scream|vampires?|halloween|spiders?|graves?|mummy|creak|shadows?|eerie|trick|treat)\b/g,
    calm:/\b(sleep|sleepy|dream|dreams|moon|stars?|night|soft|quiet|bed|lullaby|slow|gentle|hush|calm|cozy|blanket|goodnight|rest|twinkle|sky|clouds?)\b/g,
    hype:/\b(rock|loud|run|fast|go|power|fire|guitar|jump|shout|epic|boss|level|speed|racing|race|thunder|storm|crazy|wild|beat|smash|turbo|max)\b/g,
    rap:/\b(rap|yo|flow|mic|rhymes?|bars|spit|beatbox|drop)\b/g
  };
  var EMO={happy:/(\uD83D\uDE00|\uD83D\uDE04|\uD83C\uDF89|\uD83E\uDD73|\u2600|\u2764)/g,sad:/(\uD83D\uDE22|\uD83D\uDE2D|\uD83D\uDC94)/g,spooky:/(\uD83C\uDF83|\uD83D\uDC7B|\uD83E\uDDDF|\uD83E\uDD87|\uD83D\uDD77|\uD83D\uDC80)/g,calm:/(\uD83C\uDF19|\u2B50|\uD83D\uDE34|\uD83C\uDF1F)/g};

  function $(id){return D.getElementById(id);}
  function el(t,c,h){var e=D.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;}
  function esc(s){return String(s).replace(/[&<>"]/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c];});}
  function hw(){return (' '+D.documentElement.className+' ').indexOf(' hw ')>=0;}
  function clamp(v,a,b){return v<a?a:(v>b?b:v);}
  function lsGet(k,d){try{var v=localStorage.getItem(k);return v?JSON.parse(v):d;}catch(e){return d;}}
  function lsSet(k,v){try{localStorage.setItem(k,JSON.stringify(v));}catch(e){}}
  function toast(t){try{if(W.hcApp&&W.hcApp.toast){W.hcApp.toast(t);return;}}catch(e){}}

  /* ---------- lyrics -> lines -> words -> syllables ---------- */
  function syl(w){w=String(w).toLowerCase().replace(/[^a-z0-9]/g,'');if(!w)return 0;if(/^[0-9]+$/.test(w))return Math.min(3,w.length);
    if(w.length<=3)return 1;w=w.replace(/(?:[^laeiouy]es|[^laeiouy]ed|[^laeiouy]e)$/,'').replace(/^y/,'');var m=w.match(/[aeiouy]{1,2}/g);return m?Math.max(1,m.length):1;}
  var CODE_RE=/HCS1-([a-z]+)-([A-G])(maj|min)-(\d{2,3})-p(-?\d+)/;
  function stripCode(t){return String(t||'').replace(/^.*HCS1-[^\n]*$/mg,'').replace(/\s+$/,'');}
  function lines(text){var raw=stripCode(text).split(/\r?\n/),out=[],i,j;
    for(i=0;i<raw.length;i++){var l=raw[i].replace(/^\s*([-*\u2022]|\d+[.)])\s+/,'').replace(/\s+/g,' ').replace(/^\s+|\s+$/g,'');if(!l)continue;
      var ws=l.split(' ');if(ws.length<=10){out.push(ws);continue;}
      for(j=0;j<ws.length;j+=7){var c=ws.slice(j,j+7);if(c.length<3&&out.length&&j>0){out[out.length-1]=out[out.length-1].concat(c);}else out.push(c);}}
    return out.slice(0,14);}
  function sayable(w){return String(w).replace(/^[^A-Za-z0-9']+|[^A-Za-z0-9'!?]+$/g,'');}

  /* ---------- ✨ Auto: mood + settings ---------- */
  function cnt(re,t){re.lastIndex=0;var m=t.match(re);return m?m.length:0;}
  function analyze(text){var t=stripCode(text),low=t.toLowerCase(),ls=lines(t),i,j,sy=0,words=0;
    for(i=0;i<ls.length;i++)for(j=0;j<ls[i].length;j++){var s=syl(ls[i][j]);if(s){sy+=s;words++;}}
    var sc={};for(var k in MOODW)if(MOODW.hasOwnProperty(k))sc[k]=cnt(MOODW[k],low);
    for(k in EMO)if(EMO.hasOwnProperty(k))sc[k]+=2*cnt(EMO[k],t);
    var ex=(t.match(/!/g)||[]).length;sc.happy+=Math.min(2,ex)*.5;sc.hype+=ex>=3?1:0;
    if(/\bnot (happy|good|fun)\b/.test(low)){sc.sad+=2;sc.happy-=1;}
    if(hw())sc.spooky+=.5;
    var avg=ls.length?sy/ls.length:0;if(avg>11)sc.rap+=1.5;
    var mood='happy',best=.9;var order=['spooky','sad','calm','hype','rap','happy'];
    for(i=0;i<order.length;i++)if(sc[order[i]]>best){best=sc[order[i]];mood=order[i];}
    return {mood:mood,sc:sc,syl:sy,words:words,lines:ls.length,avg:avg};}
  function hash(s){var h=7;for(var i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))%100003;return h;}
  var MOODMAP={
    happy:{style:'pop',keys:['C maj','G maj','D maj','F maj'],lbl:'Happy pop',e:'\uD83C\uDFB5'},
    sad:{style:'lullaby',keys:['A min','E min','D min'],lbl:'Sad ballad',e:'\uD83D\uDE22',bpm:-4},
    spooky:{style:'spooky',keys:['D min','E min','C min','G min'],lbl:'Spooky',e:'\uD83C\uDF83'},
    calm:{style:'lullaby',keys:['F maj','C maj','G maj'],lbl:'Sleepy lullaby',e:'\uD83C\uDF19'},
    hype:{style:'rock',keys:['E maj','A maj','D maj'],lbl:'Hype rock',e:'\uD83C\uDFB8'},
    rap:{style:'rap',keys:['A min','C min','E min'],lbl:'Rap',e:'\uD83C\uDFA4'}
  };
  function autoPick(text){var a=analyze(text),m=MOODMAP[a.mood],st=STYLES[m.style],h=hash(stripCode(text));
    var bpm=st.bpm+(m.bpm||0);if(a.avg>10)bpm+=8;else if(a.avg&&a.avg<5)bpm-=6;bpm+=(h%3-1)*4;
    var lo=m.style==='lullaby'?74:80,hi=m.style==='rock'?146:140;bpm=clamp(Math.round(bpm/2)*2,lo,hi);
    return {style:m.style,key:m.keys[h%m.keys.length],bpm:bpm,pitch:0,mood:a.mood,lbl:m.lbl,e:m.e,an:a};}

  /* ---------- state ---------- */
  var pref=lsGet(PK,{});
  var S={auto:pref.auto!==false,style:pref.style||'pop',key:pref.key||'C maj',bpm:pref.bpm||112,pitch:pref.pitch||0,loop:!!pref.loop,voice:pref.voice||'',lyr:typeof pref.lyr==='string'?pref.lyr:'',lbl:'',mood:''};
  function savePref(){lsSet(PK,{auto:S.auto,style:S.style,key:S.key,bpm:S.bpm,pitch:S.pitch,loop:S.loop,voice:S.voice,lyr:S.lyr});}
  var voices=[];
  function vname(v){return String(v&&v.name||'');}
  function isNov(v){var n=vname(v).toLowerCase().replace(/\s*\(.*\)\s*$/,'');for(var i=0;i<NOVELTY.length;i++)if(n===NOVELTY[i])return true;return false;}
  function isSinger(v){var n=vname(v).toLowerCase().replace(/\s*\(.*\)\s*$/,'');for(var i=0;i<SINGERS.length;i++)if(n===SINGERS[i])return true;return false;}
  function novRank(v){var n=vname(v).toLowerCase().replace(/\s*\(.*\)\s*$/,'');var i=SINGERS.indexOf(n);if(i>=0)return i;i=NOVELTY.indexOf(n);return i>=0?10+i:99;}
  function loadVoices(){var s=SS(),all=[],nov=[],en=[],i;if(!s)return;try{all=s.getVoices()||[];}catch(e){}
    for(i=0;i<all.length;i++){var v=all[i];if(isNov(v))nov.push(v);else if(/^en/i.test(String(v.lang||'')))en.push(v);}
    nov.sort(function(a,b){return novRank(a)-novRank(b);});
    var seen={};voices=[];for(i=0;i<nov.length;i++)if(!seen[vname(nov[i])]){seen[vname(nov[i])]=1;voices.push(nov[i]);}
    for(i=0;i<en.length;i++)if(!seen[vname(en[i])]){seen[vname(en[i])]=1;voices.push(en[i]);}
    if(!S.voice&&voices.length){S.voice=vname(voices[0]);}
    renderVoices();}
  function curVoice(){for(var i=0;i<voices.length;i++)if(vname(voices[i])===S.voice)return voices[i];return null;}
  function singerOn(){var v=curVoice();return !!(v&&isSinger(v));}

  /* ---------- the song plan (eighth-note grid) ---------- */
  function keyInfo(k){var p=String(k).split(' ');return {root:NOTE[p[0]]||0,mode:p[1]==='min'?'min':'maj'};}
  function degSemi(d,mode){var sc=SCALE[mode],o=Math.floor(d/7),i=((d%7)+7)%7;return sc[i]+12*o;}
  function build(){var ls=lines(S.lyr),st=STYLES[S.style],ki=keyInfo(S.key),singer=singerOn(),ev=[],step=0,li,wi,mi=0;
    var spv=st.spv;var maxSyl=0;for(li=0;li<ls.length;li++){var c=0;for(wi=0;wi<ls[li].length;wi++)c+=syl(ls[li][wi]);if(c>maxSyl)maxSyl=c;}
    if(spv>1&&maxSyl*spv>30)spv=1;
    var lineInfo=[],tr=ki.root>6?ki.root-12:ki.root;
    for(li=0;li<ls.length;li++){var ws=ls[li],need=0,sy=[];for(wi=0;wi<ws.length;wi++){sy.push(syl(ws[wi]));need+=sy[wi]*spv;}
      var bars=need+2<=8?1:(need+2<=16?2:(need+2<=24?3:4));if(bars===3)bars=4;if(bars===1&&ls.length>1)bars=2;
      var len=bars*8,start=step,pos=start,sylDone=0,totalSyl=0;for(wi=0;wi<sy.length;wi++)totalSyl+=sy[wi];
      var lineEv=[];
      for(wi=0;wi<ws.length;wi++){var s=sy[wi];var d=s*spv;
        if(wi===ws.length-1||(s>0&&wi===lastSyl(sy)))d=Math.max(d,Math.min(start+len-pos-1,d+3));
        var deg=0;if(s>0){deg=st.mel[mi%st.mel.length];mi++;if(wi===lastSyl(sy))deg=(li%2)?4:0;mi+=s-1;}
        var semi=degSemi(deg,ki.mode)*st.range+tr*.5+S.pitch;
        var pit=clamp(Math.pow(2,(semi-4)/12),.5,2);
        lineEv.push({li:li,wi:wi,t:pos,d:s?d:0,syl:s,text:sayable(ws[wi]),pitch:pit,word:ws[wi]});
        pos+=s?d:0;sylDone+=s;}
      lineInfo.push({start:start,len:len,syl:totalSyl,words:ws});
      for(wi=0;wi<lineEv.length;wi++)ev.push(lineEv[wi]);
      step=start+len;}
    return {ls:ls,ev:ev,lines:lineInfo,body:step,st:st,ki:ki,singer:singer,spv:spv};}
  function lastSyl(sy){for(var i=sy.length-1;i>=0;i--)if(sy[i]>0)return i;return -1;}

  /* ---------- Web Audio backing track ---------- */
  var AC=null,master=null,noiseBuf=null;
  function audio(){if(AC)return AC;var C=W.AudioContext||W.webkitAudioContext;if(!C)return null;try{AC=new C();}catch(e){AC=null;return null;}
    master=AC.createGain();master.gain.value=.55;master.connect(AC.destination);
    var n=Math.floor(AC.sampleRate*.5);noiseBuf=AC.createBuffer(1,n,AC.sampleRate);var d=noiseBuf.getChannelData(0);for(var i=0;i<n;i++)d[i]=Math.random()*2-1;return AC;}
  var nodes=0;
  function env(g,t,a,peak,dec){g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(peak,t+a);g.gain.exponentialRampToValueAtTime(.0001,t+a+dec);}
  function kick(t,v){var o=AC.createOscillator(),g=AC.createGain();o.type='sine';o.frequency.setValueAtTime(150,t);o.frequency.exponentialRampToValueAtTime(42,t+.18);env(g,t,.004,.9*v,.28);o.connect(g);g.connect(master);o.start(t);o.stop(t+.35);nodes++;}
  function noise(t,hp,peak,dec){var s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=noiseBuf;f.type='highpass';f.frequency.value=hp;env(g,t,.002,peak,dec);s.connect(f);f.connect(g);g.connect(master);s.start(t);s.stop(t+dec+.05);nodes++;}
  function snare(t,v){noise(t,1500,.45*v,.16);var o=AC.createOscillator(),g=AC.createGain();o.type='triangle';o.frequency.setValueAtTime(220,t);env(g,t,.002,.25*v,.09);o.connect(g);g.connect(master);o.start(t);o.stop(t+.12);}
  function hat(t,v){noise(t,7000,.12*v,.045);}
  function midiHz(m){return 440*Math.pow(2,(m-69)/12);}
  function tone(type,m,t,dur,peak,lp){var o=AC.createOscillator(),g=AC.createGain(),last=g;o.type=type;o.frequency.setValueAtTime(midiHz(m),t);
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(peak,t+.02);g.gain.setValueAtTime(peak,t+Math.max(.03,dur*.6));g.gain.exponentialRampToValueAtTime(.0001,t+dur);
    o.connect(g);if(lp){var f=AC.createBiquadFilter();f.type='lowpass';f.frequency.value=lp;g.connect(f);last=f;}last.connect(master);o.start(t);o.stop(t+dur+.05);nodes++;}

  /* ---------- player ---------- */
  var P=null,timer=null,unlocked=false;
  function eighth(){return 60/S.bpm/2;}
  function clock(){if(P&&P.ac&&AC&&AC.state==='running')return AC.currentTime-P.t0;return (Date.now()-P.d0)/1000;}
  var INTRO=8;
  function stepInfo(g){var rel=g-INTRO;if(rel<0)return {intro:true,bar:0,i:g};var body=P.plan.body,pass=Math.floor(rel/body),r=rel-pass*body;
    for(var p=0;p<pass;p++){if(!decide(p))return (pass===p+1&&r<8)?{outro:true,bar:0,i:r}:null;}
    return {bar:Math.floor(r/8),i:r%8};}
  function decide(pass){if(P.dec[pass]==null)P.dec[pass]=!!S.loop;return P.dec[pass];}
  function schedule(){if(!P||!P.ac)return;var e8=P.e8,ahead=AC.currentTime+.16;
    while(P.t0+P.g*e8<ahead){var t=P.t0+P.g*e8,inf=stepInfo(P.g);if(inf===null){P.g=1e9;break;}
      var st=P.plan.st,ki=P.plan.ki,i=inf.i%8,cd=st.chords[inf.bar%st.chords.length],v=inf.intro?.6:1;
      if(t>=AC.currentTime-.01){
        if(inf.intro){if(i%2===0)hat(t,.8);if(i===0)kick(t,.7);}
        else{if(st.kick[i])kick(t,v);if(st.snare[i])snare(t,v);if(st.hat[i])hat(t,i%2?.6:1);
          var rootSemi=ki.root+degSemi(cd,ki.mode);var bm=36+(rootSemi%12);if(bm>43)bm-=12;
          if(st.bass[i])tone(S.style==='rock'?'sawtooth':'triangle',bm+(S.style==='spooky'&&i===7?12:0),t,e8*(S.style==='lullaby'?3.6:.9),S.style==='rock'?.16:.32,S.style==='rock'?700:900);
          if(i===0||(S.style==='rock'&&i===4)){var pd=e8*(S.style==='rock'?4:8)*.98;
            for(var n=0;n<3;n++){var sm=ki.root+degSemi(cd+2*n,ki.mode);tone(st.pad,60+((sm%12)+12)%12-(n===0?0:0),t,pd,st.pv,S.style==='lullaby'?1800:2400);}}}}
      P.g++;}}
  function speak(text,pitch,rate,isLine){var s=SS();if(!s||!text)return;var u;try{u=new W.SpeechSynthesisUtterance(text);}catch(e){return;}
    var v=curVoice();if(v){u.voice=v;if(v.lang)u.lang=v.lang;}u.pitch=pitch;u.rate=rate;u.volume=1;try{s.speak(u);}catch(e){}
    P.utt.push({text:text,pitch:Math.round(pitch*100)/100,rate:Math.round(rate*100)/100,line:!!isLine,at:Math.round(clock()*100)/100});}
  function tick(){if(!P)return;if(P.ac)schedule();var now=clock(),e8=P.e8,plan=P.plan;
    if(P.done){if(now>=P.endT){stop(true);}return;}
    var base=INTRO+P.pass*plan.body;
    while(P.ix<plan.ev.length){var ev=plan.ev[P.ix],t=(base+ev.t)*e8;if(now<t-.02)break;
      var lateLine=now-t>e8*2;
      if(ev.wi===0){var li=plan.lines[ev.li];var s=SS();
        if(s&&P.ix>0&&(s.pending||(plan.singer&&s.speaking))){try{s.cancel();}catch(e){}P.resync++;}
        if(plan.singer){var dur=li.len*e8*.88,nat=Math.max(1,li.syl)/2.7;speak(li.words.join(' ').replace(CODE_RE,''),clamp(ev.pitch,.7,1.5),clamp(nat/dur,.5,1.7),true);}}
      if(!plan.singer&&ev.syl>0&&ev.text&&!lateLine){var ds=ev.d*e8,rate=clamp((ev.syl/ds)/3.6,.6,1.8);speak(ev.text,ev.pitch,rate,false);}
      light(ev);P.ix++;}
    if(P.ix>=plan.ev.length){var bnd=(INTRO+(P.pass+1)*plan.body)*e8;
      if(now>=bnd-.03){if(decide(P.pass)){P.pass++;P.ix=0;}else{P.done=true;P.endT=bnd+8*e8;unlight();}}}}
  function play(){var s=SS();stop(false);savePref();if(W.hcVoice&&W.hcVoice.stop){try{W.hcVoice.stop();}catch(e){}}
    var safe=check(S.lyr);if(!safe.ok){setTip('\uD83D\uDEE1\uFE0F '+safe.why);return;}
    if(!stripCode(S.lyr).replace(/\s/g,'')){setTip('\u270F\uFE0F Type some lyrics first (or tap \uD83C\uDFB2)!');ui.lyr.focus();return;}
    if(S.auto)applyAuto(false);
    var plan=build();if(!plan.ev.length){setTip('\u270F\uFE0F Those lyrics have no words I can sing.');return;}
    var ac=audio();
    if(ac&&ac.state==='suspended'){try{ac.resume();}catch(e){}}
    if(s&&!unlocked){try{var u0=new W.SpeechSynthesisUtterance(' ');u0.volume=0;s.speak(u0);}catch(e){}unlocked=true;}
    P={plan:plan,ac:!!ac,t0:ac?ac.currentTime+.12:0,d0:Date.now()+120,g:0,e8:eighth(),ix:0,pass:0,dec:{},endPass:null,done:false,utt:[],resync:0,lit:-1};
    renderKaraoke(plan);ui.ov.className+=' hs-playing';ui.play.disabled=true;
    timer=setInterval(tick,25);tick();}
  function stop(natural){if(timer){clearInterval(timer);timer=null;}var s=SS();if(P){if(s){try{s.cancel();}catch(e){}}P.stopped=true;}
    if(AC&&P&&P.ac){try{master.gain.cancelScheduledValues(AC.currentTime);master.gain.setValueAtTime(.0001,AC.currentTime);}catch(e){}
      var old=master;try{master=AC.createGain();master.gain.value=.55;master.connect(AC.destination);setTimeout(function(){try{old.disconnect();}catch(e){}},300);}catch(e){}}
    W.__hsLast=P;P=null;if(ui.ov){ui.ov.className=ui.ov.className.replace(/\s*hs-playing/g,'');ui.play.disabled=false;}unlight();}

  /* ---------- karaoke ---------- */
  function renderKaraoke(plan){var h='',li,wi;var ls=plan?plan.ls:lines(S.lyr);
    if(!ls.length){ui.kar.innerHTML='<p class="hs-ph">Type lyrics below, then tap Play</p>';ui.kar.appendChild(ui.ball);return;}
    for(li=0;li<ls.length;li++){h+='<p class="hs-ln" data-l="'+li+'">';for(wi=0;wi<ls[li].length;wi++)h+='<span class="hs-w" data-w="'+li+'_'+wi+'">'+esc(ls[li][wi])+'</span> ';h+='</p>';}
    ui.kar.innerHTML=h;ui.kar.scrollTop=0;ui.kar.appendChild(ui.ball);ui.ball.style.opacity='0';}
  function light(ev){var w=ui.kar.querySelector('[data-w="'+ev.li+'_'+ev.wi+'"]');if(!w)return;
    var old=ui.kar.querySelectorAll('.hs-w.on,.hs-ln.on');for(var i=0;i<old.length;i++)old[i].className=old[i].className.replace(/\s*on\b/g,'');
    w.className+=' on';var ln=w.parentNode;ln.className+=' on';
    var past=ui.kar.querySelectorAll('[data-w]');
    if(ln.offsetTop-ui.kar.scrollTop>ui.kar.clientHeight*.55||ln.offsetTop<ui.kar.scrollTop)ui.kar.scrollTop=Math.max(0,ln.offsetTop-ui.kar.clientHeight*.3);
    ui.ball.innerHTML=hw()?'\uD83C\uDF83':'\uD83D\uDC9C';ui.ball.style.opacity='1';
    ui.ball.style.left=(w.offsetLeft+w.offsetWidth/2-13)+'px';ui.ball.style.top=Math.max(2,w.offsetTop-27)+'px';
    ui.ball.className='hs-ball';void ui.ball.offsetWidth;ui.ball.className='hs-ball hs-hop';if(P)P.lit=ev.li*100+ev.wi;}
  function unlight(){if(!ui.kar)return;var old=ui.kar.querySelectorAll('.on');for(var i=0;i<old.length;i++)old[i].className=old[i].className.replace(/\s*on\b/g,'');if(ui.ball)ui.ball.style.opacity='0';}

  /* ---------- client check (the chat has no client filter; this is a tiny one for typed lyrics, the AI path also gets the server Shield) ---------- */
  function check(t){var d=W.hcDevSafe;if(d&&d.check){try{var r=d.check(String(t));if(r&&r.ok===false)return {ok:false,why:'The Safety Shield says those lyrics aren\u2019t kid-safe, try other words!'};}catch(e){}}return {ok:true};}

  /* ---------- 🎲 write me lyrics (ONE /api/chat) ---------- */
  var TOPICS=['pizza night','my cat','outer space','a snow day','soccer','dragons','a robot friend','the beach'],busyAI=false;
  function writeLyrics(){if(busyAI)return;var topic=String(ui.topic.value||'').replace(/\s+/g,' ').replace(/^\s|\s$/g,'').slice(0,60);
    if(!topic)topic=hw()?'Halloween night':TOPICS[Math.floor(Math.random()*TOPICS.length)];
    var q='Write fun kid-friendly song lyrics about: '+topic+'. Exactly 4 short rhyming lines, 5 to 8 words each. Reply with only the 4 lines, no title, no emoji.';
    var AI=W.domoAI,aim='sigma';try{aim=AI&&AI.model?AI.model():'sigma';}catch(e){}
    var body={messages:[{role:'user',content:q.slice(0,200)}]};if(aim&&aim!=='sigma')body.model=aim;
    busyAI=true;ui.dice.disabled=true;ui.dice.innerHTML='\u23F3 Writing\u2026';
    var ctrl=('AbortController' in W)?new AbortController():null,tm=setTimeout(function(){if(ctrl)ctrl.abort();},30000);
    function done(){clearTimeout(tm);busyAI=false;ui.dice.disabled=false;ui.dice.innerHTML='\uD83C\uDFB2 Write me lyrics';}
    fetch('/api/chat',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:ctrl?ctrl.signal:undefined})
      .then(function(r){return r.json()['catch'](function(){return {};});})
      .then(function(j){done();var out=j&&j.reply?String(j.reply):'';var ls=cleanAI(out);
        if(ls.length<2){setTip('\uD83E\uDD14 Hmm, that didn\u2019t come out as a song. Try another topic!');return;}
        stop(false);S.lyr=ls.join('\n').slice(0,MAXC);ui.lyr.value=S.lyr;onLyr();S.auto=true;applyAuto(true);setTip('\uD83C\uDFB2 Fresh lyrics about '+topic+'! Tap \u25B6\uFE0F');})
      ['catch'](function(){done();setTip('\uD83D\uDE35\u200D\uD83D\uDCAB Couldn\u2019t reach my brain, check your wifi and try again.');});}
  function cleanAI(t){t=String(t).replace(/\*\*|__|`/g,'').replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g,'');var raw=t.split(/\r?\n/),out=[];
    for(var i=0;i<raw.length;i++){var l=raw[i].replace(/^\s*([-*\u2022>]|\d+[.):])\s*/,'').replace(/^["\u201C]|["\u201D]$/g,'').replace(/^\s+|\s+$/g,'');
      if(!l||/:$/.test(l)||/^(verse|chorus|title|here (are|is)|sure|okay|ok\b)/i.test(l)||l.length>90)continue;out.push(l);if(out.length===4)break;}
    if(out.length<2&&t.length<400){var parts=t.replace(/\s+/g,' ').split(/(?:[.!?,;])\s+/);out=[];for(i=0;i<parts.length&&out.length<4;i++)if(parts[i].replace(/\s/g,'').length>3)out.push(parts[i].replace(/^\s+|\s+$/g,''));}
    return out;}

  /* ---------- songs: save / copy / load ---------- */
  function code(){var k=S.key.split(' ');return 'HCS1-'+S.style+'-'+k[0]+k[1]+'-'+S.bpm+'-p'+S.pitch;}
  function songs(){var a=lsGet(SK,[]);return a&&a.length!=null?a:[];}
  function saveSong(){var t=stripCode(S.lyr);if(!t.replace(/\s/g,'')){setTip('\u270F\uFE0F Nothing to save yet!');return;}
    var a=songs(),name=t.split(/\s+/).slice(0,4).join(' ');for(var i=a.length-1;i>=0;i--)if(a[i].l===t)a.splice(i,1);
    a.unshift({n:name.slice(0,40),l:t,s:{style:S.style,key:S.key,bpm:S.bpm,pitch:S.pitch,auto:S.auto,voice:S.voice},t:Date.now()});if(a.length>MAXSONGS)a=a.slice(0,MAXSONGS);
    lsSet(SK,a);renderSongs();setTip('\uD83D\uDCBE Saved! ('+a.length+'/'+MAXSONGS+' songs on this device)');}
  function loadSong(i){var a=songs(),s=a[i];if(!s)return;stop(false);S.lyr=s.l;ui.lyr.value=s.l;var x=s.s||{};
    S.style=STYLES[x.style]?x.style:'pop';S.key=KEYS.indexOf(x.key)>=0?x.key:'C maj';S.bpm=clamp(+x.bpm||112,70,150);S.pitch=clamp(+x.pitch||0,-6,6);S.auto=!!x.auto;
    if(x.voice){for(var j=0;j<voices.length;j++)if(vname(voices[j])===x.voice)S.voice=x.voice;}
    if(S.auto)applyAuto(true);else{S.lbl='';paint();}onLyr();renderVoices();setTip('\uD83C\uDFB6 Loaded \u201C'+s.n+'\u201D');}
  function delSong(i){var a=songs();a.splice(i,1);lsSet(SK,a);renderSongs();}
  function copy(){var txt=stripCode(S.lyr)+'\n\n\uD83C\uDFA4 Tabo Song Studio code: '+code();var ok=false;
    function fb(){try{var ta=el('textarea');ta.value=txt;ta.setAttribute('readonly','');ta.style.position='fixed';ta.style.left='-9999px';D.body.appendChild(ta);ta.select();ok=D.execCommand('copy');D.body.removeChild(ta);}catch(e){}
      setTip(ok?'\uD83D\uDCCB Copied lyrics + song code!':'\uD83D\uDCCB Copy didn\u2019t work here, long-press the lyrics to copy.');}
    W.__hsCopied=txt;
    if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(txt).then(function(){setTip('\uD83D\uDCCB Copied lyrics + song code! Paste it back in here any time.');},fb);}else fb();}
  function readCode(t){var m=CODE_RE.exec(String(t||''));if(!m)return false;S.style=STYLES[m[1]]?m[1]:'pop';var k=m[2]+' '+m[3];S.key=KEYS.indexOf(k)>=0?k:S.key;S.bpm=clamp(+m[4],70,150);S.pitch=clamp(+m[5],-6,6);S.auto=false;S.lbl='';return true;}

  /* ---------- UI ---------- */
  var ui={};
  function setTip(t){if(ui.msg){ui.msg.innerHTML=esc(t);ui.msg.className='hs-msg hs-flash';void ui.msg.offsetWidth;ui.msg.className='hs-msg hs-show';}}
  function applyAuto(paintIt){var a=autoPick(S.lyr);S.style=a.style;S.key=a.key;S.bpm=a.bpm;S.pitch=0;S.mood=a.mood;S.lbl=a.e+' '+a.lbl;if(paintIt!==false)paint();else paint();savePref();return a;}
  function label(){var k=S.key.split(' ');var st=STYLES[S.style];var nm=S.auto&&S.lbl?S.lbl:('\uD83C\uDF9B\uFE0F '+st.n);
    return nm+' \u00B7 '+k[0]+(k[1]==='min'?' minor':' major')+' \u00B7 '+S.bpm+' bpm'+(S.pitch?(' \u00B7 pitch '+(S.pitch>0?'+':'')+S.pitch):'');}
  function paint(){if(!ui.ov)return;ui.lbl.innerHTML=esc(label());ui.auto.setAttribute('aria-pressed',S.auto?'true':'false');
    var b=ui.styles.querySelectorAll('button');for(var i=0;i<b.length;i++){var on=b[i].getAttribute('data-s')===S.style;b[i].className='hs-chip'+(on?' on':'');b[i].setAttribute('aria-pressed',on?'true':'false');}
    ui.bpm.value=S.bpm;ui.bpmv.innerHTML=S.bpm+' bpm';ui.pit.value=S.pitch;ui.pitv.innerHTML=(S.pitch>0?'+':'')+S.pitch;ui.key.value=S.key;
    ui.loop.setAttribute('aria-pressed',S.loop?'true':'false');ui.loop.className='hs-tb hs-loop'+(S.loop?' on':'');
    ui.tip.style.display=singerOn()?'':'none';ui.mode.innerHTML=singerOn()?'\uD83D\uDCDC sings each line':'\u2702\uFE0F sings word by word';}
  function tweak(){S.auto=false;stopIfPlaying();paint();savePref();}
  function stopIfPlaying(){if(P)stop(false);}
  function renderVoices(){if(!ui.voice)return;var h='',i;
    if(!voices.length)h='<option value="">Default voice</option>';
    for(i=0;i<voices.length;i++){var v=voices[i];h+='<option value="'+esc(vname(v))+'">'+(isNov(v)?'\u2B50 ':'')+esc(vname(v))+(isNov(v)?'':' ('+esc(String(v.lang||'').replace('_','-'))+')')+'</option>';}
    ui.voice.innerHTML=h;if(S.voice)ui.voice.value=S.voice;if(ui.voice.value!==S.voice&&voices.length){S.voice=ui.voice.value;}
    var hasNov=false;for(i=0;i<voices.length;i++)if(isNov(voices[i]))hasNov=true;
    ui.vnote.style.display=hasNov?'none':'';paint();}
  function renderSongs(){var a=songs(),h='';for(var i=0;i<a.length;i++)h+='<li><button type="button" class="hs-sl" data-i="'+i+'">\uD83C\uDFB6 '+esc(a[i].n)+'</button><button type="button" class="hs-sd" data-d="'+i+'" aria-label="Delete">\uD83D\uDDD1\uFE0F</button></li>';
    ui.songs.innerHTML=h||'<li class="hs-none">No saved songs yet</li>';ui.scount.innerHTML=a.length?('('+a.length+'/'+MAXSONGS+')'):'';}
  function onLyr(){ui.cnt.innerHTML=(ui.lyr.value.length)+'/'+MAXC;if(!P)renderKaraoke(null);}
  function buildUI(){if(ui.ov)return;var ov=el('div','hs-ov');ov.hidden=true;ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');ov.setAttribute('aria-label','Song Studio');
    var so='';for(var i=0;i<SORDER.length;i++){var st=STYLES[SORDER[i]];so+='<button type="button" class="hs-chip" data-s="'+SORDER[i]+'">'+st.e+' '+st.n+'</button>';}
    var ko='';for(i=0;i<KEYS.length;i++){var k=KEYS[i].split(' ');ko+='<option value="'+KEYS[i]+'">'+k[0]+(k[1]==='min'?' minor':' major')+'</option>';}
    ov.innerHTML='<div class="hs-card">'+
      '<div class="hs-hd"><b>\uD83C\uDFA4 Song Studio</b><button type="button" class="hs-x" aria-label="Close">\u2715</button></div>'+
      '<div class="hs-stage"><div class="hs-kar" aria-live="off"></div></div>'+
      '<div class="hs-tr"><button type="button" class="hs-tb hs-play">\u25B6\uFE0F Play</button><button type="button" class="hs-tb hs-stop">\u23F9 Stop</button><button type="button" class="hs-tb hs-loop" aria-pressed="false">\uD83D\uDD01 Loop</button></div>'+
      '<div class="hs-body">'+
        '<div class="hs-autorow"><button type="button" class="hs-auto" aria-pressed="true">\u2728 Auto</button><span class="hs-lbl"></span></div>'+
        '<div class="hs-msg"></div>'+
        '<label class="hs-l" for="hs-lyr">Lyrics <span class="hs-cnt"></span></label>'+
        '<textarea id="hs-lyr" class="hs-lyr" maxlength="'+MAXC+'" rows="5" placeholder="Type your song here, one line per line\u2026"></textarea>'+
        '<div class="hs-ai"><input class="hs-topic" type="text" maxlength="60" placeholder="Song about\u2026 (pizza, my dog)" aria-label="Song topic"><button type="button" class="hs-dice">\uD83C\uDFB2 Write me lyrics</button></div>'+
        '<label class="hs-l" for="hs-voice">Singer <span class="hs-mode"></span></label>'+
        '<select id="hs-voice" class="hs-voice"></select>'+
        '<p class="hs-tip">\u2B50 Good News sings on its own; Auto lines it up with the beat.</p>'+
        '<p class="hs-vnote">\u2B50 On iPad/iPhone/Mac, try the \u201CGood News\u201D voice, it sings! (It isn\u2019t on this device.)</p>'+
        '<div class="hs-l">Style</div><div class="hs-styles">'+so+'</div>'+
        '<div class="hs-sliders">'+
          '<label class="hs-sl2">\uD83C\uDFC3 Speed <input type="range" class="hs-bpm" min="70" max="150" step="2"><span class="hs-bpmv"></span></label>'+
          '<label class="hs-sl2">\uD83C\uDFB5 Pitch <input type="range" class="hs-pit" min="-6" max="6" step="1"><span class="hs-pitv"></span></label>'+
          '<label class="hs-sl2">\uD83C\uDFB9 Key <select class="hs-key">'+ko+'</select></label>'+
        '</div>'+
        '<div class="hs-save"><button type="button" class="hs-sv">\uD83D\uDCBE Save song</button><button type="button" class="hs-cp">\uD83D\uDCCB Copy</button></div>'+
        '<div class="hs-l">My songs <span class="hs-scount"></span></div><ul class="hs-songs"></ul>'+
        '<p class="hs-fine">Sings with your device\u2019s own voices. Nothing is recorded or uploaded. Songs save on this device only.</p>'+
      '</div></div>';
    D.body.appendChild(ov);
    function q(c){return ov.querySelector(c);}
    ui={ov:ov,kar:q('.hs-kar'),play:q('.hs-play'),stop:q('.hs-stop'),loop:q('.hs-loop'),auto:q('.hs-auto'),lbl:q('.hs-lbl'),msg:q('.hs-msg'),lyr:q('.hs-lyr'),cnt:q('.hs-cnt'),
      topic:q('.hs-topic'),dice:q('.hs-dice'),voice:q('.hs-voice'),mode:q('.hs-mode'),tip:q('.hs-tip'),vnote:q('.hs-vnote'),styles:q('.hs-styles'),bpm:q('.hs-bpm'),bpmv:q('.hs-bpmv'),
      pit:q('.hs-pit'),pitv:q('.hs-pitv'),key:q('.hs-key'),songs:q('.hs-songs'),scount:q('.hs-scount'),ball:el('div','hs-ball','\uD83D\uDC9C')};
    ui.lyr.value=S.lyr;
    q('.hs-x').onclick=close;ui.play.onclick=play;ui.stop.onclick=function(){stop(false);};
    ui.loop.onclick=function(){S.loop=!S.loop;paint();savePref();};
    ui.auto.onclick=function(){S.auto=true;stopIfPlaying();applyAuto(true);setTip('\u2728 Auto matched the style, key and speed to your lyrics!');};
    ui.lyr.oninput=function(){if(ui.lyr.value.length>MAXC)ui.lyr.value=ui.lyr.value.slice(0,MAXC);S.lyr=ui.lyr.value;if(readCode(S.lyr)){paint();setTip('\uD83C\uDFB6 Song code found, settings loaded!');}else if(S.auto)applyAuto(true);onLyr();savePref();};
    ui.dice.onclick=writeLyrics;ui.topic.onkeydown=function(e){if(e.keyCode===13){e.preventDefault();writeLyrics();}};
    ui.voice.onchange=function(){S.voice=ui.voice.value;stopIfPlaying();paint();savePref();if(singerOn())setTip('\u2B50 '+S.voice+' sings on its own; Auto lines it up with the beat.');};
    ui.styles.onclick=function(e){var b=e.target;while(b&&b!==ui.styles&&!b.getAttribute('data-s'))b=b.parentNode;if(!b||b===ui.styles)return;S.style=b.getAttribute('data-s');var st=STYLES[S.style];
      var k=S.key.split(' ');if(k[1]!==st.mode){S.key=(st.mode==='min'?'A min':'C maj');}S.bpm=st.bpm;tweak();};
    ui.bpm.oninput=function(){S.bpm=+ui.bpm.value;tweak();};ui.pit.oninput=function(){S.pitch=+ui.pit.value;tweak();};ui.key.onchange=function(){S.key=ui.key.value;tweak();};
    q('.hs-sv').onclick=saveSong;q('.hs-cp').onclick=copy;
    ui.songs.onclick=function(e){var b=e.target;while(b&&b!==ui.songs&&!b.getAttribute('data-i')&&!b.getAttribute('data-d'))b=b.parentNode;if(!b||b===ui.songs)return;
      if(b.getAttribute('data-d')!=null)delSong(+b.getAttribute('data-d'));else loadSong(+b.getAttribute('data-i'));};
    ov.addEventListener('keydown',function(e){if(e.keyCode===27){e.preventDefault();close();}});
    renderSongs();loadVoices();if(S.auto&&S.lyr)applyAuto(true);paint();onLyr();}
  var lastFocus=null;
  function open(){buildUI();if(W.hcVoice&&W.hcVoice.close){try{W.hcVoice.close();}catch(e){}}lastFocus=D.activeElement;ui.ov.hidden=false;D.documentElement.className+=' hs-open';loadVoices();onLyr();paint();
    if(!S.lyr)setTip(hw()?'\uD83C\uDF83 Type spooky lyrics or tap \uD83C\uDFB2, then \u25B6\uFE0F!':'Type lyrics or tap the dice, then Play. Auto picks the beat.');
    try{ui.play.focus();}catch(e){}}
  function close(){stop(false);if(!ui.ov)return;ui.ov.hidden=true;D.documentElement.className=D.documentElement.className.replace(/\s*hs-open/g,'');try{if(lastFocus)lastFocus.focus();}catch(e){}}
  D.addEventListener('visibilitychange',function(){if(D.hidden&&P)stop(false);});
  W.addEventListener('pagehide',function(){if(P)stop(false);});

  /* entry points: a 🎤 pill in the mode row (icon-only on phones) + one in the Talking-face voice row */
  function hook(){var modes=D.querySelector('.hc-modes');if(modes&&!$('hc-studio-btn')){var b=el('button','hm hm-st','\uD83C\uDFA4<span class="hm-stt"> Studio</span>');b.type='button';b.id='hc-studio-btn';b.title='Song Studio';b.setAttribute('aria-haspopup','dialog');b.onclick=open;
      var sc=$('hc-sc-btn');if(sc&&sc.parentNode===modes)modes.insertBefore(b,sc);else modes.appendChild(b);}
    var row=D.querySelector('.hv-row');if(row&&!row.querySelector('.hs-pill')){var p=el('button','hv-pill hs-pill','\uD83C\uDFA4 Song studio');p.type='button';p.onclick=open;var vc=row.querySelector('.hv-vc');if(vc&&vc.nextSibling)row.insertBefore(p,vc.nextSibling);else row.appendChild(p);}}
  hook();setTimeout(hook,600);
  var s0=SS();if(s0){try{if(s0.addEventListener)s0.addEventListener('voiceschanged',loadVoices);}catch(e){}}
  W.hcStudio={open:open,close:close,play:play,stop:function(){stop(false);},analyze:analyze,auto:autoPick,syl:syl,label:label,
    set:function(o){for(var k in o)if(o.hasOwnProperty(k))S[k]=o[k];if(ui.lyr&&o.lyr!=null){ui.lyr.value=S.lyr;onLyr();}if(ui.voice&&o.voice!=null)renderVoices();paint();savePref();},
    state:function(){return {playing:!!P,style:S.style,key:S.key,bpm:S.bpm,pitch:S.pitch,auto:S.auto,voice:S.voice,singer:singerOn(),label:ui.lbl?ui.lbl.textContent:label(),
      ctx:AC?AC.state:'none',nodes:nodes,utt:P?P.utt.slice(0):(W.__hsLast?W.__hsLast.utt.slice(0):[]),resync:P?P.resync:0,lit:P?P.lit:-1,
      litText:(ui.kar&&ui.kar.querySelector('.hs-w.on'))?ui.kar.querySelector('.hs-w.on').textContent:''};}};
})(window,document);
