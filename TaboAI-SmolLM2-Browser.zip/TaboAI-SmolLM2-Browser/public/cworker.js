/* Tabo 📚 Lessons: JavaScript + Lua runner in a worker, so endless loops can be stopped (v1.5.4) */
var luaReady=false;
function fmt(v){if(typeof v==='string')return v;try{if(v&&typeof v==='object')return JSON.stringify(v);}catch(e){}return String(v);}
function runJS(code,test){var out=[];var con={log:function(){out.push([].map.call(arguments,fmt).join(' '));}};con.info=con.warn=con.error=con.log;
  var st={done:0},f;
  try{f=new Function('console','__st','alert','prompt',code+'\n;__st.done=1;\n'+(test||''));}catch(e){return{out:'',err:e.name+': '+e.message};}
  try{f(con,st,function(m){out.push(fmt(m));},function(){return '';});}catch(e){var m=(e&&e.message)||String(e);return st.done?{out:out.join('\n'),fail:m}:{out:out.join('\n'),err:(e&&e.name?e.name+': ':'')+m};}
  return{out:out.join('\n')};}
var PRE='local __o={} '+
 'print=function(...) local t={} for i=1,select("#",...) do t[#t+1]=tostring((select(i,...))) end __o[#__o+1]=table.concat(t,"\\t").."\\n" end '+
 'io=io or {} io.write=function(...) for i=1,select("#",...) do __o[#__o+1]=tostring((select(i,...))) end end '+
 'function __hc_out() return table.concat(__o) end';
function runLua(code,test){
  if(!luaReady){if(typeof window==='undefined')self.window=self;importScripts('lib/fengari-web.js?v=1.6');luaReady=true;}
  var F=self.fengari,lua=F.lua,lx=F.lauxlib,ll=F.lualib,S=F.to_luastring;
  var L=lx.luaL_newstate();ll.luaL_openlibs(L);lx.luaL_dostring(L,S(PRE));
  function getOut(){lua.lua_getglobal(L,S('__hc_out'));lua.lua_pcall(L,0,1,0);var o=lua.lua_tojsstring(L,-1)||'';lua.lua_pop(L,1);return o.replace(/\n$/,'');}
  function one(src,name){var s=lx.luaL_loadbuffer(L,S(src),null,S(name));if(s===0)s=lua.lua_pcall(L,0,0,0);if(s!==0){var m=lua.lua_tojsstring(L,-1);lua.lua_pop(L,1);return String(m||'error').replace(/^\[string "[^"]*"\]:/,'Line ');}return null;}
  var e=one(code,'my_code');if(e)return{out:getOut(),err:e};
  if(test){var f=one(test,'checker');if(f)return{out:getOut(),fail:f.replace(/^Line \d+:\s*/,'')};}
  return{out:getOut()};}
onmessage=function(ev){var d=ev.data||{},r;
  try{r=d.lang==='lua'?runLua(d.code,d.test):runJS(d.code,d.test);}catch(e){r={out:'',err:d.lang==='lua'&&!luaReady?'LOAD':String(e&&e.message||e),dbg:String(e&&e.stack||e).slice(0,300)};}
  r.id=d.id;postMessage(r);};
