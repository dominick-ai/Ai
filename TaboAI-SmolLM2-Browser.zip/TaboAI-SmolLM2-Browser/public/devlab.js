/* devlab.js (hc v1.9.1; v1.9) 🛠️ Dev Lab = developer toolbox for the site owner, behind the admin PIN / 30-day admin pass.
   Tabs: 🔑 Key Tester · 🧪 Model Test · 🌐 Web Research · 🧩 Extensions (v1.9.1: free knowledge tools with on/off switches + Try it).
   Every request sends the admin pass; the server answers 403 without it.
   Keys: a pasted key lives only in the input box (and in localStorage ONLY if "remember on this device" is ticked).
   It goes to the server in the request body for that one test, is never stored or logged there, and never comes back.
   Safety: the lighter Dev Lab filter (devsafe.js) runs on the server for everything, and again here on replies from his own key. No off switch. */
(function(W,D){
  'use strict';
  var S=W.hcDevSafe,G=W.hcDevGate,AI=W.domoAI,root=null,tab='api',tok='',tested=null,MAXP=8,RK='hc_dev_keys',PK='hc_dev_arena';
  var PROV=[['auto','✨ Auto-detect (by the key\u2019s start)'],['openrouter','OpenRouter (sk-or-…)'],['google','Google Gemini (AIza…)'],['mistral','Mistral'],['cohere','Cohere'],
    ['sambanova','SambaNova'],['nvidia','NVIDIA (nvapi-…)'],['cerebras','Cerebras (csk-…)'],['together','Together'],['fireworks','Fireworks'],['deepinfra','DeepInfra'],
    ['huggingface','Hugging Face (hf_…)'],['anthropic','Anthropic (sk-ant-…)'],['openai','OpenAI (sk-…)'],['xai','xAI (xai-…)'],['custom','Custom OpenAI-compatible URL']];
  function $(id){return D.getElementById(id);}
  function esc(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function fmt(t){var parts=String(t).split('```'),o='';for(var i=0;i<parts.length;i++){if(i%2){var c=parts[i].replace(/^[\w+-]*\n/,'');o+='<pre><code>'+esc(c)+'</code></pre>';}else o+=esc(parts[i]).replace(/\*\*([^*\n]+)\*\*/g,'<b>$1</b>').replace(/`([^`\n]+)`/g,'<code>$1</code>');}return o;}
  function secs(ms){return ms==null?'':(ms<1000?ms+' ms':(ms/1000).toFixed(1)+' s');}
  function pass(){var t='';try{t=(G&&G.pass&&G.pass())||'';}catch(e){}return t||tok;}
  function api(path,body){body=body||{};body.token=pass();
    return W.fetch(path,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}).then(function(r){
      return r.json().catch(function(){return {ok:false,message:'Server error ('+r.status+').'};}).then(function(j){if(r.status===403){j=j||{};j.ok=false;j.message='🔒 Admin pass expired. Close the Lab and unlock with the 🔨 again.';}return j;});
    },function(){return {ok:false,message:'Couldn\u2019t reach the server. Check the internet.'};});}
  function clientSafe(text){if(!S)return {ok:true,text:text};var r=S.check(text);if(!r.ok)return {ok:false,msg:S.BLOCKED+' ('+r.cat+')'};return {ok:true,text:S.mask(text)};}
  function tabsHtml(){var T=[['api','🔑','API Keys'],['bugs','🐛','Bugs'],['key','🗝️','Key Tester'],['arena','🧪','Model Test'],['web','🌐','Web Research'],['ext','🧩','Extensions']],h='';
    for(var i=0;i<T.length;i++)h+='<button type="button" role="tab" class="hcdl-tab" data-tab="'+T[i][0]+'" aria-selected="false"><span class="hcdl-te">'+T[i][1]+'</span><span class="hcdl-tl">'+T[i][2]+'</span>'+(T[i][0]==='bugs'?'<span class="hcbg-bdg" id="hcbg-bdg" hidden></span>':'')+'</button>';return h;}
  function build(){
    root=D.createElement('div');root.id='hcdl';root.className='hcdl';root.setAttribute('role','dialog');root.setAttribute('aria-label','Dev Lab');
    var po='';for(var i=0;i<PROV.length;i++)po+='<option value="'+PROV[i][0]+'">'+esc(PROV[i][1])+'</option>';
    root.innerHTML='<div class="hcdl-in">'+
      '<div class="hcdl-top"><div class="hcdl-t"><b>🛠️ Dev Lab</b><span>Developer toolbox · admin only · 🛡️ safety on (lighter)</span></div>'+
      '<div class="hcdl-acts"><button type="button" id="hcdl-lock" class="hcdl-btn" title="Turn off admin mode on this device">🔒 Lock</button><button type="button" id="hcdl-x" class="hcdl-btn" aria-label="Close Dev Lab">✕</button></div></div>'+
      '<div class="hcdl-tabs" role="tablist">'+tabsHtml()+'</div>'+
      '<div class="hcdl-body">'+
      // 🔑 hc v2.2 Tabo API keys
      '<section class="hcdl-pane" data-pane="api">'+akHtml()+'</section>'+
      // 🐛 hc v2.3 bug catcher log
      '<section class="hcdl-pane" data-pane="bugs" hidden>'+bgHtml()+'</section>'+
      // 🗝️ key tester
      '<section class="hcdl-pane" data-pane="key" hidden>'+
        '<div class="hcdl-warn">⚠️ Never paste keys anyone else gave you or that cost money without a grown-up OK.</div>'+
        '<label class="hcdl-l" for="hcdl-kp">Provider</label><select id="hcdl-kp" class="hcdl-in1">'+po+'</select>'+
        '<div id="hcdl-kbw" hidden><label class="hcdl-l" for="hcdl-kb">Base URL (OpenAI-compatible)</label><input id="hcdl-kb" class="hcdl-in1" type="url" inputmode="url" placeholder="https://api.example.com/v1" autocomplete="off" autocapitalize="off" spellcheck="false"></div>'+
        '<label class="hcdl-l" for="hcdl-kk">API key</label><div class="hcdl-kr"><input id="hcdl-kk" class="hcdl-in1" type="password" placeholder="Paste a key…" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" data-lpignore="true" data-1p-ignore><button type="button" id="hcdl-kv" class="hcdl-btn" aria-label="Show or hide the key">👁</button></div>'+
        '<div class="hcdl-guess" id="hcdl-kg"></div>'+
        '<label class="hcdl-ck"><input type="checkbox" id="hcdl-kc" checked> Also try a tiny chat ("say hi")</label>'+
        '<label class="hcdl-ck"><input type="checkbox" id="hcdl-kr"> Remember on this device <small>(saved only on this iPad, in this browser, never on the server)</small></label>'+
        '<div class="hcdl-bar"><button type="button" id="hcdl-kt" class="hcdl-btn hcdl-go">🔑 Test key</button><button type="button" id="hcdl-kx" class="hcdl-btn">Clear</button></div>'+
        '<div id="hcdl-ko" aria-live="polite"></div>'+
      '</section>'+
      // 🧪 model test
      '<section class="hcdl-pane" data-pane="arena" hidden>'+
        '<label class="hcdl-l" for="hcdl-ap">Prompt (same one goes to every model)</label><textarea id="hcdl-ap" class="hcdl-in1" rows="3" maxlength="2000" placeholder="e.g. Write a haiku about pumpkins"></textarea>'+
        '<div class="hcdl-src" role="radiogroup"><label><input type="radio" name="hcdl-as" value="hc" checked> 💜 Tabo AIs</label><label><input type="radio" name="hcdl-as" value="key"> 🔑 Use my tested key</label></div>'+
        '<div class="hcdl-pk"><span id="hcdl-an">0 / '+MAXP+' picked</span> <button type="button" id="hcdl-aclr" class="hcdl-btn hcdl-sm">Clear picks</button></div>'+
        '<div id="hcdl-am" class="hcdl-models"></div>'+
        '<div class="hcdl-bar"><button type="button" id="hcdl-ar" class="hcdl-btn hcdl-go">🧪 Run test</button></div>'+
        '<div class="hcdl-xon" data-xon="arena"></div>'+'<div id="hcdl-ao" class="hcdl-cards" aria-live="polite"></div>'+
      '</section>'+
      // 🌐 research
      '<section class="hcdl-pane" data-pane="web" hidden>'+
        '<form id="hcdl-wf" autocomplete="off"><label class="hcdl-l" for="hcdl-wq">Research question</label><div class="hcdl-kr"><input id="hcdl-wq" class="hcdl-in1" type="search" maxlength="300" placeholder="e.g. how do volcanoes work"><button type="submit" id="hcdl-wg" class="hcdl-btn hcdl-go">🌐 Search</button></div></form>'+
        '<p class="hcdl-note">Searches Wikipedia (and DuckDuckGo, strict safe search) with no key, then a fast Tabo AI writes an answer with numbered sources.</p>'+
        '<div class="hcdl-xon" data-xon="web"></div>'+'<div id="hcdl-wo" aria-live="polite"></div>'+
      '</section>'+
      // 🧩 extensions
      '<section class="hcdl-pane" data-pane="ext" hidden>'+extHtml()+'</section>'+
      '</div></div>';
    D.body.appendChild(root);
    $('hcdl-x').onclick=close;
    $('hcdl-lock').onclick=function(){if(G&&G.lock)G.lock();close();};
    var tb=root.querySelectorAll('.hcdl-tab');for(i=0;i<tb.length;i++)tb[i].onclick=function(){show(this.getAttribute('data-tab'));};
    D.addEventListener('keydown',function(e){if(e.key==='Escape'&&root&&!root.hidden)close();});
    akInit();bgInit();keyInit();arenaInit();webInit();extInit();
  }
  function show(t){tab=t;var tb=root.querySelectorAll('.hcdl-tab'),ps=root.querySelectorAll('.hcdl-pane');
    for(var i=0;i<tb.length;i++){var on=tb[i].getAttribute('data-tab')===t;tb[i].setAttribute('aria-selected',on?'true':'false');tb[i].className='hcdl-tab'+(on?' on':'');}
    for(i=0;i<ps.length;i++)ps[i].hidden=ps[i].getAttribute('data-pane')!==t;
    if(t==='arena')renderModels();if(t==='api')akLoad();if(t==='bugs')bgLoad();xonPaint();}
  // ---------- 🔑 key tester ----------
  function guess(k){k=String(k||'');if(/^sk-or-/.test(k))return 'openrouter';if(/^AIza/.test(k))return 'google';if(/^nvapi-/.test(k))return 'nvidia';
    if(/^hf_/.test(k))return 'huggingface';if(/^sk-ant-/.test(k))return 'anthropic';if(/^xai-/.test(k))return 'xai';if(/^csk-/.test(k))return 'cerebras';if(/^fw_/.test(k))return 'fireworks';if(/^tgp_/.test(k))return 'together';if(/^sk-/.test(k))return 'openai';return '';}
  function pname(id){for(var i=0;i<PROV.length;i++)if(PROV[i][0]===id)return PROV[i][1].replace(/\s*\(.*$/,'');return id;}
  function keyInit(){
    var kp=$('hcdl-kp'),kk=$('hcdl-kk'),kb=$('hcdl-kb'),kr=$('hcdl-kr');
    function upd(){$('hcdl-kbw').hidden=kp.value!=='custom';var g='';if(kp.value==='auto'&&kk.value){var x=guess(kk.value.trim());g=x?'Looks like a <b>'+esc(pname(x))+'</b> key.':'Can\u2019t tell from the start of this key. Pick the provider from the list.';}$('hcdl-kg').innerHTML=g;}
    kp.onchange=function(){upd();saveKey();};kk.oninput=function(){upd();saveKey();};kb.oninput=saveKey;
    $('hcdl-kv').onclick=function(){kk.type=kk.type==='password'?'text':'password';};
    kr.onchange=function(){if(kr.checked)saveKey();else{try{W.localStorage.removeItem(RK);}catch(e){}}};
    $('hcdl-kx').onclick=function(){kk.value='';kb.value='';kp.value='auto';tested=null;$('hcdl-ko').innerHTML='';try{W.localStorage.removeItem(RK);}catch(e){}kr.checked=false;upd();};
    $('hcdl-kt').onclick=testKey;
    kk.addEventListener('keydown',function(e){if(e.key==='Enter'){e.preventDefault();testKey();}});
    try{var s=JSON.parse(W.localStorage.getItem(RK)||'null');if(s&&s.k){kk.value=s.k;kp.value=s.p||'auto';kb.value=s.b||'';kr.checked=true;}}catch(e){}
    upd();
  }
  function saveKey(){if(!$('hcdl-kr').checked)return;try{W.localStorage.setItem(RK,JSON.stringify({p:$('hcdl-kp').value,k:$('hcdl-kk').value.trim(),b:$('hcdl-kb').value.trim()}));}catch(e){}}
  function keyNow(){return {provider:$('hcdl-kp').value,key:$('hcdl-kk').value.trim(),base:$('hcdl-kb').value.trim()};}
  function testKey(){
    var k=keyNow(),o=$('hcdl-ko'),bt=$('hcdl-kt');
    if(!k.key){o.innerHTML='<div class="hcdl-card hcdl-bad">Paste a key first.</div>';return;}
    if(/^hc-/.test(k.key)){bt.disabled=true;o.innerHTML='<div class="hcdl-card">⏳ That\u2019s a Tabo key 💜 testing it…</div>';
      W.fetch(AKB+'/chat/completions',{method:'POST',headers:{'Authorization':'Bearer '+k.key,'Content-Type':'application/json'},body:JSON.stringify({model:'tabo',messages:[{role:'user',content:'Say hi in 5 words'}]})})
      .then(function(r){return r.json().catch(function(){return {error:{message:'Server error ('+r.status+').'}};});})
      .then(function(j){bt.disabled=false;if(j&&j.choices&&j.choices[0]){o.innerHTML='<div class="hcdl-card">✅ Tabo key works! Reply: '+esc(j.choices[0].message.content)+'<br><small>No base URL needed here. In other apps use '+esc(AKB)+'</small></div>';}else{o.innerHTML='<div class="hcdl-card hcdl-bad">❌ '+esc((j&&j.error&&j.error.message)||'That key didn\u2019t work.')+'</div>';}})
      .catch(function(){bt.disabled=false;o.innerHTML='<div class="hcdl-card hcdl-bad">❌ Couldn\u2019t reach Tabo. Try again.</div>';});
      return;}
    if(k.provider==='auto'&&!guess(k.key)){o.innerHTML='<div class="hcdl-card hcdl-bad">Can\u2019t tell which company this key is for. Pick the provider from the list.</div>';return;}
    if(k.provider==='custom'&&!/^https:\/\//i.test(k.base)){o.innerHTML='<div class="hcdl-card hcdl-bad">Custom needs an https:// base URL.</div>';return;}
    bt.disabled=true;o.innerHTML='<div class="hcdl-card">⏳ Testing with '+esc(pname(k.provider==='auto'?guess(k.key):k.provider))+'…</div>';
    var t0=Date.now();
    api('/api/dev/keytest',{provider:k.provider,key:k.key,base:k.provider==='custom'?k.base:undefined,chat:$('hcdl-kc').checked}).then(function(j){
      bt.disabled=false;
      if(!j||j.ok===false&&!j.provider){o.innerHTML='<div class="hcdl-card hcdl-bad">⚠️ '+esc((j&&j.message)||'Test failed.')+'</div>';return;}
      var h='<div class="hcdl-card '+(j.valid?'hcdl-good':'hcdl-bad')+'"><div class="hcdl-big">'+(j.valid?'✅ Valid':'❌ Invalid')+' · '+esc(j.providerName||j.provider)+'</div>'+
        '<div class="hcdl-kv2"><span>HTTP status</span><b>'+esc(j.status||'no answer')+'</b></div>'+
        (j.error?'<div class="hcdl-kv2"><span>Provider said</span><b class="hcdl-em">'+esc(j.error)+'</b></div>':'')+
        '<div class="hcdl-kv2"><span>Models found</span><b>'+esc(j.count||0)+'</b></div>';
      if(j.chat)h+='<div class="hcdl-kv2"><span>Test chat</span><b>'+(j.chat.ok?'✅ worked · '+esc(secs(j.chat.ms))+' · '+esc(j.chat.model)+(j.chat.reply?' · “'+esc(j.chat.reply)+'”':''):'❌ '+esc(j.chat.error||('HTTP '+j.chat.status))+' ('+esc(j.chat.model)+')')+'</b></div>';
      h+='<div class="hcdl-kv2"><span>Total time</span><b>'+secs(Date.now()-t0)+'</b></div>';
      if(j.models&&j.models.length){h+='<details class="hcdl-ml"><summary>Model ids ('+(j.count>j.models.length?'first '+j.models.length+' of '+j.count:j.models.length)+')</summary><ul>';for(var i=0;i<j.models.length;i++)h+='<li>'+esc(j.models[i])+'</li>';h+='</ul></details>';}
      if(j.valid&&j.models&&j.models.length)h+='<p class="hcdl-note">✅ You can use this key in 🧪 Model Test → “Use my tested key”.</p>';
      h+='</div>';o.innerHTML=h;
      tested=j.valid?{provider:j.provider,name:j.providerName,models:(j.models||[]).slice()}:null; // provider + model ids only; Model Test reads the key from the input box at send time
      arenaSel.key=[];if(tab==='arena')renderModels();
    });
  }
  // ---------- 🧪 model test ----------
  var arenaSel={hc:[],key:[]},open1={};
  function src(){var r=root.querySelectorAll('input[name="hcdl-as"]');for(var i=0;i<r.length;i++)if(r[i].checked)return r[i].value;return 'hc';}
  function arenaInit(){
    try{var s=JSON.parse(W.localStorage.getItem(PK)||'null');if(s&&s.hc)arenaSel.hc=s.hc.slice(0,MAXP);}catch(e){}
    if(!arenaSel.hc.length)arenaSel.hc=['sigma'];
    var r=root.querySelectorAll('input[name="hcdl-as"]');for(var i=0;i<r.length;i++)r[i].onchange=renderModels;
    $('hcdl-aclr').onclick=function(){arenaSel[src()]=[];saveSel();renderModels();};
    $('hcdl-am').addEventListener('change',function(e){var c=e.target;if(!c||c.type!=='checkbox')return;var L=arenaSel[src()],id=c.value,i=L.indexOf(id);
      if(c.checked){if(L.length>=MAXP){c.checked=false;flash();return;}if(i<0)L.push(id);}else if(i>=0)L.splice(i,1);saveSel();count();});
    $('hcdl-am').addEventListener('toggle',function(e){var d=e.target;if(d&&d.getAttribute)open1[d.getAttribute('data-b')]=d.open;},true);
    $('hcdl-ar').onclick=runArena;
  }
  function saveSel(){try{W.localStorage.setItem(PK,JSON.stringify({hc:arenaSel.hc}));}catch(e){}}
  function flash(){var n=$('hcdl-an');n.className='hcdl-flash';n.textContent='Max '+MAXP+' models at once';setTimeout(function(){n.className='';count();},1400);}
  function count(){$('hcdl-an').textContent=arenaSel[src()].length+' / '+MAXP+' picked';}
  function hcModels(){var M=(AI&&AI.models)||[{id:'sigma',n:'Tabo AI',p:'Kilo',b:'hc'},{id:'faucet',n:'Free Model Router',p:'LLMFaucet',b:'other'},{id:'qwen',n:'AI Horde',p:'AI Horde',b:'other'}];return M;}
  function renderModels(){
    var box=$('hcdl-am'),s=src(),h='',i;
    if(s==='hc'){
      var M=hcModels(),BR=(AI&&AI.brands)?AI.brands():[['hc','💜 Tabo'],['other','Others']],by={};
      for(i=0;i<M.length;i++){var b=M[i].b||'other';(by[b]=by[b]||[]).push(M[i]);}
      var seen={};
      for(var g=0;g<BR.length;g++){var k=BR[g][0];seen[k]=1;if(!by[k])continue;h+=folder(k,BR[g][1],by[k],arenaSel.hc);}
      for(k in by)if(by.hasOwnProperty(k)&&!seen[k])h+=folder(k,k,by[k],arenaSel.hc);
      h='<p class="hcdl-note">'+M.length+' Tabo AIs. Tap a brand to open it, tick up to '+MAXP+'.</p>'+h;
    }else{
      if(!tested||!tested.models.length)h='<div class="hcdl-card">🔑 Test a key in the <b>Key Tester</b> tab first. Its models show up here.</div>';
      else{var NC=/embed|whisper|tts|speech|audio|transcri|image|dall|vision|guard|moderat|rerank|ocr|orpheus|voxtral|sdxl|flux|stable-?diff|video/i,CM=tested.models.filter(function(x){return !NC.test(x);}),hid=tested.models.length-CM.length;
        h='<p class="hcdl-note">Models from your tested <b>'+esc(tested.name||tested.provider)+'</b> key (the key stays in the Key Tester box and is sent only with each test).'+(hid?' '+hid+' non-chat models (voice, images, guards…) hidden.':'')+'</p><div class="hcdl-grid">';
        for(i=0;i<CM.length;i++){var id=CM[i];h+='<label class="hcdl-mo"><input type="checkbox" value="'+esc(id)+'"'+(arenaSel.key.indexOf(id)>=0?' checked':'')+'> <span>'+esc(id)+'</span></label>';}h+='</div>';}
    }
    box.innerHTML=h;count();
  }
  function folder(k,label,L,sel){var n=0,b='';for(var i=0;i<L.length;i++){var on=sel.indexOf(L[i].id)>=0;if(on)n++;b+='<label class="hcdl-mo"><input type="checkbox" value="'+esc(L[i].id)+'"'+(on?' checked':'')+'> <span>'+esc(L[i].n)+' <small>'+esc(L[i].p||'')+'</small></span></label>';}
    var op=open1.hasOwnProperty(k)?open1[k]:(n>0);
    return '<details class="hcdl-fold" data-b="'+esc(k)+'"'+(op?' open':'')+'><summary>'+esc(label)+' <span class="hcdl-gn">'+L.length+'</span>'+(n?' <span class="hcdl-gp">'+n+' picked</span>':'')+'</summary><div class="hcdl-grid">'+b+'</div></details>';}
  function nameOf(id){var M=hcModels();for(var i=0;i<M.length;i++)if(M[i].id===id)return M[i].n;return id;}
  function runArena(){
    var p=$('hcdl-ap').value.trim(),s=src(),L=arenaSel[s].slice(0,MAXP),o=$('hcdl-ao');
    if(!p){o.innerHTML='<div class="hcdl-card hcdl-bad">Type a prompt first.</div>';return;}
    if(!L.length){o.innerHTML='<div class="hcdl-card hcdl-bad">Tick at least one model.</div>';return;}
    if(S){var c=S.check(p);if(!c.ok){o.innerHTML='<div class="hcdl-card hcdl-bad">'+esc(S.BLOCKED+' ('+c.cat+')')+'</div>';return;}}
    var k=s==='key'?keyNow():null;
    if(s==='key'&&(!tested||!k.key)){o.innerHTML='<div class="hcdl-card hcdl-bad">The key box in Key Tester is empty. Paste and test the key again.</div>';return;}
    o.innerHTML='';var run=$('hcdl-ar');run.disabled=true;var left=L.length;
    L.forEach(function(id,ix){
      var card=D.createElement('div');card.className='hcdl-card hcdl-ac';
      card.innerHTML='<div class="hcdl-ah"><b>'+esc(s==='hc'?nameOf(id):id)+'</b><span class="hcdl-ms">⏳</span></div><div class="hcdl-ab">Thinking…</div>';o.appendChild(card);
      var t0=Date.now(),tick=setInterval(function(){card.querySelector('.hcdl-ms').textContent='⏳ '+secs(Date.now()-t0);},250);
      var req=s==='hc'?api('/api/dev/arena',{model:id,prompt:p,ext:extOn()}):api('/api/dev/keytest',{mode:'chat',provider:tested.provider,key:k.key,base:k.provider==='custom'?k.base:undefined,model:id,prompt:p,ext:extOn()});
      req.then(function(j){clearInterval(tick);left--;if(!left)run.disabled=false;
        var ms=(j&&j.ms!=null)?j.ms:(Date.now()-t0);card.querySelector('.hcdl-ms').textContent='⏱ '+secs(ms);
        var ab=card.querySelector('.hcdl-ab');
        if(j&&j.ok&&j.reply){var cs=clientSafe(j.reply);if(!cs.ok){card.className+=' hcdl-bad';ab.textContent=cs.msg;return;}ab.innerHTML=fmt(cs.text);card.className+=' hcdl-good';if(j.ext&&j.ext.length)card.insertAdjacentHTML('beforeend',usedHtml(j.ext));}
        else{card.className+=' hcdl-bad';ab.textContent=(j&&j.blocked?'':'⚠️ ')+((j&&j.message)||'No answer.');}
      });
    });
  }
  // ---------- 🌐 web research ----------
  function webInit(){$('hcdl-wf').onsubmit=function(e){e.preventDefault();research();};}
  function research(){
    var q=$('hcdl-wq').value.trim(),o=$('hcdl-wo'),bt=$('hcdl-wg');
    if(!q){o.innerHTML='<div class="hcdl-card hcdl-bad">Type a question first.</div>';return;}
    if(S){var c=S.check(q);if(!c.ok){o.innerHTML='<div class="hcdl-card hcdl-bad">'+esc(S.BLOCKED+' ('+c.cat+')')+'</div>';return;}}
    bt.disabled=true;var t0=Date.now();o.innerHTML='<div class="hcdl-card">🔎 Searching Wikipedia and reading the top pages…</div>';
    api('/api/dev/research',{q:q,ext:extOn()}).then(function(j){bt.disabled=false;
      if(!j||(!j.ok&&!(j.sources&&j.sources.length))){o.innerHTML='<div class="hcdl-card hcdl-bad">'+(j&&j.blocked?'':'⚠️ ')+esc((j&&j.message)||'Search failed.')+'</div>';return;}
      var h='<div class="hcdl-card hcdl-ans">';
      if(j.answer){var cs=clientSafe(j.answer);
        var a=cs.ok?fmt(cs.text).replace(/\[(\d{1,2})\]/g,function(m,n){var s=j.sources[+n-1];return s?'<a class="hcdl-cite" href="'+esc(s.url)+'" target="_blank" rel="noopener noreferrer">['+n+']</a>':m;}):esc(cs.msg);
        h+='<div class="hcdl-at">'+a+'</div>';}
      else if(j.message)h+='<p>'+esc(j.message)+'</p>';
      if(j.blocked)h+='<p class="hcdl-em">'+esc(j.message)+'</p>';
      if(j.sources&&j.sources.length){h+='<div class="hcdl-sh">Sources</div><ol class="hcdl-srcs">';for(var i=0;i<j.sources.length;i++){var s=j.sources[i];h+='<li><a href="'+esc(s.url)+'" target="_blank" rel="noopener noreferrer">'+esc(s.title)+'</a> <small>'+esc(s.from)+'</small></li>';}h+='</ol>';}
      if(j.ext&&j.ext.length)h+=usedHtml(j.ext);h+='<div class="hcdl-tag">'+(j.modelName?'✍️ '+esc(j.modelName)+' · ':'')+'⏱ '+secs(Date.now()-t0)+' · 🛡️ Dev Lab safety</div></div>';
      o.innerHTML=h;
    });
  }
  // ---------- 🧩 extensions (v1.9.1) ----------
  // Free, no-key knowledge tools. On/off is saved on this device (localStorage). When one is ON, Model Test and Web Research send the list
  // and the server decides from the prompt which ones apply (a word to define, a sum, "weather in <city>", NASA's picture, Wikipedia).
  // Weather: he types the city every time; nothing is preset, suggested, saved, or read from the device's location.
  var XK='hc_dev_ext',XT=[
    {id:'dict',e:'📖',n:'Dictionary',d:'Word meanings, from dictionaryapi.dev',ph:'Type a word',btn:'📖 Define',hint:'“define volcano”, “what does brave mean”'},
    {id:'calc',e:'🧮',n:'Calculator + units',d:'Math and unit converter, right on this device',ph:'Math or units, like 12*7+3',btn:'🧮 Work it out',hint:'any math, or “5 miles in km”'},
    {id:'weather',e:'🌤️',n:'Weather',d:'Now + next 3 days, from Open-Meteo. You type the city.',ph:'Type a city',btn:'🌤️ Get weather',hint:'“weather in” + a city you type'},
    {id:'apod',e:'🚀',n:'NASA picture of the day',d:'NASA’s Astronomy Picture of the Day',ph:'',btn:'🚀 Show today’s picture',hint:'“NASA picture of the day”'},
    {id:'wiki',e:'📚',n:'Wikipedia',d:'Top kid-safe Wikipedia pages (same lookup as Web Research)',ph:'Look something up',btn:'📚 Look up',hint:'any topic (Web Research already uses it)'}];
  function extState(){var o={};try{o=JSON.parse(W.localStorage.getItem(XK)||'{}')||{};}catch(e){o={};}return o;}
  function extOn(){var o=extState(),a=[];for(var i=0;i<XT.length;i++)if(o[XT[i].id])a.push(XT[i].id);return a;}
  function extSave(id,on){var o=extState();if(on)o[id]=1;else delete o[id];try{W.localStorage.setItem(XK,JSON.stringify(o));}catch(e){}}
  function extHtml(){var h='<p class="hcdl-note">🧩 Switch a tool ON and 🧪 Model Test + 🌐 Web Research use it when your prompt needs it. Free, no keys. 🛡️ Dev Lab safety checks what goes in and what comes back.</p><div class="hcdl-exts">';
    for(var i=0;i<XT.length;i++){var t=XT[i];
      h+='<div class="hcdl-ext" data-x="'+t.id+'"><div class="hcdl-xh"><span class="hcdl-xe" aria-hidden="true">'+t.e+'</span><div class="hcdl-xt"><b>'+esc(t.n)+'</b><small>'+esc(t.d)+'</small></div>'+
        '<label class="hcdl-sw" title="'+esc(t.n)+' on/off"><input type="checkbox" role="switch" data-x="'+t.id+'" aria-label="'+esc(t.n)+' on or off"><span class="hcdl-sl"></span></label></div>'+
        '<div class="hcdl-xu">When on, the AIs use it for '+esc(t.hint)+'</div>'+
        '<form class="hcdl-xf" data-x="'+t.id+'" autocomplete="off"><div class="hcdl-xl">Try it</div><div class="hcdl-kr">'+(t.ph?'<input class="hcdl-in1" type="text" maxlength="200" placeholder="'+esc(t.ph)+'" aria-label="'+esc(t.n)+' Try it" autocomplete="off" autocapitalize="off" spellcheck="false">':'')+
        '<button type="submit" class="hcdl-btn hcdl-go">'+t.btn+'</button></div></form><div class="hcdl-xo" aria-live="polite"></div></div>';}
    return h+'</div>';}
  function extInit(){var o=extState(),sw=root.querySelectorAll('.hcdl-sw input');
    for(var i=0;i<sw.length;i++){sw[i].checked=!!o[sw[i].getAttribute('data-x')];
      sw[i].onchange=function(){extSave(this.getAttribute('data-x'),this.checked);this.closest('.hcdl-ext').classList.toggle('on',this.checked);xonPaint();};
      sw[i].closest('.hcdl-ext').classList.toggle('on',sw[i].checked);}
    var fs=root.querySelectorAll('.hcdl-xf');for(i=0;i<fs.length;i++)fs[i].onsubmit=function(e){e.preventDefault();extTry(this.getAttribute('data-x'),this);};
    root.addEventListener('click',function(e){var b=e.target&&e.target.closest&&e.target.closest('.hcdl-xgo');if(b){e.preventDefault();show('ext');}});
    xonPaint();}
  function xonPaint(){if(!root)return;var on=extOn(),L=root.querySelectorAll('.hcdl-xon'),h;
    if(on.length){var n=[];for(var i=0;i<XT.length;i++)if(on.indexOf(XT[i].id)>=0)n.push(XT[i].e+' '+XT[i].n);h='🧩 Tools on: '+esc(n.join(' · '))+' <button type="button" class="hcdl-xgo">change</button>';}
    else h='🧩 No tools on <button type="button" class="hcdl-xgo">turn some on</button>';
    for(var j=0;j<L.length;j++)L[j].innerHTML=h;}
  function usedHtml(u){var a=[];for(var i=0;i<u.length;i++)a.push(esc(u[i].label)+(u[i].note?' ('+esc(String(u[i].note).slice(0,40))+')':''));return '<div class="hcdl-tag hcdl-used">🧩 Used: '+a.join(' · ')+'</div>';}
  function tsafe(s){var c=clientSafe(String(s||''));return c.ok?c.text:'';}
  function extTry(id,f){
    var inp=f.querySelector('input'),q=inp?inp.value.trim():'',o=f.parentNode.querySelector('.hcdl-xo'),bt=f.querySelector('button');
    if(inp&&!q){o.innerHTML='<div class="hcdl-card hcdl-bad">'+(id==='weather'?'Type a city name first.':id==='calc'?'Type some math first.':'Type something first.')+'</div>';return;}
    if(q&&S){var c=S.check(q);if(!c.ok){o.innerHTML='<div class="hcdl-card hcdl-bad">'+esc(S.BLOCKED+' ('+c.cat+')')+'</div>';return;}}
    if(id==='calc'){var C=W.hcCalc,r=C?C.run(q):{ok:false,message:'The calculator didn\u2019t load. Close the Lab and open it again.'};
      o.innerHTML=r.ok?'<div class="hcdl-card hcdl-good hcdl-xr"><div class="hcdl-big">'+esc(r.result)+(r.kind==='unit'?' '+esc(r.text.split(' = ')[1].replace(/^\S+\s/,'')):'')+'</div><div class="hcdl-xs">'+esc(r.text)+'</div></div>':'<div class="hcdl-card hcdl-bad">'+esc(r.message)+'</div>';return;}
    bt.disabled=true;var t0=Date.now();o.innerHTML='<div class="hcdl-card">⏳ Asking…</div>';
    api('/api/dev/ext/'+id,{q:q}).then(function(j){bt.disabled=false;
      if(!j||!j.ok){o.innerHTML='<div class="hcdl-card hcdl-bad">'+(j&&j.blocked?'':'⚠️ ')+esc((j&&j.message)||'That didn\u2019t work. Try again.')+'</div>';return;}
      var h='<div class="hcdl-card hcdl-good hcdl-xr">',i,k;
      if(id==='dict'){h+='<div class="hcdl-xw"><b>'+esc(j.word)+'</b> '+(j.phonetic?'<span class="hcdl-xs">'+esc(j.phonetic)+'</span>':'')+'</div>';
        for(i=0;i<j.meanings.length;i++){var m=j.meanings[i];h+='<div class="hcdl-xp">'+esc(m.pos)+'</div><ol class="hcdl-xd">';
          for(k=0;k<m.defs.length;k++){var d=tsafe(m.defs[k].d);if(!d)continue;h+='<li>'+esc(d)+(m.defs[k].ex&&tsafe(m.defs[k].ex)?'<div class="hcdl-xs">“'+esc(tsafe(m.defs[k].ex))+'”</div>':'')+'</li>';}h+='</ol>';}}
      else if(id==='weather'){var n=j.now;h+='<div class="hcdl-xw"><b>'+esc(j.place)+'</b></div><div class="hcdl-big">'+esc(n.desc)+' · '+n.f+'°F <small>('+n.c+'°C)</small></div>'+
          '<div class="hcdl-xs">Feels like '+n.feelsF+'°F ('+n.feelsC+'°C) · 💧 '+n.hum+'% · 💨 '+n.windMph+' mph ('+n.windKmh+' km/h)'+(j.local?' · local time '+esc(j.local.slice(11,16)):'')+'</div><div class="hcdl-xdays">';
        for(i=0;i<j.days.length;i++){var y=j.days[i],dn=new Date(y.date+'T12:00:00');h+='<div class="hcdl-xday"><b>'+(i===0?'Today':esc(dn.toLocaleDateString('en-US',{weekday:'short'})))+'</b><span>'+esc(y.desc)+'</span><span>'+y.hiF+'° / '+y.loF+'°F</span>'+(y.rain!=null?'<small>☔ '+y.rain+'%</small>':'')+'</div>';}
        h+='</div>';}
      else if(id==='apod'){var tt=tsafe(j.title),ex=tsafe(j.explanation);if(!tt){o.innerHTML='<div class="hcdl-card hcdl-bad">🛡️ Today\u2019s NASA picture was hidden by Dev Lab safety.</div>';return;}
        h+='<div class="hcdl-xw"><b>'+esc(tt)+'</b> <span class="hcdl-xs">'+esc(j.date)+'</span></div>'+
          (j.image?'<a href="'+esc(j.link)+'" target="_blank" rel="noopener noreferrer"><img class="hcdl-ximg" src="'+esc(j.image)+'" alt="'+esc(tt)+'" loading="lazy" referrerpolicy="no-referrer"></a>':'<p class="hcdl-xs">(No picture to show today, it may be a video. Tap the link to see it on NASA\u2019s site.)</p>')+
          (j.credit?'<div class="hcdl-xs">📷 '+esc(j.credit)+'</div>':'')+(ex?'<details class="hcdl-xex"><summary>About this picture</summary><p>'+esc(ex)+'</p></details>':'')+
          '<a class="hcdl-xa" href="'+esc(j.link)+'" target="_blank" rel="noopener noreferrer">Open on NASA\u2019s site ↗</a>';}
      else if(id==='wiki'){for(i=0;i<j.pages.length;i++){var pg=j.pages[i],tx=tsafe(pg.text);if(!tx)continue;h+='<div class="hcdl-xwp"><a href="'+esc(pg.url)+'" target="_blank" rel="noopener noreferrer"><b>'+esc(pg.title)+'</b></a><p>'+esc(tx)+'</p></div>';}}
      h+='<div class="hcdl-tag">'+esc(j.source||'')+' · ⏱ '+secs(Date.now()-t0)+' · 🛡️ Dev Lab safety</div></div>';
      o.innerHTML=h;});
  }

  // ---------- 🔑 hc v2.2 Tabo API keys ----------
  // The raw key is shown ONCE (right after you make it) and never saved here or on the server (the server keeps only its SHA-256).
  var AKB=(W.location&&W.location.origin&&/^https?:/.test(W.location.origin)?W.location.origin:'https://taboai.sites.tab.bot')+'/v1',akModels=null,akBusy=0;
  var AKPH='hc-YOUR-KEY-HERE';
  function akHtml(){
    var curl='curl '+AKB+'/chat/completions \\\n  -H "Authorization: Bearer '+AKPH+'" \\\n  -H "Content-Type: application/json" \\\n  -d \'{"model":"tabo","messages":[{"role":"user","content":"Tell me a fun fact"}]}\'';
    var jsx='fetch("'+AKB+'/chat/completions", {\n  method: "POST",\n  headers: {\n    "Authorization": "Bearer '+AKPH+'",\n    "Content-Type": "application/json"\n  },\n  body: JSON.stringify({\n    model: "tabo",\n    messages: [{ role: "user", content: "Tell me a fun fact" }]\n  })\n})\n  .then(r => r.json())\n  .then(j => console.log(j.choices[0].message.content));';
    return ''+
    '<div class="hcak-hero"><b>🔑 Tabo API</b><span>Make keys so other apps can use all the Tabo AIs. Works like an OpenAI key. 🛡️ The Safety Shield stays on.</span></div>'+
    '<div class="hcdl-card hcak-mk"><div class="hcak-h">✨ Make a new key</div>'+
      '<div class="hcak-mkr"><div class="hcak-f1"><label class="hcdl-l" for="hcak-lb">Name</label><input id="hcak-lb" class="hcdl-in1" maxlength="40" placeholder="e.g. My Shortcut" autocomplete="off"></div>'+
      '<div class="hcak-f2"><label class="hcdl-l" for="hcak-lm">Requests / day</label><input id="hcak-lm" class="hcdl-in1" type="number" inputmode="numeric" min="1" max="1000" value="100"></div>'+
      '<button type="button" id="hcak-go" class="hcdl-btn hcdl-go hcak-gob">🔑 Make key</button></div>'+
      '<div id="hcak-new" class="hcak-new" hidden><div class="hcak-nw">⚠️ Save it now, you won\u2019t see it again!</div><div class="hcak-kbox" id="hcak-kv"></div>'+
      '<div class="hcdl-bar"><button type="button" id="hcak-cp" class="hcdl-btn hcdl-go">📋 Copy key</button><button type="button" id="hcak-tst" class="hcdl-btn">🧪 Test it</button><button type="button" id="hcak-ok" class="hcdl-btn">✓ I saved it</button></div></div>'+
      '<div id="hcak-mo" aria-live="polite"></div></div>'+
    '<div class="hcdl-card"><div class="hcak-h">🗂️ Your keys <span id="hcak-tot" class="hcak-tot"></span> <button type="button" id="hcak-rf" class="hcdl-btn hcdl-sm" aria-label="Refresh">🔄</button></div><div id="hcak-ls" class="hcak-ls"><div class="hcdl-note">Loading…</div></div></div>'+
    '<div class="hcdl-card"><div class="hcak-h">🎟️ Public keys <span id="hcak-ptot" class="hcak-tot"></span> <button type="button" id="hcak-prf" class="hcdl-btn hcdl-sm" aria-label="Refresh public keys">🔄</button></div><div class="hcdl-note">Free keys people made with their Domotime account (50/day, 10/min each).</div><div id="hcak-pls" class="hcak-ls"><div class="hcdl-note">Loading…</div></div></div>'+
    '<div class="hcdl-card"><div class="hcak-h">🧪 Test my key</div>'+
      '<label class="hcdl-l" for="hcak-tk">Paste a key</label><input id="hcak-tk" class="hcdl-in1" type="password" placeholder="hc-…" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" data-lpignore="true" data-1p-ignore>'+
      '<label class="hcdl-l" for="hcak-tm">AI</label><select id="hcak-tm" class="hcdl-in1"><option value="tabo">Tabo AI</option></select>'+
      '<label class="hcdl-l" for="hcak-tq">Message</label><div class="hcdl-kr"><input id="hcak-tq" class="hcdl-in1" maxlength="2000" value="Tell me a fun fact about apples"><button type="button" id="hcak-ts" class="hcdl-btn hcdl-go">Send</button></div>'+
      '<div id="hcak-to" aria-live="polite"></div></div>'+
    '<div class="hcdl-card hcak-how"><div class="hcak-h">📖 How to use</div>'+
      '<ol class="hcak-steps"><li>Make a key above and copy it.</li><li>In any app that takes an <b>OpenAI key</b> + a custom <b>base URL</b>, paste:</li></ol>'+
      '<div class="hcak-kvr"><span>Base URL</span><code id="hcak-bu">'+esc(AKB)+'</code><button type="button" class="hcdl-btn hcdl-sm" data-akcp="hcak-bu">📋</button></div>'+
      '<div class="hcak-kvr"><span>API key</span><code>'+AKPH+'</code></div>'+
      '<div class="hcak-kvr"><span>Model</span><code>tabo</code><small>or any AI name/id from the list</small></div>'+
      '<div class="hcak-ex"><div class="hcak-exh">curl <button type="button" class="hcdl-btn hcdl-sm" data-akcp="hcak-c1">📋</button></div><pre id="hcak-c1">'+esc(curl)+'</pre></div>'+
      '<div class="hcak-ex"><div class="hcak-exh">JavaScript <button type="button" class="hcdl-btn hcdl-sm" data-akcp="hcak-c2">📋</button></div><pre id="hcak-c2">'+esc(jsx)+'</pre></div>'+
      '<div class="hcak-tip">📲 <b>iOS Shortcuts:</b> add <b>Get Contents of URL</b> → URL <code>'+esc(AKB)+'/chat/completions</code> → Method <b>POST</b> → Headers: <code>Authorization</code> = <code>Bearer '+AKPH+'</code> → Request Body <b>JSON</b>: <code>model</code> = tabo, <code>messages</code> = an Array with one Dictionary (<code>role</code> = user, <code>content</code> = your question). Then <b>Get Dictionary Value</b> <code>choices.1.message.content</code> → <b>Show Result</b> or <b>Speak Text</b>.</div>'+
      '<p class="hcdl-note">Limits: each key has its own daily limit (resets at midnight, Chicago time) · all keys together: 2,000/day · 8 messages of history, up to 2,000 characters per message · 😈 Unhinged mode isn\u2019t in the API. Every AI on the site works, and if one is napping 💤 another answers.</p>'+
      '<a class="hcak-doc" href="api.html" target="_blank" rel="noopener">📖 Open the full API docs page ↗</a></div>';
  }
  function akAgo(t){if(!t)return 'never';var s=Math.round((Date.now()-t)/1000);if(s<60)return 'just now';if(s<3600)return Math.floor(s/60)+' min ago';if(s<86400)return Math.floor(s/3600)+' h ago';return Math.floor(s/86400)+' d ago';}
  function akDate(t){try{return new Date(t).toLocaleDateString(undefined,{month:'short',day:'numeric',year:'numeric'});}catch(e){return '';}}
  function akCopy(text,btn){var done=function(){if(btn){var o=btn.textContent;btn.textContent='✅ Copied';setTimeout(function(){btn.textContent=o;},1400);}};
    try{if(W.navigator.clipboard&&W.navigator.clipboard.writeText){W.navigator.clipboard.writeText(text).then(done,function(){akCopy2(text);done();});return;}}catch(e){}akCopy2(text);done();}
  function akCopy2(text){var t=D.createElement('textarea');t.value=text;t.setAttribute('readonly','');t.style.position='fixed';t.style.top='-1000px';D.body.appendChild(t);t.select();try{t.setSelectionRange(0,99999);D.execCommand('copy');}catch(e){}D.body.removeChild(t);}
  function akList(j){var ls=$('hcak-ls');if(!ls)return;
    if(!j||!j.ok){ls.innerHTML='<div class="hcdl-card hcdl-bad">'+esc((j&&j.message)||'Couldn\u2019t load your keys.')+'</div>';return;}
    $('hcak-tot').textContent='· all keys today '+(j.all_keys_today||0)+' / '+(j.all_keys_cap||2000);
    if(!j.keys.length){ls.innerHTML='<div class="hcdl-note">No keys yet. Make one above! 🔑</div>';return;}
    var h='';for(var i=0;i<j.keys.length;i++){var k=j.keys[i],pc=Math.min(100,Math.round(100*k.used_today/Math.max(1,k.limit))),cl=pc>=100?' full':(pc>=80?' hi':'');
      h+='<div class="hcak-row" data-id="'+esc(k.id)+'"><div class="hcak-rt"><b>'+esc(k.label)+'</b><code>'+esc(k.hint)+'</code></div>'+
        '<div class="hcak-ub"><div class="hcak-uf'+cl+'" style="width:'+pc+'%"></div></div>'+
        '<div class="hcak-rm"><span>'+k.used_today+' / '+k.limit+' today</span><span>last used '+esc(akAgo(k.last_used))+'</span><span>'+k.total+' total</span><span>made '+esc(akDate(k.created))+'</span></div>'+
        '<div class="hcak-ra"><label>Limit <input type="number" class="hcak-li" min="1" max="1000" value="'+k.limit+'" aria-label="Daily limit for '+esc(k.label)+'"></label><button type="button" class="hcdl-btn hcdl-sm hcak-sv">Save</button><button type="button" class="hcdl-btn hcdl-sm hcak-rv">🗑 Revoke</button></div></div>';}
    ls.innerHTML=h;
    var rows=ls.querySelectorAll('.hcak-row');for(i=0;i<rows.length;i++)(function(r){var id=r.getAttribute('data-id');
      r.querySelector('.hcak-rv').onclick=function(){var nm=r.querySelector('b').textContent;if(!W.confirm('Revoke "'+nm+'"? Apps using it stop working right away.'))return;this.disabled=true;api('/api/dev/apikeys',{action:'revoke',id:id}).then(akList);};
      r.querySelector('.hcak-sv').onclick=function(){var v=parseInt(r.querySelector('.hcak-li').value,10);if(!(v>=1))return;this.disabled=true;api('/api/dev/apikeys',{action:'limit',id:id,limit:Math.min(1000,v)}).then(akList);};})(rows[i]);}
  function akPub(j){var ls=$('hcak-pls');if(!ls)return;if(!j||!j.ok){ls.innerHTML='<div class="hcdl-note">Couldn\u2019t load public keys.</div>';return;}
    var rows=j.pub||[],h='',live=0,d=function(t){if(!t)return'-';try{return new Date(t).toLocaleDateString(undefined,{month:'short',day:'numeric'});}catch(e){return'-';}};
    for(var i=0;i<rows.length;i++){var r=rows[i];if(r.live)live++;h+='<div class="hcak-row hcak-prow" data-acct="'+esc(r.acct)+'"><div class="hcak-rt"><b>'+esc(r.name)+'</b> '+(r.live?'<code>'+esc(r.hint||'')+'</code>':'<span class="hcdl-note">no key</span>')+'</div><div class="hcdl-note">Made '+d(r.created)+' · '+r.used_today+' / '+(j.pub_limit||50)+' today · '+(r.total||0)+' total</div>'+(r.live?'<button type="button" class="hcdl-btn hcdl-sm hcak-prv">🗑️ Revoke</button>':'')+'</div>';}
    ls.innerHTML=h||'<div class="hcdl-note">No public keys yet.</div>';var t=$('hcak-ptot');if(t)t.textContent=live+' live · '+(j.pub_today||0)+' / '+(j.pub_cap||0)+' today';
    var rr=ls.querySelectorAll('.hcak-prow');for(i=0;i<rr.length;i++)(function(r){var b=r.querySelector('.hcak-prv');if(!b)return;b.onclick=function(){var nm=r.querySelector('b').textContent;if(!W.confirm('Revoke '+nm+'\u2019s free key? It stops working right away.'))return;b.disabled=true;api('/api/dev/apikeys',{action:'pub_revoke',acct:r.getAttribute('data-acct')}).then(akPub);};})(rr[i]);}
  function akPubLoad(){if(!$('hcak-pls'))return;api('/api/dev/apikeys',{action:'pub_list'}).then(akPub);var b=$('hcak-prf');if(b)b.onclick=akPubLoad;}
  function akLoad(){var ls=$('hcak-ls');if(!ls)return;api('/api/dev/apikeys',{action:'list'}).then(akList);akModelsLoad();akPubLoad();}
  function akModelsLoad(){if(akModels)return;akModels=[];W.fetch(AKB+'/models').then(function(r){return r.json();}).then(function(j){akModels=(j&&j.data)||[];var sel=$('hcak-tm');if(!sel||!akModels.length)return;
    var h='<option value="tabo">💜 Tabo AI (default)</option>';for(var i=0;i<akModels.length;i++){var m=akModels[i];if(m.id==='sigma')continue;h+='<option value="'+esc(m.id)+'">'+(m.honeycrisp_status==='ok'?'🟢 ':'⚪ ')+esc(m.name)+'</option>';}sel.innerHTML=h;},function(){akModels=null;});}
  function akInit(){
    $('hcak-go').onclick=function(){if(akBusy)return;var lb=$('hcak-lb').value.trim()||'My key',lm=parseInt($('hcak-lm').value,10);if(!(lm>=1))lm=100;lm=Math.min(1000,lm);
      akBusy=1;var b=this;b.disabled=true;$('hcak-mo').innerHTML='';
      api('/api/dev/apikeys',{action:'create',label:lb,limit:lm}).then(function(j){akBusy=0;b.disabled=false;
        if(!j||!j.ok||!j.created){$('hcak-mo').innerHTML='<div class="hcdl-card hcdl-bad">'+esc((j&&j.message)||'Couldn\u2019t make a key.')+'</div>';return;}
        $('hcak-kv').textContent=j.created.key;$('hcak-new').hidden=false;$('hcak-lb').value='';akList(j);});};
    $('hcak-cp').onclick=function(){akCopy($('hcak-kv').textContent,this);};
    $('hcak-ok').onclick=function(){$('hcak-kv').textContent='';$('hcak-new').hidden=true;};
    $('hcak-tst').onclick=function(){$('hcak-tk').value=$('hcak-kv').textContent;var t=$('hcak-tk');try{t.scrollIntoView({block:'center',behavior:'smooth'});}catch(e){}};
    $('hcak-rf').onclick=akLoad;
    var cps=root.querySelectorAll('[data-akcp]');for(var i=0;i<cps.length;i++)cps[i].onclick=function(){var el=$(this.getAttribute('data-akcp'));if(el)akCopy(el.textContent,this);};
    $('hcak-ts').onclick=akTest;$('hcak-tq').onkeydown=function(e){if(e.key==='Enter'){e.preventDefault();akTest();}};
  }
  function akTest(){var k=$('hcak-tk').value.trim(),q=$('hcak-tq').value.trim(),o=$('hcak-to'),b=$('hcak-ts');
    if(!/^hc-/.test(k)){o.innerHTML='<div class="hcdl-card hcdl-bad">Paste a Tabo key (it starts with hc-).</div>';return;}
    if(!q)return;b.disabled=true;var t0=Date.now();o.innerHTML='<div class="hcdl-note">⏳ Asking…</div>';
    W.fetch(AKB+'/chat/completions',{method:'POST',headers:{'Authorization':'Bearer '+k,'Content-Type':'application/json'},body:JSON.stringify({model:$('hcak-tm').value,messages:[{role:'user',content:q}]})})
      .then(function(r){return r.json().catch(function(){return {error:{message:'Server error ('+r.status+').'}};}).then(function(j){return {s:r.status,j:j};});})
      .then(function(x){b.disabled=false;var j=x.j;
        if(x.s!==200||!j.choices){o.innerHTML='<div class="hcdl-card hcdl-bad">'+(x.s===401?'🔒 ':x.s===429?'⏳ ':'⚠️ ')+esc((j.error&&j.error.message)||'Error '+x.s)+' <span class="hcdl-tag">'+x.s+'</span></div>';return;}
        var nm=j.model;for(var i=0;akModels&&i<akModels.length;i++)if(akModels[i].id===j.model)nm=akModels[i].name;
        o.innerHTML='<div class="hcdl-card hcdl-good"><div class="hcak-rep">'+fmt(j.choices[0].message.content)+'</div><div class="hcdl-tag">✅ '+esc(nm)+' · ⏱ '+secs(Date.now()-t0)+(j.honeycrisp_shield?' · 🛡️ Shield':'')+(j.honeycrisp_fallback?' · 💤 '+esc(j.honeycrisp_fallback.asked_name)+' was napping':'')+'</div></div>';
        if(root&&$('hcak-ls'))api('/api/dev/apikeys',{action:'list'}).then(akList);},
      function(){b.disabled=false;o.innerHTML='<div class="hcdl-card hcdl-bad">Couldn\u2019t reach the server. Check the internet.</div>';});}
  // ---------- 🐛 hc v2.3 Bugs: what bugcatch.js caught on everyone's devices (no personal stuff is ever in here) ----------
  var bgData=null,bgOpen=0,bgBusy=0;
  function bgHtml(){
    return '<div class="hcbg-hero"><b>🐛 Bug Catcher</b><span>The site catches bugs 24/7 on every device and logs them here (no chats, codes or names, ever). Tab reads this log every morning and fixes the real ones.</span></div>'+
      '<div class="hcbg-sum" id="hcbg-sum">Loading…</div>'+
      '<div class="hcdl-bar hcbg-bar"><button type="button" id="hcbg-rf" class="hcdl-btn">🔄 Refresh</button><button type="button" id="hcbg-tb" class="hcdl-btn hcdl-go">🧪 Make a test bug</button><button type="button" id="hcbg-cl" class="hcdl-btn">🧹 Clear fixed</button></div>'+
      '<div id="hcbg-mo" aria-live="polite"></div>'+
      '<div id="hcbg-ls" class="hcbg-ls"></div>'+
      '<p class="hcdl-note">💤 Self-healing: an AI that fails 3 times in a row naps for 10 min (the picker skips it). A page file that fails to load gets retried by itself. Errors inside your Code-mode games aren\u2019t site bugs, so they\u2019re only counted.</p>';
  }
  function bgAgo(t){var s=Math.max(0,Math.round((Date.now()-t)/1000));if(s<60)return 'just now';if(s<3600)return Math.floor(s/60)+'m ago';if(s<86400)return Math.floor(s/3600)+'h ago';return Math.floor(s/86400)+'d ago';}
  var BG_MODE={chat:'💬 Chat',code:'💻 Code',lessons:'📚 Lessons',tots:'🐣 Tots',studio:'🎤 Studio',music:'🎙️ Music',devlab:'🛠️ Dev Lab',server:'🖥️ Server',other:'❔ Other'};
  var BG_ST={'new':'🔴','fixed':'✅','ignored':'🙈'};
  function bgBadge(n){var b=$('hcbg-bdg');if(!b)return;b.textContent=n>99?'99+':String(n);b.hidden=!(n>0);}
  function bgLoad(quiet){if(bgBusy)return;bgBusy=1;
    W.fetch('/api/bugs/list',{headers:{'x-hc-pass':pass()}}).then(function(r){return r.json().catch(function(){return {ok:false};}).then(function(j){if(r.status===403){j={ok:false,message:'🔒 Admin pass expired. Close the Lab and unlock with the 🔨 again.'};}return j;});},function(){return {ok:false,message:'Couldn\u2019t reach the server. Check the internet.'};})
      .then(function(j){bgBusy=0;if(!j||!j.ok){if(!quiet)$('hcbg-sum').innerHTML='<span class="hcdl-bad">'+esc((j&&j.message)||'Couldn\u2019t load the bug log.')+'</span>';return;}
        bgData=j;bgBadge(j['new']||0);bgPaint();});}
  function bgPaint(){var j=bgData,ls=$('hcbg-ls'),sm=$('hcbg-sum');if(!j||!ls)return;
    var nz=j.noise||{},nzT=0,k;for(k in nz)if(nz.hasOwnProperty(k))nzT+=nz[k];
    sm.innerHTML='<div class="hcbg-big"><span class="hcbg-n'+(j['new']?' hot':'')+'"><b>'+j['new']+'</b> new bug'+(j['new']===1?'':'s')+'</span><span class="hcbg-n ok"><b>'+j.fixed_week+'</b> fixed this week</span></div>'+
      (nzT?'<div class="hcdl-tag">Not counted as bugs this week: '+(nz.code_preview?nz.code_preview+' in Code-mode games · ':'')+(nzT-(nz.code_preview||0))+' browser noise</div>':'');
    if(!j.bugs.length){ls.innerHTML='<div class="hcbg-empty">🎉 No bugs caught. Everything\u2019s running smooth!</div>';return;}
    var h='';for(var i=0;i<j.bugs.length;i++){var b=j.bugs[i],on=bgOpen===b.id;
      h+='<div class="hcbg-it st-'+esc(b.status)+(on?' open':'')+'"><button type="button" class="hcbg-row" data-bg="'+b.id+'" aria-expanded="'+(on?'true':'false')+'">'+
        '<span class="hcbg-ct" title="times seen">'+(BG_ST[b.status]||'')+' ×'+b.count+'</span>'+
        '<span class="hcbg-m"><span class="hcbg-msg">'+esc(String(b.message).slice(0,110))+'</span>'+
        '<span class="hcbg-meta">'+esc(BG_MODE[b.mode]||b.mode)+' · v'+esc(b.version)+' · '+bgAgo(b.last_seen)+(b.note?' · '+esc(b.note):'')+'</span></span></button>'+
        (on?bgDet(b):'')+'</div>';}
    ls.innerHTML=h;
    var rs=ls.querySelectorAll('[data-bg]');for(i=0;i<rs.length;i++)rs[i].onclick=function(){var id=+this.getAttribute('data-bg');bgOpen=bgOpen===id?0:id;bgPaint();};
    var as=ls.querySelectorAll('[data-bgs]');for(i=0;i<as.length;i++)as[i].onclick=function(){bgSet(+this.getAttribute('data-bgi'),this.getAttribute('data-bgs'));};
  }
  function bgDet(b){
    return '<div class="hcbg-det">'+
      '<div class="hcbg-full">'+esc(b.message)+'</div>'+
      '<div class="hcbg-kv"><span>Type</span><b>'+esc(b.type)+'</b><span>File</span><b>'+esc(b.source||'-')+(b.line?':'+esc(b.line):'')+'</b>'+
      '<span>Seen</span><b>'+b.count+'× · first '+bgAgo(b.first_seen)+' · last '+bgAgo(b.last_seen)+'</b><span>Device</span><b>'+esc(b.ua||'-')+(b.viewport?' · '+esc(b.viewport):'')+'</b></div>'+
      (b.stack?'<pre class="hcbg-stk">'+esc(b.stack)+'</pre>':'')+
      '<div class="hcdl-bar">'+(b.status!=='fixed'?'<button type="button" class="hcdl-btn hcdl-go" data-bgi="'+b.id+'" data-bgs="fixed">✅ Fixed</button>':'')+
      (b.status!=='ignored'?'<button type="button" class="hcdl-btn" data-bgi="'+b.id+'" data-bgs="ignored">🙈 Ignore</button>':'')+
      (b.status!=='new'?'<button type="button" class="hcdl-btn" data-bgi="'+b.id+'" data-bgs="new">↩️ Mark new</button>':'')+'</div></div>';
  }
  function bgSay(m,bad){var o=$('hcbg-mo');if(!o)return;o.innerHTML='<div class="hcdl-card '+(bad?'hcdl-bad':'hcdl-good')+'">'+m+'</div>';clearTimeout(bgSay.t);bgSay.t=setTimeout(function(){o.innerHTML='';},4000);}
  function bgSet(id,st){api('/api/bugs/update',{id:id,status:st}).then(function(j){if(!j||!j.ok){bgSay(esc((j&&j.message)||'Couldn\u2019t update it.'),1);return;}
      bgSay(st==='fixed'?'✅ Marked fixed. If it comes back, it pops up as new again.':st==='ignored'?'🙈 Ignored.':'↩️ Back to new.');bgOpen=0;bgLoad();});}
  function bgInit(){
    $('hcbg-rf').onclick=function(){bgLoad();};
    $('hcbg-cl').onclick=function(){api('/api/bugs/clear',{}).then(function(j){if(!j||!j.ok){bgSay(esc((j&&j.message)||'Couldn\u2019t clear.'),1);return;}bgSay('🧹 Cleared '+j.removed+' fixed bug'+(j.removed===1?'':'s')+'.');bgLoad();});};
    $('hcbg-tb').onclick=function(){if(!W.hcBugs){bgSay('The bug catcher isn\u2019t loaded. Reload the page.',1);return;}
      W.hcBugs.test();bgSay('🧪 Threw a harmless test bug! Watch it show up…');setTimeout(function(){bgLoad();},2500);};
  }
  function open(t){if(t)tok=t;if(!root)build();root.hidden=false;D.documentElement.className+=' hcdl-on';show(tab);if(tab!=='bugs')bgLoad(true);}
  function close(){if(!root)return;root.hidden=true;D.documentElement.className=D.documentElement.className.replace(/\s*hcdl-on/g,'');}
  W.hcDevLab={open:open,close:close};
})(window,document);
