/* devsafe.js (hc v1.9; v1.7.1) 🛠️ Dev Lab safety: LIGHTER than the main chat, but the core kid-safe categories stay blocked.
   v1.9: the same lists also run on the server (_worker.js HC_DEVSAFE) for the Dev Lab's model test, key tester chat and web research;
   this browser copy re-checks every reply that comes back from a key he typed.
   Lists come from the main filter (_worker.js BAD_SUB / BAD_TOKEN / HC_BOOZE), minus the harmless stuff the main chat is picky about:
   slang, mild words (dumb, stupid, idiot, hell, damn, crap, wtf, lmao), cartoon / video-game violence (kill, shoot, sword, boss, die),
   spooky / Halloween (ghost, zombie, skeleton, haunted, witch, blood moon), coding words (kill -9, child process, execute, abort, cocktail sort),
   pirate / fantasy words (rum, grog, ale, tavern) and identity words (gay, queer). Strong swears are masked (f***), not blocked. */
(function(G){
  'use strict';
  function d(s){try{return (typeof atob==='function'?atob(s):Buffer.from(s,'base64').toString('binary')).split('|');}catch(e){return [];}}
  var SL_SUB=d('bmlnZ3xuaWdhfG5pZ3J8ZmFnZ290fHRyYW5ueXx3ZXRiYWNrfHJhZ2hlYWR8dG93ZWxoZWFkfGJlYW5lcg=='),SL_WORD=d('ZmFnfGZhZ3N8Y29vbnxjb29uc3xnb29rfGdvb2tzfHNwaWN8c3BpY3N8ZHlrZXxkeWtlc3xraWtlfGtpa2VzfGNoaW5rfGNoaW5rc3xuZWdyb3xuZWdyb3N8cmV0YXJkfHJldGFyZHN8cmV0YXJkZWQ='); // hate slurs (kept encoded so they are not plain text in the page)
  var CATS={
    sexual:/\b(porn\w*|nudes?|naked|nudity|sex|sexual\w*|sexy|sexting|horny|orgasm\w*|erotic\w*|hentai|onlyfans|nsfw|xxx|strip ?clubs?|strippers?|prostitut\w*|hookers?|escort service\w*|boobs?|boobies|tits|titties|penis\w*|vagina\w*|dildos?|vibrators?|masturbat\w*|blow ?jobs?|hand ?jobs?|milfs?|fetish\w*|kinky|lingerie|condoms?|making out|adults? only|semen|sperm|molest\w*|rape[ds]?|raping|rapist)\b|\b18 ?\+|\bx-rated\b/,
    drugs:/\b(weed|marijuana|cannabis|cocaine|heroin|meth|methamphetamine|crystal meth|fentanyl|lsd|mdma|ecstasy pills?|shrooms|magic mushrooms|get(ting)? high|stoned|stoners?|bong|vapes?|vaping|vaper|juul\w*|nicotine|cigarettes?|cigars?|tobacco|smoking pot|alcohol\w*|vodka|whiske?y|tequila|booze|liquor|beers?|drunk\w*|hangover|cocktails?|(red|white) wine|glass(es)? of wine|drink(ing)? wine|wine bottles?|getting wasted)\b/,
    gambling:/\b(gambl\w*|casinos?|sportsbooks?|sports betting|place (a )?bets?|placing bets|betting odds|slot machines?|roulette|online poker|real[- ]money (poker|bets?|games?)|bookies?|parlays?|scratch(-| )?offs? tickets?)\b/,
    selfharm:/\b(suicid\w*|kill (myself|yourself|urself|himself|herself|themselves)|kys|self[- ]?harm\w*|cut(ting)? (myself|yourself)|hurt(ing)? (myself|yourself)|hang (myself|yourself)|end (my|your) (own )?life|overdos\w*|want to die|wanna die)\b/,
    gore:/\b(gore|gory|gorey|disembowel\w*|decapitat\w*|dismember\w*|mutilat\w*|entrails|eviscerat\w*|intestines (spill\w*|hanging|out)|tortur(e|ed|ing) (him|her|them|people|animals|kids|a person)|tortured to death|blood[- ](splatter\w*|soaked|gushing|spurting|everywhere)|severed (heads?|limbs?|arms?|legs?|fingers?)|guts (spill\w*|everywhere)|skinned alive|burned alive)\b/,
    hate:/\b(heil hitler|sieg heil|white power|white supremac\w*|kkk|ku klux|gas the jews|race war|(black|white|jewish|muslim|gay|asian|mexican|indian|chinese) people are (inferior|subhuman|animals|trash)|hate (all )?(black|white|jewish|muslim|gay|asian|mexican|indian|chinese) people)\b/
  };
  // exact harmless phrases that would trip a word above
  var OK_PHRASES=/\b(root beers?|ginger beers?|butter ?beers?|cocktail (shaker )?sort\w*|sex(tant|tet)s?|essex|middlesex|wine ?gums?|kill -?\d+|stoned age)\b/g;
  var SWEAR=/\b(f+u+c+k+\w*|motherf\w*|sh[i1]t(s|ty|ting|head|heads)?|bullsh[i1]t|b[i1]tch(es|y)?|cunts?|assholes?|bastards?|dickheads?|whores?|sluts?|pussy)\b/gi;
  var LEET={'0':'o','1':'i','3':'e','4':'a','5':'s','7':'t','@':'a','$':'s'};
  function norm(t){return String(t||'').toLowerCase().replace(/[\u200b-\u200f\u2060\ufeff]/g,'').replace(/[’`]/g,"'");}
  function leet(t){return t.replace(/[0134578@$]/g,function(c){return LEET[c];});}
  function check(text){
    var t=norm(text).replace(OK_PHRASES,' ');
    for(var k in CATS)if(CATS.hasOwnProperty(k)&&CATS[k].test(t))return {ok:false,cat:k};
    var lt=leet(t),flat=lt.replace(/[^a-z]+/g,'');
    for(var i=0;i<SL_SUB.length;i++)if(SL_SUB[i]&&flat.indexOf(SL_SUB[i])>=0&&!/niagara|snigger/.test(flat))return {ok:false,cat:'hate'};
    var words=lt.split(/[^a-z]+/);
    for(i=0;i<words.length;i++)if(words[i]&&SL_WORD.indexOf(words[i])>=0)return {ok:false,cat:'hate'};
    return {ok:true};
  }
  function mask(text){return String(text||'').replace(SWEAR,function(w){return /^shiit?ake/i.test(w)?w:w.charAt(0)+new Array(Math.min(w.length,6)).join('*');});}
  function safe(text){var r=check(text);if(!r.ok)return r;return {ok:true,text:mask(text)};}
  var api={check:check,mask:mask,safe:safe,BLOCKED:'🛡️ Blocked by Dev Lab safety',
    SYSTEM:"You are a helpful AI inside Tabo AI's Dev Lab. The person chatting is a kid developer (about 10 to 13 years old). "+
    "Keep every answer kid-safe: no sexual or 18+ content, no drugs, alcohol, vaping or gambling, no self-harm, no gore, no hate or slurs, no swearing. "+
    "Coding help, games, jokes, slang, cartoon or video-game action and spooky Halloween fun are all fine. "+
    "Never ask for personal info like their full name, address, school, phone or passwords. If something isn't kid-safe, say no kindly and suggest something fun instead."};
  if(typeof module!=='undefined'&&module.exports)module.exports=api;else G.hcDevSafe=api;
})(typeof window!=='undefined'?window:this);
