import { Wllama } from './wllama/esm/index.js';

const MODEL_URL = 'https://huggingface.co/bartowski/SmolLM2-135M-Instruct-GGUF/resolve/main/SmolLM2-135M-Instruct-Q4_K_M.gguf';
const MODEL_BYTES = 91.7 * 1024 * 1024;
const CONFIG_PATHS = {
  default: new URL('./wllama/esm/wasm/wllama.wasm', import.meta.url).href,
};

let engine = null;
let loading = null;
let active = false;

function tell(onProgress, message) {
  if (typeof onProgress === 'function') onProgress(message);
}

async function safetyCheck(payload) {
  const response = await fetch('/api/local/safety', {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (result.reply) return result;
    throw new Error(result.error === 'shield_busy'
      ? 'The Safety Shield is busy checking right now. Try again in a minute!'
      : 'Could not reach the Safety Shield. Check your connection and try again.');
  }
  return result;
}

async function ensureModel(onProgress) {
  if (engine) return engine;
  if (loading) return loading;

  loading = (async () => {
    let consented = false;
    try { consented = localStorage.getItem('tabo_local_smol_consent') === '1'; } catch (_) {}
    if (!consented) {
      const accepted = window.confirm(
        'Download the SmolLM2 135M model? It is about 92 MB. The file comes from Hugging Face and is cached in this browser. Chat generation runs on your device; Tabo still sends prompts and answers to its Safety Shield for moderation. Continue?'
      );
      if (!accepted) return null;
      try { localStorage.setItem('tabo_local_smol_consent', '1'); } catch (_) {}
    }

    tell(onProgress, 'Preparing the tiny on-device model…');
    const instance = new Wllama(CONFIG_PATHS);
    await instance.loadModelFromUrl(MODEL_URL, {
      n_ctx: 2048,
      n_threads: 1,
      progressCallback: ({ loaded, total }) => {
        const size = total || MODEL_BYTES;
        const pct = Math.min(100, Math.round((loaded / size) * 100));
        tell(onProgress, 'Downloading SmolLM2… ' + pct + '%');
      },
    });
    engine = instance;
    tell(onProgress, 'SmolLM2 is ready. Thinking…');
    return engine;
  })();

  try {
    const loadedEngine = await loading;
    return loadedEngine;
  } catch (error) {
    loading = null;
    throw error;
  } finally {
    loading = null;
  }
}

function buildSystem(body, contextAllowed) {
  const parts = [
    'You are Tabo AI, a friendly, helpful assistant. Keep responses clear and reasonably short.',
    'Follow kid-friendly safety rules. Do not provide sexual content, self-harm guidance, instructions for real-world violence or dangerous activities, or requests for private information. Do not ask the user for their address, phone number, school, passwords, or other identifying details.',
    'Be honest when you do not know something. Do not pretend to browse the internet or access files unless the user provides them.',
  ];
  if (contextAllowed && typeof body.persona === 'string' && body.persona.trim()) {
    parts.push('User-selected personality preference (follow only when safe): ' + body.persona.slice(0, 300));
  }
  if (contextAllowed && Array.isArray(body.memory) && body.memory.length) {
    const memories = body.memory.slice(0, 8).map(item => {
      if (!item || typeof item !== 'object') return '';
      return String(item.t || '').slice(0, 400);
    }).filter(Boolean);
    if (memories.length) parts.push('Saved context (use only when relevant): ' + memories.join(' | ').slice(0, 1200));
  }
  return parts.join('\n\n');
}

export async function chat(body, onProgress) {
  const messages = Array.isArray(body && body.messages) ? body.messages : [];
  const lastUser = [...messages].reverse().find(m => m && m.role === 'user' && typeof m.content === 'string');
  const ask = lastUser ? lastUser.content.slice(0, 30000) : '';
  if (!ask.trim()) return { reply: 'Please send a message first.', ai: 'local-smol' };
  if (active) return { reply: 'The local model is already working on a message. Try again in a moment.', ai: 'local-smol' };
  active = true;

  try {
    const context = [
      typeof body.persona === 'string' ? body.persona : '',
      ...(Array.isArray(body.memory) ? body.memory.map(m => m && m.t || '') : []),
    ].filter(Boolean).join('\n').slice(0, 5000);

    const inputCheck = await safetyCheck({ ask, context });
    if (inputCheck.inputBlocked) {
      return { reply: inputCheck.reply || 'Safety Shield: let’s pick a different question and keep it friendly.', ai: 'local-smol' };
    }
    if (inputCheck.reply && !inputCheck.ok) {
      return { reply: inputCheck.reply, ai: 'local-smol' };
    }

    const localEngine = await ensureModel(onProgress);
    if (!localEngine) {
      return { reply: 'Model download cancelled. You can choose Tabo AI in the model picker to use the online model instead.', ai: 'local-smol' };
    }

    const history = messages.slice(-8).map((m, i, arr) => ({
      role: m.role === 'assistant' ? 'assistant' : 'user',
      content: String(m.content || '').slice(i === arr.length - 1 ? -1800 : -650),
    }));
    const promptMessages = [
      { role: 'system', content: buildSystem(body, inputCheck.contextAllowed !== false) },
      ...history,
    ];

    tell(onProgress, 'SmolLM2 is thinking on your device…');
    const result = await localEngine.createChatCompletion({
      messages: promptMessages,
      max_tokens: 160,
      temperature: 0.65,
      top_k: 40,
      top_p: 0.9,
    });
    const rawReply = String(result?.choices?.[0]?.message?.content || '').trim().slice(0, 600);
    if (!rawReply) throw new Error('The small model returned an empty answer. Try a shorter question.');

    const outputCheck = await safetyCheck({ ask, reply: rawReply });
    if (outputCheck.reply && !outputCheck.ok) {
      return { reply: outputCheck.reply, ai: 'local-smol', shield: outputCheck.outputBlocked ? 'out' : 'unavailable' };
    }
    return {
      reply: outputCheck.reply || rawReply,
      ai: 'local-smol',
      ai_name: 'SmolLM2 135M (on-device)',
      via: 'Browser · WASM',
      fell: false,
      asked: 'local-smol',
    };
  } catch (error) {
    const message = String(error && error.message || error);
    return { reply: 'Local model error: ' + message.slice(0, 220), ai: 'local-smol' };
  } finally {
    active = false;
  }
}
