/* voice.js (Tabo v2.1: the talking face is now a colorful BLOB buddy (or your Tot) with custom eyes + colors, best-voice auto-pick, smoother speech. v1.9.5: the face has EMOTIONS, the user Nov 1 6:51 PM: it blushes when it says something embarrassing, grins, laughs, frowns... v1.9.4: 🎙️ opens the TALKING FACE, the user Nov 1 6:49 PM. v1.9.3: "add a voice bot in chat"). Uses ONLY the browser's own Web Speech API:
   no keys, no server, no audio stored. 🎙️ mic = voice typing (fills the box, auto-sends when you stop talking);
   🔊 Read replies aloud (speechSynthesis, voice picker); 🎙️ mic / 😀 Talking face = a cartoon face that listens
   (or takes typing when speech recognition is missing, e.g. the iPad home-screen app), thinks, then says the answer out loud. Spoken text goes through the SAME send() -> /api/chat -> Safety Shield as typed
   text, and the same 200-character limit. ES5 only. */
(function(){
  'use strict';
  var W=window,D=document;
  function $(id){return D.getElementById(id);}
  var form=$('composer'),input=$('msg'),log=$('log');
  if(!form||!input||!log)return;
  var PK='hc_voice_v1',MAX=200;
  function SRC(){return W.SpeechRecognition||W.webkitSpeechRecognition||null;}
  function SS(){return ('speechSynthesis' in W)&&W.SpeechSynthesisUtterance?W.speechSynthesis:null;}
  function trim(s){return String(s==null?'':s).replace(/^\s+|\s+$/g,'');}
  function toast(m){if(W.hcApp&&W.hcApp.toast)W.hcApp.toast(m);}
  function hasC(el,c){return el&&(' '+el.className+' ').indexOf(' '+c+' ')>=0;}
  function setC(el,c,on){if(!el)return;var h=hasC(el,c);if(on&&!h)el.className+=' '+c;else if(!on&&h)el.className=(' '+el.className+' ').replace(' '+c+' ',' ').replace(/^\s+|\s+$/g,'');}
  var pref={on:false,v:'',m:false};
  try{var r0=JSON.parse(localStorage.getItem(PK)||'null');if(r0&&typeof r0==='object'){pref.on=!!r0.on;pref.v=String(r0.v||'');pref.m=!!r0.m;}}catch(e){}
  function savePref(){try{localStorage.setItem(PK,JSON.stringify(pref));}catch(e){}}
  function lang(){var l=(navigator.language||'en-US');return /^en/i.test(l)?l:'en-US';}

  /* ---------- clean text for speaking ---------- */
  function clean(t){t=String(t||'');
    t=t.replace(/```[\s\S]*?(```|$)/g,' (code block) ');
    t=t.replace(/`([^`]*)`/g,'$1');
    t=t.replace(/!\[[^\]]*\]\([^)]*\)/g,' ').replace(/\[([^\]]+)\]\([^)]*\)/g,'$1');
    t=t.replace(/https?:\/\/\S+/g,' link ');
    t=t.replace(/<[^>]+>/g,' ');
    t=t.replace(/\*+\s*bleep\s*\*+/gi,' bleep ').replace(/(^|[^A-Za-z*])[A-Za-z]{1,3}\*+[A-Za-z*]*/g,'$1bleep'); /* v2.0.1 unhinged: *BLEEP* and f*** are spoken as "bleep" */
    t=t.replace(/[\uD800-\uDBFF][\uDC00-\uDFFF]/g,' ').replace(/[\u2600-\u27BF\u2B00-\u2BFF\u2300-\u23FF\uFE0E\uFE0F\u200D\u20E3]/g,' ');
    t=t.replace(/^\s{0,3}#{1,6}\s*/gm,'').replace(/^\s*>\s?/gm,'').replace(/^\s*[-*+]\s+/gm,'').replace(/^\s*\d+\.\s+/gm,'');
    t=t.replace(/[*_~|#\\]+/g,' ').replace(/\s*\n+\s*/g,'. ').replace(/([.!?:;,])\s*\.(?=\s|$)/g,'$1').replace(/\.\s*\./g,'.').replace(/\s{2,}/g,' ');
    return trim(t.replace(/^[.\s]+/,''));}
  function chunks(t){var parts=t.match(/[^.!?]+[.!?]*\s*/g)||[t],out=[],cur='';
    for(var i=0;i<parts.length;i++){var p=parts[i];
      while(p.length>180){var cut=p.lastIndexOf(' ',180);if(cut<40)cut=180;if(trim(cur)){out.push(trim(cur));cur='';}out.push(trim(p.slice(0,cut)));p=p.slice(cut);}
      if(cur&&(cur+p).length>60){out.push(trim(cur));cur='';}cur+=p;}
    if(trim(cur))out.push(trim(cur));var o2=[];for(var j=0;j<out.length;j++)if(out[j])o2.push(out[j]);return o2.length?o2:[t];}

  /* ---------- voices (v2.1: auto-picks the BEST voice: Premium / Enhanced / Siri / Natural, en-US first, no novelty voices) ---------- */
  var voices=[],bestName='';
  var NOVEL=/novelty|whisper|bells|bad news|good news|bahh|bubbles|cellos|jester|organ|trinoids|zarvox|boing|albert|superstar|wobble|deranged|hysterical|pipe organ|fred\b|junior|ralph|kathy|grandma|grandpa|eddy|flo\b|reed|rocko|sandy|shelley/i;
  function vScore(v){var n=String(v.name||''),l=String(v.lang||''),s=0;
    if(/premium/i.test(n))s+=40;if(/enhanced/i.test(n))s+=35;if(/siri/i.test(n))s+=30;if(/natural|neural/i.test(n))s+=25;
    if(/google us english|online \(natural\)/i.test(n))s+=14;if(/^(samantha|ava|zoe|allison|evan|nathan|tom|susan|joelle|noelle|aaron|nicky)\b/i.test(n))s+=6;
    if(/en[-_]US/i.test(l))s+=10;else if(/en[-_](GB|AU|IE|CA)/i.test(l))s+=6;else s+=2;
    if(NOVEL.test(n))s-=100;if(/compact/i.test(n))s-=4;if(v['default'])s+=1;return s;}
  function loadVoices(){var s=SS();if(!s)return [];var all=[];try{all=s.getVoices()||[];}catch(e){}
    var en=[],seen={};for(var i=0;i<all.length;i++){var v=all[i];if(!v||!/^en([-_]|$)/i.test(v.lang||'')||seen[v.name])continue;seen[v.name]=1;en.push(v);}
    en.sort(function(a,b){return vScore(b)-vScore(a)||(a.name<b.name?-1:1);});
    var good=[];for(var j=0;j<en.length;j++)if(vScore(en[j])>-50)good.push(en[j]);if(!good.length)good=en;
    voices=good.slice(0,14);bestName=voices.length?voices[0].name:'';fillSels();return voices;}
  function bestVoice(){return voices.length?voices[0]:null;}
  function pickVoice(){if(pref.v){for(var i=0;i<voices.length;i++)if(voices[i].name===pref.v)return voices[i];}return bestVoice();}
  var sels=[];
  function fillSels(){for(var k=0;k<sels.length;k++){var sel=sels[k],b=bestVoice(),h='<option value="">\u2B50 Best voice (auto)'+(b?': '+String(b.name).replace(/[<>&"]/g,'').slice(0,22):'')+'</option>';
      for(var i=0;i<voices.length;i++){var v=voices[i],nm=String(v.name).replace(/[<>&"]/g,'');h+='<option value="'+nm+'"'+(v.name===pref.v?' selected':'')+'>'+(v.name===bestName?'\u2B50 ':'')+nm.slice(0,28)+' ('+String(v.lang).replace('_','-')+')'+(v.name===bestName?' \u00B7 Best':'')+'</option>';}
      sel.innerHTML=h;var ok=false;for(var z=0;z<voices.length;z++)if(voices[z].name===pref.v)ok=true;sel.value=ok?pref.v:'';}}
  function preview(){unlock();speakText('Hi! This is my voice. Do you like it?',null,null);}
  function bindSel(sel){sels.push(sel);sel.addEventListener('change',function(){pref.v=sel.value;savePref();fillSels();if(SS())preview();});}
  var TIP='\uD83D\uDCA1 Get better voices: Settings \u2192 Accessibility \u2192 Spoken Content \u2192 Voices \u2192 English \u2192 download an Enhanced voice';
  function voiceBox(cls){return '<span class="hb-vbox '+(cls||'')+'"><label><span class="sr-only">Voice</span><select class="hv-sel" aria-label="Reading voice"></select></label><button type="button" class="hb-prev" aria-label="Preview this voice">\u25B6</button></span>';}
  function wireBox(el){var sel=el.querySelector('.hv-sel'),pb=el.querySelector('.hb-prev');if(sel)bindSel(sel);if(pb)pb.addEventListener('click',function(){if(!SS()){toast('Reading aloud isn\u2019t supported on this browser \uD83D\uDE15');return;}loadVoices();preview();});}

  /* ---------- speaking (v2.1: one sentence at a time, natural rate 1.0, a little pitch per feeling, no cut-offs: chunked + iOS keepalive) ---------- */
  var spk={el:null,cb:null,id:0,poll:null,word:null,ka:null};
  var PITCH={happy:1.05,excited:1.14,embarrassed:1.02,sad:.92,surprised:1.12,confused:1,laughing:1.1,spooky:.96};
  function unlock(){var s=SS();if(!s||unlock.done)return;unlock.done=1;try{var u=new W.SpeechSynthesisUtterance(' ');u.volume=0;s.speak(u);}catch(e){}}
  function markEl(el,on){if(!el)return;setC(el,'hv-speaking',on);var b=el.querySelector('.hv-play');if(b){b.innerHTML=on?'\u23F9':'\uD83D\uDD0A';b.setAttribute('aria-label',on?'Stop reading':'Read this reply aloud');}}
  function stopSpeak(silent){var s=SS();spk.id++;clearInterval(spk.poll);spk.poll=null;clearInterval(spk.ka);spk.ka=null;var el=spk.el,cb=spk.cb;spk.el=null;spk.cb=null;spk.word=null;
    try{if(s)s.cancel();}catch(e){}markEl(el,false);orbState();if(cb&&!silent)cb(false);}
  function isIOS(){var u=navigator.userAgent||'';return /iP(hone|ad|od)/.test(u)||(/Macintosh/.test(u)&&'ontouchend' in D);}
  function speakText(text,el,cb,onWord){var s=SS();if(!s){if(cb)cb(false);return false;}
    var t=clean(text);stopSpeak(true);if(!t){if(cb)cb(true);return false;}
    if(!voices.length)loadVoices();
    var id=++spk.id,list=chunks(t),v=pickVoice(),idx=0,pos=0,offs=[],uStart=0,uLen=0;spk.el=el;spk.cb=cb||null;spk.word=onWord||null;markEl(el,true);
    for(var i=0;i<list.length;i++){var off=t.indexOf(list[i],pos);if(off<0)off=pos;pos=off+list[i].length;offs.push(off);}
    function done(){if(id!==spk.id)return;spk.id++;clearInterval(spk.poll);spk.poll=null;clearInterval(spk.ka);spk.ka=null;var c=spk.cb;markEl(spk.el,false);spk.el=null;spk.cb=null;spk.word=null;orbState();if(c)c(true);}
    function next(){if(id!==spk.id)return;if(idx>=list.length){done();return;}
      var k=idx++,txt=list[k],off=offs[k],fired=false,u=new W.SpeechSynthesisUtterance(txt);
      if(v)u.voice=v;u.lang=v?v.lang:lang();u.rate=1;u.pitch=PITCH[emotionOf(txt)]||1;u.volume=1;
      function fin(){if(fired||id!==spk.id)return;fired=true;setTimeout(next,40);}
      u.onend=fin;u.onerror=fin;
      u.onboundary=function(ev){bump();if(id!==spk.id||!spk.word)return;if(ev&&ev.name&&ev.name!=='word')return;var ci=ev&&typeof ev.charIndex==='number'?ev.charIndex:0;try{spk.word(off+ci);}catch(e){}};
      u.onstart=function(){bump();if(id!==spk.id||!spk.word)return;try{spk.word(off);}catch(e){}};
      uStart=new Date().getTime();uLen=txt.length;u.__fin=fin;spk.cur=u;
      try{s.speak(u);}catch(e){fin();}}
    next();
    /* keepalive: iOS/Safari can get stuck "paused", Chrome stops long speech after ~15 s */
    spk.ka=setInterval(function(){if(id!==spk.id)return;try{if(s.paused)s.resume();else if(!isIOS()&&/Chrome\//.test(navigator.userAgent||'')&&s.speaking){s.pause();s.resume();}}catch(e){}},9000);
    /* safety net per sentence: some browsers never fire onend */
    spk.poll=setInterval(function(){if(id!==spk.id)return;var busy=false;try{busy=s.speaking||s.pending;}catch(e){}
      var el2=new Date().getTime()-uStart;
      if(spk.cur&&((!busy&&el2>1500)||el2>4000+uLen*140)){var f=spk.cur.__fin;spk.cur=null;if(f)f();}},500);
    orbState();return true;}
  function speaking(){return !!spk.cb||!!spk.el||spk.poll!==null;}

  /* ---------- per-reply 🔊 replay / ⏹ stop ---------- */
  function msgText(el){var c=el.cloneNode(true),x=c.querySelectorAll('.aip-tag,.hv-ctl');for(var i=0;i<x.length;i++)if(x[i].parentNode)x[i].parentNode.removeChild(x[i]);
    var br=c.querySelectorAll('br');for(var j=0;j<br.length;j++)br[j].parentNode.replaceChild(D.createTextNode('\n'),br[j]);return c.textContent||'';}
  function decorate(){if(!SS())return;var ms=log.querySelectorAll('.msg.bot');for(var i=0;i<ms.length;i++){var m=ms[i];
      if(hasC(m,'tp')||m.querySelector('.hv-ctl'))continue;var sp=D.createElement('span');sp.className='hv-ctl';
      sp.innerHTML='<button type="button" class="hv-play" aria-label="Read this reply aloud">\uD83D\uDD0A</button>';m.appendChild(sp);if(spk.el===m)markEl(m,true);}}
  log.addEventListener('click',function(e){var b=e.target;while(b&&b!==log&&!hasC(b,'hv-play'))b=b.parentNode;if(!b||b===log)return;
    var m=b.parentNode&&b.parentNode.parentNode;if(!m)return;e.preventDefault();unlock();
    if(spk.el===m){stopSpeak();return;}speakText(msgText(m),m,null);});
  if(W.MutationObserver){var mo=new MutationObserver(function(){decorate();});mo.observe(log,{childList:true,subtree:true});}
  decorate();

  /* ---------- 200-char limit + send through the normal chat path ---------- */
  function fit(t){t=trim(t).replace(/\s+/g,' ');if(t.length<=MAX)return t;var c=t.lastIndexOf(' ',MAX);if(c<MAX-40)c=MAX;
    toast('\u2702\uFE0F That was long, so I trimmed it to 200 characters (the chat limit)');return trim(t.slice(0,c));}
  function sendVoice(t){t=fit(t);if(!t)return false;input.value=t;
    if(!W.hcApp||!W.hcApp.send){return false;}if(W.hcApp.busy&&W.hcApp.busy()){toast('\u23F3 Wait for the reply, then try again');return false;}
    return W.hcApp.send(t);}

  /* ---------- speech recognition (shared by the mic and voice chat) ---------- */
  var rec=null,recOn=false;
  function listen(o){var C=SRC();if(!C){o.fail('unsupported');return false;}
    if(rec){try{rec.abort();}catch(e){}rec=null;}
    var r;try{r=new C();}catch(e){o.fail('unsupported');return false;}
    rec=r;var fin='',inter='',ended=false,silT=null;
    try{r.lang=lang();r.interimResults=true;r.continuous=false;r.maxAlternatives=1;}catch(e){}
    function sil(){clearTimeout(silT);silT=setTimeout(function(){if(rec===r&&recOn&&trim(fin+inter))try{r.stop();}catch(e){}},2200);}
    r.onresult=function(ev){var f='',it='',res=ev.results;for(var i=0;i<res.length;i++){var a=res[i][0]&&res[i][0].transcript||'';if(res[i].isFinal)f+=a;else it+=a;}
      fin=f;inter=it;hear();if(o.interim)o.interim(trim(f+' '+it));sil();};
    r.onerror=function(ev){var er=ev&&ev.error||'error';if(er==='aborted')return;o.err=er;};
    r.onend=function(){if(ended)return;ended=true;clearTimeout(silT);if(rec===r){rec=null;recOn=false;}orbState();
      var t=trim(fin||inter);if(o.err&&!t)o.fail(o.err);else o.done(t);};
    try{r.start();recOn=true;}catch(e){rec=null;recOn=false;o.fail('start');return false;}
    orbState();return true;}
  function stopListen(abort){if(!rec)return;try{if(abort)rec.abort();else rec.stop();}catch(e){}}
  /* iPad/iPhone home-screen app: speech recognition is often missing or blocked there, but read-aloud still works */
  function standalone(){try{return !!(navigator.standalone||(W.matchMedia&&W.matchMedia('(display-mode: standalone)').matches));}catch(e){return false;}}
  var SAFARI='Voice typing needs Safari: open taboai.sites.tab.bot in Safari \uD83E\uDDED';
  function errMsg(er){if(er==='unsupported')return standalone()?SAFARI:'Voice typing isn\u2019t supported on this browser \uD83D\uDE15 Try Safari or Chrome';
    if((er==='service-not-allowed'||er==='start')&&standalone())return SAFARI;
    if(er==='not-allowed'||er==='service-not-allowed')return '\uD83C\uDF99\uFE0F Allow the microphone (and Speech Recognition in Settings) to talk';
    if(er==='no-speech')return 'Didn\u2019t hear anything \uD83E\uDD14 Tap \uD83C\uDF99\uFE0F and talk';
    if(er==='network')return 'Voice typing needs internet \uD83D\uDCF6 Try again';
    if(er==='audio-capture')return 'No microphone found \uD83C\uDF99\uFE0F';return 'Voice didn\u2019t start \uD83D\uDE15 Tap \uD83C\uDF99\uFE0F to try again';}

  /* ---------- UI: mic in the composer (opens the Talking Face) + a voice row ---------- */
  var send=form.querySelector('.send');
  var mic=D.createElement('button');mic.type='button';mic.className='hv-mic';mic.setAttribute('aria-label','Talk to your blob buddy');mic.setAttribute('aria-haspopup','dialog');mic.innerHTML='\uD83C\uDF99\uFE0F';
  form.insertBefore(mic,send);setC(form,'hv-has',true);
  var row=D.createElement('div');row.className='hv-row';
  row.innerHTML='<button type="button" class="hv-pill hv-vc" aria-haspopup="dialog">\uD83E\uDEE7 Blob buddy</button>'+
    '<button type="button" class="hv-pill hv-ra" aria-pressed="false">\uD83D\uDD0A Read aloud</button>'+
    '<span class="hv-sw">'+voiceBox('')+'</span>';
  form.parentNode.insertBefore(row,form);
  var raBtn=row.querySelector('.hv-ra'),vcBtn=row.querySelector('.hv-vc');wireBox(row.querySelector('.hb-vbox'));
  function paintRA(){raBtn.setAttribute('aria-pressed',pref.on?'true':'false');raBtn.innerHTML=pref.on?'\uD83D\uDD0A Read aloud: on':'\uD83D\uDD07 Read aloud: off';setC(row,'hv-raon',pref.on);}
  raBtn.addEventListener('click',function(){if(!SS()){toast('Reading aloud isn\u2019t supported on this browser \uD83D\uDE15');return;}
    pref.on=!pref.on;savePref();paintRA();if(pref.on){unlock();loadVoices();toast('\uD83D\uDD0A I\u2019ll read my replies out loud');}else{stopSpeak();toast('\uD83D\uDD07 Reading aloud is off');}});
  paintRA();
  var dict=false;

  /* ---------- 🫧 v2.1 the BLOB buddy (the user Nov 2 6:29 PM: "don't make it a talking face, just a nice little colorful blob or your Tot") ---------- */
  var BK='hc_blob_v1';
  var COLS={bubblegum:['Bubblegum','#ffc2e2','#ff7ec0','#ec4f9e'],tangerine:['Tangerine','#ffdcae','#ffa557','#f57a2c'],lemon:['Lemon','#fff6b8','#ffe066','#f7b928'],
    mint:['Mint','#c4fae3','#5ee6b4','#1fbf88'],sky:['Sky','#c6e8ff','#6dbbff','#3c86f2'],grape:['Grape','#e3d1ff','#ad85ff','#7d4fe0'],
    cotton:['Cotton candy','#ffd0ea','#d9c2ff','#a6d6ff'],rainbow:['Rainbow','#ff6b8b','#ffd166','#5ee6b4','#6dbbff','#b28dff']};
  var COLK=['bubblegum','tangerine','lemon','mint','sky','grape','cotton','rainbow'];
  var EYEK=['round','anime','sleepy','cat','star','heart','googly','shades'];
  var EYEN={round:'\uD83D\uDC40 Round',anime:'\u2728 Anime',sleepy:'\uD83D\uDE34 Sleepy',cat:'\uD83D\uDC31 Cat',star:'\u2B50 Star',heart:'\uD83D\uDC96 Heart',googly:'\uD83E\uDD2A Googly',shades:'\uD83D\uDE0E Shades'};
  var INK='#3b2350';
  var bp={eye:'round',col:'bubblegum',tot:false};
  try{var b0=JSON.parse(localStorage.getItem(BK)||'null');if(b0&&typeof b0==='object'){if(EYEN[b0.eye])bp.eye=b0.eye;if(COLS[b0.col])bp.col=b0.col;bp.tot=!!b0.tot;}}catch(e){}
  function saveBP(){try{localStorage.setItem(BK,JSON.stringify(bp));}catch(e){}}
  /* one eye, drawn around 0,0. .hb-pup moves to look around; the whole .hb-ein squishes to blink */
  function eyeSVG(k,s){var st=' stroke="'+INK+'" stroke-width="2.6" stroke-linejoin="round"';
    if(k==='anime')return '<ellipse rx="13" ry="17" fill="#fff"'+st+'/><g clip-path="url(#hbcA)"><g class="hb-pup"><ellipse rx="10" ry="13.5" fill="url(#hbIris)"/><ellipse cy="1.5" rx="5" ry="7" fill="#1b1036"/><ellipse cx="-3.6" cy="-6" rx="3.8" ry="4.6" fill="#fff"/><circle cx="3.6" cy="5.5" r="2" fill="#fff"/></g></g><path class="hb-tw" d="M'+(s*9)+' -19l1.4 3.2 3.2 1.4-3.2 1.4-1.4 3.2-1.4-3.2-3.2-1.4 3.2-1.4Z" fill="#fff6a8" stroke="#f5b524" stroke-width="1"/>';
    if(k==='sleepy')return '<path d="M-13 0A13 11 0 0 0 13 0Z" fill="#fff"'+st+'/><g clip-path="url(#hbcS)"><g class="hb-pup"><circle cy="3" r="5.6" fill="#2a1840"/><circle cx="-1.8" cy="1.4" r="1.6" fill="#fff"/></g></g><path d="M-15 0H15" stroke="'+INK+'" stroke-width="3.2" stroke-linecap="round"/><path d="M'+(s*10)+' 7l'+(s*4)+' 4M'+(s*4)+' 10l'+(s*2)+' 4" stroke="'+INK+'" stroke-width="2" stroke-linecap="round"/>';
    if(k==='cat')return '<ellipse rx="12.5" ry="14" fill="#d4f57a"'+st+'/><g clip-path="url(#hbcR)"><g class="hb-pup"><ellipse rx="3.2" ry="11" fill="#1d1430"/><circle cx="-4.5" cy="-6" r="2.2" fill="#fff"/></g></g>';
    if(k==='star')return '<g class="hb-pup"><path d="M0 -15L4.4 -5.4 15 -4.6 7 2.6 9.3 13 0 7.6-9.3 13-7 2.6-15-4.6-4.4-5.4Z" fill="#ffd84d"'+st+'/><circle cx="-3" cy="-4" r="2.3" fill="#fff"/></g>';
    if(k==='heart')return '<g class="hb-pup"><path d="M0 12C-14 3-16-6-11-11-7-15-2-13 0-8 2-13 7-15 11-11 16-6 14 3 0 12Z" fill="#ff4f8b"'+st+'/><ellipse cx="-5.5" cy="-6" rx="2.8" ry="2.1" fill="#fff"/></g>';
    if(k==='googly')return '<circle r="16.5" fill="#fff"'+st+'/><g clip-path="url(#hbcG)"><g class="hb-pup hb-goo"><circle r="8.5" fill="#1d1430"/><circle cx="-2.6" cy="-2.6" r="2.2" fill="#fff"/></g></g>';
    if(k==='shades')return '<g class="hb-pup"><path d="M-15 -8H14Q17 -8 16 -4L13 6Q12 10 7 10H-8Q-13 10-14 6L-17-4Q-18-8-15-8Z" fill="#1d1430"/><path d="M-9 -4.5L-4 5M-3 -4.5L0 1" stroke="#fff" stroke-opacity=".55" stroke-width="2.4" stroke-linecap="round"/>'+(s>0?'<path d="M-16 -5Q-26 -10 -36 -5" stroke="#1d1430" stroke-width="4" fill="none" stroke-linecap="round"/>':'')+'</g>';
    return '<ellipse rx="12" ry="14" fill="#fff"'+st+'/><g clip-path="url(#hbcR)"><g class="hb-pup"><circle r="7" fill="#2a1840"/><circle cx="-2.5" cy="-2.8" r="2.5" fill="#fff"/></g></g>';}
  var EYEMOVE={round:5,anime:3.5,sleepy:3,cat:4.5,star:2.5,heart:2.5,googly:7,shades:1.5};
  function blobSVG(){return '<svg class="hv-svg hb-svg" viewBox="0 0 200 200" aria-hidden="true" focusable="false">'+
    '<defs><linearGradient id="hbG" x1="0" y1="0" x2="1" y2="1"></linearGradient>'+
    '<radialGradient id="hbIris" cx="50%" cy="35%" r="70%"><stop offset="0" stop-color="#c4b5fd"/><stop offset=".55" stop-color="#7c3aed"/><stop offset="1" stop-color="#3b1a8a"/></radialGradient>'+
    '<radialGradient id="hbShine" cx="35%" cy="25%" r="60%"><stop offset="0" stop-color="#fff" stop-opacity=".75"/><stop offset=".5" stop-color="#fff" stop-opacity=".12"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>'+
    '<clipPath id="hbcR"><ellipse rx="12.5" ry="14"/></clipPath><clipPath id="hbcA"><ellipse rx="13" ry="17"/></clipPath><clipPath id="hbcS"><path d="M-13 0A13 11 0 0 0 13 0Z"/></clipPath><clipPath id="hbcG"><circle r="16.5"/></clipPath>'+
    '<clipPath id="hvcAM"><path class="hv-mclip" data-k="a" d=""/></clipPath></defs>'+
    '<ellipse class="hb-shadow" cx="100" cy="186" rx="52" ry="7" fill="#7c3aed" opacity=".14"/>'+
    '<g class="hv-head hb-body">'+
      '<path class="hb-blob" d="" fill="url(#hbG)" stroke="rgba(80,40,110,.18)" stroke-width="2"/>'+
      '<path class="hb-tint" d="" fill="#fff" opacity="0"/>'+
      '<path class="hb-gloss" d="" fill="url(#hbShine)"/>'+
      '<ellipse class="hb-hl" cx="68" cy="66" rx="13" ry="7.5" fill="#fff" opacity=".6" transform="rotate(-28 68 66)"/><circle class="hb-hl" cx="84" cy="57" r="3.4" fill="#fff" opacity=".7"/>'+
      '<g class="hb-face">'+
        '<ellipse class="hb-cheek" cx="58" cy="124" rx="12" ry="7.5" fill="#ff5f99" opacity=".3"/><ellipse class="hb-cheek" cx="142" cy="124" rx="12" ry="7.5" fill="#ff5f99" opacity=".3"/>'+
        '<g class="hv-eye hb-eye" data-cx="74" data-cy="100" data-s="-1"><g class="hb-ein"></g><path class="hb-laugh" d="M-12 4Q0 -11 12 4" stroke="'+INK+'" stroke-width="4.2" fill="none" stroke-linecap="round" opacity="0"/></g>'+
        '<g class="hv-eye hb-eye" data-cx="126" data-cy="100" data-s="1"><g class="hb-ein"></g><path class="hb-laugh" d="M-12 4Q0 -11 12 4" stroke="'+INK+'" stroke-width="4.2" fill="none" stroke-linecap="round" opacity="0"/></g>'+
        '<path class="hv-mouth" data-k="a" d="" fill="#4a1636" stroke="'+INK+'" stroke-width="2.6" stroke-linejoin="round"/>'+
        '<g clip-path="url(#hvcAM)"><ellipse class="hv-tongue" data-k="a" cx="100" cy="150" rx="11" ry="7" fill="#ff8fb1"/></g>'+
      '</g>'+
      /* emotion extras: CSS fades them in per feeling */
      '<g class="hv-fx">'+
        '<g class="hv-blush"><ellipse cx="56" cy="125" rx="16" ry="9.5" fill="#ff4f8b" opacity=".5"/><ellipse cx="144" cy="125" rx="16" ry="9.5" fill="#ff4f8b" opacity=".5"/>'+
          '<path d="M48 121l-3 7M55 121l-3 7M62 121l-3 7M140 121l-3 7M147 121l-3 7M154 121l-3 7" stroke="#e8317a" stroke-width="2" stroke-linecap="round" opacity=".7"/></g>'+
        '<g class="hv-sweat"><path d="M156 60C156 60 148 72 148 77A8 8 0 0 0 164 77C164 72 156 60 156 60Z" fill="#9ee3ff" stroke="#38a8e0" stroke-width="2"/><ellipse cx="153" cy="76" rx="2" ry="3" fill="#fff" opacity=".85"/></g>'+
        '<g class="hv-tear"><path d="M70 116C70 116 64 125 64 129A6 6 0 0 0 76 129C76 125 70 116 70 116Z" fill="#8cc4ff" stroke="#3b82f6" stroke-width="1.6"/></g>'+
        '<g class="hv-spark"><path class="hv-tw" d="M24 52l3 8 8 3-8 3-3 8-3-8-8-3 8-3Z" fill="#fff07a" stroke="#f5b524" stroke-width="1.2"/><path class="hv-tw t2" d="M174 40l3 8 8 3-8 3-3 8-3-8-8-3 8-3Z" fill="#fff07a" stroke="#f5b524" stroke-width="1.2"/><path class="hv-tw t3" d="M178 150l2 5 5 2-5 2-2 5-2-5-5-2 5-2Z" fill="#fff07a" stroke="#f5b524" stroke-width="1.2"/><path class="hv-tw t2" d="M22 150l2 5 5 2-5 2-2 5-2-5-5-2 5-2Z" fill="#ffb3e0" stroke="#ec4f9e" stroke-width="1.2"/></g>'+
        '<g class="hv-shock" stroke="#f5b524" stroke-width="4" stroke-linecap="round"><path d="M56 26l7 11M100 10v13M144 26l-7 11"/></g>'+
        '<text class="hv-q" x="160" y="52" font-size="38" font-weight="900" fill="#8b5cf6" stroke="#fff" stroke-width="2" font-family="Arial Rounded MT Bold,Arial,sans-serif">?</text>'+
        '<g class="hv-joy"><path d="M50 106C50 106 44 114 44 118A6 6 0 0 0 56 118C56 114 50 106 50 106Z" fill="#a8d4ff" stroke="#3b82f6" stroke-width="1.4"/><path d="M150 106C150 106 144 114 144 118A6 6 0 0 0 156 118C156 114 150 106 150 106Z" fill="#a8d4ff" stroke="#3b82f6" stroke-width="1.4"/></g>'+
        '<g class="hv-boo"><text x="150" y="44" font-size="20" font-weight="900" fill="#a78bfa" font-family="Arial Rounded MT Bold,Arial,sans-serif">boo!</text></g>'+
      '</g>'+
    '</g></svg>';}
  /* mouth shapes: o = how open (0 = closed smile, 1 = wide open); M = the feeling's mouth (width, smile/frown, side shift, tilt, round "O", wobble) */
  var MZ={mw:1,ms:1,mo:0,mdx:0,mt:0,rd:0,wv:0};
  function mouthD(k,o,M){M=M||MZ;var op=M.mo+o*(1-M.mo*.6),sm=M.ms,y0=128,cx=100+M.mdx,
      hw=18*M.mw+o*4,cd=sm<0?-sm*11:0,ly=y0+cd+M.mt+M.wv,ry=y0+cd-M.mt-M.wv,
      yT=y0+5*sm-8*M.rd-2*o,yB=y0+9+2*sm+24*op,yC=yB,f=function(n){return n.toFixed(1);};
    if(yB<yT+5)yB=yT+5;
    return 'M'+f(cx-hw)+' '+f(ly)+'Q'+f(cx)+' '+f(yT)+' '+f(cx+hw)+' '+f(ry)+'Q'+f(cx+hw*.82)+' '+f(yC)+' '+f(cx)+' '+f(yB)+'Q'+f(cx-hw*.82)+' '+f(yC)+' '+f(cx-hw)+' '+f(ly)+'Z';}
  var TINT={happy:'#ffffff',excited:'#ffd23f',embarrassed:'#ff4f9a',sad:'#5b8cff',surprised:'#ffffff',confused:'#a78bfa',laughing:'#ffb020',spooky:'#f4f0ff'};
  function paintColor(){if(!svg)return;var g=svg.querySelector('#hbG'),c=COLS[bp.col]||COLS.bubblegum,h='';
    for(var i=1;i<c.length;i++)h+='<stop offset="'+((i-1)/(c.length-2)).toFixed(2)+'" stop-color="'+c[i]+'"/>';
    if(g){while(g.firstChild)g.removeChild(g.firstChild);for(var j=1;j<c.length;j++){var sn=D.createElementNS('http://www.w3.org/2000/svg','stop');sn.setAttribute('offset',((j-1)/(c.length-2)).toFixed(2));sn.setAttribute('stop-color',c[j]);g.appendChild(sn);}
      if(bp.col!=='rainbow')g.removeAttribute('gradientTransform');}
    if(ov)ov.setAttribute('data-col',bp.col);}
  function paintEyes(){if(!svg)return;var ws=svg.querySelectorAll('.hb-eye');for(var i=0;i<ws.length;i++){var s=+ws[i].getAttribute('data-s');ws[i].querySelector('.hb-ein').innerHTML=eyeSVG(bp.eye,s);}
    pups=svg.querySelectorAll('.hb-pup');if(ov)ov.setAttribute('data-eye',bp.eye);}
  function totOn(){return !!(bp.tot&&W.hcTots&&W.hcTots.sel&&W.hcTots.sel());}
  function paintTot(){if(!ov)return;var box=ov.querySelector('.hb-tot'),on=totOn();setC(ov,'hb-usetot',on);
    if(on){var t=W.hcTots.sel();try{box.innerHTML=W.hcTots.svg(t,{size:200});}catch(e){box.innerHTML='';setC(ov,'hb-usetot',false);}}else box.innerHTML='';
    var tt=ov.querySelector('.hb-ttl-n');if(tt)tt.textContent=on?(W.hcTots.sel().n||'My Tot'):'Blob buddy';}

  /* ---------- 😳 EMOTIONS: a tiny scorer over the words picks how the face feels (per reply, then per sentence while it talks) ---------- */
  var EMO_IC={happy:'\uD83D\uDE0A',excited:'\uD83E\uDD29',embarrassed:'\uD83D\uDE33',sad:'\uD83D\uDE22',surprised:'\uD83D\uDE2E',confused:'\uD83E\uDD14',laughing:'\uD83D\uDE02',spooky:'\uD83D\uDC7B'};
  var EMO_NM={happy:'Happy',excited:'Excited',embarrassed:'Embarrassed',sad:'Sad',surprised:'Surprised',confused:'Thinking',laughing:'Laughing',spooky:'Spooky'};
  var EMOS=['happy','excited','embarrassed','sad','surprised','confused','laughing','spooky'];
  /* [emotion, pattern, points per match] */
  var EMO_R=[
    ['sad',/sorry to hear|so sorry for your|sorry for your loss|that'?s (so |really )?sad|\bsad(ly|ness)?\b|\bunfortunately\b|heartbr\w+|\bcry(ing)?\b|passed away|\blonely\b|\bupset\b/gi,4],
    ['sad',/\uD83D\uDE22|\uD83D\uDE2D|\uD83D\uDE1E|\uD83D\uDE14|\uD83D\uDC94|\uD83E\uDD7A|\u2639/g,4],
    ['embarrassed',/\boops+(ie|y)?\b|\bwhoops+(ie|y)?\b|\buh oh\b|\bmy bad\b|\bawkward\w*|\bembarrass\w*|\bi was wrong\b|\bi made a mistake\b|\bmy mistake\b|\bi messed up\b|\bblush\w*|\bsilly me\b|\bcringe\w*/gi,4],
    ['embarrassed',/\bsorry\b(?! to hear| for your)|\bapologi[sz]e\b/gi,2],
    ['embarrassed',/\uD83D\uDE33|\uD83D\uDE05|\uD83D\uDE48|\uD83E\uDEE3|\uD83D\uDE2C/g,4],
    ['excited',/!!|\bawesome\b|\bamazing\b|\bincredible\b|\bwoo+(hoo+)?\b|\byay+\b|\bhooray\b|\bfantastic\b|\bso cool\b|\bsuper cool\b|\blet'?s go\b|\bcongrat\w*|\bexcit\w*/gi,2],
    ['excited',/\uD83C\uDF89|\uD83E\uDD29|\uD83E\uDD73|\uD83D\uDE80|\uD83D\uDD25|\u2728|\uD83C\uDF8A|\uD83D\uDE4C/g,3],
    ['surprised',/\bwow+\b|\bwhoa+\b|\bwoah+\b|\breally\?|\bno way\b|\bwait,? what\b|\bbelieve it or not\b|\bsurpris\w*|\bomg\b|\bholy\b|\bmind[- ]blow\w*/gi,3],
    ['surprised',/\uD83D\uDE2E|\uD83D\uDE32|\uD83E\uDD2F|\uD83D\uDE31|\uD83D\uDE2F/g,3],
    ['confused',/\bhm+\b|\bhmm+\b|\bnot sure\b|\bi don'?t know\b|\bi'?m not certain\b|\bconfus\w*|\bpuzzl\w*|\bwhat do you mean\b|\bit depends\b|\btricky\b|\bunclear\b/gi,2],
    ['confused',/\uD83E\uDD14|\uD83E\uDDD0/g,3],
    ['laughing',/\b(ha){2,}h?\b|\bhehe+\b|\blol+\b|\blmao\b|\brofl\b|\bhilarious\b|\bfunny\b|\blaugh\w*/gi,3],
    ['laughing',/\bjokes?\b|\bpuns?\b|\bknock,? knock\b|\bpunchline\b/gi,2],
    ['laughing',/\uD83D\uDE02|\uD83E\uDD23|\uD83D\uDE06|\uD83D\uDE39/g,3],
    ['spooky',/\bboo+\b|\bspook\w*|\bghosts?\b|\bghostly\b|\bhaunt\w*|\bscary\b|\bcreepy\b|\bvampires?\b|\bzombies?\b|\bwitch(es)?\b|\bskeletons?\b|\bmonsters?\b|\bmummy\b|\bmwa+ha+\w*/gi,3],
    ['spooky',/\uD83D\uDC7B|\uD83D\uDC80|\uD83E\uDDDB|\uD83E\uDDDF|\uD83D\uDD77|\uD83E\uDD87|\u2620/g,3]];
  var EMO_PRI=['embarrassed','sad','laughing','surprised','spooky','excited','confused'];
  function isHW(){return /(^|\s)hw(\s|$)/.test(D.documentElement.className);}
  function emoScore(t){t=String(t||'');var sc={},i,m,n;for(i=0;i<EMOS.length;i++)sc[EMOS[i]]=0;
    for(i=0;i<EMO_R.length;i++){var r=EMO_R[i];r[1].lastIndex=0;m=t.match(r[1]);if(m)sc[r[0]]+=m.length*r[2];}
    n=(t.match(/!/g)||[]).length;sc.excited+=Math.min(1.5,n*.5);           /* a few ! = a bit excited */
    n=(t.match(/\?/g)||[]).length;if(n)sc.confused+=Math.min(3,1.5+n*.5);   /* a question = a thinking look */
    if(W.hcUnhinged&&W.hcUnhinged.on()){ /* v2.0.1 unhinged: the face laughs + gets hyped way more (caps meltdowns, bleeps, roasts) */
      n=(t.match(/\b[A-Z]{3,}\b/g)||[]).length;sc.excited+=1+Math.min(3,n);
      n=(t.match(/\bbleep\b|[A-Za-z]\*{2,}|\broast\w*|\bimagine\b|\bbruh\b|\bcan'?t even\b|\bscream\w*|\bfudge\b|\bbiscuit\b|\bheck\b/gi)||[]).length;sc.laughing+=1.2+Math.min(4,n*1.5);
      sc.confused=Math.max(0,sc.confused-1);}
    return sc;}
  function emotionOf(t){var sc=emoScore(t),best='happy',bv=1.9;   /* needs at least 2 points, else the normal smile */
    for(var i=0;i<EMO_PRI.length;i++){var e=EMO_PRI[i];if(sc[e]>bv){best=e;bv=sc[e];}}
    return best;}
  var emoNow='happy',emoS=null,emoSi=-1,emoBadge=null;
  function setEmo(e){if(!EMO_IC[e])e='happy';emoNow=e;if(!ov)return;
    for(var i=0;i<EMOS.length;i++)setC(ov,'hv-e-'+EMOS[i],EMOS[i]===e);ov.setAttribute('data-emo',e);
    if(emoBadge&&emoBadge.getAttribute('data-e')!==e){emoBadge.setAttribute('data-e',e);emoBadge.innerHTML=EMO_IC[e];emoBadge.setAttribute('title',EMO_NM[e]);
      setC(emoBadge,'pop',false);void emoBadge.offsetWidth;setC(emoBadge,'pop',true);}}
  /* split the spoken caption into sentences; each gets its own feeling when it has a strong one, else the whole reply's */
  function emoPlan(raw,t){var whole=emotionOf(raw);emoS=[];emoSi=-1;var re=/[^.!?]+[.!?]*\s*/g,m;
    while((m=re.exec(t))){var e=emotionOf(m[0]);emoS.push({i:m.index,e:e==='happy'?whole:e});if(!m[0])break;}
    return whole;}
  function emoAt(ci){if(!emoS||!emoS.length)return;var k=0;for(var i=0;i<emoS.length;i++){if(emoS[i].i<=ci)k=i;else break;}
    if(k===emoSi)return;emoSi=k;setEmo(emoS[k].e);}

  var ov=null,svg=null,stEl=null,saidEl=null,capEl=null,tform=null,tin=null,hintEl=null,muteBtn=null,faceBtn=null,eyes=[],pups=[],mouths=[],mclips=[],tongue=null,head0=null,blobP=null,tintP=null,glossP=null,shadowE=null,faceG=null,cheeks=[],laughs=[],custEl=null,totBox=null;
  var vc={on:false,phase:'idle',wait:false,rounds:0,via:'',fake:null};
  function custHTML(){var h='<div class="hb-sec"><b class="hb-h">\uD83D\uDC40 Eyes</b><div class="hb-chips hb-eyes">';
    for(var i=0;i<EYEK.length;i++)h+='<button type="button" class="hb-chip" data-eye="'+EYEK[i]+'" aria-pressed="false">'+EYEN[EYEK[i]]+'</button>';
    h+='</div></div><div class="hb-sec"><b class="hb-h">\uD83C\uDFA8 Color</b><div class="hb-chips hb-cols">';
    for(var j=0;j<COLK.length;j++){var c=COLS[COLK[j]],bg=c.length>4?'linear-gradient(135deg,'+c.slice(1).join(',')+')':'linear-gradient(135deg,'+c[1]+','+c[2]+' 55%,'+c[3]+')';
      h+='<button type="button" class="hb-sw" data-col="'+COLK[j]+'" aria-pressed="false" aria-label="'+c[0]+'" title="'+c[0]+'" style="background:'+c[2]+';background:'+bg+'"></button>';}
    h+='</div></div><div class="hb-sec hb-totrow"><label class="hd-sw"><input type="checkbox" class="hb-totin"><span class="sw"></span><span>\uD83E\uDEE7 Use my Tot</span></label></div>'+
      '<div class="hb-sec"><b class="hb-h">\uD83D\uDD0A Voice</b>'+voiceBox('hb-vb')+'<p class="hb-tip">'+TIP+'</p></div>';return h;}
  function paintCust(){if(!custEl)return;var b=custEl.querySelectorAll('[data-eye]'),i;for(i=0;i<b.length;i++)b[i].setAttribute('aria-pressed',b[i].getAttribute('data-eye')===bp.eye?'true':'false');
    b=custEl.querySelectorAll('[data-col]');for(i=0;i<b.length;i++)b[i].setAttribute('aria-pressed',b[i].getAttribute('data-col')===bp.col?'true':'false');
    var ti=custEl.querySelector('.hb-totin'),has=!!(W.hcTots&&W.hcTots.sel&&W.hcTots.sel());custEl.querySelector('.hb-totrow').style.display=has?'':'none';if(ti)ti.checked=totOn();}
  function build(){if(ov)return;ov=D.createElement('div');ov.className='hv-ov hv-idle';ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');ov.setAttribute('aria-label','Blob buddy');ov.hidden=true;
    ov.innerHTML='<div class="hv-card"><div class="hv-top"><button type="button" class="hv-mute" aria-pressed="false"></button><span class="hv-ttl">\uD83E\uDEE7 <span class="hb-ttl-n">Blob buddy</span></span><span class="hb-tr"><button type="button" class="hb-cb" aria-expanded="false" aria-label="Change eyes, color and voice">\uD83C\uDFA8</button><button type="button" class="hv-x" aria-label="Close the blob buddy">\u2715</button></span></div>'+
      '<div class="hb-cust" hidden>'+custHTML()+'</div>'+
      '<div class="hv-mid"><button type="button" class="hv-faceb" aria-label="Tap to talk"><span class="hv-glow"></span><span class="hv-glow g2"></span>'+blobSVG()+'<span class="hb-tot" aria-hidden="true"></span></button>'+
      '<p class="hv-st" role="status"><span class="hv-stt">Hi!</span><span class="hv-dots"><i>.</i><i>.</i><i>.</i></span></p><p class="hv-said"></p><div class="hv-capw"><span class="hv-emo" aria-hidden="true"></span><div class="hv-cap" aria-live="polite"></div></div>'+
      '<form class="hv-tform" autocomplete="off"><input class="hv-tin" type="text" maxlength="200" enterkeyhint="send" placeholder="Type to talk to me" aria-label="Type to talk to me"><button type="submit" class="hv-tgo" aria-label="Send">\u27A4</button></form>'+
      '<p class="hv-hint"></p></div>'+
      '<div class="hv-bot"><p class="hv-note">I listen, think, then say the answer out loud. Same Safety Shield as typing. Nothing is saved. Tap \uD83C\uDFA8 for eyes, colors &amp; voices.</p></div></div>';
    D.body.appendChild(ov);svg=ov.querySelector('.hv-svg');stEl=ov.querySelector('.hv-stt');saidEl=ov.querySelector('.hv-said');capEl=ov.querySelector('.hv-cap');
    tform=ov.querySelector('.hv-tform');tin=ov.querySelector('.hv-tin');hintEl=ov.querySelector('.hv-hint');muteBtn=ov.querySelector('.hv-mute');faceBtn=ov.querySelector('.hv-faceb');
    eyes=ov.querySelectorAll('.hb-eye');mouths=ov.querySelectorAll('.hv-mouth');mclips=ov.querySelectorAll('.hv-mclip');laughs=ov.querySelectorAll('.hb-laugh');cheeks=ov.querySelectorAll('.hb-cheek');
    tongue=ov.querySelector('.hv-tongue');head0=ov.querySelector('.hb-body');emoBadge=ov.querySelector('.hv-emo');blobP=ov.querySelector('.hb-blob');tintP=ov.querySelector('.hb-tint');glossP=ov.querySelector('.hb-gloss');
    shadowE=ov.querySelector('.hb-shadow');faceG=ov.querySelector('.hb-face');custEl=ov.querySelector('.hb-cust');totBox=ov.querySelector('.hb-tot');
    wireBox(custEl.querySelector('.hb-vbox'));fillSels();paintMute();paintColor();paintEyes();paintTot();paintCust();setEmo('happy');drawMouth(0);
    ov.querySelector('.hv-x').addEventListener('click',closeVC);
    var cb=ov.querySelector('.hb-cb');cb.addEventListener('click',function(){var open=custEl.hidden;custEl.hidden=!open;cb.setAttribute('aria-expanded',open?'true':'false');setC(ov,'hb-custon',open);if(open){loadVoices();paintCust();}});
    custEl.addEventListener('click',function(e){var b=e.target;while(b&&b!==custEl&&!b.getAttribute('data-eye')&&!b.getAttribute('data-col'))b=b.parentNode;if(!b||b===custEl)return;
      if(b.getAttribute('data-eye')){bp.eye=b.getAttribute('data-eye');paintEyes();setEmo('excited');setTimeout(function(){if(vc.phase==='idle')setEmo('happy');},900);}
      else{bp.col=b.getAttribute('data-col');paintColor();}
      saveBP();paintCust();});
    custEl.querySelector('.hb-totin').addEventListener('change',function(){bp.tot=!!this.checked;saveBP();paintTot();});
    /* the eyes follow your finger / mouse */
    function look(e){var t=e.touches&&e.touches[0]||e;if(!svg||t.clientX==null)return;var r=svg.getBoundingClientRect();if(!r.width)return;
      eye.px=Math.max(-1,Math.min(1,(t.clientX-(r.left+r.width/2))/(r.width*.9)));eye.py=Math.max(-1,Math.min(1,(t.clientY-(r.top+r.height*.48))/(r.height*.9)));eye.pt=new Date().getTime();}
    ov.addEventListener('mousemove',look);ov.addEventListener('touchstart',look);ov.addEventListener('touchmove',look);
    faceBtn.addEventListener('click',faceTap);
    muteBtn.addEventListener('click',function(){pref.m=!pref.m;savePref();paintMute();
      if(pref.m&&vc.phase==='speaking'&&!vc.fake){var t=capEl.getAttribute('data-t')||'';stopSpeak(true);fakeTalk(t,vc.after);}});
    tform.addEventListener('submit',function(e){e.preventDefault();var t=trim(tin.value);if(!t)return;unlock();
      if(vc.phase==='listening')stopListen(true);if(vc.phase==='speaking'){stopSpeak(true);endFake();}
      if(W.hcApp&&W.hcApp.busy&&W.hcApp.busy()){toast('\u23F3 Wait for the reply, then try again');return;}
      vc.on=true;tin.value='';ask(t,'type');});
    tin.addEventListener('focus',function(){if(vc.phase==='listening'){vc.quietStop=true;stopListen(true);phase('idle');}});}
  function paintMute(){if(!muteBtn)return;muteBtn.innerHTML=pref.m?'\uD83D\uDD07':'\uD83D\uDD0A';muteBtn.setAttribute('aria-pressed',pref.m?'true':'false');
    muteBtn.setAttribute('aria-label',pref.m?'Sound is off: tap to unmute the face':'Mute the face');setC(ov,'hv-muted',pref.m);}
  var LINES={idle:'Tap me to talk',listening:'Listening',thinking:'Thinking',speaking:'Talking (tap me to stop)'};
  function phase(p,msg){vc.phase=p;if(!ov)return;if(p==='listening'||p==='thinking'){emoS=null;setEmo('happy');}var cs=['idle','listening','thinking','speaking'];for(var i=0;i<cs.length;i++)setC(ov,'hv-'+cs[i],cs[i]===p);
    stEl.textContent=msg||(p==='idle'&&!SRC()?'Type to talk to me \uD83D\uDC47':LINES[p]);
    faceBtn.setAttribute('aria-label',p==='idle'?(SRC()?'Tap to talk':'Type below to talk'):p==='listening'?'Tap to stop listening':'Tap to stop');}
  function orbState(){}
  function hintPaint(){if(!hintEl)return;var h='';if(!SRC())h=standalone()?'\uD83C\uDF99\uFE0F Voice typing needs Safari. Typing works great here!':'\uD83C\uDF99\uFE0F Voice typing isn\u2019t on this browser, so type to me.';
    else if(!SS())h='Talking out loud isn\u2019t supported on this browser, so I\u2019ll show my answer.';hintEl.textContent=h;setC(ov,'hv-nosr',!SRC());}

  /* caption: the reply's words, the one being said lights up */
  var capW=[];
  function setCaption(t){capW=[];capEl.innerHTML='';capEl.setAttribute('data-t',t||'');setC(ov,'hv-hascap',!!t);if(!t)return;var re=/\S+/g,m,frag=D.createDocumentFragment(),last=0;
    while((m=re.exec(t))){if(m.index>last)frag.appendChild(D.createTextNode(t.slice(last,m.index)));var s=D.createElement('span');s.textContent=m[0];frag.appendChild(s);capW.push({i:m.index,el:s});last=m.index+m[0].length;}
    capEl.appendChild(frag);capEl.scrollTop=0;}
  var curW=-1;
  function lightWord(ci){emoAt(ci);var k=-1;for(var i=0;i<capW.length;i++){if(capW[i].i<=ci)k=i;else break;}if(k===curW)return;
    if(curW>=0&&capW[curW])capW[curW].el.className='';curW=k;if(k>=0){capW[k].el.className='on';
      var el=capW[k].el;try{if(el.offsetTop-capEl.scrollTop>capEl.clientHeight-24)capEl.scrollTop=el.offsetTop-capEl.clientHeight/2;}catch(e){}}}
  function clearLight(){if(curW>=0&&capW[curW])capW[curW].el.className='';curW=-1;}

  /* listen -> ask -> talk -> listen again */
  function vcListen(){if(!vc.on)return;if(!SRC()){phase('idle');return;}saidEl.textContent='';vc.quietStop=false;
    var ok=listen({interim:function(t){saidEl.textContent='\u201C'+t.slice(0,MAX)+'\u201D';},
      done:function(t){if(!vc.on)return;if(vc.quietStop){phase('idle');return;}
        if(!t){phase('idle','I didn\u2019t hear anything, so I stopped. Tap me to talk');return;}ask(t,'voice');},
      fail:function(er){if(!vc.on)return;if(vc.quietStop){phase('idle');return;}
        phase('idle',er==='no-speech'?'I didn\u2019t hear anything, so I stopped. Tap me to talk':(er==='start'||er==='not-allowed')&&vc.rounds?'Tap me to keep talking':errMsg(er));
        if(er==='unsupported'||er==='service-not-allowed'||er==='not-allowed')hintPaint();}});
    if(ok)phase('listening');}
  function ask(t,via){var f=fit(t);if(!f)return;saidEl.textContent='\u201C'+f+'\u201D';vc.via=via;setCaption('');phase('thinking');vc.wait=true;
    if(!sendVoice(f)){vc.wait=false;phase('idle','Couldn\u2019t send that. Try again');}}
  function after(ok){if(!vc.on||vc.phase!=='speaking')return;clearLight();
    if(!ok){phase('idle','Hmm, that didn\u2019t work. Try again');setEmo('confused');return;}vc.rounds++;
    if(vc.via==='voice'&&SRC()){setTimeout(function(){if(vc.on&&vc.phase==='speaking')vcListen();},350);}
    else phase('idle',SRC()?'Tap me to talk, or type':'Type another one \uD83D\uDC47');}
  /* muted (or no speech voice): the face still "talks" for about as long as the words take */
  function fakeTalk(t,cb){endFake();var w=(t.match(/\S+/g)||[]).length,dur=Math.max(1400,Math.min(14000,w*330)),t0=new Date().getTime();
    vc.fake=setInterval(function(){var f=(new Date().getTime()-t0)/dur;bump();if(f>=1){endFake();if(cb)cb(true);return;}lightWord(Math.floor(f*t.length));},280);}
  function endFake(){if(vc.fake){clearInterval(vc.fake);vc.fake=null;}}
  function talk(text,ok,el){var t=clean(text||'');setCaption(t);curW=-1;phase('speaking');if(ok===false)emoS=null,setEmo('embarrassed');else{setEmo(emoPlan(text||'',t));emoAt(0);}vc.after=function(full){after(ok&&full!==false);};
    if(!t){after(ok);return;}
    if(pref.m||!SS()){fakeTalk(t,vc.after);return;}
    speakText(t,el||null,function(full){if(!full){if(vc.phase==='speaking')phase('idle');return;}vc.after(true);},lightWord);}
  function faceTap(){unlock();loadVoices();
    if(vc.phase==='idle'){vc.on=true;if(SRC())vcListen();else{try{tin.focus();}catch(e){}}return;}
    if(vc.phase==='listening'){stopListen(false);return;}
    /* thinking or talking: stop */
    vc.wait=false;endFake();stopSpeak(true);clearLight();phase('idle','Stopped. Tap me to talk again');}
  function openVC(){build();stopSpeak(true);unlock();loadVoices();ov.hidden=false;setC(D.documentElement,'hv-open',true);
    vc.on=true;vc.rounds=0;vc.wait=false;saidEl.textContent='';setCaption('');hintPaint();paintMute();paintTot();paintCust();phase('idle');anim();
    if(SRC()){vcListen();try{faceBtn.focus();}catch(e){}}  /* this tap is the user gesture, so start listening now */
    else{stEl.textContent='Hi! Type to talk to me \uD83D\uDC47';try{tin.focus();}catch(e){}}}
  function closeVC(){if(!ov||ov.hidden)return;vc.on=false;vc.wait=false;endFake();stopListen(true);stopSpeak(true);ov.hidden=true;setC(D.documentElement,'hv-open',false);phase('idle');try{mic.focus();}catch(e){}}
  mic.addEventListener('click',function(){if(W.hcApp&&W.hcApp.busy&&W.hcApp.busy()){toast('\u23F3 Wait for the reply, then talk');return;}openVC();});
  vcBtn.addEventListener('click',openVC);
  D.addEventListener('keydown',function(e){if(ov&&!ov.hidden&&(e.keyCode===27||e.key==='Escape')){e.preventDefault();closeVC();}},true);

  /* every finished reply: the face says it, or Read aloud reads it */
  D.addEventListener('hc:reply',function(e){var d=e.detail||{};
    if(ov&&!ov.hidden&&vc.on&&vc.wait){vc.wait=false;if(d.away){phase('idle','Oops, that got lost. Try again');setEmo('embarrassed');return;}talk(d.text||'',!!d.ok,d.el);return;}
    if(d.away)return;
    if(pref.on&&d.ok&&d.text)speakText(d.text,d.el||null,null);});

  /* leave the page / switch to Code: stop everything */
  function bye(){if(ov&&!ov.hidden){vc.wait=false;endFake();stopListen(true);stopSpeak(true);clearLight();phase('idle','Paused. Tap me to talk again');}else stopSpeak(true);}
  D.addEventListener('visibilitychange',function(){if(D.hidden)bye();});
  W.addEventListener('pagehide',bye);
  var cm=$('hc-mode-code');if(cm)cm.addEventListener('click',function(){closeVC();stopSpeak(true);});

  /* ---------- 🫧 blob animation: breathe when idle, wobble + squish, bounce while talking, the smile opens to the speech rhythm, eyes blink + follow ---------- */
  /* each feeling: body (sx/sy squash, dr droop, tl tall top, gh ghost wiggle, wob jiggle, ta tint), eyes (es height, ew size, pdx/pdy look, pw how much they look around, lg laugh ^^),
     mouth (see mouthD), cheeks (bl), head (hy/hr), motions (bo bounce, sh shake, wg sway, wb wobbly smile) */
  var EP={
    happy:      {sx:1,   sy:1,   dr:0, tl:0,  gh:0, wob:0,  ta:0,   es:1,   ew:1,   pdx:0, pdy:0, pw:1,  lg:0, mw:1,   ms:1,   mo:0,   mdx:0, mt:0,  rd:0, bl:.3, hy:0,  hr:0,  bo:0, sh:0, wg:0, wb:0},
    excited:    {sx:.95, sy:1.06,dr:0, tl:.6, gh:0, wob:.3, ta:.22, es:1.08,ew:1.12,pdx:0, pdy:-1,pw:.5, lg:0, mw:1.28,ms:1.35,mo:.38, mdx:0, mt:0,  rd:0, bl:.5, hy:-2, hr:0,  bo:1, sh:0, wg:0, wb:0},
    embarrassed:{sx:1.03,sy:.95, dr:.2,tl:0,  gh:0, wob:.1, ta:.26, es:.82, ew:.96, pdx:5, pdy:5, pw:.12,lg:0, mw:.62,ms:.55, mo:0,   mdx:5, mt:2,  rd:0, bl:1,  hy:3,  hr:7,  bo:0, sh:0, wg:0, wb:1},
    sad:        {sx:1.08,sy:.9,  dr:1, tl:0,  gh:0, wob:0,  ta:.3,  es:.62, ew:1,   pdx:0, pdy:5, pw:.15,lg:0, mw:.8, ms:-1,  mo:0,   mdx:0, mt:0,  rd:0, bl:.15,hy:5,  hr:0,  bo:0, sh:0, wg:0, wb:0},
    surprised:  {sx:.93, sy:1.1, dr:0, tl:1,  gh:0, wob:.15,ta:.12, es:1.2, ew:1.15,pdx:0, pdy:0, pw:.2, lg:0, mw:.42,ms:0,   mo:.55, mdx:0, mt:0,  rd:1, bl:.25,hy:-4, hr:0,  bo:0, sh:0, wg:0, wb:0},
    confused:   {sx:1,   sy:1,   dr:0, tl:.2, gh:0, wob:0,  ta:.2,  es:1,   ew:1,   pdx:4, pdy:-5,pw:.15,lg:0, mw:.6, ms:.25, mo:0,   mdx:12,mt:-5, rd:0, bl:.25,hy:0,  hr:-8, bo:0, sh:0, wg:0, wb:0},
    laughing:   {sx:1.04,sy:.96, dr:0, tl:0,  gh:0, wob:.4, ta:.18, es:1,   ew:1.05,pdx:0, pdy:0, pw:0,  lg:1, mw:1.22,ms:1.4, mo:.5,  mdx:0, mt:0,  rd:0, bl:.6, hy:-1, hr:0,  bo:0, sh:1, wg:0, wb:0},
    spooky:     {sx:.97, sy:1.04,dr:0, tl:.4, gh:1, wob:.1, ta:.62, es:1.1, ew:1.1, pdx:0, pdy:0, pw:.4, lg:0, mw:.7, ms:.2,  mo:.45, mdx:0, mt:0,  rd:1, bl:.4, hy:-3, hr:0,  bo:0, sh:0, wg:1, wb:0}};
  var EK=[];(function(){for(var k in EP.happy)if(EP.happy.hasOwnProperty(k))EK.push(k);})();
  var EC={};(function(){for(var i=0;i<EK.length;i++)EC[EK[i]]=EP.happy[EK[i]];})();
  var MC={mw:1,ms:1,mo:0,mdx:0,mt:0,rd:0,wv:0};
  var lvl=0,lastB=0,bAmp=0,raf=null,RAF=W.requestAnimationFrame||function(f){return setTimeout(f,33);};
  var eye={x:0,y:0,tx:0,ty:0,next:0,blink:0,nextBlink:0,px:0,py:0,pt:0,gx:0,gy:0,gvx:0,gvy:0},mo=0,frames=0,sqv=0,sq=0;
  function hear(){lvl=Math.min(1,lvl+.5);}
  function bump(){lastB=new Date().getTime();bAmp=.65+Math.random()*.35;sqv-=.05*bAmp;}
  function f1(n){return n.toFixed(1);}
  function blobD(t,sx,sy,base){var N=30,pts=[],cx=100,R=64,cy=base-R*sy,i;
    for(i=0;i<N;i++){var a=i/N*Math.PI*2,ca=Math.cos(a),sa=Math.sin(a),
        r=R*(1+.032*Math.sin(3*a+t*2.1)+.022*Math.sin(5*a-t*1.7)+EC.wob*.045*Math.sin(4*a+t*10));
      var x=ca*r*sx,y=sa*r*sy;
      if(sa>0){y+=EC.dr*7*sa*sa;x*=1+EC.dr*.1*sa;if(EC.gh>.01)y+=EC.gh*6.5*Math.sin(a*9+t*7)*sa*sa*sa;}
      else y*=1+EC.tl*.08*(-sa);
      pts.push([cx+x,cy+y]);}
    var m=[(pts[N-1][0]+pts[0][0])/2,(pts[N-1][1]+pts[0][1])/2],d='M'+f1(m[0])+' '+f1(m[1]);
    for(i=0;i<N;i++){var p=pts[i],q=pts[(i+1)%N];d+='Q'+f1(p[0])+' '+f1(p[1])+' '+f1((p[0]+q[0])/2)+' '+f1((p[1]+q[1])/2);}
    return d+'Z';}
  function drawMouth(o){for(var i=0;i<mouths.length;i++)mouths[i].setAttribute('d',mouthD('a',o,MC));
    for(var j=0;j<mclips.length;j++)mclips[j].setAttribute('d',mouthD('a',o,MC));
    var op=MC.mo+o*(1-MC.mo*.6);
    if(tongue){tongue.setAttribute('cx',(100+MC.mdx).toFixed(1));tongue.setAttribute('cy',(143+op*20+(MC.ms<0?-4:0)).toFixed(1));tongue.setAttribute('ry',(5+op*7).toFixed(1));}
    if(svg)svg.setAttribute('data-mouth',o.toFixed(2));}
  var tintCol='';
  function anim(){if(raf)return;var t0=new Date().getTime();eye.nextBlink=t0+1800;(function step(){if(!ov||ov.hidden){raf=null;return;}frames++;
      var n=new Date().getTime(),t=(n-t0)/1000,p=vc.phase,i,G=EP[emoNow]||EP.happy;
      for(i=0;i<EK.length;i++){var kk=EK[i];EC[kk]+=(G[kk]-EC[kk])*.14;}
      /* where the eyes look: your finger (for 2.5 s), the caption while talking, or around the room */
      if(n-eye.pt<2500){eye.tx=eye.px*6;eye.ty=eye.py*5;}
      else if(n>eye.next){if(p==='thinking'){eye.tx=(Math.random()*2-1)*4;eye.ty=-5;}else if(p==='speaking'){eye.tx=(Math.random()*2-1)*2;eye.ty=3.5;}
        else if(p==='listening'){eye.tx=(Math.random()*2-1)*1.5;eye.ty=0;}else{eye.tx=(Math.random()*2-1)*5;eye.ty=(Math.random()*2-1)*3.5;}eye.next=n+(p==='thinking'?500:900+Math.random()*1900);}
      eye.x+=(eye.tx-eye.x)*.2;eye.y+=(eye.ty-eye.y)*.2;
      var mv=(EYEMOVE[bp.eye]||4)/5,px=(eye.x*EC.pw+EC.pdx)*mv+Math.cos(t*9)*3*EC.wg,py=(eye.y*EC.pw+EC.pdy)*mv+Math.sin(t*9)*3*EC.wg;
      /* googly eyes: wobbly physics */
      eye.gvx+=(px*1.25-eye.gx)*.18;eye.gvy+=(py*1.25+1.5-eye.gy)*.18;eye.gvx*=.78;eye.gvy*=.78;eye.gx+=eye.gvx;eye.gy+=eye.gvy;
      if(n>eye.nextBlink){eye.blink=n;eye.nextBlink=n+2200+Math.random()*3300;if(Math.random()<.2)eye.nextBlink=n+260;}
      var bt=n-eye.blink,blk=bp.eye==='shades'?1:(bt<160?Math.max(.08,Math.abs(1-bt/80)):1),wide=(p==='listening'?1.1:1)*EC.ew,ys=Math.max(.06,blk*wide*EC.es);
      /* body: breathe, squash/stretch with the talking, bounce */
      var talk=p==='speaking',breathe=Math.sin(t*2.2)*.022,tgt=talk?mo*.09:(p==='listening'?lvl*.05:0);
      sqv+=(tgt-sq)*.25;sqv*=.72;sq+=sqv;
      var bounce=talk?Math.abs(Math.sin(t*6.2))*5:0;bounce+=Math.abs(Math.sin(t*7.5))*10*EC.bo;
      var sx=EC.sx*(1+breathe*.6+sq),sy=EC.sy*(1-breathe*.6-sq*1.1+(talk?.02:0)),base=176;
      var d=blobD(t,sx,sy,base);blobP.setAttribute('d',d);tintP.setAttribute('d',d);glossP.setAttribute('d',d);
      var tc=TINT[emoNow]||'#fff';if(tc!==tintCol){tintCol=tc;tintP.setAttribute('fill',tc);}tintP.setAttribute('opacity',(EC.ta*.9).toFixed(3));
      if(bp.col==='rainbow'){var g=svg.querySelector('#hbG');if(g)g.setAttribute('gradientTransform','rotate('+((t*30)%360).toFixed(1)+' .5 .5)');}
      var lift=bounce+(EC.hy<0?-EC.hy:0)*0,hyy=EC.hy;
      var tilt=(p==='thinking'?Math.sin(t*2)*3:0)+EC.hr*.6+Math.sin(t*26)*2.5*EC.sh+Math.sin(t*3.2)*7*EC.wg;
      var hx=Math.sin(t*23)*2*EC.sh+Math.sin(t*3.2)*4*EC.wg;
      head0.setAttribute('transform','translate('+hx.toFixed(2)+' '+(-lift).toFixed(2)+') rotate('+tilt.toFixed(2)+' 100 150)');
      shadowE.setAttribute('rx',(52*sx*(1-lift/60)).toFixed(1));shadowE.setAttribute('opacity',(.16-lift/200).toFixed(3));
      /* the face rides the squash and leans toward where it looks */
      var fy=(base-64*sy)-112+hyy*.6+(1-sy)*20,fx=eye.x*.6;
      faceG.setAttribute('transform','translate('+fx.toFixed(2)+' '+fy.toFixed(2)+')');
      for(i=0;i<eyes.length;i++){var e=eyes[i],cx=+e.getAttribute('data-cx'),cy=+e.getAttribute('data-cy')+(EC.es<.8?(1-EC.es)*6:0);
        e.setAttribute('transform','translate('+cx+' '+cy.toFixed(2)+')');var ein=e.firstChild;
        ein.setAttribute('transform','scale('+wide.toFixed(3)+' '+ys.toFixed(3)+')');ein.setAttribute('opacity',(1-EC.lg).toFixed(2));
        if(laughs[i])laughs[i].setAttribute('opacity',EC.lg.toFixed(2));}
      for(var j=0;j<pups.length;j++){var goo=bp.eye==='googly';pups[j].setAttribute('transform','translate('+(goo?eye.gx:px).toFixed(2)+' '+(goo?eye.gy:py).toFixed(2)+')');}
      for(var c=0;c<cheeks.length;c++)cheeks[c].setAttribute('opacity',(EC.bl*.7).toFixed(2));
      /* mouth: the feeling's shape, opening and closing with the words */
      MC.mw=EC.mw;MC.ms=EC.ms;MC.mo=EC.mo;MC.mdx=EC.mdx;MC.mt=EC.mt;MC.rd=EC.rd;MC.wv=Math.sin(t*15)*1.6*EC.wb;
      var tg=0;if(talk){var since=n-lastB;
          if(since<420)tg=bAmp*Math.sin(Math.PI*Math.min(1,since/300));
          else tg=.12+.6*Math.abs(Math.sin(t*8.6))*(.65+.35*Math.sin(t*2.3));}
        else if(p==='listening')tg=.06+lvl*.25;else if(p==='thinking')tg=.08;
      mo+=(tg-mo)*.45;if(mo<0)mo=0;drawMouth(mo);lvl*=.9;
      /* using a Tot: it squishes + bounces with the words too */
      if(totBox&&totOn()){totBox.style.webkitTransform=totBox.style.transform='translate('+hx.toFixed(1)+'px,'+(-lift*1.4).toFixed(1)+'px) rotate('+tilt.toFixed(1)+'deg) scale('+sx.toFixed(3)+','+sy.toFixed(3)+')';}
      raf=RAF(step);})();}

  var s0=SS();if(s0){loadVoices();try{if(s0.addEventListener)s0.addEventListener('voiceschanged',loadVoices);else s0.onvoiceschanged=loadVoices;}catch(e){}}
  W.hcVoice={clean:clean,open:openVC,close:closeVC,speak:speakText,stop:stopSpeak,emotion:emotionOf,emotions:EMOS.slice(0),
    setEmotion:function(e){setEmo(e);return emoNow;},
    say:function(text){build();if(ov.hidden)openVC();if(vc.phase==='listening')stopListen(true);vc.on=true;vc.via='type';talk(text,true);return emoNow;},
    state:function(){return {phase:vc.phase,rounds:vc.rounds,dict:dict,read:pref.on,mute:pref.m,voices:voices.length,open:!!(ov&&!ov.hidden),frames:frames,mouth:svg?+svg.getAttribute('data-mouth'):0,emotion:emoNow,emoClass:ov?(ov.className.match(/hv-e-\w+/)||[''])[0]:'',eye:bp.eye,color:bp.col,tot:totOn(),voice:(pickVoice()||{}).name||''};},
    setLook:function(o){o=o||{};if(EYEN[o.eye])bp.eye=o.eye;if(COLS[o.color])bp.col=o.color;if('tot' in o)bp.tot=!!o.tot;saveBP();if(ov){paintEyes();paintColor();paintTot();paintCust();}return {eye:bp.eye,color:bp.col,tot:totOn()};},
    eyes:EYEK.slice(0),colors:COLK.slice(0),best:function(){loadVoices();return bestName;},score:vScore};
})();
