/* hccode.js (v1.9.2: + hook for the admin-only 📷 example pictures (window.hcCodeLook from hcexamples.js; nothing loads for normal visitors); v1.5.1: + Z AI coders GLM 4.5 Flash + GLM 4.6V Flash; v1.5: + Baseten coders GLM 5.3 + GLM 5.3 Fast; v1.4: 🕹️ touch joystick in every Web/3D program + 🎮 Play mode that hides the site UI; v1.3: 🎨 style picker + ✨ Make it prettier + 🧊 3D with self-hosted three.js; v1.2 "Tabo Code", the user Oct 29): its own mode (💬 Chat | 🧑‍💻 Code). Describe a program, pick a coding model
   and a language; the server's AI writes it (kid-safe prompt first, Safety Shield in + out). Web programs run in a locked sandbox
   iframe (sandbox="allow-scripts" only + a strict CSP: no internet, no cookies, no site storage, can't navigate away); Python runs
   in the browser (Skulpt, self-hosted under /py/) in the same kind of sandbox; JavaScript runs in the sandbox with a console;
   Java/C++/C/C#/Go/Rust/Ruby/Lua run on a free code runner through the server (only the code + typed input are sent).
   Projects live ONLY in this browser's localStorage. ES5 only. */
(function(){
  'use strict';
  var W=window,D=document,R=D.documentElement;
  function $(id){return D.getElementById(id);}
  var sec=$('code');if(!sec)return;
  var PK='hc_code_v1',MODEK='hc_mode',CMK='hc_code_model',MAXP=30,MAXV=10,ASKMAX=500,CODEMAX=30000;
  function now(){return new Date().getTime();}
  function trim(s){return String(s==null?'':s).replace(/^\s+|\s+$/g,'');}
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
  function load(k,d){try{var r=localStorage.getItem(k);if(r){var v=JSON.parse(r);if(v&&typeof v==='object')return v;}}catch(e){}return d;}
  function uid(){return now().toString(36)+Math.floor(Math.random()*1e6).toString(36);}
  function toast(m,u){if(W.hcApp&&W.hcApp.toast)W.hcApp.toast(m,u);}
  function watch(){return (W.innerWidth||R.clientWidth)<=260;}
  function split(){return (W.innerWidth||R.clientWidth)>=900;}

  /* ---------- languages + models ---------- */
  /* run: web = sandboxed page, py = Skulpt in the sandbox, js = sandbox console, wb = free code runner (server), '' = copy only */
  var LANGS=[['web','\uD83C\uDF10 Web','html','web'],['3d','\uD83E\uDDCA 3D','html','3d'],['python','\uD83D\uDC0D Python','py','py'],['js','\uD83D\uDFE8 JavaScript','js','js'],
    ['java','\u2615 Java','java','wb'],['cpp','\u2795 C++','cpp','wb'],['c','\uD83C\uDDE8 C','c','wb'],['cs','#\uFE0F\u20E3 C#','cs','wb'],
    ['swift','\uD83D\uDC26 Swift','swift',''],['go','\uD83D\uDC39 Go','go','wb'],['rust','\uD83E\uDD80 Rust','rs','wb'],['ruby','\uD83D\uDC8E Ruby','rb','wb'],['lua','\uD83C\uDF19 Lua','lua','wb']];
  var LBY={};for(var li=0;li<LANGS.length;li++)LBY[LANGS[li][0]]=LANGS[li];
  /* only models that write good code (the user: "only good ones"); tested Oct 29 with "make a clicker game" */
  var CM=['sigma','qwen'],CMH={'llama-70b':' \u00B7 slow','cf-qwq':' \u00B7 slow thinker','deepseek-v32':' \u00B7 often busy','bt-glm53':' \u00B7 Baseten','bt-glm53-fast':' \u00B7 Baseten','zai-glm45-flash':' \u00B7 Z AI \u00B7 slow','zai-glm46v-flash':' \u00B7 Z AI','ax-deepseek-v4-pro':' \u00B7 APInex','ax-glm53':' \u00B7 APInex','ax-kimi-k3':' \u00B7 APInex','ax-qwen38-max':' \u00B7 APInex','ax-gpt6-luna':' \u00B7 APInex','ax-deepseek-v4-flash':' \u00B7 APInex','ax-deepseek-v41-flash':' \u00B7 APInex','ax-glm53-flash':' \u00B7 APInex','ax-mimo-v26-flash':' \u00B7 APInex','lg-k-exaone-2.5':' \u00B7 LG EXAONE'}; /* v1.5: + Baseten coders (daily limit) */
  var AI=W.domoAI,MB={};if(AI&&AI.models)for(var mi=0;mi<AI.models.length;mi++)MB[AI.models[mi].id]=AI.models[mi];
  var STARTERS={'3d':[['\uD83E\uDE90 Solar system','Make a solar system'],['\uD83E\uDDCA Spinning cube art','Make spinning cube art'],['\uD83C\uDFCE\uFE0F 3D racing game','Make a 3D racing game: a bright colorful car (box body, cabin, 4 wheels) that I steer left and right down a long road with 3 lanes and lane stripes, trees on the sides, obstacles to dodge, gold coins to collect, a score, and it slowly speeds up. Chase camera behind the car.'],['\uD83E\uDDF1 Block builder','Make a 3D block builder'],['\uD83C\uDF0A Ocean waves','Make 3D ocean waves']],
    web:['\uD83C\uDFAE Clicker game','\uD83D\uDC0D Snake game','\uD83E\uDDEE Calculator','\u26BD Bouncing ball','\uD83C\uDFA8 Drawing pad','\u23F1\uFE0F Stopwatch'],
    python:['\uD83D\uDD22 Guess the number','\uD83D\uDC22 Turtle drawing','\u2753 Quiz game','\u2716\uFE0F Times tables'],
    other:['\uD83D\uDC4B Hello world','\uD83D\uDD22 Guess the number','\u2716\uFE0F Times tables','\uD83C\uDFB2 Dice roller']};

  /* v1.3 \uD83C\uDFA8 styles (Web + 3D): the server turns the id into design instructions */
  var STYLES=[['','\u2728 Auto'],['neon','\uD83D\uDCA1 Neon / Glow'],['clean','\u26AA Clean / Minimal'],['cartoon','\uD83D\uDE1C Cartoon'],['pixel','\uD83D\uDC7E Pixel / Retro'],
    ['glass','\uD83E\uDE9F Glass'],['space','\uD83C\uDF0C Space'],['candy','\uD83C\uDF6C Candy / Pastel'],['darkpro','\uD83D\uDDA4 Dark Pro']],STK='hc_code_style';
  function visual(l){return l==='web'||l==='3d';}
  var PRETTY='Make it prettier: give it a more polished, beautiful design (colors, gradients, shadows, smooth animations, nicer layout and effects) without changing how it works or removing any features';
  /* ---------- projects (localStorage only) ---------- */
  var db=load(PK,null);if(!db||!(db.list instanceof Array))db={cur:null,list:[]};
  function find(id){for(var i=0;i<db.list.length;i++)if(db.list[i].id===id)return db.list[i];return null;}
  function fresh(lang){return {id:uid(),t:'',lang:lang||'web',u:now(),v:[],i:-1,d:null};}
  var cur=db.cur?find(db.cur):null;if(!cur)cur=fresh(db.lang||'web');
  function codeOf(p){return p.d!=null?p.d:(p.i>=0&&p.v[p.i]?p.v[p.i].c:'');}
  function title(p){return p.t||(p.v.length&&p.v[0].a&&p.v[0].a.indexOf('\u270F')!==0?p.v[0].a:(p.v.length||p.d?'My project':'New project'));}
  function saveDb(quiet){
    db.cur=cur.id;db.lang=cur.lang;
    if((cur.v.length||cur.d)&&!find(cur.id))db.list.push(cur);
    db.list.sort(function(a,b){return b.u-a.u;});
    var cut=0;while(db.list.length>MAXP&&db.list[db.list.length-1]!==cur){db.list.pop();cut++;}
    var ok=false,guard=0;
    while(!ok&&guard<80){try{localStorage.setItem(PK,JSON.stringify(db));ok=true;}catch(e){guard++;
      var trimmed=false;for(var i=db.list.length-1;i>=0&&!trimmed;i--){var p=db.list[i];if(p.v.length>1){var keep=p.v[p.i>=0?p.i:p.v.length-1];p.v=[keep];p.i=0;trimmed=true;}}
      if(!trimmed){if(db.list.length>1&&db.list[db.list.length-1]!==cur){db.list.pop();cut++;}else break;}}}
    if(!ok&&!quiet)toast('\uD83D\uDCBE This device is out of space. Delete a project to save more.');
    else if(cut&&!quiet)toast('\uD83D\uDDC2\uFE0F Oldest project removed (30 projects max)');
    if(openList())renderList();
  }

  /* ---------- elements ---------- */
  var langSel=$('cb-lang'),modelSel=$('cb-model'),titleBtn=$('cb-title'),tabPv=$('cb-tab-pv'),tabEd=$('cb-tab-ed'),undoBtn=$('cb-undo'),runBtn=$('cb-run'),fsBtn=$('cb-fs'),
    frameWrap=$('cb-frame'),outEl=$('cb-out'),stdinWrap=$('cb-stdin-w'),stdin=$('cb-stdin'),emptyEl=$('cb-empty'),busyEl=$('cb-busy'),busyT=$('cb-busy-t'),errEl=$('cb-err'),
    stEl=$('cb-st'),ta=$('cb-ta'),hlEl=$('cb-hl'),copyBtn=$('cb-copy'),dlBtn=$('cb-dl'),form=$('cb-form'),input=$('cb-msg'),sendBtn=form.querySelector('.send'),chips=$('cb-chips'),
    pvBox=$('cb-pv'),fsX=$('cb-fs-x'),listEl=$('cb-list'),runNote=$('cb-runnote'),styleRow=$('cb-srow'),styleSel=$('cb-style'),prettyBtn=$('cb-pretty');

  /* ---------- syntax highlighting (overlay under a transparent textarea) ---------- */
  var KW={
    js:'var let const function return if else for while do break continue new this class extends import from export true false null undefined typeof instanceof try catch finally throw switch case default async await of in delete void',
    python:'def return if elif else for while break continue import from as class True False None and or not in is try except finally raise with lambda pass global yield print input range len',
    java:'public private protected static final void int long double float boolean char byte short class new return if else for while do break continue import package true false null try catch finally throw throws this super extends implements interface String System',
    c:'int long double float char void short unsigned signed const static struct enum typedef return if else for while do break continue switch case default sizeof include define true false NULL bool auto class public private new delete namespace using std template cout cin endl string vector',
    cs:'using namespace class static void int long double float bool char string var new return if else for foreach while do break continue public private protected true false null try catch finally throw this Console',
    swift:'import func let var return if else for in while repeat break continue struct class enum true false nil switch case default guard print',
    go:'package import func var const return if else for range break continue type struct map chan go defer true false nil switch case default fmt',
    rust:'fn let mut return if else for in while loop break continue struct enum impl use pub match true false Some None Ok Err self Self println',
    ruby:'def end return if elsif else unless for in while until do break next class module true false nil puts gets require self yield then',
    lua:'local function end return if then elseif else for in while do repeat until break true false nil and or not print'};
  var KWM={web:'js','3d':'js',js:'js',python:'python',java:'java',c:'c',cpp:'c',cs:'cs',swift:'swift',go:'go',rust:'rust',ruby:'ruby',lua:'lua'},KWS={};
  function kwSet(lang){var k=KWM[lang]||'js';if(!KWS[k]){var o={},a=KW[k].split(' ');for(var i=0;i<a.length;i++)o[a[i]]=1;KWS[k]=o;}return KWS[k];}
  function tokRe(lang){
    var com=lang==='python'||lang==='ruby'?'#[^\\n]*':(lang==='lua'?'--\\[\\[[\\s\\S]*?\\]\\]|--[^\\n]*':'\\/\\/[^\\n]*|\\/\\*[\\s\\S]*?\\*\\/');
    if((lang==='web'||lang==='3d'))com='<!--[\\s\\S]*?-->|'+com;
    if(lang==='python')com='"""[\\s\\S]*?"""|\'\'\'[\\s\\S]*?\'\'\'|'+com;
    var str='"(?:[^"\\\\\\n]|\\\\.)*"?|\'(?:[^\'\\\\\\n]|\\\\.)*\'?'+((lang==='web'||lang==='3d')||lang==='js'||lang==='go'?'|`(?:[^`\\\\]|\\\\.)*`?':'');
    return new RegExp('('+com+')|('+str+')|('+((lang==='web'||lang==='3d')?'<\\/?[A-Za-z][\\w-]*|\\/?>':'#\\s*include\\b|#\\s*define\\b')+')|(\\b\\d+(?:\\.\\d+)?\\b)|([A-Za-z_$][\\w$]*)','g');
  }
  var reCache={};
  function hl(src,lang){
    if(src.length>60000)return esc(src);
    var re=reCache[lang]||(reCache[lang]=tokRe(lang)),ks=kwSet(lang),out='',last=0,m;re.lastIndex=0;
    while((m=re.exec(src))){
      if(m.index>last)out+=esc(src.slice(last,m.index));
      var t=m[0],c=m[1]?'c':m[2]?'s':m[3]?'t':m[4]?'n':(ks.hasOwnProperty(t)?'k':'');
      out+=c?'<span class="h'+c+'">'+esc(t)+'</span>':esc(t);
      last=re.lastIndex;if(!t.length)re.lastIndex++;
    }
    return out+esc(src.slice(last));
  }
  var hlTimer=null;
  function paintHl(){hlEl.innerHTML=hl(ta.value,cur.lang)+'\n ';syncScroll();}
  function syncScroll(){hlEl.scrollTop=ta.scrollTop;hlEl.scrollLeft=ta.scrollLeft;}
  ta.addEventListener('scroll',syncScroll);
  var saveTimer=null;
  ta.addEventListener('input',function(){paintHl();var v=ta.value;cur.d=(cur.i>=0&&cur.v[cur.i]&&cur.v[cur.i].c===v)?null:v;cur.u=now();
    clearTimeout(saveTimer);saveTimer=setTimeout(function(){saveDb(true);},700);});
  ta.addEventListener('keydown',function(e){ /* Tab key types 2 spaces instead of leaving the editor */
    if(e.keyCode===9&&!e.shiftKey&&!e.altKey&&!e.ctrlKey&&!e.metaKey&&ta.value){var s=ta.selectionStart,en=ta.selectionEnd;
      if(typeof s==='number'){e.preventDefault();ta.value=ta.value.slice(0,s)+'  '+ta.value.slice(en);ta.selectionStart=ta.selectionEnd=s+2;
        var ev;try{ev=new Event('input');}catch(x){ev=D.createEvent('Event');ev.initEvent('input',true,true);}ta.dispatchEvent(ev);}}});

  /* ---------- the sandbox ---------- */
  var ORIGIN=(location.protocol==='http:'||location.protocol==='https:')?location.protocol+'//'+location.host:'';
  function csp(extra){return "default-src 'none'; script-src 'unsafe-inline' 'unsafe-eval'"+(extra||'')+"; style-src 'unsafe-inline'; img-src data: blob:; media-src data: blob:; font-src data:; connect-src 'none'; frame-src 'none'; child-src 'none'; worker-src 'none'; object-src 'none'; manifest-src 'none'; form-action 'none'; base-uri 'none'";}
  /* runs first inside the sandbox: errors go to the app, alert/prompt/confirm become on-page messages, links + forms + window.open do nothing,
     localStorage becomes a pretend one (the real one isn't reachable from the sandbox) */
  var GUARD='(function(){var P=window.parent;function send(k,t){try{P.postMessage({hcc:1,k:k,t:String(t).slice(0,300)},"*");}catch(e){}}'+
    'window.onerror=function(m,s,l){send("err",m+(l?" (line "+l+")":""));};'+
    'function fake(){var m={};var o={getItem:function(k){return Object.prototype.hasOwnProperty.call(m,k)?m[k]:null;},setItem:function(k,v){m[k]=String(v);},removeItem:function(k){delete m[k];},clear:function(){m={};},key:function(i){var a=[];for(var k in m)a.push(k);return a[i]||null;}};'+
    'try{Object.defineProperty(o,"length",{get:function(){var n=0;for(var k in m)n++;return n;}});}catch(e){}return o;}'+
    'var ss=["localStorage","sessionStorage"];for(var i=0;i<ss.length;i++){var ok=false;try{ok=!!window[ss[i]];}catch(e){}if(!ok){try{Object.defineProperty(window,ss[i],{value:fake(),configurable:true});}catch(e){}}}'+
    'var tq=null;function msg(t){try{if(!document.body)return;if(!tq){tq=document.createElement("div");tq.style.cssText="position:fixed;left:50%;bottom:16px;transform:translateX(-50%);-webkit-transform:translateX(-50%);max-width:90%;background:#2a1a0c;color:#fff;padding:10px 16px;border-radius:12px;font:600 15px sans-serif;z-index:2147483647;box-shadow:0 6px 20px rgba(0,0,0,.3);text-align:center";}tq.textContent=String(t);document.body.appendChild(tq);clearTimeout(tq._t);tq._t=setTimeout(function(){if(tq.parentNode)tq.parentNode.removeChild(tq);},2600);}catch(e){}}'+
    'window.alert=function(t){msg(t);};window.confirm=function(t){msg(t);return true;};window.prompt=function(t,d){return d==null?"":String(d);};window.open=function(){return null;};'+
    'document.addEventListener("click",function(e){var a=e.target;while(a&&a.nodeName!=="A")a=a.parentNode;if(a&&a.getAttribute){var h=a.getAttribute("href")||"";if(h&&h.charAt(0)!=="#")e.preventDefault();}},true);'+
    'document.addEventListener("submit",function(e){e.preventDefault();},true);})();';
  /* v1.4 \uD83D\uDD79\uFE0F touch joystick (the user Oct 29: "control it with a stick"): injected into every Web + 3D program. On touch screens, once the program
     listens for keys (or reads window.HC_STICK), a translucent stick (bottom-left) + "A" button (bottom-right) appear; dragging fires real keydown/keyup
     events (arrows, or WASD when the program only uses WASD; A = Space or Enter) and window.HC_STICK = {x,y,active,a} gives smooth -1..1 movement. ES5. */
  var STICK="(function(){\nif(window.HC_STICK_ON)return;window.HC_STICK_ON=1;\nvar W=window,D=document,wadd=W.addEventListener,st={x:0,y:0,active:false,a:false},uses=false,shown=false,touch=false,ui=null;\ntry{Object.defineProperty(W,\"HC_STICK\",{get:function(){if(!uses){uses=true;chk();}return st;},configurable:true});}catch(e){W.HC_STICK=st;}\nvar KR=/^(keydown|keyup|keypress)$/;\nvar oa=null;try{var ET=W.EventTarget&&EventTarget.prototype;oa=ET&&ET.addEventListener;if(oa){ET.addEventListener=function(t,f,o){if(!uses&&KR.test(String(t))&&this!==ui&&!(this&&this.nodeName&&/^(INPUT|TEXTAREA|SELECT)$/.test(this.nodeName))){uses=true;setTimeout(chk,0);}return oa.call(this,t,f,o);};}}catch(e){}\nif(!oa){try{var P=[W,D,W.HTMLElement&&HTMLElement.prototype];for(var pi=0;pi<P.length;pi++)(function(o){if(!o||!o.addEventListener)return;var f0=o.addEventListener;o.addEventListener=function(t,f,x){if(!uses&&KR.test(String(t))){uses=true;setTimeout(chk,0);}return f0.call(this,t,f,x);};})(P[pi]);}catch(e){}}\nfunction propKeys(){try{return !!(W.onkeydown||W.onkeyup||D.onkeydown||D.onkeyup||(D.body&&(D.body.onkeydown||D.body.onkeyup)));}catch(e){return false;}}\ntry{var mq=W.matchMedia;touch=!!((mq&&mq(\"(pointer: coarse)\").matches)||((\"ontouchstart\" in W||(navigator.maxTouchPoints||0)>0)&&!(mq&&mq(\"(hover: hover)\").matches))||/OculusBrowser|Quest|Pico/i.test(navigator.userAgent));}catch(e){}\nvar src=null,K=null;\nfunction scan(){if(src!=null)return;src=\"\";try{var s=D.getElementsByTagName(\"script\");for(var i=0;i<s.length;i++)src+=(s[i].text||\"\")+\"\\n\";}catch(e){}\nvar ar=/Arrow(Up|Down|Left|Right)|(keyCode|which)\\s*={2,3}\\s*(3[7-9]|40)\\b|case\\s+(3[7-9]|40)\\s*:|\\b(3[7-9]|40)\\s*:\\s*[\"'](up|down|left|right)/i.test(src),\nwa=/Key[WASD]\\b|={2,3}\\s*[\"'][wasdWASD][\"']|case\\s*[\"'][wasdWASD][\"']|keys?\\s*\\.\\s*[wasd]\\b|keys?\\s*\\[\\s*[\"'][wasdWASD][\"']\\s*\\]|(keyCode|which)\\s*={2,3}\\s*(87|65|83|68)\\b|case\\s+(87|65|83|68)\\s*:/.test(src);\nK={arrows:ar||!wa,wasd:!ar,space:/[\"'] [\"']|Space|\\b32\\b/.test(src)||!/Enter|\\b13\\b/.test(src),enter:/Enter|\\b13\\b/.test(src)&&!/[\"'] [\"']|Space|\\b32\\b/.test(src)};}\nvar KEYS={up:[[\"ArrowUp\",\"ArrowUp\",38],[\"w\",\"KeyW\",87]],down:[[\"ArrowDown\",\"ArrowDown\",40],[\"s\",\"KeyS\",83]],left:[[\"ArrowLeft\",\"ArrowLeft\",37],[\"a\",\"KeyA\",65]],right:[[\"ArrowRight\",\"ArrowRight\",39],[\"d\",\"KeyD\",68]],\nfire:[[\" \",\"Space\",32],[\"Enter\",\"Enter\",13]]};\nfunction fireKey(type,k,rep){var e;try{e=new KeyboardEvent(type,{key:k[0],code:k[1],keyCode:k[2],which:k[2],bubbles:true,cancelable:true,repeat:!!rep});}catch(x){try{e=D.createEvent(\"Event\");e.initEvent(type,true,true);e.key=k[0];e.code=k[1];}catch(y){return;}}\ntry{if(e.keyCode!==k[2])Object.defineProperty(e,\"keyCode\",{get:function(){return k[2];}});}catch(x){}try{if(e.which!==k[2])Object.defineProperty(e,\"which\",{get:function(){return k[2];}});}catch(x){}\ntry{if(e.charCode===undefined||type===\"keypress\")Object.defineProperty(e,\"charCode\",{get:function(){return type===\"keypress\"?k[2]:0;}});}catch(x){}\ne.hcStick=1;var t=D.activeElement;if(!t||t===D.documentElement||/^(INPUT|TEXTAREA|SELECT|IFRAME)$/.test(t.nodeName||\"\"))t=D.body||D;t.dispatchEvent(e);}\nfunction want(d){scan();var a=KEYS[d],r=[];if(d===\"fire\"){if(K.space)r.push(a[0]);if(K.enter)r.push(a[1]);}else{if(K.arrows)r.push(a[0]);if(K.wasd)r.push(a[1]);}return r;}\nvar held={},rep={};\nfunction press(d,on){if(!!held[d]===on)return;held[d]=on;var ks=want(d),i;clearTimeout(rep[d]);clearInterval(rep[d]);\nif(on){for(i=0;i<ks.length;i++){fireKey(\"keydown\",ks[i]);if(d===\"fire\")fireKey(\"keypress\",ks[i]);}rep[d]=setTimeout(function(){rep[d]=setInterval(function(){for(var j=0;j<ks.length;j++)fireKey(\"keydown\",ks[j],1);},90);},400);}\nelse for(i=0;i<ks.length;i++)fireKey(\"keyup\",ks[i]);}\nfunction el(tag,css){var e=D.createElement(tag);e.style.cssText=css;return e;}\nvar base,knob,btn,R=60,sp=null,bp=null,cx=0,cy=0;\nvar NS=\"position:fixed;z-index:2147483640;touch-action:none;-ms-touch-action:none;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;-webkit-tap-highlight-color:rgba(0,0,0,0);\";\nfunction build(){if(ui||!D.body)return;ui=el(\"div\",\"position:fixed;left:0;top:0;width:0;height:0;z-index:2147483640\");\nvar m=Math.min(W.innerWidth||400,W.innerHeight||400);R=m<380?50:(m>700?70:60);var S=R*2;\nbase=el(\"div\",NS+\"left:18px;bottom:18px;left:calc(18px + env(safe-area-inset-left));bottom:calc(18px + env(safe-area-inset-bottom));width:\"+S+\"px;height:\"+S+\"px;border-radius:50%;background:rgba(20,24,36,.28);background:radial-gradient(circle,rgba(20,24,36,.18),rgba(20,24,36,.38));border:2px solid rgba(255,255,255,.75);box-shadow:0 0 0 1px rgba(0,0,0,.25),0 4px 22px rgba(0,0,0,.28),inset 0 0 18px rgba(0,0,0,.2);-webkit-backdrop-filter:blur(3px);backdrop-filter:blur(3px)\");\nknob=el(\"div\",\"position:absolute;left:50%;top:50%;width:\"+Math.round(S*.46)+\"px;height:\"+Math.round(S*.46)+\"px;margin:-\"+Math.round(S*.23)+\"px 0 0 -\"+Math.round(S*.23)+\"px;border-radius:50%;background:rgba(255,255,255,.55);background:radial-gradient(circle at 35% 30%,rgba(255,255,255,.95),rgba(220,225,235,.6));border:1px solid rgba(0,0,0,.25);box-shadow:0 3px 10px rgba(0,0,0,.4);pointer-events:none\");\nbase.appendChild(knob);\nbtn=el(\"div\",NS+\"right:22px;bottom:30px;right:calc(22px + env(safe-area-inset-right));bottom:calc(30px + env(safe-area-inset-bottom));width:\"+Math.round(R*1.3)+\"px;height:\"+Math.round(R*1.3)+\"px;border-radius:50%;text-align:center;font:900 \"+Math.round(R*.55)+\"px system-ui,-apple-system,sans-serif;line-height:\"+Math.round(R*1.3-4)+\"px;color:#fff;text-shadow:0 1px 3px rgba(0,0,0,.5);background:rgba(239,68,68,.6);border:2px solid rgba(255,255,255,.75);box-shadow:0 0 0 1px rgba(0,0,0,.25),0 4px 18px rgba(0,0,0,.3)\");\nbtn.textContent=\"A\";btn.setAttribute(\"aria-label\",\"A button\");base.setAttribute(\"aria-label\",\"Joystick\");\nui.appendChild(base);ui.appendChild(btn);ui.style.display=\"none\";D.body.appendChild(ui);\nfunction setK(dx,dy){var l=Math.sqrt(dx*dx+dy*dy);if(l>R){dx=dx*R/l;dy=dy*R/l;}var t=\"translate(\"+dx+\"px,\"+dy+\"px)\";knob.style.transform=t;knob.style.webkitTransform=t;\nst.x=Math.round(dx/R*100)/100;st.y=Math.round(dy/R*100)/100;st.active=!!(dx||dy);var th=0.38;\npress(\"left\",st.x<-th);press(\"right\",st.x>th);press(\"up\",st.y<-th);press(\"down\",st.y>th);}\nfunction sStart(x,y){var r=base.getBoundingClientRect();cx=r.left+r.width/2;cy=r.top+r.height/2;setK(x-cx,y-cy);base.style.background=\"rgba(20,24,36,.45)\";}\nfunction sMove(x,y){setK(x-cx,y-cy);}\nfunction sEnd(){setK(0,0);st.active=false;base.style.background=\"rgba(20,24,36,.32)\";}\nfunction bOn(on){st.a=on;btn.style.background=on?\"rgba(239,68,68,.9)\":\"rgba(239,68,68,.6)\";btn.style.transform=on?\"scale(.92)\":\"\";btn.style.webkitTransform=btn.style.transform;press(\"fire\",on);}\nfunction stop(e){if(e.cancelable)e.preventDefault();if(e.stopPropagation)e.stopPropagation();}\nif(W.PointerEvent){\nbase.addEventListener(\"pointerdown\",function(e){stop(e);sp=e.pointerId;try{base.setPointerCapture(sp);}catch(x){}sStart(e.clientX,e.clientY);});\nbase.addEventListener(\"pointermove\",function(e){if(e.pointerId!==sp)return;stop(e);sMove(e.clientX,e.clientY);});\nvar se=function(e){if(e.pointerId!==sp)return;stop(e);sp=null;sEnd();};base.addEventListener(\"pointerup\",se);base.addEventListener(\"pointercancel\",se);base.addEventListener(\"lostpointercapture\",se);\nbtn.addEventListener(\"pointerdown\",function(e){stop(e);bp=e.pointerId;try{btn.setPointerCapture(bp);}catch(x){}bOn(true);});\nvar be=function(e){if(e.pointerId!==bp)return;stop(e);bp=null;bOn(false);};btn.addEventListener(\"pointerup\",be);btn.addEventListener(\"pointercancel\",be);btn.addEventListener(\"lostpointercapture\",be);\nvar no=function(e){stop(e);};base.addEventListener(\"touchstart\",no);base.addEventListener(\"touchmove\",no);btn.addEventListener(\"touchstart\",no);btn.addEventListener(\"touchmove\",no);\n}else{\nfunction ft(l,id){for(var i=0;i<l.length;i++)if(l[i].identifier===id)return l[i];return null;}\nbase.addEventListener(\"touchstart\",function(e){stop(e);var t=e.changedTouches[0];sp=t.identifier;sStart(t.clientX,t.clientY);});\nbase.addEventListener(\"touchmove\",function(e){stop(e);var t=ft(e.changedTouches,sp);if(t)sMove(t.clientX,t.clientY);});\nvar te=function(e){stop(e);if(ft(e.changedTouches,sp)){sp=null;sEnd();}};base.addEventListener(\"touchend\",te);base.addEventListener(\"touchcancel\",te);\nbtn.addEventListener(\"touchstart\",function(e){stop(e);bOn(true);});var tb=function(e){stop(e);bOn(false);};btn.addEventListener(\"touchend\",tb);btn.addEventListener(\"touchcancel\",tb);}\nbase.addEventListener(\"contextmenu\",stop);btn.addEventListener(\"contextmenu\",stop);\nW.addEventListener(\"blur\",function(){sEnd();if(st.a)bOn(false);});}\nfunction chk(){if(!uses&&propKeys())uses=true;if(shown||!uses||!touch||W.HC_NO_WEBGL)return;if(!D.body){D.addEventListener(\"DOMContentLoaded\",chk);return;}build();if(ui){ui.style.display=\"\";shown=true;}}\nfunction onT(){if(!touch){touch=true;chk();}}\nW.addEventListener(\"touchstart\",onT,true);\nwadd.call(W,\"keydown\",function(e){if(!e.hcStick&&(e.key===\"Escape\"||e.keyCode===27)){try{parent.postMessage({hcc:1,k:\"esc\",t:\"\"},\"*\");}catch(x){}}},true);\nW.addEventListener(\"load\",function(){chk();var n=0,iv=setInterval(function(){chk();if(++n>10||shown)clearInterval(iv);},500);});\nif(D.readyState!==\"loading\")setTimeout(chk,0);else D.addEventListener(\"DOMContentLoaded\",chk);\n})();";
  function head(extra,stick){return '<meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="'+csp(extra)+'"><script>'+GUARD+'<\/script>'+(stick?'<script>'+STICK+'<\/script>':'');}
  function safeJs(s){return JSON.stringify(s).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');}
  function webDoc(code){
    code=String(code).replace(/<meta[^>]+http-equiv\s*=\s*["']?\s*refresh[^>]*>/gi,'').replace(/<base\b[^>]*>/gi,'');
    var m=/^\s*<!doctype[^>]*>/i.exec(code),h=head('',1);
    if(!m)return '<!DOCTYPE html>'+h+code;  /* the CSP + guard come before anything in the program, so nothing runs without them */
    return code.slice(0,m[0].length)+h+code.slice(m[0].length);
  }
  /* v1.3 \uD83E\uDDCA 3D: three.js r186 is self-hosted on this site (/lib/three-hc.js, global THREE + THREE.OrbitControls) and is the ONLY outside
     file the 3D sandbox may load (its exact URL is added to script-src; connect-src stays 'none'). Imports/CDN tags the AI writes anyway are rewritten. */
  var THREE_URL=ORIGIN+'/lib/three-hc.js';
  function strip3d(code){
    return String(code).replace(/<script\b[^>]*type\s*=\s*["']?importmap["']?[^>]*>[\s\S]*?<\/script>/gi,'')
      .replace(/<script\b[^>]*\bsrc\s*=[^>]*>\s*<\/script>/gi,'')
      .replace(/^[ \t]*import\s*\{([^}]*)\}\s*from\s*['"]three['"];?/gm,function(a,n){return 'const {'+n.replace(/\bas\b/g,':')+'} = THREE;';})
      .replace(/^[ \t]*import\s+[\s\S]*?\s+from\s*['"][^'"]*['"];?[ \t]*$/gm,'')
      .replace(/^[ \t]*import\s*['"][^'"]*['"];?[ \t]*$/gm,'');
  }
  /* runs after three.js, before the program: OrbitControls as a global too, a friendly note when WebGL is missing, and a
     \uD83E\uDD7D Enter VR button only when the device really supports immersive VR (Quest browser) */
  var GL3D='(function(){function note(t){function put(){var d=document.createElement("div");d.style.cssText="position:fixed;left:0;right:0;top:0;bottom:0;display:flex;align-items:center;justify-content:center;text-align:center;padding:24px;background:#0b1020;color:#fff;font:700 18px/1.4 system-ui,sans-serif;z-index:2147483646";d.innerHTML=t;document.body.appendChild(d);}if(document.body)put();else document.addEventListener("DOMContentLoaded",put);}'+
    'if(!window.THREE){note("\uD83E\uDDCA 3D couldn\u2019t load. Check your wifi and press \u25B6 Run.");window.onerror=function(){return true;};return;}window.OrbitControls=THREE.OrbitControls;'+
    'var ok=false;try{var c=document.createElement("canvas");ok=!!(window.WebGLRenderingContext&&(c.getContext("webgl2")||c.getContext("webgl")));}catch(e){}'+
    'if(!ok){note("\uD83E\uDDCA This device or browser can\u2019t show 3D (WebGL is off or not supported).<br><br>Try a newer browser, or turn on hardware acceleration.");window.onerror=function(){return true;};window.HC_NO_WEBGL=true;return;}'+
    /* older-style AI code: point/spot lights without a decay go dark in r186 -> default decay 0 (an explicit decay is kept) */
    'function D0(K,n){if(!K)return K;function F(){var a=[].slice.call(arguments);if(a[n]===undefined)a[n]=0;a.unshift(null);return new (Function.prototype.bind.apply(K,a))();}F.prototype=K.prototype;return F;}THREE.PointLight=D0(THREE.PointLight,3);THREE.SpotLight=D0(THREE.SpotLight,5);'+
/* v1.4: remembers the first scene + camera; a program whose animation loop never calls renderer.render (a common AI slip = blank screen)
       gets it rendered for it; after 2.5 s a scene with nothing in view (or nothing rendered) tells the app -> "Scene looks empty: Fix it" */
    '(function(){var OR=THREE.WebGLRenderer,L=null,S0=null,C0=null,fr=false,manual=false,inAuto=false;if(!OR)return;'+
    'function W0(K,f){if(!K)return K;function F(){var a=[].slice.call(arguments);a.unshift(null);var o=new (Function.prototype.bind.apply(K,a))();f(o);return o;}F.prototype=K.prototype;return F;}'+
    'THREE.Scene=W0(THREE.Scene,function(o){if(!S0)S0=o;});THREE.PerspectiveCamera=W0(THREE.PerspectiveCamera,function(o){if(!C0)C0=o;});'+
    'THREE.WebGLRenderer=W0(OR,function(r){var or=r.render,osal=r.setAnimationLoop;'+
    'r.render=function(sc,ca){fr=true;if(!inAuto)manual=true;if(sc&&sc.isScene&&ca&&ca.isCamera&&!(L&&L.s===sc&&L.c===ca))L={s:sc,c:ca};return or.apply(r,arguments);};'+
    'if(osal)r.setAnimationLoop=function(cb){if(typeof cb!=="function")return osal.call(r,cb);return osal.call(r,function(t,x){fr=false;cb.call(this,t,x);if(!fr&&!manual&&S0&&C0){inAuto=true;try{r.render(S0,C0);}catch(e){}inAuto=false;}});};});'+
    'setTimeout(function(){try{if(!L){parent.postMessage({hcc:1,k:"empty",t:"0/0"},"*");return;}var tot=0,inv=0,fu=new THREE.Frustum(),m=new THREE.Matrix4();L.c.updateMatrixWorld();m.multiplyMatrices(L.c.projectionMatrix,L.c.matrixWorldInverse);fu.setFromProjectionMatrix(m);'+
    'L.s.updateMatrixWorld();L.s.traverseVisible(function(o){if(o.isMesh&&o.geometry&&!o.isPoints){tot++;try{if(o.isInstancedMesh||fu.intersectsObject(o))inv++;}catch(e){inv++;}}});'+
    'if(inv===0||tot<3)parent.postMessage({hcc:1,k:"empty",t:tot+"/"+inv},"*");}catch(e){}},2500);})();'+
        'var X=navigator.xr;if(!X||!X.isSessionSupported)return;var O=THREE.WebGLRenderer;function HR(p){var r=new O(p);var sal=r.setAnimationLoop,done=0;r.setAnimationLoop=function(cb){if(cb&&!done){done=1;X.isSessionSupported("immersive-vr").then(function(s){if(s)vr(r);},function(){});}return sal.apply(r,arguments);};return r;}HR.prototype=O.prototype;THREE.WebGLRenderer=HR;'+
    'function vr(r){var b=document.createElement("button");b.textContent="\uD83E\uDD7D Enter VR";b.style.cssText="position:fixed;left:50%;bottom:14px;-webkit-transform:translateX(-50%);transform:translateX(-50%);z-index:2147483645;padding:12px 18px;border:0;border-radius:14px;background:#7c3aed;color:#fff;font:800 16px system-ui,sans-serif;box-shadow:0 6px 20px rgba(0,0,0,.35);cursor:pointer";var cur=null;'+
    'b.onclick=function(){if(cur){cur.end();return;}X.requestSession("immersive-vr",{optionalFeatures:["local-floor","bounded-floor","hand-tracking"]}).then(function(s){cur=s;r.xr.enabled=true;r.xr.setSession(s);b.textContent="Exit VR";s.addEventListener("end",function(){cur=null;b.textContent="\uD83E\uDD7D Enter VR";});},function(e){b.textContent="VR didn\u2019t start";});};document.body.appendChild(b);}})();';
  function threeDoc(code){
    code=strip3d(String(code).replace(/<meta[^>]+http-equiv\s*=\s*["']?\s*refresh[^>]*>/gi,'').replace(/<base\b[^>]*>/gi,''));
    var h=head(' '+THREE_URL,1)+'<script src="'+THREE_URL+'?v=1.3"><\/script><script>'+GL3D+'<\/script>',m=/^\s*<!doctype[^>]*>/i.exec(code);
    if(!m)return '<!DOCTYPE html>'+h+code;
    return code.slice(0,m[0].length)+h+code.slice(m[0].length);
  }
  /* a downloaded 3D file loads three.js from this site so it still works when opened on its own */
  function stickDl(code){var t='<script>'+STICK+'<\/script>',m=/<head[^>]*>/i.exec(code)||/^\s*<!doctype[^>]*>/i.exec(code);return m?code.slice(0,m.index+m[0].length)+t+code.slice(m.index+m[0].length):t+code;}
  function threeDl(code){var s='<script src="'+(ORIGIN||'https://taboai.sites.tab.bot')+'/lib/three-hc.js"><\/script><script>window.OrbitControls=THREE.OrbitControls;<\/script>';code=strip3d(code);
    var m=/<head[^>]*>/i.exec(code);return m?code.slice(0,m.index+m[0].length)+s+code.slice(m.index+m[0].length):s+code;}
  var CON_CSS='<style>html,body{margin:0;background:#0f172a;color:#e2e8f0;font:15px/1.45 ui-monospace,Menlo,Consolas,monospace}#out{white-space:pre-wrap;word-wrap:break-word;padding:12px;margin:0}'+
    '.err{color:#fca5a5}.ok{color:#86efac}.typed{color:#fde68a}input.in{font:inherit;background:#1e293b;color:#fde68a;border:1px solid #f59e0b;border-radius:6px;padding:2px 6px;width:60%;min-width:120px;outline:none}#turtle{background:#fff;text-align:center}#turtle canvas{max-width:100%}</style>';
  function pyDoc(code){
    var py=ORIGIN+'/py/';
    return '<!DOCTYPE html><html><head>'+head(' '+py)+CON_CSS+'<script src="'+py+'skulpt.min.js?v=1.2"><\/script><script src="'+py+'skulpt-stdlib.js?v=1.2"><\/script></head><body><div id="turtle"></div><pre id="out"></pre><script>'+
      '(function(){var CODE='+safeJs(code)+';var out=document.getElementById("out"),tt=document.getElementById("turtle");'+
      'function w(t,c){var s=document.createElement("span");if(c)s.className=c;s.textContent=t;out.appendChild(s);window.scrollTo(0,document.body.scrollHeight);}'+
      'function done(k,t){try{parent.postMessage({hcc:1,k:k,t:String(t||"").slice(0,300)},"*");}catch(e){}}'+
      'if(!window.Sk){w("Python couldn\\u2019t load. Check your connection and press Run again.","err");return;}'+
      'if(!/\\bturtle\\b/.test(CODE))tt.style.display="none";'+
      'Sk.configure({output:function(t){w(t);},read:function(x){if(Sk.builtinFiles===undefined||Sk.builtinFiles.files[x]===undefined)throw "File not found: \'"+x+"\'";return Sk.builtinFiles.files[x];},'+
      '__future__:Sk.python3,yieldLimit:100,inputfunTakesPrompt:true,inputfun:function(p){return new Promise(function(res){if(p)w(p);var i=document.createElement("input");i.className="in";i.setAttribute("aria-label","Type your answer, then press Enter");out.appendChild(i);try{i.focus();}catch(e){}'+
      'i.addEventListener("keydown",function(e){if(e.keyCode===13){var v=i.value,s=document.createElement("span");s.className="typed";s.textContent=v+"\\n";out.replaceChild(s,i);res(v);}});});}});'+
      '(Sk.TurtleGraphics||(Sk.TurtleGraphics={})).target="turtle";Sk.TurtleGraphics.width=Math.min(560,(window.innerWidth||400)-8);Sk.TurtleGraphics.height=Math.min(420,Math.max(240,(window.innerHeight||400)-60));'+
      'Sk.misceval.asyncToPromise(function(){return Sk.importMainWithBody("<stdin>",false,CODE,true);}).then(function(){w("\\n\\u2705 Program finished","ok");done("done");},function(e){var t=String(e);w("\\n\\u26A0\\uFE0F "+t,"err");done("err",t);});})();'+
      '<\/script></body></html>';
  }
  function jsDoc(code){
    return '<!DOCTYPE html><html><head>'+head('')+CON_CSS+'</head><body><pre id="out"></pre><script>(function(){var out=document.getElementById("out");'+
      'function f(a){var r=[];for(var i=0;i<a.length;i++){var x=a[i];if(typeof x==="object"&&x!==null){try{x=JSON.stringify(x);}catch(e){x=String(x);}}r.push(String(x));}return r.join(" ");}'+
      'function w(t,c){var s=document.createElement("span");if(c)s.className=c;s.textContent=t+"\\n";out.appendChild(s);}'+
      'window.console={log:function(){w(f(arguments));},info:function(){w(f(arguments));},warn:function(){w(f(arguments),"typed");},error:function(){w(f(arguments),"err");},table:function(x){w(f([x]));},clear:function(){out.innerHTML="";}};'+
      'window.addEventListener("error",function(e){w("\\u26A0\\uFE0F "+e.message+(e.lineno?" (line "+e.lineno+")":""),"err");});})();<\/script><script>'+
      String(code).replace(/<\/script/gi,'<\\/script')+'\n<\/script><script>setTimeout(function(){var o=document.getElementById("out");if(!o.firstChild)o.textContent="(no output: use console.log() to print)";},50);<\/script></body></html>';
  }
  var frame=null,expectLoad=false;
  function killFrame(){if(frame&&frame.parentNode)frame.parentNode.removeChild(frame);frame=null;}
  function mount(doc,xr){
    killFrame();
    frame=D.createElement('iframe');
    frame.setAttribute('sandbox','allow-scripts'); /* NO allow-same-origin / top-navigation / popups / forms / modals */
    frame.setAttribute('title','Preview of your program');
    frame.setAttribute('referrerpolicy','no-referrer');
    frame.setAttribute('allow',"camera 'none'; microphone 'none'; geolocation 'none'; payment 'none'; usb 'none'"+(xr?'; xr-spatial-tracking *':''));
    frame.className='cb-if';
    expectLoad=true;
    frame.onload=function(){if(expectLoad){expectLoad=false;if(playing)setTimeout(focusGame,30);return;} /* a 2nd load = the program tried to go to another page */
      var d='<!DOCTYPE html>'+head('')+'<body style="font:600 16px sans-serif;color:#7c4a12;background:#fff8eb;text-align:center;padding:30px 14px">\uD83D\uDEE1\uFE0F Blocked: the program tried to open another page.<br><br>Press \u25B6 Run to start it again.</body>';
      expectLoad=true;frame.srcdoc=d;};
    frame.srcdoc=doc;
    frameWrap.appendChild(frame);
  }
  W.addEventListener('message',function(e){var d=e.data;if(!frame||e.source!==frame.contentWindow||!d||d.hcc!==1)return;
    if(d.k==='err')showErr(d.t);else if(d.k==='esc'&&playing)fs(false);
    else if(d.k==='empty'&&errEl.hidden&&cur.lang==='3d'){var n=String(d.t).split('/');if(n[1]==='0'||isGame(codeOf(cur)))showEmpty();}});
  function showEmpty(){errEl.hidden=false;errEl.innerHTML='\uD83E\uDDCA <span>Scene looks empty</span> <button type="button" class="cb-fix" id="cb-fix">\uD83D\uDD27 Fix it</button>';
    var fx=$('cb-fix');if(fx)fx.onclick=function(){ask('Fix it: the 3D scene looks empty (only particles or nothing visible). Add a clearly visible player object, a ground or track, obstacles and collectibles, a sky color, bright lights, and a camera that follows and looks at the player. Keep the game idea.');};}
  function showErr(t){if(!t){errEl.hidden=true;return;}errEl.hidden=false;errEl.innerHTML='\u26A0\uFE0F <span>'+esc(String(t).slice(0,160))+'</span> <button type="button" class="cb-fix" id="cb-fix">\uD83D\uDD27 Fix it</button>';
    var fx=$('cb-fix');if(fx)fx.onclick=function(){ask('Fix this error: '+String(t).slice(0,200));};}

  /* ---------- run ---------- */
  var runSeq=0;
  function runNow(){
    var code=codeOf(cur),L=LBY[cur.lang]||LBY.web;showErr('');
    commitDraft();
    emptyEl.hidden=!!trim(code);
    if(!trim(code)){killFrame();outEl.hidden=true;return;}
    if(L[3]==='web'||L[3]==='3d'||L[3]==='py'||L[3]==='js'){outEl.hidden=true;frameWrap.hidden=false;mount(L[3]==='web'?webDoc(code):L[3]==='3d'?threeDoc(code):L[3]==='py'?pyDoc(code):jsDoc(code),L[3]==='3d');}
    else if(L[3]==='wb'){killFrame();frameWrap.hidden=true;outEl.hidden=false;wbRun(code);}
    else{killFrame();frameWrap.hidden=true;outEl.hidden=false;outEl.className='cb-out';outEl.textContent='\u25B6 '+L[1].replace(/^\S+\s/,'')+' can\u2019t run on this site yet.\n\nCopy it (</> Code \u2192 \uD83D\uDCCB Copy) into an app like Replit or Swift Playgrounds to run it.';}
    if(!split())setTab('pv');
  }
  function wbRun(code){
    var my=++runSeq;outEl.className='cb-out';outEl.textContent='\u23F3 Compiling + running on the free code runner\u2026';runBtn.disabled=true;
    var ctrl=('AbortController' in W)?new AbortController():null,timer=setTimeout(function(){if(ctrl)ctrl.abort();},32000);
    fetch('/api/hc/run',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({lang:cur.lang,code:code,stdin:stdin.value||''}),signal:ctrl?ctrl.signal:undefined})
      .then(function(r){return r.json()['catch'](function(){return {};});})
      .then(function(j){clearTimeout(timer);if(my!==runSeq)return;runBtn.disabled=false;
        if(!j||!j.ok){outEl.className='cb-out bad';outEl.textContent=(j&&j.message)||'The free code runner didn\u2019t answer. Try \u25B6 Run again in a few seconds!';return;}
        var t='';if(j.compile)t+='\uD83D\uDD27 Compiler says:\n'+j.compile+'\n';if(j.output)t+=j.output;if(j.error)t+=(t?'\n':'')+'\u26A0\uFE0F '+j.error;
        if(!t)t='(the program printed nothing)';t+='\n'+(j.status==='0'?'\u2705 Program finished':'\u26A0\uFE0F Program stopped (exit '+(j.status||j.signal||'?')+')');
        outEl.className='cb-out'+(j.status==='0'?'':' bad');outEl.textContent=t;
        if(j.status!=='0'&&(j.compile||j.error))showErr((j.compile||j.error).split('\n')[0]);})
      ['catch'](function(){clearTimeout(timer);if(my!==runSeq)return;runBtn.disabled=false;outEl.className='cb-out bad';outEl.textContent='Couldn\u2019t reach the code runner. Check your wifi and try again!';});
  }

  /* ---------- versions ---------- */
  function commitDraft(){if(cur.d!=null&&cur.d!==(cur.i>=0&&cur.v[cur.i]?cur.v[cur.i].c:'')){pushV(cur.d,'\u270F\uFE0F Your edits','');}cur.d=null;}
  function pushV(code,a,who){cur.v=cur.v.slice(0,cur.i+1);cur.v.push({c:code,a:a,m:who||'',t:now()});while(cur.v.length>MAXV)cur.v.shift();cur.i=cur.v.length-1;cur.d=null;cur.u=now();saveDb();ui();}
  function undo(){if(busy)return;if(cur.d!=null){cur.d=null;}else if(cur.i>0)cur.i--;else return;cur.u=now();saveDb();setCode(codeOf(cur));runNow();ui();
    toast('\u21B6 Back to version '+(cur.i+1)+' of '+cur.v.length);}
  function setCode(c){ta.value=c||'';paintHl();ta.scrollTop=0;ta.scrollLeft=0;syncScroll();}

  /* ---------- UI state ---------- */
  var tab='pv';
  function setTab(t){tab=t;sec.className=sec.className.replace(/\s*\bcb-on-\w+\b/g,'')+' cb-on-'+t;
    tabPv.setAttribute('aria-selected',t==='pv'?'true':'false');tabEd.setAttribute('aria-selected',t==='ed'?'true':'false');
    if(t==='ed')setTimeout(syncScroll,0);}
  function ui(){
    var L=LBY[cur.lang]||LBY.web,has=!!trim(codeOf(cur));
    langSel.value=cur.lang;titleBtn.textContent='\uD83D\uDCC1 '+title(cur);
    undoBtn.disabled=!(cur.d!=null||cur.i>0);
    stdinWrap.hidden=L[3]!=='wb';
    runNote.textContent=L[3]==='3d'?'\uD83D\uDD12 3D runs safely in a sandbox (no internet). Drag to look around, pinch to zoom':L[3]==='web'?'\uD83D\uDD12 Runs safely in a sandbox: no internet, no cookies, can\u2019t leave this page':L[3]==='py'?'\uD83D\uDD12 Python runs right here in a safe sandbox (no internet)':
      L[3]==='js'?'\uD83D\uDD12 Runs in a safe sandbox (no internet). Shows console.log output':L[3]==='wb'?'\u25B6 Runs on a free code runner (only your code is sent)':'\u25B6 Run works for Web, Python, JavaScript, Java, C++, C, C#, Go, Rust, Ruby + Lua. Copy Swift into an app to run it';
    input.placeholder=has?'Ask for a change (make it blue, add a score)\u2026':'Describe what to make\u2026';
    var st=STARTERS[cur.lang]||(cur.lang==='web'?STARTERS.web:STARTERS.other),h='';
    for(var i=0;i<st.length;i++){var sl=st[i] instanceof Array?st[i]:[st[i],''];h+='<button type="button" class="chip"'+(sl[1]?' data-q="'+esc(sl[1])+'"':'')+'>'+esc(sl[0])+'</button>';}
    chips.innerHTML=h;chips.style.display=has?'none':'';
    if(styleRow){styleRow.style.display=visual(cur.lang)?'':'none';prettyBtn.style.display=has?'':'none';prettyBtn.disabled=busy;}
    var v=cur.i>=0?cur.v[cur.i]:null;
    if(!stSet){stEl.innerHTML=v?esc('v'+(cur.i+1)+(cur.d!=null?' + your edits':'')+(v.m?' \u00B7 made by '+v.m:'')):(has?'':'\u2728 Tell Tabo Code what to make, pick a model + language');}
  }
  var stSet=false;
  function status(html){stSet=!!html;if(html)stEl.innerHTML=html;else ui();}

  /* ---------- model picker (coding models only) ---------- */
  function fillModels(){var h='',hide=(AI&&AI.hidden)?AI.hidden():[];
    for(var i=0;i<CM.length;i++){var id=CM[i],m=MB[id];if(!m||(id!=='sigma'&&hide.indexOf&&hide.indexOf(id)>=0))continue;h+='<option value="'+id+'">'+esc(m.e+' '+m.n+(id==='sigma'?' (default)':(CMH[id]||'')))+'</option>';}
    modelSel.innerHTML=h;var s='sigma';try{s=localStorage.getItem(CMK)||'sigma';if(s==='bt-glm53')s='ax-glm53';}catch(e){}modelSel.value=s;if(modelSel.value!==s)modelSel.value='sigma';}
  modelSel.addEventListener('change',function(){try{localStorage.setItem(CMK,modelSel.value);}catch(e){}});
  function fillLangs(){var h='';for(var i=0;i<LANGS.length;i++)h+='<option value="'+LANGS[i][0]+'">'+esc(LANGS[i][1])+'</option>';langSel.innerHTML=h;}
  langSel.addEventListener('change',function(){var l=langSel.value;if(busy){langSel.value=cur.lang;return;}if(l===cur.lang)return;
    if(trim(codeOf(cur))){cur=fresh(l);db.lang=l;toast('\u2728 New '+LBY[l][1].replace(/^\S+\s/,'')+' project');}else cur.lang=l;
    db.cur=cur.id;db.lang=l;saveDb(true);status('');setCode(codeOf(cur));runNow();ui();});

  /* ---------- ask the AI ---------- */
  var busy=false,busyTimer=null,GAMEW=/\b(games?|canvas|pixel(s|ated)?|sprites?|platformers?|farm(s|ing)?|arcade|rpg|shooter|snake|tetris|pong|flappy|mario|minecraft|zelda|pokemon|level|player|enem(y|ies))\b/i;
  function ask(text){
    text=trim(text).replace(/\s+/g,' ').slice(0,ASKMAX);if(!text||busy)return;
    commitDraft();
    /* v1.9.2: a game/canvas/pixel ask in plain JavaScript (no page to draw on) -> switch to Web (HTML) so the game can run */
    var swNote='';
    if(cur.lang==='js'&&GAMEW.test(text)&&LBY.web){if(trim(codeOf(cur))){cur=fresh('web');db.cur=cur.id;}else cur.lang='web';db.lang='web';langSel.value='web';saveDb(true);setCode(codeOf(cur));ui();
      swNote='\uD83D\uDD04 Switched to HTML so your game can run';toast(swNote);}
    var prev=codeOf(cur);if(prev.length>CODEMAX){toast('\uD83D\uDCE6 This project is too big for the AI to change. Start a new one!');return;}
    busy=true;sendBtn.disabled=true;if(prettyBtn)prettyBtn.disabled=true;input.value='';chips.style.display='none';showErr('');
    var model=modelSel.value||'sigma',mName=(MB[model]&&MB[model].n)||'Tabo AI',proj=cur,t0=now();
    busyEl.hidden=false;emptyEl.hidden=true;if(!split())setTab('pv');
    function tick(){var s=Math.round((now()-t0)/1000);busyT.textContent=(prev?'Changing your program':'Building your program')+' with '+mName+'\u2026 '+s+'s';}
    tick();busyTimer=setInterval(tick,1000);
    status('\uD83E\uDDD1\u200D\uD83D\uDCBB '+esc('\u201C'+text+'\u201D')+(swNote?' <span class="cb-who">'+esc(swNote)+'</span>':''));
    var body={ask:text,lang:proj.lang};if(styleSel&&styleSel.value&&visual(proj.lang))body.style=styleSel.value;if(model!=='sigma')body.model=model;if(prev)body.code=prev;
    var ctrl=('AbortController' in W)?new AbortController():null,timer=null;
    function end(){clearInterval(busyTimer);clearTimeout(timer);busy=false;sendBtn.disabled=false;if(prettyBtn)prettyBtn.disabled=false;busyEl.hidden=true;if(LK&&LK.busy)LK.busy(false);}
    /* v1.9.2 📷 admin-only example pictures: a vision AI turns them into a style guide first (hcexamples.js loads only in admin mode) */
    var LK=(W.hcCodeLook&&W.hcCodeLook.has&&W.hcCodeLook.has())?W.hcCodeLook:null;
    if(LK){var nP=LK.count();if(LK.busy)LK.busy(true);status('📷 '+esc('Reading the style from '+nP+(nP>1?' pictures':' picture')+'…'));
      busyT.textContent='📷 Reading the style from your '+(nP>1?nP+' pictures':'picture')+'…';clearInterval(busyTimer);
      LK.get().then(function(x){body.look={t:x.t,sig:x.sig};body.token=x.token;
          status('🧑‍💻 '+esc('“'+text+'”')+' <span class="cb-who">📷 style from '+x.n+(x.n>1?' pictures':' picture')+'</span>');
          t0=now();tick();busyTimer=setInterval(tick,1000);go();},
        function(e){end();status('<span class="cb-bad">'+esc((e&&e.message)||'Couldn’t read the pictures. Try again!')+'</span>');input.value=text;if(proj===cur){if(!trim(codeOf(cur)))emptyEl.hidden=false;ui();}});
      return;}
    go();
    function go(){timer=setTimeout(function(){if(ctrl)ctrl.abort();},115000);
    fetch('/api/hc/code',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body),signal:ctrl?ctrl.signal:undefined})
      .then(function(r){return r.text();})
      .then(function(tx){var j=null;try{j=JSON.parse(tx);}catch(e){}end();
        if(!j||!j.ok||!j.code){var msg=(j&&j.message)||'Hmm, I couldn\u2019t reach the coding AI. Check your wifi and try again!';
          status('<span class="cb-bad">'+esc(msg)+'</span>');if(proj===cur){if(!trim(codeOf(cur)))emptyEl.hidden=false;ui();}input.value=text;return;}
        var who=j.ai_name||mName,fellTxt=j.fell&&j.asked!==j.ai?' ('+mName+' was busy)':'';
        if(!proj.t&&!proj.v.length)proj.t=text.length>40?text.slice(0,38)+'\u2026':text;
        if(proj!==cur){cur=proj;}
        pushV(j.code,text,who);
        setCode(j.code);stSet=false;
        status((j.note?esc(j.note)+' ':'')+'<span class="cb-who">v'+(cur.i+1)+' \u00B7 made by '+esc(who)+esc(fellTxt)+(body.look?' \u00B7 \uD83D\uDCF7 style from your pictures':'')+(swNote?' \u00B7 '+esc(swNote):'')+'</span>');
        runNow();autoPlay();})
      ['catch'](function(){end();status('<span class="cb-bad">'+esc('Hmm, that took too long or the wifi dropped. Try again!')+'</span>');input.value=text;if(!trim(codeOf(cur)))emptyEl.hidden=false;});
    }
  }
  form.addEventListener('submit',function(e){e.preventDefault();ask(input.value);});
  chips.addEventListener('click',function(e){var b=e.target;while(b&&b!==chips&&!(b.className&&/\bchip\b/.test(b.className)))b=b.parentNode;
    if(b&&b!==chips){var q=b.getAttribute('data-q');if(q){ask(q);return;}var t=b.textContent.replace(/^[^A-Za-z]+/,'');ask('Make a '+t.toLowerCase());}});
  /* v1.3 \uD83C\uDFA8 style picker + \u2728 Make it prettier (Web + 3D) */
  if(styleSel){var sh='';for(var si=0;si<STYLES.length;si++)sh+='<option value="'+STYLES[si][0]+'">'+STYLES[si][1]+'</option>';styleSel.innerHTML=sh;
    var sv='';try{sv=localStorage.getItem(STK)||'';}catch(e){}styleSel.value=sv;if(styleSel.value!==sv)styleSel.value='';
    styleSel.addEventListener('change',function(){try{localStorage.setItem(STK,styleSel.value);}catch(e){}
      if(styleSel.value)toast('\uD83C\uDFA8 Style: '+styleSel.options[styleSel.selectedIndex].text.replace(/^\S+\s/,'')+(trim(codeOf(cur))?'. Tap Make it prettier to restyle':''));});
    prettyBtn.addEventListener('click',function(){if(trim(codeOf(cur)))ask(PRETTY);});}

  /* ---------- toolbar ---------- */
  tabPv.addEventListener('click',function(){setTab('pv');});
  tabEd.addEventListener('click',function(){setTab('ed');});
  runBtn.addEventListener('click',function(){runNow();ui();autoPlay();});
  undoBtn.addEventListener('click',undo);
  /* v1.4 🎮 Play mode (the user Oct 29: "remove the ui when you start a game"): the preview fills the whole screen and every bit of the site's
     own UI is hidden, with a small see-through ✕ Exit (+ </> back to the code). Esc, the phone/browser Back button and TV Back exit too.
     Starts by itself when a game runs (▶ Run, a new AI result) unless "Auto full-screen games" is off in My Projects; 🎮 Play always starts it. */
  var APK='hc_code_autoplay',playing=false,pushed=false,fsCode=$('cb-fs-code'),apBox=$('cb-autoplay');
  function autoOn(){try{return localStorage.getItem(APK)!=='0';}catch(e){return true;}}
  if(apBox){apBox.checked=autoOn();apBox.addEventListener('change',function(){try{localStorage.setItem(APK,apBox.checked?'1':'0');}catch(e){}toast(apBox.checked?'\uD83C\uDFAE Games will open full screen':'Games stay in the preview box');});}
  function isGame(c){return /addEventListener\s*\(\s*["'](key|pointer|touch|mouse)|onkey(down|up)|requestAnimationFrame|setAnimationLoop|<canvas|\bgame\b|\bscore\b|HC_STICK/i.test(c||'');}
  function focusGame(){if(!playing||!frame)return;try{frame.focus();}catch(e){}try{frame.contentWindow.focus();}catch(e){}}
  function fs(on,fromHist){on=!!on;if(on&&watch())return;
    pvBox.className=pvBox.className.replace(/\s*\bfs\b/g,'')+(on?' fs':'');fsX.hidden=!on;if(fsCode)fsCode.hidden=!on;
    R.className=R.className.replace(/\s*\bcb-fsn\b/g,'')+(on?' cb-fsn':'');
    if(on===playing)return;playing=on;
    if(on){if(!split())setTab('pv');if(!pushed&&W.history&&history.pushState){try{history.pushState({hcPlay:1},'');pushed=true;}catch(e){}}setTimeout(focusGame,60);}
    else{if(pushed&&!fromHist){pushed=false;try{history.back();}catch(e){}}pushed=false;try{fsBtn.focus();}catch(e){}}}
  function autoPlay(force){if(!force&&!autoOn())return;var c=codeOf(cur);if(!visual(cur.lang)||!trim(c))return;if(force||isGame(c))fs(true);}
  W.addEventListener('popstate',function(){if(playing)fs(false,true);});
  fsBtn.addEventListener('click',function(){if(!split())setTab('pv');if(visual(cur.lang)&&trim(codeOf(cur))&&!frame)runNow();fs(true);});
  fsX.addEventListener('click',function(){fs(false);});
  if(fsCode)fsCode.addEventListener('click',function(){fs(false);if(!split())setTab('ed');});
  D.addEventListener('keydown',function(e){if((e.keyCode===27||e.keyCode===10009||e.keyCode===461)&&/\bfs\b/.test(pvBox.className)){e.preventDefault();fs(false);}});
  copyBtn.addEventListener('click',function(){var t=ta.value;function ok(){toast('\uD83D\uDCCB Code copied!');}
    function old(){try{ta.focus();ta.select();D.execCommand('copy');ok();}catch(e){toast('Select the code and copy it by hand');}}
    if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t).then(ok,old);else old();});
  dlBtn.addEventListener('click',function(){var code=ta.value;if(!trim(code)){toast('Nothing to download yet');return;}var L=LBY[cur.lang]||LBY.web;
    var name=cur.lang==='java'?'Main':(title(cur).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,40)||'my-project');
    if(cur.lang==='3d')code=threeDl(code);
    if(visual(cur.lang))code=stickDl(code);
    try{var b=new Blob([code],{type:visual(cur.lang)?'text/html':'text/plain'}),u=URL.createObjectURL(b),a=D.createElement('a');a.href=u;a.download=name+'.'+L[2];a.rel='noopener';
      D.body.appendChild(a);a.click();setTimeout(function(){D.body.removeChild(a);URL.revokeObjectURL(u);},1500);toast('\u2B07\uFE0F Downloaded '+name+'.'+L[2]);}catch(e){toast('Download isn\u2019t supported here. Use \uD83D\uDCCB Copy instead');}});

  /* ---------- projects list (in its own drawer) ---------- */
  var editing=null;
  function openList(){return $('hc-projs')&&/\bopen\b/.test($('hc-projs').className);}
  function when(t){var d=new Date(t),n=new Date();if(d.toDateString()===n.toDateString()){var h=d.getHours(),m=d.getMinutes();return (h%12||12)+':'+(m<10?'0':'')+m+(h<12?' AM':' PM');}
    return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()]+' '+d.getDate();}
  function renderList(){var h='';
    if(!db.list.length)h='<p class="hd-empty">No projects yet. Make something and it saves by itself!</p>';
    for(var i=0;i<db.list.length;i++){var p=db.list[i],on=p.id===cur.id?' on':'',L=LBY[p.lang]||LBY.web;
      if(editing===p.id){h+='<div class="ci ed'+on+'"><input class="ci-in" type="text" maxlength="60" value="'+esc(title(p))+'" aria-label="Project name" data-id="'+p.id+'"><button type="button" class="ci-b" data-act="ok" data-id="'+p.id+'" aria-label="Save name">\u2714\uFE0F</button></div>';continue;}
      h+='<div class="ci'+on+'"><button type="button" class="ci-o" data-act="open" data-id="'+p.id+'"><span class="ci-t">'+esc(title(p))+'</span><span class="ci-w">'+esc(L[1]+' \u00B7 '+when(p.u)+' \u00B7 v'+Math.max(1,p.i+1))+'</span></button>'+
        '<button type="button" class="ci-b" data-act="ren" data-id="'+p.id+'" aria-label="Rename project">\u270F\uFE0F</button><button type="button" class="ci-b" data-act="del" data-id="'+p.id+'" aria-label="Delete project">\uD83D\uDDD1\uFE0F</button></div>';}
    listEl.innerHTML=h;
    if(editing){var inp=listEl.querySelector('.ci-in');if(inp){try{inp.focus();inp.select();}catch(e){}}}}
  function openProject(id){if(busy)return;var p=find(id);if(!p)return;commitDraft();cur=p;db.cur=p.id;saveDb(true);status('');setCode(codeOf(cur));runNow();ui();if(W.hcApp)W.hcApp.close();}
  function newProject(){if(busy)return;commitDraft();saveDb(true);cur=fresh(cur.lang);db.cur=cur.id;status('');setCode('');runNow();ui();if(W.hcApp)W.hcApp.close(true);try{input.focus();}catch(e){}}
  function finishRename(id){var inp=listEl.querySelector('.ci-in'),p=find(id);if(p&&inp){p.t=trim(inp.value).slice(0,60);saveDb(true);if(p===cur)ui();}editing=null;renderList();
    var b=listEl.querySelector('[data-act="ren"][data-id="'+id+'"]');if(b)try{b.focus();}catch(e){}}
  function delProject(id){if(busy&&id===cur.id)return;var idx=-1;for(var i=0;i<db.list.length;i++)if(db.list[i].id===id)idx=i;if(idx<0)return;
    var gone=db.list.splice(idx,1)[0],was=gone===cur;
    if(was){cur=db.list.length?db.list[0]:fresh(gone.lang);setCode(codeOf(cur));status('');runNow();}
    saveDb(true);renderList();ui();
    toast('\uD83D\uDDD1\uFE0F Project deleted',function(){db.list.push(gone);if(was){cur=gone;setCode(codeOf(cur));status('');runNow();}saveDb(true);renderList();ui();});}
  listEl.addEventListener('click',function(e){var b=e.target;while(b&&b!==listEl&&!b.getAttribute('data-act'))b=b.parentNode;if(!b||b===listEl)return;
    var a=b.getAttribute('data-act'),id=b.getAttribute('data-id');
    if(a==='open')openProject(id);else if(a==='ren'){editing=id;renderList();}else if(a==='ok')finishRename(id);else if(a==='del')delProject(id);});
  listEl.addEventListener('keydown',function(e){var t=e.target;if(t&&t.className==='ci-in'){var k=e.keyCode;if(k===13){e.preventDefault();finishRename(t.getAttribute('data-id'));}else if(k===27){e.preventDefault();if(e.stopPropagation)e.stopPropagation();editing=null;renderList();}}});
  $('cb-new2').addEventListener('click',newProject);
  titleBtn.addEventListener('click',function(){if(W.hcApp)W.hcApp.open('hc-projs',titleBtn);});

  /* ---------- mode switch: 💬 Chat | 🧑‍💻 Code (remembered) ---------- */
  var mChat=$('hc-mode-chat'),mCode=$('hc-mode-code'),started=false;
  function setMode(m,save){var code=m==='code';
    R.className=R.className.replace(/\s*\bhc-codemode\b/g,'')+(code?' hc-codemode':'');
    $('chat').hidden=code;sec.hidden=!code;
    mChat.className='hm'+(code?'':' on');mCode.className='hm'+(code?' on':'');mChat.setAttribute('aria-selected',code?'false':'true');mCode.setAttribute('aria-selected',code?'true':'false');
    if(save)try{localStorage.setItem(MODEK,m);}catch(e){}
    if(W.hcApp&&W.hcApp.close)W.hcApp.close(true);
    if(code&&!started){started=true;fillModels();setCode(codeOf(cur));runNow();ui();}
    if(code&&!split())setTab(trim(codeOf(cur))?tab:'pv');
  }
  mChat.addEventListener('click',function(){setMode('chat',true);});
  mCode.addEventListener('click',function(){setMode('code',true);});
  fillLangs();setTab('pv');
  var m0='chat';try{m0=localStorage.getItem(MODEK)||'chat';}catch(e){}
  setMode(m0==='code'?'code':'chat',false);
  W.addEventListener('resize',function(){if(!started)return;if(split())sec.className=sec.className.replace(/\s*\bcb-on-\w+\b/g,'')+' cb-on-'+tab;});
  W.hcCode={renderList:renderList,newProject:newProject,isOn:function(){return /\bhc-codemode\b/.test(R.className);},ask:ask,run:runNow};
})();
