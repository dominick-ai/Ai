/* bugcatch.js (hc v2.3) 🐛 Bug Catcher: loads first on every page. Catches errors, rejected promises, console.error, failed /api/ calls
   (5xx or network) and files that fail to load, and reports each unique bug (at most once per 10 min per device, max 20 an hour)
   to POST /api/bugs/report. NO personal data: never chat text, lyrics, codes/PINs, keys, localStorage or names; messages and
   stacks are scrubbed (hc-…, sk-…, digit runs, emails, query strings) here AND again on the server.
   Noise (browser extensions, "ResizeObserver loop", bare "Script error.", errors inside the Code-mode preview sandbox, offline)
   is only counted, never logged as a site bug.
   Self-heal: a page file that fails to load or throws while the app starts shows "🔧 Something hiccuped, tap to reload" and is
   retried once with a cache-busting query. Everything here is wrapped in try: the catcher must never cause a bug itself. ES5. */
(function(W,D){
  'use strict';
  if(W.hcBugs)return;
  var VER='?',T0=+new Date(),started=false,busy=false,forceNext=false,sentLog=[],noise={},noiseAt=0,noiseTimer=null,toastEl=null,origin='';
  try{origin=W.location.protocol+'//'+W.location.host;}catch(e){}
  try{var cs=D.currentScript&&D.currentScript.src||'';var vm=/[?&]v=([\w.\-]+)/.exec(cs);if(vm)VER=vm[1];}catch(e){}
  var LS=null;try{LS=W.localStorage;LS.setItem('hc_bug_t','1');LS.removeItem('hc_bug_t');}catch(e){LS=null;}
  var mem={};
  function lget(k){try{if(LS){var v=LS.getItem(k);return v?JSON.parse(v):null;}}catch(e){}return mem[k]||null;}
  function lset(k,v){try{if(LS){LS.setItem(k,JSON.stringify(v));return;}}catch(e){}mem[k]=v;}
  function now(){return +new Date();}
  function hash(s){var h=5381;s=String(s);for(var i=0;i<s.length;i++){h=((h<<5)+h+s.charCodeAt(i))|0;}return (h>>>0).toString(36);}
  // ---------- scrub (same rules as the server) ----------
  function scrub(s,max){
    try{s=String(s==null?'':s);
      s=s.replace(/https?:\/\/(taboai\.sites\.tab\.bot|honeycrispai\.sites\.tab\.bot|127\.0\.0\.1(:\d+)?|localhost(:\d+)?)/gi,'');
      s=s.replace(/\b(hc|sk|gsk|nvapi|csk|xai|fw|tgp|hf|pk|rk)([-_])([A-Za-z0-9_\-]{6,})/gi,function(m,a,d,t){return (/[A-Z0-9]/.test(t)||t.length>=20)?a+d+'[key]':m;});
      s=s.replace(/\bAIza[0-9A-Za-z_\-]{10,}/g,'[key]').replace(/\bBearer\s+\S+/gi,'Bearer [key]')
        .replace(/[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}/g,'[email]')
        .replace(/\b[a-f0-9]{24,}\b/gi,'[hex]').replace(/[A-Za-z0-9_\-]{40,}/g,'[long]')
        .replace(/\?([^\s#'"()]+)/g,function(m,q){if(/^v=[\w.]+(:\d+){0,2}$/.test(q))return m;var lc=/(:\d+:\d+)$/.exec(q);return '?\u2026'+(lc?lc[1]:'');})
        .replace(/\d{6,}/g,'[num]');
      return max?s.slice(0,max):s;}catch(e){return '';}
  }
  function path(u){try{u=String(u||'');if(origin&&u.indexOf(origin)===0)u=u.slice(origin.length);return u.split('#')[0].split('?')[0];}catch(e){return '';}}
  // ---------- where am I ----------
  function cls(){return ' '+(D.documentElement&&D.documentElement.className||'')+' ';}
  function mode(){try{var c=cls(),dl=D.getElementById('hcdl');
    if(dl&&!dl.hidden)return 'devlab';
    if(c.indexOf(' hcmp-open ')>=0)return 'music';
    if(c.indexOf(' hs-open ')>=0)return 'studio';
    if(c.indexOf(' tt-open ')>=0)return 'tots';
    if(c.indexOf(' ls-open ')>=0)return 'lessons';
    if(c.indexOf(' hc-codemode ')>=0)return 'code';
    return 'chat';}catch(e){return 'other';}}
  function ua(){try{var u=navigator.userAgent||'',dev='other',br='other',sa=false;
    var touchMac=/Macintosh/.test(u)&&navigator.maxTouchPoints>1;
    if(/iPad/.test(u)||touchMac)dev='iPad';else if(/iPhone|iPod/.test(u))dev='iPhone';else if(/Android/.test(u))dev='Android';else if(/Macintosh/.test(u))dev='Mac';else if(/Windows/.test(u))dev='Windows';else if(/CrOS/.test(u))dev='Chromebook';else if(/Linux/.test(u))dev='Linux';
    if(/CriOS/.test(u))br='Chrome iOS';else if(/FxiOS/.test(u))br='Firefox iOS';else if(/EdgiOS|Edg\//.test(u))br='Edge';else if(/Firefox\//.test(u))br='Firefox';else if(/Chrome\//.test(u))br='Chrome';else if(/Safari\//.test(u)||/AppleWebKit/.test(u))br='Safari';
    try{sa=!!(navigator.standalone||(W.matchMedia&&W.matchMedia('(display-mode: standalone)').matches));}catch(e){}
    return dev+' '+br+(sa?' PWA':'');}catch(e){return 'other';}}
  function vp(){try{return (W.innerWidth||0)+'x'+(W.innerHeight||0);}catch(e){return '';}}
  // ---------- noise ----------
  var EXT=/(chrome|moz|safari|safari-web|ms-browser)-extension:\/\/|webkit-masked-url:\/\/|extensions::|^resource:\/\//i;
  function addNoise(k){try{noise[k]=(noise[k]||0)+1;if(!noiseTimer)noiseTimer=setTimeout(flushNoise,Math.max(60000,600000-(now()-noiseAt)));}catch(e){}}
  function flushNoise(beacon){try{noiseTimer=null;var any=false,k;for(k in noise)if(noise.hasOwnProperty(k)&&noise[k])any=true;if(!any)return;
    var b={type:'noise',noise:noise,version:VER};noise={};noiseAt=now();post(b,beacon===true);}catch(e){}}
  function noiseKind(msg,src,stack){
    msg=String(msg||'');var all=msg+' '+(src||'')+' '+(stack||'');
    if(EXT.test(all))return 'extension';
    if(/ResizeObserver loop/i.test(msg))return 'resize_observer';
    if(/^(Uncaught )?Script error\.?$/i.test(msg)&&!src)return 'script_error';
    if(/^about:srcdoc|^blob:|^data:/i.test(String(src||'')))return 'code_preview';
    return '';
  }
  // ---------- send ----------
  function post(b,beacon){try{var s=JSON.stringify(b);if(s.length>4000)return;
      if(beacon&&navigator.sendBeacon){try{if(navigator.sendBeacon('/api/bugs/report',new Blob([s],{type:'text/plain'})))return;}catch(e){}}
      var f=W.__hcBugFetch||W.fetch;
      if(f){f.call(W,'/api/bugs/report',{method:'POST',headers:{'content-type':'application/json'},body:s,keepalive:true})['catch'](function(){});return;}
      if(navigator.sendBeacon)navigator.sendBeacon('/api/bugs/report',new Blob([s],{type:'text/plain'}));
    }catch(e){}}
  function report(type,msg,src,line,col,stack){
    if(busy)return;busy=true;
    try{
      var nk=noiseKind(msg,src,stack);if(nk){addNoise(nk);return;}
      var m=scrub(msg,300).replace(/^Uncaught\s+/,'');if(!m)return;
      var source=path(src),t=now(),h=hash(type+'|'+m+'|'+source),force=forceNext;forceNext=false;
      sentLog.push({type:type,message:m,source:source,at:t,sent:false});if(sentLog.length>30)sentLog.shift();
      var seen=lget('hc_bug_seen')||{},hr=lget('hc_bug_hr')||{s:0,n:0},slot=Math.floor(t/3600000),k;
      if(!force&&seen[h]&&t-seen[h]<600000)return; // the same bug at most once per 10 min per device
      if(hr.s!==slot)hr={s:slot,n:0};
      if(hr.n>=20)return; // max 20 reports per device per hour
      hr.n++;seen[h]=t;for(k in seen)if(seen.hasOwnProperty(k)&&t-seen[k]>600000)delete seen[k];
      lset('hc_bug_seen',seen);lset('hc_bug_hr',hr);sentLog[sentLog.length-1].sent=true;
      post({type:type,message:m,source:source,line:line||0,col:col||0,stack:scrub(stack,1200),mode:mode(),version:VER,ua:ua(),viewport:vp(),ts:t});
    }catch(e){}finally{busy=false;}
  }
  // ---------- 🔧 self-heal 2: friendly toast + one cache-busted retry ----------
  function toast(txt){try{
      if(!D.body){setTimeout(function(){toast(txt);},300);return;}
      if(!toastEl){var st=D.createElement('style');st.textContent='#hc-heal{position:fixed;left:50%;top:calc(10px + env(safe-area-inset-top,0px));transform:translateX(-50%);z-index:2147483646;max-width:calc(100vw - 24px);box-sizing:border-box;background:#fff7e6;color:#7c4a12;border:2px solid #f5c26b;border-radius:16px;padding:10px 16px;font:700 15px/1.3 -apple-system,system-ui,sans-serif;box-shadow:0 6px 20px rgba(124,74,18,.22);cursor:pointer;text-align:center;opacity:0;transition:opacity .25s}#hc-heal.on{opacity:1}#hc-heal small{display:block;font-weight:600;font-size:12px;opacity:.75;margin-top:2px}';
        (D.head||D.body).appendChild(st);
        toastEl=D.createElement('button');toastEl.type='button';toastEl.id='hc-heal';toastEl.setAttribute('role','status');
        toastEl.onclick=function(){try{var u=W.location.href.split('#')[0].replace(/([?&])hcr=\d+&?/,'$1').replace(/[?&]$/,'');W.location.replace(u+(u.indexOf('?')>=0?'&':'?')+'hcr='+now()+(W.location.hash||''));}catch(e){W.location.reload();}};
        D.body.appendChild(toastEl);setTimeout(function(){if(toastEl)toastEl.className='on';},20);}
      toastEl.innerHTML='\uD83D\uDD27 Something hiccuped, tap to reload'+(txt?'<small>'+txt+'</small>':'');
      clearTimeout(toastEl._t);toastEl._t=setTimeout(function(){try{if(toastEl&&toastEl.parentNode){toastEl.parentNode.removeChild(toastEl);}toastEl=null;}catch(e){}},15000);
    }catch(e){}}
  var healed={};
  function heal(src){try{
      var p=path(src);if(!p||!/\.js$/.test(p)||p.indexOf('/api/')===0||p==='/bugcatch.js')return;
      var key='hc_heal:'+p,ss=null;try{ss=W.sessionStorage;}catch(e){}
      var did=healed[p]||(ss&&ss.getItem(key)&&now()-(+ss.getItem(key))<600000);
      toast(did?'':'fixing it\u2026');
      if(did)return;healed[p]=1;try{if(ss)ss.setItem(key,String(now()));}catch(e){}
      var s=D.createElement('script');s.src=p+'?v='+VER+'&hcr='+now();
      s.onload=function(){try{if(toastEl){toastEl.innerHTML='\u2705 Fixed it! <small>tap to reload if something still looks off</small>';}}catch(e){}};
      (D.body||D.head).appendChild(s);
    }catch(e){}}
  function ours(src){var p=path(src);return !!p&&p.charAt(0)==='/'&&!/^\/\//.test(p)&&(String(src).indexOf('://')<0||(origin&&String(src).indexOf(origin)===0));}
  function startup(){return !started||now()-T0<4000;}
  // ---------- catch ----------
  try{W.addEventListener('error',function(e){try{
      var t=e&&e.target;
      if(t&&t!==W&&t.tagName){ // a file failed to load
        var tag=String(t.tagName).toLowerCase(),src=t.src||t.href||t.currentSrc||'';
        if(!(tag==='script'||tag==='link'||tag==='img'))return;
        if(EXT.test(src)){addNoise('extension');return;}
        if(/[?&]hcr=/.test(src)&&tag==='script'){report('resource','script failed to load again after retry: '+path(src),src,0,0,'');toast('');return;}
        report('resource',tag+' failed to load: '+(ours(src)?path(src):scrub(src,120)),src,0,0,'');
        if(tag==='script'&&ours(src)&&path(src).indexOf('/api/')!==0){if(startup())heal(src);else toast('');}
        return;
      }
      var er=e&&e.error,msg=(e&&e.message)||(er&&er.message)||'',fn=(e&&e.filename)||'';
      report(er&&er.hcTest?'test':'error',(er&&er.name&&msg.indexOf(er.name)<0?er.name+': ':'')+msg,fn,e&&e.lineno,e&&e.colno,er&&er.stack);
      if(startup()&&ours(fn)&&!noiseKind(msg,fn,er&&er.stack)&&!(er&&er.hcTest))heal(fn);
    }catch(x){}},true);}catch(e){}
  try{W.addEventListener('unhandledrejection',function(e){try{
      var r=e&&e.reason,msg=r&&(r.message||r.name)?(r.name&&r.name!=='Error'?r.name+': ':'')+(r.message||''):String(r);
      if(r&&(r.name==='AbortError'||/aborted|NotAllowedError|play\(\) request|interrupted by/i.test(msg)))return;
      if(r&&r.domoNet||navigator.onLine===false){addNoise('offline');return;}
      var st=r&&r.stack||'',m=/(https?:\/\/[^\s)]+?):(\d+):(\d+)/.exec(st);
      report(r&&r.hcTest?'test':'rejection','Unhandled promise: '+msg,m?m[1]:'',m?+m[2]:0,m?+m[3]:0,st);
    }catch(x){}});}catch(e){}
  try{var CE=W.console&&W.console.error;
    if(CE){W.console.error=function(){try{CE.apply(W.console,arguments);}catch(e){}
      try{var a=arguments[0],msg='',st='';
        if(a&&typeof a==='object'&&(a.message||a.stack)){msg=(a.name?a.name+': ':'')+a.message;st=a.stack||'';}
        else if(typeof a==='string')msg=a;else return;
        var m=/(https?:\/\/[^\s)]+?):(\d+):(\d+)/.exec(st);
        report('console','console.error: '+msg,m?m[1]:'',m?+m[2]:0,m?+m[3]:0,st);
      }catch(e){}};}}catch(e){}
  // the Code-mode preview runs in a sandboxed iframe; its errors come here as messages -> counted as "code_preview", never logged
  try{W.addEventListener('message',function(e){try{var d=e&&e.data;if(d&&d.hcc===1&&d.k==='err')addNoise('code_preview');}catch(x){}});}catch(e){}
  // failed /api/ calls: wrap fetch once every page script (incl. the body tunnel) is in, so retries inside it don't count
  function wrapFetch(){try{
      var F=W.fetch;if(!F||F._hcBug)return;W.__hcBugFetch=F;
      var X=function(input,o){
        var u='';try{u=typeof input==='string'?input:(input&&input.url)||String(input);}catch(e){}
        var p=path(u),meth=String((o&&o.method)||(input&&input.method)||'GET').toUpperCase(),api=p.indexOf('/api/')===0&&p!=='/api/bugs/report'&&(u.indexOf('://')<0||(origin&&u.indexOf(origin)===0));
        var pr=F.apply(this===W||!this?W:this,arguments);
        if(!api||!pr||!pr.then)return pr;
        return pr.then(function(r){try{if(r&&r.status>=500)report('fetch',meth+' '+p+' \u2192 '+r.status,p,0,0,'');}catch(e){}return r;},
          function(err){try{var n=String(err&&err.name||'');
            if(n==='AbortError'||/abort/i.test(String(err&&err.message)));else if(navigator.onLine===false)addNoise('offline');
            else report('fetch',meth+' '+p+' \u2192 network error',p,0,0,'');}catch(e){}throw err;});
      };
      X._hcBug=true;X._domoTun=F._domoTun;W.fetch=X;
    }catch(e){}}
  function ready(){started=true;T0=now();}
  try{if(D.readyState==='complete'){wrapFetch();ready();}else{D.addEventListener('DOMContentLoaded',wrapFetch);W.addEventListener('load',ready);}}catch(e){}
  try{W.addEventListener('pagehide',function(){try{flushNoise(true);}catch(e){}});}catch(e){}
  W.hcBugs={
    version:VER,
    log:function(){return sentLog.slice();},
    noise:function(){var o={},k;for(k in noise)if(noise.hasOwnProperty(k))o[k]=noise[k];return o;},
    mode:mode,ua:ua,scrub:scrub,
    // 🧪 Dev Lab: a harmless test error (always reported, skips the 10-min dedupe once)
    test:function(kind){forceNext=true;var e=new Error('\uD83E\uDDEA Test bug from the Dev Lab (harmless)');e.hcTest=true;
      if(kind==='rejection'){e.message='\uD83E\uDDEA Test rejected promise from the Dev Lab (harmless)';Promise.reject(e);return;}
      setTimeout(function(){throw e;},0);},
    flush:function(){flushNoise(false);}
  };
})(window,document);
