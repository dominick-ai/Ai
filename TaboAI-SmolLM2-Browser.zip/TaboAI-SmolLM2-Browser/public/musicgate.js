/* musicgate.js (hc v2.0) 🎙️ the little mic at the bottom = the door to MUSIC STUDIO PRO.
   Its own 6-digit code is checked on the server only (/api/music/check). The right code gives a 30-day signed pass kept on this device.
   The Pro studio's code is NOT in the public files: /api/music/app.js + app.css answer 403 without a valid music pass and load only after unlock. ES5. */
(function(W,D){
  'use strict';
  var KP='hc_music_pass',busy=0,loading=0,loaded=0;
  function live(t){return typeof t==='string'&&/^\d{10,13}\.[a-f0-9]{40}$/.test(t)&&+t.split('.')[0]>new Date().getTime();}
  function pass(){try{var t=W.localStorage.getItem(KP)||'';return live(t)?t:'';}catch(e){return '';}}
  function setPass(t){try{if(t)W.localStorage.setItem(KP,t);else W.localStorage.removeItem(KP);}catch(e){}}
  function post(b){return W.fetch('/api/music/check',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(b)}).then(function(r){return r.json()['catch'](function(){return {ok:false,net:1};});});}
  function el(t,c,h){var e=D.createElement(t);if(c)e.className=c;if(h!=null)e.innerHTML=h;return e;}
  function say(m){try{if(W.hcApp&&W.hcApp.toast)W.hcApp.toast(m);}catch(e){}}
  function css(){if(D.getElementById('hcmg-css'))return;var s=el('style');s.id='hcmg-css';
    s.textContent='.hcmg-fab{position:fixed;left:8px;left:calc(8px + env(safe-area-inset-left));bottom:8px;bottom:calc(8px + env(safe-area-inset-bottom));z-index:30;width:34px;height:34px;padding:0;border-radius:50%;border:1px solid #ffe5d4;background:#ffffff;box-shadow:0 2px 8px rgba(65,59,53,.18);font-size:17px;line-height:32px;text-align:center;cursor:pointer;-webkit-tap-highlight-color:transparent;font-family:inherit;opacity:.92}'+
    '.hcmg-fab:active{-webkit-transform:scale(.9);transform:scale(.9)}.hcmg-fab:focus-visible{outline:2px solid #ee7d45;outline-offset:2px}'+
    'html.hw .hcmg-fab{background:#23201d;border-color:#6f2c10;box-shadow:0 2px 10px rgba(221,94,34,.35)}'+
    'html.hcmg-on .fine{padding-left:40px}@media (min-width:900px){html.hcmg-on .fine{padding-left:0}}'+
    'html.hs-open .hcmg-fab,html.hcmp-open .hcmg-fab,html.hv-open .hcmg-fab{display:none}'+
    '.hcmg{position:fixed;top:0;left:0;right:0;bottom:0;z-index:20010;background:rgba(9,8,7,.62);display:-webkit-flex;display:flex;-webkit-align-items:center;align-items:center;-webkit-justify-content:center;justify-content:center;padding:14px}'+
    '.hcmg-b{background:#161412;color:#f5f1ee;border-radius:22px;padding:18px 18px 14px;width:100%;max-width:300px;box-shadow:0 16px 50px rgba(0,0,0,.5);text-align:center;font-family:inherit;border:1px solid #36312c}'+
    '.hcmg-b h2{margin:0 0 2px;font-size:19px}.hcmg-b p{margin:0 0 10px;font-size:13px;color:#fcc8a6}'+
    '.hcmg-dots{display:-webkit-flex;display:flex;-webkit-justify-content:center;justify-content:center;margin:6px 0 4px}.hcmg-dots i{display:block;width:14px;height:14px;border-radius:50%;margin:0 6px;border:2px solid #b8481a;-webkit-transition:background .12s;transition:background .12s}.hcmg-dots i.f{background:#f6a274}'+
    '.hcmg-e{min-height:20px;font-size:15px;font-weight:800;color:#fcc8a6;margin:2px 0 6px}'+
    '.hcmg-k{display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;-webkit-justify-content:center;justify-content:center}'+
    '.hcmg-k button{width:31%;margin:1%;height:50px;border-radius:14px;border:1px solid #36312c;background:#211e1b;color:#ffffff;font:inherit;font-size:21px;font-weight:800;cursor:pointer;-webkit-tap-highlight-color:transparent}'+
    '.hcmg-k button:active{background:#4a1e0b}.hcmg-k .x{font-size:15px;color:#fcc8a6}'+
    '.hcmg-in{position:absolute;left:-9999px;width:1px;height:1px;opacity:0}'+
    '.hcmg-shake{-webkit-animation:hcmgS .45s;animation:hcmgS .45s}@-webkit-keyframes hcmgS{0%,100%{-webkit-transform:none}20%,60%{-webkit-transform:translateX(-10px)}40%,80%{-webkit-transform:translateX(10px)}}@keyframes hcmgS{0%,100%{transform:none}20%,60%{transform:translateX(-10px)}40%,80%{transform:translateX(10px)}}'+
    'html.hw .hcmg-b{background:#171513;border-color:#6f2c10}html.hw .hcmg-dots i{border-color:#ee7d45}html.hw .hcmg-dots i.f{background:#f6a274}html.hw .hcmg-k button{background:#23201d;border-color:#6f2c10}html.hw .hcmg-k button:active{background:#933914}';
    D.getElementsByTagName('head')[0].appendChild(s);}
  function loadApp(t,cb){
    if(W.hcMusicPro){cb(true);return;}
    if(loading){return;}loading=1;
    var l=el('link');l.rel='stylesheet';l.href='/api/music/app.css?v=2.0&t='+encodeURIComponent(t);D.getElementsByTagName('head')[0].appendChild(l);
    var s=el('script');s.src='/api/music/app.js?v=2.0&t='+encodeURIComponent(t);
    s.onload=function(){loading=0;loaded=1;cb(!!W.hcMusicPro);};
    s.onerror=function(){loading=0;if(s.parentNode)s.parentNode.removeChild(s);cb(false);};
    D.body.appendChild(s);
  }
  function go(t){loadApp(t,function(ok){if(ok&&W.hcMusicPro){W.hcMusicPro.open();}else{say('\uD83C\uDFB5 Couldn\u2019t load the studio, check your wifi.');}});}
  function pad(){
    if(D.getElementById('hcmg'))return;css();
    var o=el('div','hcmg');o.id='hcmg';o.setAttribute('role','dialog');o.setAttribute('aria-modal','true');o.setAttribute('aria-label','Music Studio code');
    var keys='';for(var i=1;i<=9;i++)keys+='<button type="button" data-k="'+i+'">'+i+'</button>';
    keys+='<button type="button" class="x" data-k="x">Cancel</button><button type="button" data-k="0">0</button><button type="button" class="x" data-k="b" aria-label="Delete">\u232B</button>';
    o.innerHTML='<div class="hcmg-b"><h2>\uD83D\uDD12 Music Studio</h2><p>Enter code</p><div class="hcmg-dots" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i><i></i></div>'+
      '<div class="hcmg-e" id="hcmg-e" aria-live="polite"></div><input class="hcmg-in" id="hcmg-in" type="password" inputmode="numeric" pattern="[0-9]*" maxlength="6" autocomplete="off" aria-label="Music Studio code"><div class="hcmg-k">'+keys+'</div></div>';
    D.body.appendChild(o);
    var box=o.firstChild,dots=o.querySelectorAll('.hcmg-dots i'),er=D.getElementById('hcmg-e'),inp=D.getElementById('hcmg-in'),code='';
    function draw(){for(var i=0;i<6;i++)dots[i].className=i<code.length?'f':'';}
    function close(){if(o.parentNode)o.parentNode.removeChild(o);}
    function nope(msg){box.className='hcmg-b';void box.offsetWidth;box.className='hcmg-b hcmg-shake';er.textContent=msg||'Nope \uD83C\uDFB5';code='';inp.value='';draw();}
    function submit(){if(busy||code.length!==6)return;busy=1;er.textContent='\u2026';
      post({pin:code,remember:true}).then(function(j){busy=0;
        if(j&&j.ok&&j.token){setPass(j.token);er.textContent='\uD83C\uDFB6 Unlocked!';setTimeout(function(){close();go(j.token);},250);}
        else if(j&&j.error==='locked')nope('Too many tries, wait 10 min \u23F3');
        else nope('Nope \uD83C\uDFB5');
      },function(){busy=0;nope('No wifi? Try again');});}
    function key(k){if(k==='x'){close();return;}if(k==='b'){code=code.slice(0,-1);er.textContent='';draw();return;}
      if(code.length<6){code+=k;er.textContent='';draw();}if(code.length===6)submit();}
    o.addEventListener('click',function(e){var b=e.target;while(b&&b!==o&&!b.getAttribute('data-k'))b=b.parentNode;if(!b||b===o){if(e.target===o)close();return;}key(b.getAttribute('data-k'));});
    inp.addEventListener('input',function(){var v=(inp.value||'').replace(/\D/g,'').slice(0,6);code=v;draw();er.textContent='';if(code.length===6)submit();});
    D.addEventListener('keydown',function kd(e){if(!o.parentNode){D.removeEventListener('keydown',kd);return;}if(e.target===inp)return;
      if(/^[0-9]$/.test(e.key)){key(e.key);e.preventDefault();}else if(e.key==='Backspace'){key('b');e.preventDefault();}else if(e.key==='Escape')close();});
  }
  function open(){
    var t=pass();
    if(!t){pad();return;}
    if(W.hcMusicPro){W.hcMusicPro.open();return;}
    post({token:t}).then(function(j){if(j&&j.ok)go(t);else{setPass('');pad();}},function(){go(t);});
  }
  function fab(){
    if(D.getElementById('hcmg-fab'))return;css();
    var b=el('button','hcmg-fab','\uD83C\uDF99\uFE0F');b.type='button';b.id='hcmg-fab';b.title='Music Studio';b.setAttribute('aria-label','Music Studio (locked)');b.setAttribute('aria-haspopup','dialog');
    b.onclick=open;D.body.appendChild(b);
    if(D.documentElement.className.indexOf('hcmg-on')<0)D.documentElement.className+=' hcmg-on';
  }
  W.hcMusicGate={open:open,pad:pad,pass:pass,forget:function(){setPass('');}};
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',fab);else fab();
})(window,document);
