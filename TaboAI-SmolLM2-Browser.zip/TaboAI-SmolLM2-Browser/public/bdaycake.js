/* bdaycake.js (Tabo AI v2.7.1): Dom's Birthday cake. ES5 only, NO CSS filters.
   Only while bday.js says it's on (Nov 5 2026 America/Chicago, or ?bday=1). ?cake=1 opens it right away.
   Blow out the candles: the mic (Web Audio, loud + sustained low-frequency noise), or tap a candle, or hold "Blow",
   or Space/Enter. All out -> confetti burst, "Happy Birthday Dom!", a little synth jingle, Relight.
   Wishes stay on this device only (localStorage tabo_bday26_wishes). */
(function(){
  'use strict';
  var D=document,W=window,B=W.domoBday;
  if(!B||!B.on)return;
  var framed=false;try{framed=W.top!==W;}catch(e){framed=true;}if(framed)return;
  var N=5,KW='tabo_bday26_wishes';
  var raf=W.requestAnimationFrame||W.webkitRequestAnimationFrame||function(f){return setTimeout(f,16);};
  function $(id){return D.getElementById(id);}
  function esc(s){return String(s).replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}

  var css=
  '.bk-ov{position:fixed;left:0;top:0;right:0;bottom:0;z-index:9000;overflow-y:auto;-webkit-overflow-scrolling:touch;color:#2a1a0c;'+
    'background:#fff3df;background:-webkit-radial-gradient(50% 30%,circle,#fff8eb 0%,#ffe2b8 55%,#ffc2d6 100%);background:radial-gradient(circle at 50% 30%,#fff8eb 0%,#ffe2b8 55%,#ffc2d6 100%);'+
    'font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;-webkit-animation:bkIn .35s ease-out both;animation:bkIn .35s ease-out both}'+
  '.bk-ov[hidden]{display:none}'+
  '.bk-flags{position:absolute;left:0;right:0;top:0;height:34px;overflow:hidden;pointer-events:none;white-space:nowrap;text-align:center;line-height:0}'+
  '.bk-flag{display:inline-block;width:0;height:0;border-left:13px solid transparent;border-right:13px solid transparent;border-top:24px solid #ff4fa3;margin:0 3px;-webkit-transform-origin:50% 0;transform-origin:50% 0;-webkit-animation:bkSway 2.4s ease-in-out infinite;animation:bkSway 2.4s ease-in-out infinite}'+
  '.bk-bal{position:absolute;bottom:-90px;width:46px;height:56px;border-radius:50% 50% 48% 48%;pointer-events:none;opacity:.8;-webkit-animation:bkRise 11s linear infinite;animation:bkRise 11s linear infinite}'+
  '.bk-bal:after{content:"";position:absolute;left:50%;top:100%;width:1px;height:46px;background:rgba(90,60,40,.45)}'+
  '.bk-in{position:relative;box-sizing:border-box;max-width:620px;margin:0 auto;min-height:100%;padding:44px 16px 28px;padding-top:calc(44px + env(safe-area-inset-top));text-align:center}'+
  '.bk-x{position:absolute;right:12px;top:10px;top:calc(10px + env(safe-area-inset-top));z-index:3;width:42px;height:42px;border:0;border-radius:50%;background:#fff;color:#7c4a12;font-size:18px;font-weight:800;cursor:pointer;box-shadow:0 2px 0 #e7cfa6}'+
  '.bk-h{margin:2px 0 4px;font-size:28px;line-height:1.15;font-weight:900;color:#b45309;letter-spacing:-.3px}'+
  '.bk-sub{margin:0 0 6px;font-size:15px;color:#7c4a12;min-height:20px}'+
  '.bk-stage{position:relative;width:300px;height:330px;margin:4px auto 0}'+
  '.bk-buddy{position:absolute;left:-14px;bottom:4px;width:86px;height:110px;z-index:2;-webkit-animation:bkBounce 1.3s ease-in-out infinite;animation:bkBounce 1.3s ease-in-out infinite}'+
  '.bk-buddy img{position:absolute;left:0;bottom:0;width:86px;height:86px;border-radius:26px;box-shadow:0 3px 0 rgba(124,74,18,.25)}'+
  '.bk-hat{position:absolute;left:27px;top:-2px;width:0;height:0;border-left:15px solid transparent;border-right:15px solid transparent;border-bottom:40px solid #3aa7ff;-webkit-transform:rotate(-14deg);transform:rotate(-14deg)}'+
  '.bk-hat:before{content:"";position:absolute;left:-9px;top:14px;width:18px;height:6px;background:#ffe14a;border-radius:3px}'+
  '.bk-hat:after{content:"";position:absolute;left:-7px;top:-10px;width:14px;height:14px;border-radius:50%;background:#ff4fa3}'+
  '.bk-say{position:absolute;left:-10px;top:-8px;background:#fff;border-radius:14px;padding:6px 10px;font-size:13px;font-weight:800;color:#7c4a12;box-shadow:0 2px 0 #e7cfa6;white-space:nowrap;z-index:3}'+
  '.bk-cake{position:absolute;left:50%;bottom:0;width:230px;margin-left:-115px;height:250px}'+
  '.bk-plate{position:absolute;left:-14px;right:-14px;bottom:0;height:18px;border-radius:50%;background:#fff;box-shadow:0 3px 0 #e7cfa6}'+
  '.bk-t1{position:absolute;left:0;right:0;bottom:10px;height:92px;border-radius:14px 14px 10px 10px;background:#f59e0b;background:-webkit-linear-gradient(top,#ffb547,#e2850a);background:linear-gradient(#ffb547,#e2850a)}'+
  '.bk-t2{position:absolute;left:30px;right:30px;bottom:98px;height:70px;border-radius:12px 12px 8px 8px;background:#ff7eb8;background:-webkit-linear-gradient(top,#ff9ccb,#f0609f);background:linear-gradient(#ff9ccb,#f0609f)}'+
  '.bk-drip{position:absolute;left:-2px;right:-2px;top:-2px;height:20px;border-radius:12px 12px 0 0;background:#fff8eb}'+
  '.bk-drip i{position:absolute;top:12px;width:16px;height:18px;border-radius:0 0 9px 9px;background:#fff8eb}'+
  '.bk-spr{position:absolute;width:8px;height:3px;border-radius:2px}'+
  '.bk-cands{position:absolute;left:30px;right:30px;bottom:166px;height:84px}'+
  '.bk-c{position:absolute;bottom:0;width:30px;height:84px;margin-left:-15px;padding:0;border:0;background:transparent;cursor:pointer;-webkit-tap-highlight-color:transparent}'+
  '.bk-c:focus{outline:none}.bk-c:focus-visible .bk-wax{box-shadow:0 0 0 3px #fff,0 0 0 6px #3aa7ff}'+
  '.bk-wax{position:absolute;left:9px;bottom:0;width:12px;height:46px;border-radius:3px;background:#fff;background:-webkit-repeating-linear-gradient(135deg,#fff 0 6px,#3aa7ff 6px 10px);background:repeating-linear-gradient(-45deg,#fff 0 6px,#3aa7ff 6px 10px)}'+
  '.bk-c:nth-child(2n) .bk-wax{background:#fff;background:-webkit-repeating-linear-gradient(135deg,#fff 0 6px,#ff4fa3 6px 10px);background:repeating-linear-gradient(-45deg,#fff 0 6px,#ff4fa3 6px 10px)}'+
  '.bk-wick{position:absolute;left:14px;bottom:46px;width:2px;height:7px;background:#3b2a1a}'+
  '.bk-glow{position:absolute;left:-10px;bottom:40px;width:50px;height:50px;border-radius:50%;background:-webkit-radial-gradient(center,circle,rgba(255,214,90,.55),rgba(255,214,90,0) 70%);background:radial-gradient(circle,rgba(255,214,90,.55),rgba(255,214,90,0) 70%);-webkit-animation:bkGlow 1.1s ease-in-out infinite;animation:bkGlow 1.1s ease-in-out infinite}'+
  '.bk-fl{position:absolute;left:8px;bottom:51px;width:14px;height:24px;border-radius:50% 50% 50% 50%/60% 60% 40% 40%;background:#ffb020;background:-webkit-radial-gradient(50% 75%,circle,#fff6c4 0,#ffd23f 35%,#ff8a1f 75%);background:radial-gradient(circle at 50% 75%,#fff6c4 0,#ffd23f 35%,#ff8a1f 75%);'+
    '-webkit-transform-origin:50% 90%;transform-origin:50% 90%;-webkit-animation:bkFlick .5s ease-in-out infinite alternate;animation:bkFlick .5s ease-in-out infinite alternate}'+
  '.bk-c:nth-child(2) .bk-fl,.bk-c:nth-child(2) .bk-glow{-webkit-animation-delay:-.2s;animation-delay:-.2s}.bk-c:nth-child(3) .bk-fl{-webkit-animation-delay:-.35s;animation-delay:-.35s}.bk-c:nth-child(4) .bk-fl{-webkit-animation-delay:-.1s;animation-delay:-.1s}'+
  '.bk-c.out .bk-fl,.bk-c.out .bk-glow{display:none}'+
  '.bk-c.wob .bk-fl{-webkit-animation:bkWob .18s ease-in-out infinite alternate;animation:bkWob .18s ease-in-out infinite alternate}'+
  '.bk-smoke{position:absolute;left:9px;bottom:52px;width:12px;height:12px;border-radius:50%;background:rgba(140,140,150,.55);opacity:0;pointer-events:none}'+
  '.bk-c.out .bk-smoke{-webkit-animation:bkSmoke 1.4s ease-out forwards;animation:bkSmoke 1.4s ease-out forwards}'+
  '.bk-c.out .bk-smoke.s2{-webkit-animation-delay:.18s;animation-delay:.18s}'+
  '.bk-meter{width:220px;max-width:80%;height:10px;margin:12px auto 0;border-radius:6px;background:rgba(124,74,18,.15);overflow:hidden}'+
  '.bk-meter i{display:block;height:100%;width:0;border-radius:6px;background:#3aa7ff;-webkit-transition:width .08s linear;transition:width .08s linear}'+
  '.bk-row{display:-webkit-box;display:-webkit-flex;display:flex;-webkit-flex-wrap:wrap;flex-wrap:wrap;-webkit-box-pack:center;-webkit-justify-content:center;justify-content:center;gap:10px;margin:14px 0 4px}'+
  '.bk-b{-webkit-appearance:none;appearance:none;border:0;cursor:pointer;font-family:inherit;font-size:16px;font-weight:800;color:#2a1a0c;background:#fff;border-radius:999px;padding:12px 18px;box-shadow:0 3px 0 #e7cfa6;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;touch-action:manipulation}'+
  '.bk-b:active,.bk-b.held{-webkit-transform:translateY(2px);transform:translateY(2px);box-shadow:0 1px 0 #e7cfa6}'+
  '.bk-b.pri{background:#f59e0b;color:#fff;box-shadow:0 3px 0 #b45309}'+
  '.bk-b:focus-visible,.bk-x:focus-visible,.bk-wish textarea:focus-visible{outline:3px solid #3aa7ff;outline-offset:2px}'+
  '.bk-hint{margin:6px 0 0;font-size:13px;color:#a07a4c}'+
  '.bk-done{display:none;margin:10px 0 0}.bk-ov.alldone .bk-done{display:block}.bk-ov.alldone .bk-blowrow,.bk-ov.alldone .bk-meter{display:none}'+
  '.bk-hb{margin:0;font-size:30px;font-weight:900;color:#e0457f;-webkit-animation:bkPop .7s cubic-bezier(.2,1.6,.4,1) both;animation:bkPop .7s cubic-bezier(.2,1.6,.4,1) both}'+
  '.bk-wish{max-width:420px;margin:18px auto 0;background:rgba(255,255,255,.75);border-radius:18px;padding:12px 14px;text-align:left;box-shadow:0 2px 0 #e7cfa6}'+
  '.bk-wish h3{margin:0 0 6px;font-size:16px;color:#7c4a12}'+
  '.bk-wish textarea{box-sizing:border-box;width:100%;min-height:58px;border:1px solid #e7cfa6;border-radius:12px;padding:8px 10px;font:inherit;font-size:16px;color:#2a1a0c;background:#fff;resize:vertical}'+
  '.bk-wish .bk-b{font-size:14px;padding:9px 14px;margin-top:8px}'+
  '.bk-wl{list-style:none;margin:8px 0 0;padding:0;font-size:14px;color:#5a3a1a}.bk-wl li{padding:5px 0;border-top:1px dashed #ecd9bb;word-wrap:break-word}'+
  '.bk-fine{font-size:12px;color:#a07a4c;margin:6px 0 0}'+
  '.tbtn.bk-open{font-size:18px}'+
  '@media (max-width:420px){.bk-h{font-size:23px}.bk-stage{-webkit-transform:scale(.9);transform:scale(.9);-webkit-transform-origin:50% 100%;transform-origin:50% 100%;margin-top:-26px}.bk-in{padding-left:12px;padding-right:12px}}'+
  '@media (max-height:700px){.bk-stage{-webkit-transform:scale(.82);transform:scale(.82);-webkit-transform-origin:50% 100%;transform-origin:50% 100%;margin-top:-50px}}'+
  '@-webkit-keyframes bkIn{0%{opacity:0}100%{opacity:1}}@keyframes bkIn{0%{opacity:0}100%{opacity:1}}'+
  '@-webkit-keyframes bkFlick{0%{-webkit-transform:scale(1,1) rotate(-3deg);opacity:1}50%{-webkit-transform:scale(.9,1.12) rotate(2deg)}100%{-webkit-transform:scale(1.05,.92) rotate(4deg);opacity:.9}}'+
  '@keyframes bkFlick{0%{transform:scale(1,1) rotate(-3deg);opacity:1}50%{transform:scale(.9,1.12) rotate(2deg)}100%{transform:scale(1.05,.92) rotate(4deg);opacity:.9}}'+
  '@-webkit-keyframes bkWob{0%{-webkit-transform:skewX(-18deg) scale(.85,.8)}100%{-webkit-transform:skewX(18deg) scale(.8,.7)}}@keyframes bkWob{0%{transform:skewX(-18deg) scale(.85,.8)}100%{transform:skewX(18deg) scale(.8,.7)}}'+
  '@-webkit-keyframes bkGlow{0%,100%{opacity:.75;-webkit-transform:scale(1)}50%{opacity:1;-webkit-transform:scale(1.12)}}@keyframes bkGlow{0%,100%{opacity:.75;transform:scale(1)}50%{opacity:1;transform:scale(1.12)}}'+
  '@-webkit-keyframes bkSmoke{0%{opacity:.8;-webkit-transform:translate(0,0) scale(.6)}100%{opacity:0;-webkit-transform:translate(8px,-46px) scale(2.2)}}@keyframes bkSmoke{0%{opacity:.8;transform:translate(0,0) scale(.6)}100%{opacity:0;transform:translate(8px,-46px) scale(2.2)}}'+
  '@-webkit-keyframes bkBounce{0%,100%{-webkit-transform:translateY(0)}50%{-webkit-transform:translateY(-8px)}}@keyframes bkBounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}'+
  '@-webkit-keyframes bkSway{0%,100%{-webkit-transform:rotate(-6deg)}50%{-webkit-transform:rotate(6deg)}}@keyframes bkSway{0%,100%{transform:rotate(-6deg)}50%{transform:rotate(6deg)}}'+
  '@-webkit-keyframes bkRise{0%{-webkit-transform:translateY(0)}100%{-webkit-transform:translateY(-130vh)}}@keyframes bkRise{0%{transform:translateY(0)}100%{transform:translateY(-130vh)}}'+
  '@-webkit-keyframes bkPop{0%{-webkit-transform:scale(.5);opacity:0}100%{-webkit-transform:scale(1);opacity:1}}@keyframes bkPop{0%{transform:scale(.5);opacity:0}100%{transform:scale(1);opacity:1}}'+
  '@media (prefers-reduced-motion:reduce){.bk-bal,.bk-flag,.bk-buddy{-webkit-animation:none;animation:none}.bk-bal{display:none}}';

  var ov=null,opener=null,isOpen=false,lit=N,ac=null,mic=null,micRAF=0,holdT=0,songStop=null,lastBlow=0;
  var COLS=['#ff4fa3','#ffb020','#3fd17a','#3aa7ff','#a35cff'];

  function build(){
    var st=D.createElement('style');st.id='bk-css';st.appendChild(D.createTextNode(css));(D.head||D.documentElement).appendChild(st);
    ov=D.createElement('div');ov.className='bk-ov';ov.id='bk-ov';ov.hidden=true;
    ov.setAttribute('role','dialog');ov.setAttribute('aria-modal','true');ov.setAttribute('aria-labelledby','bk-h');
    var h='<div class="bk-flags" aria-hidden="true">',i;
    for(i=0;i<30;i++)h+='<span class="bk-flag" style="border-top-color:'+COLS[i%5]+';-webkit-animation-delay:-'+(i%7)*0.3+'s;animation-delay:-'+(i%7)*0.3+'s"></span>';
    h+='</div>';
    for(i=0;i<6;i++)h+='<span class="bk-bal" aria-hidden="true" style="left:'+(4+i*16)+'%;background:'+COLS[(i+2)%5]+';-webkit-animation-delay:-'+(i*1.9)+'s;animation-delay:-'+(i*1.9)+'s;-webkit-animation-duration:'+(10+i%3*2)+'s;animation-duration:'+(10+i%3*2)+'s"></span>';
    h+='<button type="button" class="bk-x" id="bk-x" aria-label="Close birthday screen">\u2715</button>';
    h+='<div class="bk-in"><h2 class="bk-h" id="bk-h">\uD83C\uDF82 Dom\u2019s Birthday Cake</h2>';
    h+='<p class="bk-sub" id="bk-sub" aria-live="polite">Make a wish\u2026 then blow out the candles! \uD83C\uDF2C\uFE0F</p>';
    h+='<div class="bk-stage"><div class="bk-buddy" aria-hidden="true"><span class="bk-say" id="bk-say">Make a wish!</span><span class="bk-hat"></span><img src="icon-192.png?v=2.7" alt="" width="86" height="86"></div>';
    h+='<div class="bk-cake"><div class="bk-plate"></div><div class="bk-t1"><div class="bk-drip">'+drips(8)+'</div>'+sprinkles(14,200,70)+'</div>';
    h+='<div class="bk-t2"><div class="bk-drip">'+drips(6)+'</div>'+sprinkles(9,150,50)+'</div><div class="bk-cands" id="bk-cands">';
    for(i=0;i<N;i++)h+='<button type="button" class="bk-c" data-i="'+i+'" style="left:'+(10+i*20)+'%" aria-label="Blow out candle '+(i+1)+'"><span class="bk-glow"></span><span class="bk-wax"></span><span class="bk-wick"></span><span class="bk-fl"></span><span class="bk-smoke"></span><span class="bk-smoke s2"></span></button>';
    h+='</div></div></div>';
    h+='<div class="bk-meter" aria-hidden="true"><i id="bk-lvl"></i></div>';
    h+='<div class="bk-row bk-blowrow"><button type="button" class="bk-b" id="bk-mic">\uD83C\uDFA4 Blow into the mic</button><button type="button" class="bk-b pri" id="bk-blow" aria-label="Blow (hold it down)">\uD83D\uDCA8 Blow</button></div>';
    h+='<p class="bk-hint bk-blowrow" id="bk-hint">Hold \uD83D\uDCA8 Blow, tap a candle, or press Space</p>';
    h+='<div class="bk-done"><p class="bk-hb">\uD83C\uDF89 Happy Birthday Dom!</p><div class="bk-row"><button type="button" class="bk-b pri" id="bk-relight">\uD83D\uDD6F\uFE0F Relight</button><button type="button" class="bk-b" id="bk-song">\uD83C\uDFB5 Play the song</button></div></div>';
    h+='<div class="bk-wish"><h3>\uD83D\uDC8C Leave a birthday wish</h3><label class="sr-only" for="bk-wt">Your birthday wish</label><textarea id="bk-wt" maxlength="200" placeholder="Type a wish for Dom\u2026"></textarea>';
    h+='<button type="button" class="bk-b" id="bk-wsave">\uD83D\uDC8C Save wish</button><ul class="bk-wl" id="bk-wl"></ul><p class="bk-fine">\uD83D\uDD12 Saved on this device only. Nobody else can see it.</p></div>';
    h+='</div>';
    ov.innerHTML=h;D.body.appendChild(ov);
    $('bk-x').onclick=close;
    var cs=ov.querySelectorAll('.bk-c');for(i=0;i<cs.length;i++)cs[i].onclick=function(){out(this);};
    $('bk-mic').onclick=startMic;
    $('bk-relight').onclick=relight;
    $('bk-song').onclick=song;
    $('bk-wsave').onclick=saveWish;
    var bb=$('bk-blow');
    function down(e){if(e&&e.type==='touchstart')e.preventDefault();bb.className='bk-b pri held';blowOne();clearInterval(holdT);holdT=setInterval(blowOne,380);}
    function up(){bb.className='bk-b pri';clearInterval(holdT);holdT=0;}
    bb.addEventListener('touchstart',down,false);bb.addEventListener('touchend',up,false);bb.addEventListener('touchcancel',up,false);
    bb.addEventListener('mousedown',down,false);bb.addEventListener('mouseup',up,false);bb.addEventListener('mouseleave',up,false);
    bb.addEventListener('click',function(e){if(e.detail===0)blowOne();},false); /* keyboard Enter/Space on the button */
    D.addEventListener('keydown',onKey,true);
    renderWishes();
    /* a 🎂 button in the top bar too, so the cake is there even after the banner's x */
    var acts=D.querySelector('header.top .acts');
    if(acts){var b=D.createElement('button');b.type='button';b.className='tbtn ib bk-open';b.id='bk-open';b.setAttribute('aria-label','Dom\u2019s birthday cake');b.innerHTML='\uD83C\uDF82';b.onclick=function(){open(b);};acts.insertBefore(b,acts.firstChild);}
    if(/[?&]cake=1(&|$)/.test(location.search))setTimeout(function(){open(null);},1300);
  }
  function drips(n){var s='';for(var i=0;i<n;i++)s+='<i style="left:'+(4+i*(92/n))+'%;height:'+(10+(i*7)%14)+'px"></i>';return s;}
  function sprinkles(n,w,hh){var s='';for(var i=0;i<n;i++)s+='<span class="bk-spr" style="left:'+(8+((i*37)%84))+'%;top:'+(26+((i*23)%Math.max(1,hh-36)))+'px;background:'+COLS[i%5]+';-webkit-transform:rotate('+(i*47%180)+'deg);transform:rotate('+(i*47%180)+'deg)"></span>';return s;}

  function focusables(){var q=ov.querySelectorAll('button,textarea,a[href],input'),o=[];for(var i=0;i<q.length;i++){var e=q[i];if(e.disabled)continue;if(!(e.offsetWidth||e.offsetHeight))continue;o.push(e);}return o;}
  function onKey(e){if(!isOpen)return;var k=e.key||'',kc=e.keyCode;
    if(k==='Escape'||k==='Esc'||kc===27){e.preventDefault();e.stopPropagation();close();return;}
    if(k==='Tab'||kc===9){var f=focusables();if(!f.length)return;var a=D.activeElement,i=f.indexOf(a);
      if(e.shiftKey){if(i<=0){e.preventDefault();f[f.length-1].focus();}}else{if(i<0||i===f.length-1){e.preventDefault();f[0].focus();}}return;}
    var t=e.target,tg=t&&t.tagName;
    if((k===' '||k==='Spacebar'||k==='Enter'||kc===32||kc===13)&&!(tg==='BUTTON'||tg==='TEXTAREA'||tg==='INPUT'||tg==='A')){
      e.preventDefault();e.stopPropagation();if(lit===0){if(k==='Enter'||kc===13)relight();return;}blowOne();}}

  function say(s){var b=$('bk-say');if(b)b.textContent=s;}
  function sub(s){var b=$('bk-sub');if(b)b.textContent=s;}
  function out(btn){if(!btn||btn.className.indexOf(' out')>=0)return false;btn.className='bk-c out';btn.setAttribute('aria-label','Candle '+(+btn.getAttribute('data-i')+1)+' is out');lit--;
    puff();
    if(lit>0){sub(lit===1?'1 candle left! \uD83D\uDD25':lit+' candles left! \uD83D\uDD25');say(lit>2?'Keep going!':'Almost!');}
    else allOut();return true;}
  function blowOne(){var t=Date.now();if(t-lastBlow<200)return;lastBlow=t;var cs=ov.querySelectorAll('.bk-c'),lst=[];for(var i=0;i<cs.length;i++)if(cs[i].className.indexOf(' out')<0)lst.push(cs[i]);
    if(!lst.length)return;out(lst[Math.floor(Math.random()*lst.length)]);}
  function wobble(on){var cs=ov.querySelectorAll('.bk-c');for(var i=0;i<cs.length;i++){if(cs[i].className.indexOf(' out')>=0)continue;cs[i].className=on?'bk-c wob':'bk-c';}}
  function allOut(){wobble(false);stopMic();clearInterval(holdT);ov.className='bk-ov alldone';sub('You did it! Your wish is on its way \u2728');say('Yay!! \uD83C\uDF89');
    var r=$('bk-cands').getBoundingClientRect();
    B.confetti({burst:true,n:160,ms:3800,balloons:5,x:r.left+r.width/2,y:r.top+20});
    setTimeout(song,350);
    setTimeout(function(){var b=$('bk-relight'),a=D.activeElement;if(!b||!isOpen)return;if(!a||a===D.body||!ov.contains(a)||a.id==='bk-blow'||a.id==='bk-mic'||(a.className&&String(a.className).indexOf('bk-c')===0))try{b.focus();}catch(e){}},60);}
  function relight(){if(songStop)songStop();var cs=ov.querySelectorAll('.bk-c');for(var i=0;i<cs.length;i++){cs[i].className='bk-c';cs[i].setAttribute('aria-label','Blow out candle '+(i+1));}
    lit=N;ov.className='bk-ov';sub('Candles are lit again! Make another wish \uD83C\uDF2C\uFE0F');say('Make a wish!');var b=$('bk-blow');if(b)try{b.focus();}catch(e){}}

  /* ---------- sound ---------- */
  function ctx(){if(!ac){var A=W.AudioContext||W.webkitAudioContext;if(!A)return null;try{ac=new A();}catch(e){return null;}}if(ac.state==='suspended'&&ac.resume){try{ac.resume();}catch(e){}}return ac;}
  function puff(){var c=ctx();if(!c)return;try{var n=Math.floor(c.sampleRate*0.25),buf=c.createBuffer(1,n,c.sampleRate),d=buf.getChannelData(0);for(var i=0;i<n;i++)d[i]=(Math.random()*2-1)*(1-i/n);
    var s=c.createBufferSource();s.buffer=buf;var f=c.createBiquadFilter();f.type='lowpass';f.frequency.value=900;var g=c.createGain();g.gain.value=0.18;s.connect(f);f.connect(g);g.connect(c.destination);s.start();}catch(e){}}
  /* Happy Birthday (traditional, public domain) as an original little synth arrangement */
  var MEL=[[67,.75],[67,.25],[69,1],[67,1],[72,1],[71,2],[67,.75],[67,.25],[69,1],[67,1],[74,1],[72,2],[67,.75],[67,.25],[79,1],[76,1],[72,1],[71,1],[69,2],[77,.75],[77,.25],[76,1],[72,1],[74,1],[72,3]];
  var BAS=[[48,3],[55,3],[55,3],[48,3],[48,3],[53,3],[48,3],[55,3],[48,3]];
  function hz(m){return 440*Math.pow(2,(m-69)/12);}
  function song(){var c=ctx();if(!c)return;if(songStop)songStop();var bt=0.36,t0=c.currentTime+0.08,t=t0,nodes=[],i;
    var master=c.createGain();master.gain.value=0.22;master.connect(c.destination);
    function note(m,st,du,type,vol){var o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.value=hz(m);g.gain.setValueAtTime(0.0001,st);g.gain.exponentialRampToValueAtTime(vol,st+0.02);g.gain.exponentialRampToValueAtTime(0.0001,st+Math.max(0.12,du*0.95));o.connect(g);g.connect(master);o.start(st);o.stop(st+du+0.05);nodes.push(o);}
    for(i=0;i<MEL.length;i++){var du=MEL[i][1]*bt;note(MEL[i][0],t,du,'triangle',0.9);note(MEL[i][0]+12,t,du*0.6,'square',0.06);t+=du;}
    var tb=t0+bt;for(i=0;i<BAS.length;i++){var d2=BAS[i][1]*bt;note(BAS[i][0],tb,d2*0.9,'sine',0.5);note(BAS[i][0]+7,tb+bt,bt*0.8,'triangle',0.12);note(BAS[i][0]+12,tb+2*bt,bt*0.8,'triangle',0.12);tb+=d2;}
    /* sparkle at the end */
    for(i=0;i<6;i++)note(84+[0,4,7,12,7,16][i],t+0.05+i*0.07,0.18,'sine',0.25);
    songStop=function(){for(var j=0;j<nodes.length;j++){try{nodes[j].stop();}catch(e){}}try{master.disconnect();}catch(e){}songStop=null;};}

  /* ---------- mic: a blow = loud, sustained, low-frequency noise ---------- */
  function micMsg(s){var h=$('bk-hint');if(h)h.textContent=s;}
  function startMic(){var c=ctx();var md=W.navigator&&navigator.mediaDevices;
    if(mic){stopMic();micMsg('Mic off. Hold \uD83D\uDCA8 Blow, tap a candle, or press Space');return;}
    if(!c||!md||!md.getUserMedia){micMsg('No mic here \uD83D\uDE45 Hold \uD83D\uDCA8 Blow or tap the candles instead!');return;}
    micMsg('Asking for the mic\u2026');
    var p;try{p=md.getUserMedia({audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}});}catch(e){p=null;}
    if(!p||!p.then){micMsg('Mic didn\u2019t work. Hold \uD83D\uDCA8 Blow or tap the candles!');return;}
    p.then(function(stream){if(!isOpen||lit===0){stream.getTracks().forEach(function(t){t.stop();});return;}
      var src=c.createMediaStreamSource(stream),an=c.createAnalyser();an.fftSize=1024;an.smoothingTimeConstant=0.3;src.connect(an);
      mic={s:stream,src:src,an:an,data:new Uint8Array(an.frequencyBinCount),floor:-1,cal:0,hot:0,last:0};
      $('bk-mic').textContent='\uD83C\uDFA4 Mic on (tap to stop)';micMsg('Mic is on! Blow hard at the screen \uD83C\uDF2C\uFE0F');loop();
    },function(){micMsg('Mic is off (that\u2019s ok!). Hold \uD83D\uDCA8 Blow or tap the candles');});}
  function loop(){if(!mic)return;var an=mic.an,d=mic.data;an.getByteFrequencyData(d);
    var bin=(ac.sampleRate||48000)/an.fftSize,lo=Math.max(1,Math.round(500/bin)),hiA=Math.round(1500/bin),hiB=Math.min(d.length-1,Math.round(5000/bin)),sl=0,sh=0,i;
    for(i=1;i<=lo;i++)sl+=d[i];sl/=lo;for(i=hiA;i<=hiB;i++)sh+=d[i];sh/=Math.max(1,hiB-hiA+1);
    if(mic.cal<25){mic.cal++;mic.floor=mic.floor<0?sl:Math.max(mic.floor,sl);}
    var thr=Math.max(150,(mic.floor<0?0:mic.floor)+45),lvl=Math.min(1,sl/Math.max(thr,1));
    var m=$('bk-lvl');if(m)m.style.width=Math.round(lvl*100)+'%';
    var t=Date.now();
    if(mic.cal>=25&&sl>=thr&&sh>=40){if(!mic.hot)mic.hot=t;wobble(true);
      if(t-mic.hot>=260&&t-mic.last>=320){mic.last=t;blowOne();}}
    else{if(mic.hot)wobble(false);mic.hot=0;}
    micRAF=raf(loop);}
  function stopMic(){if(!mic)return;try{mic.s.getTracks().forEach(function(t){t.stop();});mic.src.disconnect();}catch(e){}mic=null;var b=$('bk-mic');if(b)b.textContent='\uD83C\uDFA4 Blow into the mic';var m=$('bk-lvl');if(m)m.style.width='0';}

  /* ---------- wishes: this device only ---------- */
  function wishes(){try{var a=JSON.parse(localStorage.getItem(KW)||'[]');return a&&a.length!=null?a:[];}catch(e){return [];}}
  function renderWishes(){var a=wishes(),h='';for(var i=a.length-1;i>=0&&i>=a.length-10;i--)h+='<li>\uD83D\uDC8C '+esc(a[i].t)+'</li>';$('bk-wl').innerHTML=h;}
  function saveWish(){var ta=$('bk-wt'),v=(ta.value||'').replace(/^\s+|\s+$/g,'');if(!v){ta.focus();return;}var a=wishes();a.push({t:v.slice(0,200),at:Date.now()});if(a.length>30)a=a.slice(-30);try{localStorage.setItem(KW,JSON.stringify(a));}catch(e){}ta.value='';renderWishes();sub('Wish saved \uD83D\uDC8C');}

  function open(from){if(!ov)return;opener=from||D.activeElement;isOpen=true;ov.hidden=false;ov.scrollTop=0;try{$('bk-blow').focus();}catch(e){}
    B.confetti({n:60,ms:2500,balloons:3});}
  function close(){if(!isOpen)return;isOpen=false;stopMic();clearInterval(holdT);if(songStop)songStop();ov.hidden=true;
    var o=opener;opener=null;if(o&&o.focus&&D.body.contains(o)&&(o.offsetWidth||o.offsetHeight)){try{o.focus();}catch(e){}}}
  W.taboCake={open:open,close:close,blow:blowOne,relight:relight,lit:function(){return lit;},isOpen:function(){return isOpen;}};
  if(D.readyState==='loading')D.addEventListener('DOMContentLoaded',build);else build();
})();
